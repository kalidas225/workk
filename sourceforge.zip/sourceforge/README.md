# sourceforge

A self-hosted clone of [start.spring.io](https://start.spring.io) — generates ready-to-run **Spring Boot** *or* **Python** project zips. Frontend in **Angular 18**, backend in **Java 21 + Spring Boot 3.3.5**.

The generator service itself runs on Java 21, but the *generated* projects can target Java 8/11/17/21/22/23 or Python 3.10/3.11/3.12/3.13.

---

## Features

- **Language**: Java or Python (selectable at the top — UI reshapes accordingly)
- **Java build tools**: Maven, Gradle (Groovy), Gradle (Kotlin)
- **Python build tools**: Poetry (`pyproject.toml`) or pip (`requirements.txt` + `setup.py`)
- **Cross-field validation**: Python projects must use Poetry or pip; Java projects must use Maven or Gradle. Spring Boot row is hidden when Python is selected.
- **50+ starter packages** — Java starters (Spring Web, Data JPA, Security, Kafka, …) and Python packages (FastAPI, SQLAlchemy, Pydantic, pytest, ruff, …) grouped by category.
- **Database configuration** — choose H2, PostgreSQL, MySQL, Oracle, or SQL Server. JDBC driver auto-added (Java) or matching Python package (psycopg2-binary, pymysql, …). Connection URL / username / password / `ddl-auto` flow into the generated `application.properties`. Hibernate dialect set automatically when Spring Data JPA is selected. H2 console enabled when H2 is picked.
- **Environments (Java)** — opt in to generate `bootstrap.yaml` plus per-profile `bootstrap-{dev,ist,uat,ppd,prod}.yaml` files with environment-specific log levels, actuator exposure, and Spring Cloud Config Server settings.
- **DMZR section** — opt in to bundle **HashiCorp Vault policies** (HCL per environment, KV secret stubs, Kubernetes auth setup) and/or a **Helm chart** with vault-agent injector annotations, deployment/service/serviceaccount templates, and per-environment `values-*.yaml` overrides.
- **OS-aware shortcuts** — `⌘ B` / `⌘ ↵` shown on macOS, `Ctrl B` / `Ctrl ↵` on Windows and Linux. Detected at runtime from `navigator.platform` / `userAgent`.
- **BNP Paribas** branding in the header nav.
- **Smart Lombok handling** — emitted as `provided` + `optional`, excluded from Spring Boot Maven plugin repackage.
- **Searchable dependency picker** with keyboard navigation (↑/↓/Enter/Esc).

---

## Project structure

```
sourceforge/
├── backend/                          # Spring Boot 3.3.5 on Java 21
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/sourceforge/starter/
│       │   ├── SourceforgeApplication.java
│       │   ├── config/CorsConfig.java
│       │   ├── controller/
│       │   │   ├── MetadataController.java     (GET /api/metadata)
│       │   │   └── GeneratorController.java    (POST /api/generate)
│       │   ├── exception/
│       │   ├── model/
│       │   │   ├── ProjectRequest.java         (with database, environments, dmzr fields)
│       │   │   ├── DatabaseConfig.java
│       │   │   ├── EnvironmentConfig.java
│       │   │   ├── DmzrConfig.java
│       │   │   ├── LanguageMetadata.java
│       │   │   └── MetadataResponse.java
│       │   └── service/
│       │       ├── DependencyCatalogService.java   (Java + Python catalogs)
│       │       ├── MetadataService.java
│       │       ├── ProjectGeneratorService.java    (dispatch by language)
│       │       ├── PomBuilder.java                 (Maven pom.xml)
│       │       ├── GradleBuilder.java              (Gradle Groovy + Kotlin)
│       │       ├── PythonBuilder.java              (pyproject.toml + requirements.txt + main.py)
│       │       ├── SourceTemplateService.java     (Java main, tests, application.properties)
│       │       ├── BootstrapYamlBuilder.java       (bootstrap-{env}.yaml)
│       │       └── DmzrBuilder.java                (Vault HCL + Helm chart)
│       └── main/resources/application.properties
│
└── frontend/                         # Angular 18 (standalone components, signals)
    ├── package.json
    ├── angular.json
    ├── proxy.conf.json
    └── src/
        ├── index.html
        ├── styles.scss
        ├── main.ts
        └── app/
            ├── app.config.ts
            ├── app.component.{ts,html,scss}
            ├── models/metadata.model.ts
            └── services/starter-api.service.ts
```

---

## Running it

### Prerequisites
- **Java 21+** (Temurin / Oracle / Corretto / Liberica)
- **Maven 3.6+** (or use IntelliJ's bundled Maven)
- **Node 18+** and **npm**
- Internet access for first-run dependency downloads

### Backend — IntelliJ
1. Open the `backend` folder as a Maven project.
2. **Verify Project SDK = JDK 21** — `File → Project Structure → Project → SDK = 21`.
3. **Verify module language level = 21** — `File → Project Structure → Modules → sourceforge-backend → Language level = 21`.
4. Refresh Maven (right sidebar → refresh icon).
5. Right-click `SourceforgeApplication.java` → `Run`.

Or from the command line:

```bash
cd backend
mvn clean install
mvn spring-boot:run
```

The app listens on **http://localhost:8080**.

### Frontend

```bash
cd frontend
npm install     # first time only
npm start       # ng serve on :4200, proxying /api to backend on :8080
```

Open **http://localhost:4200**.

For production:

```bash
npm run build
# static files in dist/sourceforge-frontend
```

---

## Generated project examples

### Java + PostgreSQL + bootstrap files + DMZR

POST body:
```json
{
  "type": "maven", "language": "java", "bootVersion": "3.3.5",
  "groupId": "com.example", "artifactId": "shop", "name": "shop",
  "description": "Shop API", "packageName": "com.example.shop",
  "packaging": "jar", "javaVersion": "21",
  "dependencies": ["web", "data-jpa"],
  "database": { "type": "postgresql", "url": "", "username": "postgres", "password": "secret", "ddlAuto": "update" },
  "environments": {
    "enabled": true,
    "environments": ["dev", "ist", "prod"],
    "configServerUrl": "https://config.example.com",
    "configServerProfile": "dev"
  },
  "dmzr": {
    "enabled": true, "vaultPolicies": true, "helmChart": true,
    "vaultRole": "shop", "vaultSecretPath": "secret/data/shop",
    "kubernetesNamespace": "shop-prod",
    "dockerImage": "registry.example.com/shop:1.0",
    "environments": ["dev", "prod"]
  }
}
```

Produces:
```
shop/
├── pom.xml
├── src/main/java/com/example/shop/ShopApplication.java
├── src/main/resources/
│   ├── application.properties        (datasource block + JPA + dialect)
│   ├── bootstrap.yaml
│   ├── bootstrap-dev.yaml
│   ├── bootstrap-ist.yaml
│   └── bootstrap-prod.yaml
├── dmzr/
│   ├── vault/
│   │   ├── kubernetes-auth.md
│   │   ├── policies/shop-dev.hcl
│   │   ├── policies/shop-prod.hcl
│   │   ├── secrets/dev.yaml
│   │   └── secrets/prod.yaml
│   └── helm/
│       ├── chart/Chart.yaml
│       ├── chart/values.yaml
│       ├── chart/templates/deployment.yaml   (with vault-agent annotations)
│       ├── chart/templates/service.yaml
│       ├── chart/templates/serviceaccount.yaml
│       ├── values-dev.yaml
│       └── values-prod.yaml
└── README.md
```

### Python + FastAPI + PostgreSQL

POST body:
```json
{
  "type": "poetry", "language": "python", "bootVersion": "",
  "groupId": "com.example", "artifactId": "svc", "name": "svc",
  "description": "Python service", "packageName": "com.example.svc",
  "packaging": "wheel", "javaVersion": "3.12",
  "dependencies": ["fastapi", "uvicorn", "pydantic", "py-pytest"],
  "database": { "type": "postgresql", "url": "", "username": "u", "password": "p", "ddlAuto": "update" },
  "environments": { "enabled": false, "environments": [], "configServerUrl": "", "configServerProfile": "" },
  "dmzr": { "enabled": false, "vaultPolicies": false, "helmChart": false, "vaultRole": "", "vaultSecretPath": "", "kubernetesNamespace": "default", "dockerImage": "", "environments": [] }
}
```

Produces:
```
svc/
├── pyproject.toml         (fastapi, uvicorn, pydantic, psycopg2-binary auto-added)
├── src/com_example_svc/
│   ├── __init__.py
│   └── main.py            (FastAPI app with /, /healthz)
├── tests/
│   ├── __init__.py
│   └── test_smoke.py      (TestClient smoke test)
├── .gitignore
└── README.md
```

---

## Validation rules

The backend rejects mismatched combos with a clear `400 Bad Request`:
- `python + maven|gradle-*` → "Python projects require build type poetry or pip"
- `java + poetry|pip` → "Java projects require build type maven, gradle-groovy or gradle-kotlin"
- `python + jar|war` → "Python projects require packaging wheel or sdist"
- `java + wheel|sdist` → "Java projects require packaging jar or war"
- `environments.enabled = true + language != java` → "Environment configs (bootstrap-*.yaml) are only supported for Java projects"

The frontend prevents most of these by reshaping the UI based on the selected language.

---

## API endpoints

| Method | Path | Description |
| ------ | ---- | ----------- |
| `GET`  | `/api/metadata` | Returns languages + per-language metadata bundles + environment list |
| `POST` | `/api/generate` | Body: `ProjectRequest` JSON. Returns project as `application/zip`. |

---

## Troubleshooting

**IntelliJ shows compile errors on backend:**
The cause is almost always the IntelliJ Project SDK or module language level being set below 21.
1. `File → Project Structure → Project → SDK = 21`
2. `Modules → sourceforge-backend → Language level = 21`
3. `Build → Rebuild Project`

**`mvn` fails with "release version 21 not supported":**
Your `JAVA_HOME` points to an older JDK. Install JDK 21 and update `JAVA_HOME`, or in IntelliJ set `Settings → Build, Execution → Build Tools → Maven → Runner → JRE` to a JDK 21.

**Frontend can't reach backend:**
Edit `frontend/proxy.conf.json` if backend isn't on `localhost:8080`.

---

## License

MIT.
