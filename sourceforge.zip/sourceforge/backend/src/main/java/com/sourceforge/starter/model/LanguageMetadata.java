package com.sourceforge.starter.model;

import java.util.List;

/**
 * Bundle of metadata for a single language (java, python, ...).
 * The frontend reads the active language's bundle to drive the UI.
 */
public record LanguageMetadata(
        String id,                              // "java" or "python"
        String label,                           // "Java" / "Python"
        List<String> buildTypes,                // e.g. ["maven","gradle-groovy","gradle-kotlin"] or ["poetry","pip"]
        List<String> runtimeVersions,           // Java: ["21","17",..]  Python: ["3.13","3.12",..]
        List<String> packagings,                // Java: ["jar","war"]   Python: ["wheel","sdist"]
        List<String> frameworkVersions,         // Java: Spring Boot versions  Python: empty
        ProjectDefaults defaults,
        List<DependencyCategory> dependencies
) {
}
