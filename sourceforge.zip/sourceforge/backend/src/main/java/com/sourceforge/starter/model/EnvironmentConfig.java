package com.sourceforge.starter.model;

import java.util.List;

/**
 * Configures generation of bootstrap-{env}.yaml files for Java projects.
 * Only emitted when enabled is true and language is java.
 */
public record EnvironmentConfig(
        boolean enabled,
        List<String> environments,         // subset of: dev, ist, uat, ppd, prod
        String configServerUrl,            // optional Spring Cloud Config Server URL
        String configServerProfile         // optional default profile
) {
    public static final List<String> ALLOWED = List.of("dev", "ist", "uat", "ppd", "prod");

    public EnvironmentConfig {
        if (environments == null) environments = List.of();
        if (configServerUrl == null) configServerUrl = "";
        if (configServerProfile == null) configServerProfile = "";
        // Defensive: only keep known environment ids
        environments = environments.stream().filter(ALLOWED::contains).toList();
    }

    public static EnvironmentConfig disabled() {
        return new EnvironmentConfig(false, List.of(), "", "");
    }
}
