package com.sourceforge.starter.service;

import com.sourceforge.starter.exception.GenerationException;
import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Assembles the project as a ZIP in memory.
 * Dispatches Java vs Python builders, applies validation rules, and stitches in
 * bootstrap YAML files (Java only) and DMZR Vault / Helm assets when requested.
 */
@Service
public class ProjectGeneratorService {

    private static final Logger log = LoggerFactory.getLogger(ProjectGeneratorService.class);

    private final DependencyCatalogService catalog;
    private final PomBuilder pomBuilder;
    private final GradleBuilder gradleBuilder;
    private final PythonBuilder pythonBuilder;
    private final SourceTemplateService templates;
    private final BootstrapYamlBuilder bootstrapBuilder;
    private final DmzrBuilder dmzrBuilder;
    private final ArchitectureTemplateService architecture;

    public ProjectGeneratorService(DependencyCatalogService catalog,
                                   PomBuilder pomBuilder,
                                   GradleBuilder gradleBuilder,
                                   PythonBuilder pythonBuilder,
                                   SourceTemplateService templates,
                                   BootstrapYamlBuilder bootstrapBuilder,
                                   DmzrBuilder dmzrBuilder,
                                   ArchitectureTemplateService architecture) {
        this.catalog = catalog;
        this.pomBuilder = pomBuilder;
        this.gradleBuilder = gradleBuilder;
        this.pythonBuilder = pythonBuilder;
        this.templates = templates;
        this.bootstrapBuilder = bootstrapBuilder;
        this.dmzrBuilder = dmzrBuilder;
        this.architecture = architecture;
    }

    public byte[] generate(ProjectRequest request) {
        validateLanguageBuildCombo(request);
        log.debug("validation OK  artifact={}  lang={}  build={}", request.artifactId(), request.language(), request.type());

        List<Dependency> resolved = resolveAndValidate(request);
        log.info("resolved {} dependencies for {} (requested {})", resolved.size(), request.artifactId(), request.dependencies().size());

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ZipOutputStream zip = new ZipOutputStream(baos)) {

            String root = request.artifactId() + "/";

            if (request.isPython()) {
                writePythonProject(zip, root, request, resolved);
                log.info("python project written  artifact={}  build={}", request.artifactId(), request.type());
            } else {
                writeJavaProject(zip, root, request, resolved);
                log.info("java project written  artifact={}  build={}  boot={}", request.artifactId(), request.type(), request.bootVersion());
            }

            if (request.environments().enabled() && !request.environments().environments().isEmpty()) {
                log.info("bootstrap yamls written  artifact={}  profiles={}",
                        request.artifactId(), request.environments().environments());
            }

            if (request.dmzr().enabled()) {
                writeDmzrAssets(zip, root, request);
                log.info("DMZR assets written  artifact={}  vault={}  helm={}  envs={}",
                        request.artifactId(),
                        request.dmzr().vaultPolicies(),
                        request.dmzr().helmChart(),
                        request.dmzr().environments().isEmpty() ? EnvironmentConfig.ALLOWED : request.dmzr().environments());
            }

            writeEntry(zip, root + "HELP.md", buildHelp(request, resolved));

            zip.finish();
            return baos.toByteArray();
        } catch (IOException e) {
            log.error("zip generation failed for artifact={}: {}", request.artifactId(), e.getMessage());
            throw new GenerationException("Failed to generate project zip: " + e.getMessage(), e);
        }
    }

    /** Cross-field validation rules between language and build type. */
    private void validateLanguageBuildCombo(ProjectRequest request) {
        String lang = request.language();
        String type = request.type();
        String pkg  = request.packaging();
        if ("java".equals(lang)) {
            if (!List.of("maven", "gradle-groovy", "gradle-kotlin").contains(type)) {
                log.warn("rejected request  artifact={}  reason=invalid build type for java: {}", request.artifactId(), type);
                throw new GenerationException("Java projects require build type maven, gradle-groovy or gradle-kotlin (got '" + type + "')");
            }
            if (!List.of("jar", "war").contains(pkg)) {
                log.warn("rejected request  artifact={}  reason=invalid packaging for java: {}", request.artifactId(), pkg);
                throw new GenerationException("Java projects require packaging jar or war (got '" + pkg + "')");
            }
            if (request.bootVersion() == null || request.bootVersion().isBlank()) {
                log.warn("rejected request  artifact={}  reason=missing Spring Boot version", request.artifactId());
                throw new GenerationException("Java projects require a Spring Boot version");
            }
        } else if ("python".equals(lang)) {
            if (!List.of("poetry", "pip").contains(type)) {
                log.warn("rejected request  artifact={}  reason=invalid build type for python: {}", request.artifactId(), type);
                throw new GenerationException("Python projects require build type poetry or pip (got '" + type + "')");
            }
            if (!List.of("wheel", "sdist").contains(pkg)) {
                log.warn("rejected request  artifact={}  reason=invalid packaging for python: {}", request.artifactId(), pkg);
                throw new GenerationException("Python projects require packaging wheel or sdist (got '" + pkg + "')");
            }
        }
        if (request.environments().enabled() && !"java".equals(lang)) {
            log.warn("rejected request  artifact={}  reason=environments only supported for java", request.artifactId());
            throw new GenerationException("Environment configs (bootstrap-*.yaml) are only supported for Java projects");
        }
    }

    private void writeJavaProject(ZipOutputStream zip, String root, ProjectRequest request, List<Dependency> resolved) throws IOException {
        String packagePath = request.packageName().replace('.', '/');
        String mainSrc = root + "src/main/java/" + packagePath + "/";
        String testSrc = root + "src/test/java/" + packagePath + "/";
        String resourcesDir = root + "src/main/resources/";

        if ("maven".equals(request.type())) {
            writeEntry(zip, root + "pom.xml", pomBuilder.build(request, resolved));
            writeWrapperEntries(zip, root, true);
        } else if ("gradle-kotlin".equals(request.type())) {
            writeEntry(zip, root + "build.gradle.kts", gradleBuilder.buildKotlin(request, resolved));
            writeEntry(zip, root + "settings.gradle.kts", gradleBuilder.settingsKotlin(request));
            writeWrapperEntries(zip, root, false);
        } else {
            writeEntry(zip, root + "build.gradle", gradleBuilder.buildGroovy(request, resolved));
            writeEntry(zip, root + "settings.gradle", gradleBuilder.settingsGroovy(request));
            writeWrapperEntries(zip, root, false);
        }

        writeEntry(zip, mainSrc + templates.mainClassName(request) + ".java", templates.mainClass(request));
        writeEntry(zip, testSrc + templates.testClassName(request) + ".java", templates.testClass(request));

        // Architecture-specific source files (MVC layered or microservice)
        var archFiles = architecture.javaSources(request);
        for (var f : archFiles) {
            writeEntry(zip, mainSrc + f.relativePath(), f.content());
        }
        if (!archFiles.isEmpty()) {
            log.info("architecture sources written  artifact={}  architecture={}  files={}",
                    request.artifactId(), request.architecture(), archFiles.size());
        }

        String appProps = templates.applicationProperties(request) + architecture.extraProperties(request);
        writeEntry(zip, resourcesDir + "application.properties", appProps);
        writeEntry(zip, resourcesDir + "static/.gitkeep", "");
        writeEntry(zip, resourcesDir + "templates/.gitkeep", "");

        // Bootstrap YAML files for selected environments
        if (request.environments().enabled() && !request.environments().environments().isEmpty()) {
            writeEntry(zip, resourcesDir + "bootstrap.yaml",
                    bootstrapBuilder.buildBootstrapBase(request, request.environments()));
            for (String env : request.environments().environments()) {
                writeEntry(zip, resourcesDir + "bootstrap-" + env + ".yaml",
                        bootstrapBuilder.buildBootstrapEnv(request, env));
            }
        }

        writeEntry(zip, root + ".gitignore", templates.gitignore(request.type()));
        writeEntry(zip, root + "README.md", templates.readme(request));
    }

    private void writePythonProject(ZipOutputStream zip, String root, ProjectRequest request, List<Dependency> resolved) throws IOException {
        String packageDir = request.packageName().replace('.', '_');
        String srcDir = root + "src/" + packageDir + "/";
        String testDir = root + "tests/";

        if ("poetry".equals(request.type())) {
            writeEntry(zip, root + "pyproject.toml", pythonBuilder.buildPoetryPyproject(request, resolved));
        } else {
            writeEntry(zip, root + "requirements.txt", pythonBuilder.buildRequirementsTxt(resolved));
            String devReqs = pythonBuilder.buildRequirementsDevTxt(resolved);
            if (!devReqs.isBlank()) {
                writeEntry(zip, root + "requirements-dev.txt", devReqs);
            }
            writeEntry(zip, root + "setup.py", pythonBuilder.buildSetupPy(request, resolved));
        }

        writeEntry(zip, srcDir + "__init__.py", pythonBuilder.buildInitPy(request));

        var pyArch = pythonBuilder.architectureSources(request);
        if (pyArch.isEmpty()) {
            writeEntry(zip, srcDir + "main.py", pythonBuilder.buildMainModule(request, resolved));
        } else {
            for (var f : pyArch) {
                writeEntry(zip, srcDir + f.relativePath(), f.content());
            }
            writeEntry(zip, srcDir + "main.py", pythonBuilder.buildArchitectureMain(request));
            log.info("architecture sources written  artifact={}  architecture={}  files={}",
                    request.artifactId(), request.architecture(), pyArch.size());
        }

        writeEntry(zip, testDir + "__init__.py", "");
        writeEntry(zip, testDir + "test_smoke.py", pythonBuilder.buildTestModule(request, resolved));

        writeEntry(zip, root + ".gitignore", pythonBuilder.buildGitignore());
        writeEntry(zip, root + "README.md", pythonBuilder.buildPythonReadme(request));
    }

    private void writeDmzrAssets(ZipOutputStream zip, String root, ProjectRequest request) throws IOException {
        DmzrConfig dmzr = request.dmzr();
        String dmzrRoot = root + "dmzr/";

        // Environments for which to generate per-env assets — fall back to the dmzr's own list or default 5
        List<String> envs = dmzr.environments().isEmpty()
                ? EnvironmentConfig.ALLOWED
                : dmzr.environments();

        if (dmzr.vaultPolicies()) {
            String vaultDir = dmzrRoot + "vault/";
            writeEntry(zip, vaultDir + "kubernetes-auth.md", dmzrBuilder.vaultKubernetesAuth(request, dmzr));
            for (String env : envs) {
                writeEntry(zip, vaultDir + "policies/" + request.artifactId() + "-" + env + ".hcl",
                        dmzrBuilder.vaultPolicy(request, dmzr, env));
                writeEntry(zip, vaultDir + "secrets/" + env + ".yaml",
                        dmzrBuilder.vaultSecretStub(request, dmzr, env));
            }
        }

        if (dmzr.helmChart()) {
            String helmDir = dmzrRoot + "helm/";
            String chartDir = helmDir + "chart/";
            writeEntry(zip, chartDir + "Chart.yaml", dmzrBuilder.helmChartYaml(request));
            writeEntry(zip, chartDir + "values.yaml", dmzrBuilder.helmValuesYaml(request, dmzr));
            writeEntry(zip, chartDir + "templates/deployment.yaml", dmzrBuilder.helmDeployment(request, dmzr));
            writeEntry(zip, chartDir + "templates/service.yaml", dmzrBuilder.helmService(request));
            writeEntry(zip, chartDir + "templates/serviceaccount.yaml", dmzrBuilder.helmServiceAccount(request));
            for (String env : envs) {
                writeEntry(zip, helmDir + "values-" + env + ".yaml", dmzrBuilder.helmValuesForEnv(env));
            }
        }

        writeEntry(zip, dmzrRoot + "README.md", dmzrBuilder.helmReadme(request, dmzr));
    }

    private List<Dependency> resolveAndValidate(ProjectRequest request) {
        Set<String> seen = new HashSet<>();
        List<Dependency> out = new ArrayList<>();
        List<String> unknown = new ArrayList<>();
        for (String id : request.dependencies()) {
            if (id == null || id.isBlank() || !seen.add(id)) continue;
            var match = catalog.findById(id);
            if (match.isEmpty()) unknown.add(id);
            else                 out.add(match.get());
        }
        if (!unknown.isEmpty()) {
            log.warn("rejected request  artifact={}  unknown dependency ids: {}", request.artifactId(), unknown);
            throw new GenerationException("Unknown dependency id(s): " + String.join(", ", unknown));
        }

        // Auto-add database driver based on database.type for Java projects.
        // For Python, do the same but pull from the python catalog ids.
        if (request.database() != null && !"none".equals(request.database().type())) {
            String dbType = request.database().type();
            String driverId;
            if (request.isPython()) {
                driverId = switch (dbType) {
                    case "postgresql" -> "py-psycopg2";
                    case "mysql"      -> "py-pymysql";
                    case "oracle"     -> "py-cx-oracle";
                    case "mssql"      -> "py-pyodbc";
                    case "h2"         -> "py-aiosqlite"; // No H2 in Python; sqlite is the closest analog
                    default            -> null;
                };
            } else {
                driverId = switch (dbType) {
                    case "h2"         -> "h2";
                    case "postgresql" -> "postgresql";
                    case "mysql"      -> "mysql";
                    case "oracle"     -> "oracle";
                    case "mssql"      -> "mssql";
                    default            -> null;
                };
            }
            if (driverId != null && seen.add(driverId)) {
                catalog.findById(driverId).ifPresent(d -> {
                    out.add(d);
                    log.debug("auto-added db driver  artifact={}  db={}  driver={}", request.artifactId(), dbType, driverId);
                });
            }
        }

        // Architecture scaffolds need a web layer to compile/run. Auto-add it.
        if (!"standard".equals(request.architecture())) {
            if (request.isJava() && seen.add("web")) {
                catalog.findById("web").ifPresent(d -> {
                    out.add(d);
                    log.debug("auto-added web starter for {} architecture  artifact={}", request.architecture(), request.artifactId());
                });
            }
            if (request.isPython() && seen.add("fastapi")) {
                catalog.findById("fastapi").ifPresent(d -> {
                    out.add(d);
                    log.debug("auto-added fastapi for {} architecture  artifact={}", request.architecture(), request.artifactId());
                });
                // FastAPI needs an ASGI server + pydantic to actually run
                if (seen.add("uvicorn")) catalog.findById("uvicorn").ifPresent(out::add);
                if (seen.add("pydantic")) catalog.findById("pydantic").ifPresent(out::add);
            }
        }
        return out;
    }

    private String buildHelp(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Getting Started\n\n");
        sb.append("This project was generated by **sourceforge**.\n\n");
        sb.append("## Project metadata\n\n");
        sb.append("- **Group**: ").append(req.groupId()).append("\n");
        sb.append("- **Artifact**: ").append(req.artifactId()).append("\n");
        sb.append("- **Name**: ").append(req.name()).append("\n");
        sb.append("- **Package**: ").append(req.packageName()).append("\n");
        sb.append("- **Language**: ").append(req.language()).append("\n");
        sb.append("- **Runtime version**: ").append(req.javaVersion()).append("\n");
        sb.append("- **Build**: ").append(req.type()).append("\n");
        sb.append("- **Packaging**: ").append(req.packaging()).append("\n");
        if (req.isJava()) {
            sb.append("- **Spring Boot**: ").append(req.bootVersion()).append("\n");
        }
        if (req.database() != null && !"none".equals(req.database().type())) {
            sb.append("- **Database**: ").append(req.database().type()).append("\n");
        }
        if (req.environments().enabled()) {
            sb.append("- **Bootstrap profiles**: ").append(String.join(", ", req.environments().environments())).append("\n");
        }
        if (req.dmzr().enabled()) {
            sb.append("- **DMZR**: ");
            List<String> bits = new ArrayList<>();
            if (req.dmzr().vaultPolicies()) bits.add("Vault policies");
            if (req.dmzr().helmChart())     bits.add("Helm chart");
            sb.append(String.join(" + ", bits)).append("\n");
        }
        sb.append("\n## Dependencies\n\n");
        if (deps.isEmpty()) {
            sb.append("_No starters were selected._\n");
        } else {
            for (Dependency d : deps) {
                sb.append("### ").append(d.name()).append("\n");
                sb.append(d.description()).append("\n\n");
                if (!d.groupId().isBlank()) {
                    sb.append("- Coordinates: `").append(d.groupId()).append(":").append(d.artifactId()).append("`\n");
                } else {
                    sb.append("- Package: `").append(d.artifactId()).append("`\n");
                }
                sb.append("- Scope: `").append(d.scope()).append("`\n\n");
            }
        }
        return sb.toString();
    }

    private void writeWrapperEntries(ZipOutputStream zip, String root, boolean maven) throws IOException {
        if (maven) {
            writeEntry(zip, root + ".mvn/wrapper/README.md",
                    "Run `mvn -N io.takari:maven:wrapper` or `mvn -N wrapper:wrapper` to generate the Maven Wrapper files.\n");
        } else {
            writeEntry(zip, root + "gradle/wrapper/README.md",
                    "Run `gradle wrapper` (with a local Gradle install) to generate the Gradle Wrapper files (gradlew, gradlew.bat, gradle-wrapper.jar, gradle-wrapper.properties).\n");
        }
    }

    private void writeEntry(ZipOutputStream zip, String name, String content) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        if (content != null && !content.isEmpty()) {
            zip.write(content.getBytes(StandardCharsets.UTF_8));
        }
        zip.closeEntry();
    }
}
