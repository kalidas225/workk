package com.sourceforge.starter.controller;

import com.sourceforge.starter.model.MetadataResponse;
import com.sourceforge.starter.service.MetadataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MetadataController {

    private static final Logger log = LoggerFactory.getLogger(MetadataController.class);

    private final MetadataService metadataService;

    public MetadataController(MetadataService metadataService) {
        this.metadataService = metadataService;
    }

    @GetMapping("/metadata")
    public ResponseEntity<MetadataResponse> metadata() {
        log.debug("GET /api/metadata");
        return ResponseEntity.ok(metadataService.getMetadata());
    }
}
