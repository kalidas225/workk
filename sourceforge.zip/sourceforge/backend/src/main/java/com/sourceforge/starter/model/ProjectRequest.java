package com.sourceforge.starter.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.util.List;

/**
 * Incoming request from the frontend describing the project to generate.
 *
 * For Java/Kotlin/Groovy: type is maven | gradle-groovy | gradle-kotlin, language is java
 * For Python: type is poetry | pip, language is python, bootVersion is ignored (kept blank or "n/a")
 */
public record ProjectRequest(
        @NotBlank @Pattern(regexp = "maven|gradle-groovy|gradle-kotlin|poetry|pip",
                message = "type must be maven, gradle-groovy, gradle-kotlin, poetry or pip")
        String type,

        @NotBlank @Pattern(regexp = "java|python",
                message = "language must be java or python")
        String language,

        String bootVersion,             // optional for python projects

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.\\-]*$", message = "groupId is invalid")
        String groupId,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_\\-]*$", message = "artifactId is invalid")
        String artifactId,

        @NotBlank
        String name,

        String description,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.]*$", message = "packageName is invalid")
        String packageName,

        @NotBlank @Pattern(regexp = "jar|war|wheel|sdist", message = "packaging must be jar, war, wheel or sdist")
        String packaging,

        @NotBlank
        String javaVersion,             // for java: 8/11/17/21/22/23 ; for python: 3.10/3.11/3.12/3.13

        @NotNull
        List<String> dependencies,

        DatabaseConfig database,

        EnvironmentConfig environments,

        DmzrConfig dmzr
) {
    public ProjectRequest {
        if (dependencies == null) dependencies = List.of();
        if (description == null) description = "";
        if (database == null) database = DatabaseConfig.none();
        if (environments == null) environments = EnvironmentConfig.disabled();
        if (dmzr == null) dmzr = DmzrConfig.disabled();
        if (bootVersion == null) bootVersion = "";
    }

    public boolean isPython() {
        return "python".equals(language);
    }

    public boolean isJava() {
        return "java".equals(language);
    }
}
