package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Generates additional Java source files for layered (MVC) and microservice
 * architectures. Every emitted file is self-contained and compiles against the
 * spring-boot-starter-web dependency alone (which the generator guarantees is
 * present whenever a non-standard architecture is selected).
 *
 * The classes deliberately avoid JPA / database types so the project compiles
 * and runs regardless of whether a datasource was configured. Persistence is
 * represented by a simple in-memory repository.
 */
@Component
public class ArchitectureTemplateService {

    /** A single generated source file: relative path under the package dir + content. */
    public record SourceFile(String relativePath, String content) {}

    /**
     * Build the architecture-specific source files for a Java project.
     * Returns an empty list for "standard" (only the main class is emitted elsewhere).
     */
    public List<SourceFile> javaSources(ProjectRequest req) {
        if (req.isMvc()) return mvcSources(req);
        if (req.isMicroservice()) return microserviceSources(req);
        return List.of();
    }

    // =========================================================
    //  MVC — layered: controller -> service -> repository -> model + DTO
    // =========================================================
    private List<SourceFile> mvcSources(ProjectRequest req) {
        String pkg = req.packageName();
        List<SourceFile> files = new ArrayList<>();

        // ----- model/Greeting.java -----
        files.add(new SourceFile("model/Greeting.java",
                "package " + pkg + ".model;\n\n" +
                "/** Domain model. */\n" +
                "public class Greeting {\n\n" +
                "    private Long id;\n" +
                "    private String message;\n\n" +
                "    public Greeting() {\n" +
                "    }\n\n" +
                "    public Greeting(Long id, String message) {\n" +
                "        this.id = id;\n" +
                "        this.message = message;\n" +
                "    }\n\n" +
                "    public Long getId() {\n" +
                "        return id;\n" +
                "    }\n\n" +
                "    public void setId(Long id) {\n" +
                "        this.id = id;\n" +
                "    }\n\n" +
                "    public String getMessage() {\n" +
                "        return message;\n" +
                "    }\n\n" +
                "    public void setMessage(String message) {\n" +
                "        this.message = message;\n" +
                "    }\n" +
                "}\n"));

        // ----- dto/GreetingRequest.java -----
        files.add(new SourceFile("dto/GreetingRequest.java",
                "package " + pkg + ".dto;\n\n" +
                "/** Inbound payload for creating a greeting. */\n" +
                "public class GreetingRequest {\n\n" +
                "    private String message;\n\n" +
                "    public String getMessage() {\n" +
                "        return message;\n" +
                "    }\n\n" +
                "    public void setMessage(String message) {\n" +
                "        this.message = message;\n" +
                "    }\n" +
                "}\n"));

        // ----- repository/GreetingRepository.java (in-memory, no JPA needed) -----
        files.add(new SourceFile("repository/GreetingRepository.java",
                "package " + pkg + ".repository;\n\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import org.springframework.stereotype.Repository;\n\n" +
                "import java.util.ArrayList;\n" +
                "import java.util.List;\n" +
                "import java.util.Optional;\n" +
                "import java.util.concurrent.ConcurrentHashMap;\n" +
                "import java.util.concurrent.atomic.AtomicLong;\n\n" +
                "/**\n" +
                " * Simple in-memory repository so the project compiles and runs without a\n" +
                " * database. Swap for a Spring Data JPA repository when persistence is added.\n" +
                " */\n" +
                "@Repository\n" +
                "public class GreetingRepository {\n\n" +
                "    private final ConcurrentHashMap<Long, Greeting> store = new ConcurrentHashMap<>();\n" +
                "    private final AtomicLong sequence = new AtomicLong(0);\n\n" +
                "    public List<Greeting> findAll() {\n" +
                "        return new ArrayList<>(store.values());\n" +
                "    }\n\n" +
                "    public Optional<Greeting> findById(Long id) {\n" +
                "        return Optional.ofNullable(store.get(id));\n" +
                "    }\n\n" +
                "    public Greeting save(Greeting greeting) {\n" +
                "        if (greeting.getId() == null) {\n" +
                "            greeting.setId(sequence.incrementAndGet());\n" +
                "        }\n" +
                "        store.put(greeting.getId(), greeting);\n" +
                "        return greeting;\n" +
                "    }\n" +
                "}\n"));

        // ----- service/GreetingService.java -----
        files.add(new SourceFile("service/GreetingService.java",
                "package " + pkg + ".service;\n\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import " + pkg + ".repository.GreetingRepository;\n" +
                "import org.springframework.stereotype.Service;\n\n" +
                "import java.util.List;\n" +
                "import java.util.Optional;\n\n" +
                "/** Business logic layer. */\n" +
                "@Service\n" +
                "public class GreetingService {\n\n" +
                "    private final GreetingRepository repository;\n\n" +
                "    public GreetingService(GreetingRepository repository) {\n" +
                "        this.repository = repository;\n" +
                "    }\n\n" +
                "    public List<Greeting> findAll() {\n" +
                "        return repository.findAll();\n" +
                "    }\n\n" +
                "    public Optional<Greeting> findById(Long id) {\n" +
                "        return repository.findById(id);\n" +
                "    }\n\n" +
                "    public Greeting create(String message) {\n" +
                "        Greeting greeting = new Greeting(null, message);\n" +
                "        return repository.save(greeting);\n" +
                "    }\n" +
                "}\n"));

        // ----- controller/GreetingController.java -----
        files.add(new SourceFile("controller/GreetingController.java",
                "package " + pkg + ".controller;\n\n" +
                "import " + pkg + ".dto.GreetingRequest;\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import " + pkg + ".service.GreetingService;\n" +
                "import org.springframework.http.ResponseEntity;\n" +
                "import org.springframework.web.bind.annotation.*;\n\n" +
                "import java.util.List;\n\n" +
                "/** REST controller — presentation layer. */\n" +
                "@RestController\n" +
                "@RequestMapping(\"/api/greetings\")\n" +
                "public class GreetingController {\n\n" +
                "    private final GreetingService service;\n\n" +
                "    public GreetingController(GreetingService service) {\n" +
                "        this.service = service;\n" +
                "    }\n\n" +
                "    @GetMapping\n" +
                "    public List<Greeting> all() {\n" +
                "        return service.findAll();\n" +
                "    }\n\n" +
                "    @GetMapping(\"/{id}\")\n" +
                "    public ResponseEntity<Greeting> byId(@PathVariable Long id) {\n" +
                "        return service.findById(id)\n" +
                "                .map(ResponseEntity::ok)\n" +
                "                .orElseGet(() -> ResponseEntity.notFound().build());\n" +
                "    }\n\n" +
                "    @PostMapping\n" +
                "    public ResponseEntity<Greeting> create(@RequestBody GreetingRequest request) {\n" +
                "        Greeting created = service.create(request.getMessage());\n" +
                "        return ResponseEntity.ok(created);\n" +
                "    }\n" +
                "}\n"));

        return files;
    }

    // =========================================================
    //  Microservice — adds REST client, health/info, config props, global error handling
    // =========================================================
    private List<SourceFile> microserviceSources(ProjectRequest req) {
        String pkg = req.packageName();
        // Reuse the layered classes as the core domain...
        List<SourceFile> files = new ArrayList<>(mvcSources(req));

        // ----- config/AppProperties.java -----
        files.add(new SourceFile("config/AppProperties.java",
                "package " + pkg + ".config;\n\n" +
                "import org.springframework.boot.context.properties.ConfigurationProperties;\n" +
                "import org.springframework.context.annotation.Configuration;\n\n" +
                "/**\n" +
                " * Externalised configuration, bound from properties prefixed with 'app'.\n" +
                " * Example: app.downstream-url=http://localhost:9090\n" +
                " */\n" +
                "@Configuration\n" +
                "@ConfigurationProperties(prefix = \"app\")\n" +
                "public class AppProperties {\n\n" +
                "    /** Base URL of a downstream service this microservice calls. */\n" +
                "    private String downstreamUrl = \"http://localhost:9090\";\n\n" +
                "    public String getDownstreamUrl() {\n" +
                "        return downstreamUrl;\n" +
                "    }\n\n" +
                "    public void setDownstreamUrl(String downstreamUrl) {\n" +
                "        this.downstreamUrl = downstreamUrl;\n" +
                "    }\n" +
                "}\n"));

        // ----- config/RestClientConfig.java (RestClient is part of spring-web 6.1+) -----
        files.add(new SourceFile("config/RestClientConfig.java",
                "package " + pkg + ".config;\n\n" +
                "import org.springframework.context.annotation.Bean;\n" +
                "import org.springframework.context.annotation.Configuration;\n" +
                "import org.springframework.web.client.RestClient;\n\n" +
                "/** Provides a configured RestClient for outbound calls. */\n" +
                "@Configuration\n" +
                "public class RestClientConfig {\n\n" +
                "    @Bean\n" +
                "    public RestClient restClient(AppProperties properties) {\n" +
                "        return RestClient.builder()\n" +
                "                .baseUrl(properties.getDownstreamUrl())\n" +
                "                .build();\n" +
                "    }\n" +
                "}\n"));

        // ----- client/DownstreamClient.java -----
        files.add(new SourceFile("client/DownstreamClient.java",
                "package " + pkg + ".client;\n\n" +
                "import org.springframework.stereotype.Component;\n" +
                "import org.springframework.web.client.RestClient;\n\n" +
                "/**\n" +
                " * Thin wrapper over RestClient representing a call to another microservice.\n" +
                " * Returns a String to keep the example dependency-free.\n" +
                " */\n" +
                "@Component\n" +
                "public class DownstreamClient {\n\n" +
                "    private final RestClient restClient;\n\n" +
                "    public DownstreamClient(RestClient restClient) {\n" +
                "        this.restClient = restClient;\n" +
                "    }\n\n" +
                "    public String fetchStatus() {\n" +
                "        try {\n" +
                "            return restClient.get()\n" +
                "                    .uri(\"/status\")\n" +
                "                    .retrieve()\n" +
                "                    .body(String.class);\n" +
                "        } catch (Exception ex) {\n" +
                "            // Downstream not reachable in local dev — degrade gracefully.\n" +
                "            return \"unknown\";\n" +
                "        }\n" +
                "    }\n" +
                "}\n"));

        // ----- web/GlobalExceptionHandler.java -----
        files.add(new SourceFile("web/GlobalExceptionHandler.java",
                "package " + pkg + ".web;\n\n" +
                "import org.springframework.http.HttpStatus;\n" +
                "import org.springframework.http.ResponseEntity;\n" +
                "import org.springframework.web.bind.annotation.ExceptionHandler;\n" +
                "import org.springframework.web.bind.annotation.RestControllerAdvice;\n\n" +
                "import java.time.Instant;\n" +
                "import java.util.Map;\n\n" +
                "/** Centralised error handling — returns a consistent JSON error body. */\n" +
                "@RestControllerAdvice\n" +
                "public class GlobalExceptionHandler {\n\n" +
                "    @ExceptionHandler(IllegalArgumentException.class)\n" +
                "    public ResponseEntity<Map<String, Object>> handleBadRequest(IllegalArgumentException ex) {\n" +
                "        Map<String, Object> body = Map.of(\n" +
                "                \"timestamp\", Instant.now().toString(),\n" +
                "                \"status\", HttpStatus.BAD_REQUEST.value(),\n" +
                "                \"error\", \"Bad Request\",\n" +
                "                \"message\", ex.getMessage() == null ? \"\" : ex.getMessage()\n" +
                "        );\n" +
                "        return ResponseEntity.badRequest().body(body);\n" +
                "    }\n\n" +
                "    @ExceptionHandler(Exception.class)\n" +
                "    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {\n" +
                "        Map<String, Object> body = Map.of(\n" +
                "                \"timestamp\", Instant.now().toString(),\n" +
                "                \"status\", HttpStatus.INTERNAL_SERVER_ERROR.value(),\n" +
                "                \"error\", \"Internal Server Error\",\n" +
                "                \"message\", ex.getMessage() == null ? \"\" : ex.getMessage()\n" +
                "        );\n" +
                "        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);\n" +
                "    }\n" +
                "}\n"));

        // ----- controller/StatusController.java (exercises the client + properties) -----
        files.add(new SourceFile("controller/StatusController.java",
                "package " + pkg + ".controller;\n\n" +
                "import " + pkg + ".client.DownstreamClient;\n" +
                "import org.springframework.web.bind.annotation.GetMapping;\n" +
                "import org.springframework.web.bind.annotation.RequestMapping;\n" +
                "import org.springframework.web.bind.annotation.RestController;\n\n" +
                "import java.util.Map;\n\n" +
                "/** Surfaces this service's status and the downstream service's status. */\n" +
                "@RestController\n" +
                "@RequestMapping(\"/api/status\")\n" +
                "public class StatusController {\n\n" +
                "    private final DownstreamClient downstreamClient;\n\n" +
                "    public StatusController(DownstreamClient downstreamClient) {\n" +
                "        this.downstreamClient = downstreamClient;\n" +
                "    }\n\n" +
                "    @GetMapping\n" +
                "    public Map<String, String> status() {\n" +
                "        return Map.of(\n" +
                "                \"service\", \"UP\",\n" +
                "                \"downstream\", downstreamClient.fetchStatus()\n" +
                "        );\n" +
                "    }\n" +
                "}\n"));

        return files;
    }

    /**
     * Extra application.properties lines for the chosen architecture.
     * Returns "" when nothing extra is needed.
     */
    public String extraProperties(ProjectRequest req) {
        if (req.isMicroservice()) {
            return "\n# ===== Microservice =====\n" +
                    "app.downstream-url=http://localhost:9090\n";
        }
        return "";
    }
}
