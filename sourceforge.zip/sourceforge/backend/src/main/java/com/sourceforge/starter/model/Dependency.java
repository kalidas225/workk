package com.sourceforge.starter.model;

import java.util.List;

public record Dependency(
        String id,
        String name,
        String description,
        String groupId,
        String artifactId,
        String version,
        String scope,
        String category,
        List<String> incompatibleWith,
        String minBootVersion,
        String maxBootVersion
) {
    public Dependency {
        if (incompatibleWith == null) {
            incompatibleWith = List.of();
        }
        if (scope == null || scope.isBlank()) {
            scope = "compile";
        }
    }
}
