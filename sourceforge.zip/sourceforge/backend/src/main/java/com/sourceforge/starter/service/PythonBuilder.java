package com.sourceforge.starter.service;

import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PythonBuilder {

    /** Build pyproject.toml for Poetry. */
    public String buildPoetryPyproject(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("[tool.poetry]\n");
        sb.append("name = \"").append(req.artifactId()).append("\"\n");
        sb.append("version = \"0.1.0\"\n");
        sb.append("description = \"").append(escapeToml(req.description())).append("\"\n");
        sb.append("authors = [\"").append(escapeToml(req.groupId())).append("\"]\n");
        sb.append("readme = \"README.md\"\n");
        sb.append("packages = [{ include = \"").append(req.packageName().replace('.', '_')).append("\", from = \"src\" }]\n\n");

        sb.append("[tool.poetry.dependencies]\n");
        sb.append("python = \"^").append(req.javaVersion()).append("\"\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append(d.artifactId()).append(" = \"").append(d.version() != null ? d.version() : "*").append("\"\n");
        }

        List<Dependency> devDeps = devDeps(deps);
        if (!devDeps.isEmpty()) {
            sb.append("\n[tool.poetry.group.dev.dependencies]\n");
            for (Dependency d : devDeps) {
                sb.append(d.artifactId()).append(" = \"").append(d.version() != null ? d.version() : "*").append("\"\n");
            }
        }

        sb.append("\n[build-system]\n");
        sb.append("requires = [\"poetry-core>=1.0.0\"]\n");
        sb.append("build-backend = \"poetry.core.masonry.api\"\n\n");

        // Tool configs that play nicely if user picked them
        if (deps.stream().anyMatch(d -> "py-ruff".equals(d.id()))) {
            sb.append("[tool.ruff]\nline-length = 100\ntarget-version = \"py").append(pyTarget(req)).append("\"\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-black".equals(d.id()))) {
            sb.append("[tool.black]\nline-length = 100\ntarget-version = [\"py").append(pyTarget(req)).append("\"]\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-mypy".equals(d.id()))) {
            sb.append("[tool.mypy]\npython_version = \"").append(req.javaVersion()).append("\"\nstrict = true\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-pytest".equals(d.id()))) {
            sb.append("[tool.pytest.ini_options]\ntestpaths = [\"tests\"]\nasyncio_mode = \"auto\"\n");
        }
        return sb.toString();
    }

    /** Build requirements.txt for pip-based projects. */
    public String buildRequirementsTxt(List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Runtime dependencies\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Build requirements-dev.txt for pip-based projects with dev tools. */
    public String buildRequirementsDevTxt(List<Dependency> deps) {
        List<Dependency> devDeps = devDeps(deps);
        if (devDeps.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("-r requirements.txt\n\n");
        sb.append("# Development dependencies\n");
        for (Dependency d : devDeps) {
            sb.append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Minimal setup.py for pip-style projects (gives `pip install -e .` support). */
    public String buildSetupPy(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("from setuptools import setup, find_packages\n\n");
        sb.append("setup(\n");
        sb.append("    name=\"").append(req.artifactId()).append("\",\n");
        sb.append("    version=\"0.1.0\",\n");
        sb.append("    description=\"").append(req.description().replace("\"", "\\\"")).append("\",\n");
        sb.append("    package_dir={\"\": \"src\"},\n");
        sb.append("    packages=find_packages(where=\"src\"),\n");
        sb.append("    python_requires=\">=").append(req.javaVersion()).append("\",\n");
        sb.append("    install_requires=[\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append("        \"").append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\",\n");
        }
        sb.append("    ],\n");
        sb.append(")\n");
        return sb.toString();
    }

    /** Main module — different per framework. */
    public String buildMainModule(ProjectRequest req, List<Dependency> deps) {
        boolean fastapi = deps.stream().anyMatch(d -> "fastapi".equals(d.id()));
        boolean flask   = deps.stream().anyMatch(d -> "flask".equals(d.id()));

        if (fastapi) {
            return ""
                    + "\"\"\"" + req.name() + " — main entry point.\"\"\"\n"
                    + "from fastapi import FastAPI\n\n"
                    + "app = FastAPI(title=\"" + req.name() + "\", description=\"" + escapeQuotes(req.description()) + "\")\n\n"
                    + "@app.get(\"/\")\n"
                    + "def root() -> dict[str, str]:\n"
                    + "    return {\"message\": \"Hello from " + req.name() + "\"}\n\n"
                    + "@app.get(\"/healthz\")\n"
                    + "def healthz() -> dict[str, str]:\n"
                    + "    return {\"status\": \"ok\"}\n";
        }
        if (flask) {
            return ""
                    + "\"\"\"" + req.name() + " — Flask app entry point.\"\"\"\n"
                    + "from flask import Flask\n\n"
                    + "app = Flask(__name__)\n\n"
                    + "@app.route(\"/\")\n"
                    + "def root():\n"
                    + "    return {\"message\": \"Hello from " + req.name() + "\"}\n\n"
                    + "@app.route(\"/healthz\")\n"
                    + "def healthz():\n"
                    + "    return {\"status\": \"ok\"}\n\n"
                    + "if __name__ == \"__main__\":\n"
                    + "    app.run(host=\"0.0.0.0\", port=8080)\n";
        }
        // Plain library / CLI
        return ""
                + "\"\"\"" + req.name() + " — main module.\"\"\"\n\n"
                + "def main() -> None:\n"
                + "    print(\"Hello from " + req.name() + "\")\n\n"
                + "if __name__ == \"__main__\":\n"
                + "    main()\n";
    }

    public String buildInitPy(ProjectRequest req) {
        return "\"\"\"" + req.name() + " package.\"\"\"\n__version__ = \"0.1.0\"\n";
    }

    public String buildTestModule(ProjectRequest req, List<Dependency> deps) {
        boolean fastapi = deps.stream().anyMatch(d -> "fastapi".equals(d.id()));
        boolean flask   = deps.stream().anyMatch(d -> "flask".equals(d.id()));

        if (fastapi) {
            return ""
                    + "\"\"\"Smoke tests.\"\"\"\n"
                    + "from fastapi.testclient import TestClient\n"
                    + "from " + req.packageName().replace('.', '_') + ".main import app\n\n"
                    + "client = TestClient(app)\n\n"
                    + "def test_root():\n"
                    + "    r = client.get(\"/\")\n"
                    + "    assert r.status_code == 200\n";
        }
        if (flask) {
            return ""
                    + "\"\"\"Smoke tests.\"\"\"\n"
                    + "from " + req.packageName().replace('.', '_') + ".main import app\n\n"
                    + "def test_root():\n"
                    + "    with app.test_client() as c:\n"
                    + "        r = c.get(\"/\")\n"
                    + "        assert r.status_code == 200\n";
        }
        return ""
                + "def test_smoke():\n"
                + "    assert 1 + 1 == 2\n";
    }

    public String buildGitignore() {
        return ""
                + "# Byte-compiled / optimized / DLL files\n"
                + "__pycache__/\n*.py[cod]\n*$py.class\n\n"
                + "# Distribution / packaging\n"
                + "build/\ndist/\n*.egg-info/\n.eggs/\n\n"
                + "# Virtual environments\n"
                + ".venv/\nvenv/\nenv/\n\n"
                + "# Testing & coverage\n"
                + ".pytest_cache/\n.coverage\nhtmlcov/\n\n"
                + "# Type checkers\n"
                + ".mypy_cache/\n.ruff_cache/\n\n"
                + "# IDE\n.idea/\n.vscode/\n*.iml\n\n"
                + "# OS\n.DS_Store\nThumbs.db\n";
    }

    public String buildPythonReadme(ProjectRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(req.name()).append("\n\n");
        if (!req.description().isBlank()) sb.append(req.description()).append("\n\n");
        sb.append("Generated with **sourceforge** — a Spring Boot / Python project initializer.\n\n");
        sb.append("## Setup\n\n");
        if ("poetry".equals(req.type())) {
            sb.append("```bash\npoetry install\npoetry run python -m ").append(req.packageName().replace('.', '_')).append(".main\n```\n\n");
        } else {
            sb.append("```bash\npython -m venv .venv && source .venv/bin/activate\npip install -r requirements.txt\npython -m ").append(req.packageName().replace('.', '_')).append(".main\n```\n\n");
        }
        sb.append("## Run tests\n\n```bash\n");
        if ("poetry".equals(req.type())) sb.append("poetry run pytest\n");
        else                              sb.append("pytest\n");
        sb.append("```\n");
        return sb.toString();
    }

    // ===== helpers =====
    private List<Dependency> runtimeDeps(List<Dependency> deps) {
        List<Dependency> out = new ArrayList<>();
        for (Dependency d : deps) {
            if (!"dev".equals(d.scope())) out.add(d);
        }
        return out;
    }

    private List<Dependency> devDeps(List<Dependency> deps) {
        List<Dependency> out = new ArrayList<>();
        for (Dependency d : deps) {
            if ("dev".equals(d.scope())) out.add(d);
        }
        return out;
    }

    /** Convert poetry-style version ("^0.115.0", "*") to pip-style (">=0.115.0,<0.116.0"). */
    private String toPipVersion(String v) {
        if (v == null || v.isBlank() || "*".equals(v)) return "";
        if (v.startsWith("^")) {
            String bare = v.substring(1);
            return ">=" + bare;
        }
        if (v.startsWith("~")) return ">=" + v.substring(1);
        if (v.startsWith(">=") || v.startsWith("<=") || v.startsWith("==") || v.startsWith(">") || v.startsWith("<")) {
            return v;
        }
        return "==" + v;
    }

    private String pyTarget(ProjectRequest req) {
        // "3.12" -> "312"
        return req.javaVersion().replace(".", "");
    }

    private String escapeToml(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String escapeQuotes(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
