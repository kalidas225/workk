package com.sourceforge.starter.controller;

import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.ProjectGeneratorService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class GeneratorController {

    private static final Logger log = LoggerFactory.getLogger(GeneratorController.class);

    private final ProjectGeneratorService generator;

    public GeneratorController(ProjectGeneratorService generator) {
        this.generator = generator;
    }

    @PostMapping(value = "/generate", produces = "application/zip")
    public ResponseEntity<byte[]> generate(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        log.info("POST /api/generate  artifact={}  language={}  build={}  runtime={}  deps={}  db={}  envs={}  dmzr={}",
                request.artifactId(),
                request.language(),
                request.type(),
                request.javaVersion(),
                request.dependencies().size(),
                request.database() != null ? request.database().type() : "none",
                request.environments() != null && request.environments().enabled()
                        ? request.environments().environments() : "off",
                request.dmzr() != null && request.dmzr().enabled() ? "on" : "off");

        byte[] zip = generator.generate(request);

        log.info("POST /api/generate  artifact={}  size={}KB  took={}ms",
                request.artifactId(), zip.length / 1024, System.currentTimeMillis() - start);

        ContentDisposition cd = ContentDisposition.attachment()
                .filename(request.artifactId() + ".zip")
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/zip"));
        headers.setContentDisposition(cd);
        headers.setContentLength(zip.length);
        return new ResponseEntity<>(zip, headers, HttpStatus.OK);
    }
}
