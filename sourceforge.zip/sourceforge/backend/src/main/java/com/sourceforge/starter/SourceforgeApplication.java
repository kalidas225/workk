package com.sourceforge.starter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class SourceforgeApplication {

    private static final Logger log = LoggerFactory.getLogger(SourceforgeApplication.class);

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(SourceforgeApplication.class, args);
        Environment env = ctx.getEnvironment();
        log.info("sourceforge started  port={}  metadata=http://localhost:{}/api/metadata",
                env.getProperty("server.port", "8080"),
                env.getProperty("server.port", "8080"));
    }
}
