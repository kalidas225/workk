package com.sourceforge.starter.model;

/**
 * Database configuration for the generated project.
 * When type is "none", no database properties are added to application.properties
 * and no JDBC driver dependency is auto-injected.
 */
public record DatabaseConfig(
        String type,         // none | h2 | postgresql | mysql | oracle | mssql
        String url,          // jdbc URL (optional)
        String username,     // optional
        String password,     // optional
        String ddlAuto       // none | validate | update | create | create-drop
) {
    public DatabaseConfig {
        if (type == null || type.isBlank()) type = "none";
        if (url == null) url = "";
        if (username == null) username = "";
        if (password == null) password = "";
        if (ddlAuto == null || ddlAuto.isBlank()) ddlAuto = "update";
    }

    public static DatabaseConfig none() {
        return new DatabaseConfig("none", "", "", "", "update");
    }
}
