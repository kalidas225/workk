package com.sourceforge.starter.service;

import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GradleBuilder {

    public String buildGroovy(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("plugins {\n");
        sb.append("    id 'java'\n");
        if ("war".equals(req.packaging())) sb.append("    id 'war'\n");
        sb.append("    id 'org.springframework.boot' version '").append(req.bootVersion()).append("'\n");
        sb.append("    id 'io.spring.dependency-management' version '1.1.6'\n");
        if ("kotlin".equals(req.language())) {
            sb.append("    id 'org.jetbrains.kotlin.jvm' version '1.9.25'\n");
            sb.append("    id 'org.jetbrains.kotlin.plugin.spring' version '1.9.25'\n");
        } else if ("groovy".equals(req.language())) {
            sb.append("    id 'groovy'\n");
        }
        sb.append("}\n\n");

        sb.append("group = '").append(req.groupId()).append("'\n");
        sb.append("version = '0.0.1-SNAPSHOT'\n\n");

        sb.append("java {\n");
        sb.append("    toolchain {\n");
        sb.append("        languageVersion = JavaLanguageVersion.of(").append(req.javaVersion()).append(")\n");
        sb.append("    }\n");
        sb.append("}\n\n");

        sb.append("repositories {\n");
        sb.append("    mavenCentral()\n");
        sb.append("}\n\n");

        sb.append("dependencies {\n");
        for (Dependency d : deps) {
            String conf = mapScopeGroovy(d.scope(), d.id());
            String coord = d.groupId() + ":" + d.artifactId() + (d.version() != null ? ":" + d.version() : "");
            sb.append("    ").append(conf).append(" '").append(coord).append("'\n");
        }
        sb.append("    testImplementation 'org.springframework.boot:spring-boot-starter-test'\n");
        if ("kotlin".equals(req.language())) {
            sb.append("    implementation 'org.jetbrains.kotlin:kotlin-reflect'\n");
            sb.append("    implementation 'com.fasterxml.jackson.module:jackson-module-kotlin'\n");
        } else if ("groovy".equals(req.language())) {
            sb.append("    implementation 'org.codehaus.groovy:groovy'\n");
        }
        if ("war".equals(req.packaging())) {
            sb.append("    providedRuntime 'org.springframework.boot:spring-boot-starter-tomcat'\n");
        }
        sb.append("}\n\n");

        sb.append("tasks.named('test') {\n");
        sb.append("    useJUnitPlatform()\n");
        sb.append("}\n");
        return sb.toString();
    }

    public String buildKotlin(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("plugins {\n");
        sb.append("    java\n");
        if ("war".equals(req.packaging())) sb.append("    war\n");
        sb.append("    id(\"org.springframework.boot\") version \"").append(req.bootVersion()).append("\"\n");
        sb.append("    id(\"io.spring.dependency-management\") version \"1.1.6\"\n");
        if ("kotlin".equals(req.language())) {
            sb.append("    kotlin(\"jvm\") version \"1.9.25\"\n");
            sb.append("    kotlin(\"plugin.spring\") version \"1.9.25\"\n");
        }
        sb.append("}\n\n");
        sb.append("group = \"").append(req.groupId()).append("\"\n");
        sb.append("version = \"0.0.1-SNAPSHOT\"\n\n");
        sb.append("java {\n");
        sb.append("    toolchain {\n");
        sb.append("        languageVersion = JavaLanguageVersion.of(").append(req.javaVersion()).append(")\n");
        sb.append("    }\n");
        sb.append("}\n\n");
        sb.append("repositories {\n    mavenCentral()\n}\n\n");
        sb.append("dependencies {\n");
        for (Dependency d : deps) {
            String conf = mapScopeKotlin(d.scope(), d.id());
            String coord = d.groupId() + ":" + d.artifactId() + (d.version() != null ? ":" + d.version() : "");
            sb.append("    ").append(conf).append("(\"").append(coord).append("\")\n");
        }
        sb.append("    testImplementation(\"org.springframework.boot:spring-boot-starter-test\")\n");
        if ("kotlin".equals(req.language())) {
            sb.append("    implementation(\"org.jetbrains.kotlin:kotlin-reflect\")\n");
            sb.append("    implementation(\"com.fasterxml.jackson.module:jackson-module-kotlin\")\n");
        }
        if ("war".equals(req.packaging())) {
            sb.append("    providedRuntime(\"org.springframework.boot:spring-boot-starter-tomcat\")\n");
        }
        sb.append("}\n\n");
        sb.append("tasks.withType<Test> {\n    useJUnitPlatform()\n}\n");
        return sb.toString();
    }

    public String settingsGroovy(ProjectRequest req) {
        return "rootProject.name = '" + req.artifactId() + "'\n";
    }

    public String settingsKotlin(ProjectRequest req) {
        return "rootProject.name = \"" + req.artifactId() + "\"\n";
    }

    private String mapScopeGroovy(String scope, String id) {
        if ("lombok".equals(id)) {
            return "compileOnly";
        }
        return switch (scope) {
            case "runtime" -> "runtimeOnly";
            case "test" -> "testImplementation";
            case "provided" -> "compileOnly";
            default -> "implementation";
        };
    }

    private String mapScopeKotlin(String scope, String id) {
        if ("lombok".equals(id)) return "compileOnly";
        return switch (scope) {
            case "runtime" -> "runtimeOnly";
            case "test" -> "testImplementation";
            case "provided" -> "compileOnly";
            default -> "implementation";
        };
    }
}
