package com.sourceforge.starter.service;

import com.sourceforge.starter.model.LanguageMetadata;
import com.sourceforge.starter.model.MetadataResponse;
import com.sourceforge.starter.model.ProjectDefaults;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MetadataService {

    // Java
    public static final List<String> JAVA_BUILD_TYPES = List.of("maven", "gradle-groovy", "gradle-kotlin");
    public static final List<String> JAVA_VERSIONS    = List.of("21", "17", "11", "8");
    public static final List<String> JAVA_PACKAGINGS  = List.of("jar", "war");
    public static final List<String> BOOT_VERSIONS    = List.of("3.3.5", "3.3.4", "3.2.11", "3.1.12");

    // Python
    public static final List<String> PYTHON_BUILD_TYPES = List.of("poetry", "pip");
    public static final List<String> PYTHON_VERSIONS    = List.of("3.13", "3.12", "3.11", "3.10");
    public static final List<String> PYTHON_PACKAGINGS  = List.of("wheel", "sdist");

    public static final List<String> ENVIRONMENTS = List.of("dev", "ist", "uat", "ppd", "prod");

    private final DependencyCatalogService catalog;

    public MetadataService(DependencyCatalogService catalog) {
        this.catalog = catalog;
    }

    public MetadataResponse getMetadata() {
        LanguageMetadata java = new LanguageMetadata(
                "java", "Java",
                JAVA_BUILD_TYPES, JAVA_VERSIONS, JAVA_PACKAGINGS, BOOT_VERSIONS,
                new ProjectDefaults(
                        "maven", "java", "3.3.5",
                        "com.example", "demo", "demo",
                        "Demo project for Spring Boot", "com.example.demo",
                        "jar", "21"
                ),
                catalog.getJavaCategories()
        );

        LanguageMetadata python = new LanguageMetadata(
                "python", "Python",
                PYTHON_BUILD_TYPES, PYTHON_VERSIONS, PYTHON_PACKAGINGS, List.of(),
                new ProjectDefaults(
                        "poetry", "python", "",
                        "com.example", "demo", "demo",
                        "Demo Python project", "com.example.demo",
                        "wheel", "3.12"
                ),
                catalog.getPythonCategories()
        );

        return new MetadataResponse(
                List.of("java", "python"),
                "java",
                List.of(java, python),
                ENVIRONMENTS
        );
    }
}
