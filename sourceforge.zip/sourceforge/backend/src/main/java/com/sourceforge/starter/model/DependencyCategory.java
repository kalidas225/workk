package com.sourceforge.starter.model;

import java.util.List;

public record DependencyCategory(String name, List<Dependency> dependencies) {
}
