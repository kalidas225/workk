package com.sourceforge.starter.model;

import java.util.List;

/**
 * Configures generation of DMZR (deployment) assets:
 * - HashiCorp Vault policies & KV secret stubs
 * - Helm chart with vault-agent injector annotations
 */
public record DmzrConfig(
        boolean enabled,
        boolean vaultPolicies,                 // generate Vault policies + secret stubs
        boolean helmChart,                     // generate Helm chart skeleton
        String vaultRole,                      // Kubernetes auth role name in Vault
        String vaultSecretPath,                // base KV path, e.g. "secret/data/myapp"
        String kubernetesNamespace,            // target K8s namespace
        String dockerImage,                    // base image:tag for deployment
        List<String> environments              // dev/ist/uat/ppd/prod targeted
) {
    public DmzrConfig {
        if (vaultRole == null || vaultRole.isBlank()) vaultRole = "";
        if (vaultSecretPath == null || vaultSecretPath.isBlank()) vaultSecretPath = "";
        if (kubernetesNamespace == null || kubernetesNamespace.isBlank()) kubernetesNamespace = "default";
        if (dockerImage == null || dockerImage.isBlank()) dockerImage = "";
        if (environments == null) environments = List.of();
    }

    public static DmzrConfig disabled() {
        return new DmzrConfig(false, false, false, "", "", "default", "", List.of());
    }
}
