package com.sourceforge.starter.model;

import java.util.List;

/**
 * Top-level metadata: a list of language bundles plus the default language id.
 * Frontend renders UI based on the active language bundle.
 */
public record MetadataResponse(
        List<String> languages,                 // ["java","python"]
        String defaultLanguage,
        List<LanguageMetadata> languageMetadata,
        List<String> environments,              // ["dev","ist","uat","ppd","prod"] for env config UI
        List<ArchitectureOption> architectures  // standard / mvc / microservice
) {
}
