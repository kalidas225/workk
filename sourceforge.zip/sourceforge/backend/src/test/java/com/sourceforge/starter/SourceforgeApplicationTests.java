package com.sourceforge.starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SourceforgeApplicationTests {

    @Test
    void contextLoads() {
    }
}
