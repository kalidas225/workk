package com.sourceforge.starter;

import com.sourceforge.starter.model.DatabaseConfig;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.ProjectGeneratorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ProjectGeneratorServiceTests {

    @Autowired
    ProjectGeneratorService generator;

    @Test
    void generatesJavaMavenZipWithEnvAndDmzr() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "3.3.5",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21",
                List.of("web", "data-jpa", "lombok"),
                new DatabaseConfig("h2", "", "sa", "", "update"),
                new EnvironmentConfig(true, List.of("dev", "ist", "prod"), "https://config.example.com", "dev"),
                new DmzrConfig(true, true, true, "demo-role", "secret/data/demo", "demo-ns", "registry.example.com/demo:1.0", List.of("dev", "prod"))
        );
        byte[] zip = generator.generate(req);
        assertNotNull(zip);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("demo/pom.xml"));
        assertTrue(entries.contains("demo/src/main/java/com/example/demo/DemoApplication.java"));
        assertTrue(entries.contains("demo/src/main/resources/application.properties"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-dev.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-prod.yaml"));
        assertTrue(entries.contains("demo/dmzr/vault/policies/demo-dev.hcl"));
        assertTrue(entries.contains("demo/dmzr/helm/chart/Chart.yaml"));
        assertTrue(entries.contains("demo/dmzr/helm/values-dev.yaml"));
    }

    @Test
    void generatesPythonPoetryZip() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "poetry", "python", "",
                "com.example", "service", "service", "Python service",
                "com.example.service", "wheel", "3.12",
                List.of("fastapi", "uvicorn", "pydantic", "py-pytest"),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("service/pyproject.toml"));
        assertTrue(entries.contains("service/src/com_example_service/__init__.py"));
        assertTrue(entries.contains("service/src/com_example_service/main.py"));
        assertTrue(entries.contains("service/tests/test_smoke.py"));
        assertTrue(entries.contains("service/README.md"));
    }

    @Test
    void generatesPythonPipZipWithPostgres() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "pip", "python", "",
                "com.example", "api", "api", "API",
                "com.example.api", "wheel", "3.11",
                List.of("fastapi", "uvicorn", "sqlalchemy"),
                new DatabaseConfig("postgresql", "", "postgres", "secret", "update"),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("api/requirements.txt"));
        assertTrue(entries.contains("api/setup.py"));
    }

    private Set<String> unzip(byte[] zipBytes) throws Exception {
        Set<String> entries = new HashSet<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) entries.add(e.getName());
        }
        return entries;
    }
}
