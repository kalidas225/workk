import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StarterApiService } from './services/starter-api.service';
import {
  DATABASE_OPTIONS,
  DDL_AUTO_OPTIONS,
  Dependency,
  DependencyCategory,
  LanguageMetadata,
  MetadataResponse,
  ProjectRequest,
  buildTypeLabel,
  packagingLabel
} from './models/metadata.model';

interface FormState {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
  dbType: string;
  dbUrl: string;
  dbUsername: string;
  dbPassword: string;
  dbDdlAuto: string;
  // Env section
  envEnabled: boolean;
  envSelected: string[];                 // subset of [dev,ist,uat,ppd,prod]
  envConfigServerUrl: string;
  envConfigServerProfile: string;
  // DMZR section
  dmzrEnabled: boolean;
  dmzrVaultPolicies: boolean;
  dmzrHelmChart: boolean;
  dmzrVaultRole: string;
  dmzrVaultSecretPath: string;
  dmzrK8sNamespace: string;
  dmzrDockerImage: string;
  dmzrEnvironments: string[];
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  metadata = signal<MetadataResponse | null>(null);
  loading = signal(false);
  generating = signal(false);
  errorMessage = signal<string | null>(null);
  successMessage = signal<string | null>(null);

  readonly DATABASE_OPTIONS = DATABASE_OPTIONS;
  readonly DDL_AUTO_OPTIONS = DDL_AUTO_OPTIONS;
  readonly buildTypeLabel = buildTypeLabel;
  readonly packagingLabel = packagingLabel;

  // OS-aware shortcut modifier label: "⌘" on Mac, "Ctrl" elsewhere.
  readonly modKeyLabel = signal<string>(this.detectModKey());

  form = signal<FormState>({
    type: 'maven',
    language: 'java',
    bootVersion: '3.3.5',
    groupId: 'com.example',
    artifactId: 'demo',
    name: 'demo',
    description: 'Demo project for Spring Boot',
    packageName: 'com.example.demo',
    packaging: 'jar',
    javaVersion: '21',
    dbType: 'none',
    dbUrl: '',
    dbUsername: '',
    dbPassword: '',
    dbDdlAuto: 'update',
    envEnabled: false,
    envSelected: ['dev'],
    envConfigServerUrl: '',
    envConfigServerProfile: 'dev',
    dmzrEnabled: false,
    dmzrVaultPolicies: true,
    dmzrHelmChart: true,
    dmzrVaultRole: '',
    dmzrVaultSecretPath: '',
    dmzrK8sNamespace: 'default',
    dmzrDockerImage: '',
    dmzrEnvironments: ['dev', 'prod']
  });

  selectedIds = signal<Set<string>>(new Set());

  modalOpen = signal(false);
  summaryOpen = signal(false);
  searchQuery = signal('');
  highlightedIndex = signal(0);

  private packageNameTouched = false;
  private nameTouched = false;
  private dbUrlTouched = false;
  private dbUsernameTouched = false;

  constructor(private api: StarterApiService) {}

  // ===== language-aware metadata accessors =====
  activeLanguage = computed<LanguageMetadata | null>(() => {
    const meta = this.metadata();
    if (!meta) return null;
    return meta.languageMetadata.find(l => l.id === this.form().language) ?? meta.languageMetadata[0];
  });

  buildTypes = computed<string[]>(() => this.activeLanguage()?.buildTypes ?? []);
  runtimeVersions = computed<string[]>(() => this.activeLanguage()?.runtimeVersions ?? []);
  packagings = computed<string[]>(() => this.activeLanguage()?.packagings ?? []);
  frameworkVersions = computed<string[]>(() => this.activeLanguage()?.frameworkVersions ?? []);
  dependencyCatalog = computed<DependencyCategory[]>(() => this.activeLanguage()?.dependencies ?? []);

  isJava = computed<boolean>(() => this.form().language === 'java');
  isPython = computed<boolean>(() => this.form().language === 'python');

  selectedDeps = computed<Dependency[]>(() => {
    const ids = this.selectedIds();
    const cats = this.dependencyCatalog();
    const flat: Dependency[] = [];
    for (const c of cats) for (const d of c.dependencies) if (ids.has(d.id)) flat.push(d);
    return flat;
  });

  ngOnInit(): void { this.loadMetadata(); }

  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent) {
    const isMod = e.ctrlKey || e.metaKey;
    if (isMod && e.key === 'Enter') { e.preventDefault(); this.generate(); return; }
    if (isMod && e.key.toLowerCase() === 'b') { e.preventDefault(); this.openDependencyModal(); return; }
    if (this.modalOpen()) {
      if (e.key === 'Escape') { this.closeDependencyModal(); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); this.moveHighlight(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.moveHighlight(-1); }
      else if (e.key === 'Enter') {
        e.preventDefault();
        const flat = this.filteredDepsFlat();
        const i = this.highlightedIndex();
        if (flat[i]) this.toggleDependency(flat[i].id);
      }
    }
    if (this.summaryOpen() && e.key === 'Escape') this.summaryOpen.set(false);
  }

  // ===== OS detection =====
  private detectModKey(): string {
    if (typeof navigator === 'undefined') return 'Ctrl';
    const ua = (navigator.userAgent || '').toLowerCase();
    const platform = ((navigator as any).platform || '').toLowerCase();
    const isMac = /mac|iphone|ipad|ipod/.test(platform) || /mac os x|macintosh/.test(ua);
    return isMac ? '⌘' : 'Ctrl';
  }

  loadMetadata(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.api.getMetadata().subscribe({
      next: (meta) => {
        this.metadata.set(meta);
        // Pick default language and seed form from its defaults
        const defLang = meta.languageMetadata.find(l => l.id === meta.defaultLanguage) ?? meta.languageMetadata[0];
        this.applyLanguageDefaults(defLang);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMessage.set('Could not reach the backend. Is the server running on http://localhost:8080 ?');
        console.error(err);
      }
    });
  }

  private applyLanguageDefaults(lang: LanguageMetadata) {
    const d = lang.defaults;
    this.form.update(f => ({
      ...f,
      language: lang.id,
      type: d.type,
      bootVersion: d.bootVersion,
      groupId: d.groupId,
      artifactId: d.artifactId,
      name: d.name,
      description: d.description,
      packageName: d.packageName,
      packaging: d.packaging,
      javaVersion: d.javaVersion
    }));
    this.selectedIds.set(new Set());
  }

  reset(): void {
    const meta = this.metadata();
    if (!meta) return;
    const lang = meta.languageMetadata.find(l => l.id === meta.defaultLanguage) ?? meta.languageMetadata[0];
    this.applyLanguageDefaults(lang);
    this.form.update(f => ({
      ...f,
      dbType: 'none', dbUrl: '', dbUsername: '', dbPassword: '', dbDdlAuto: 'update',
      envEnabled: false, envSelected: ['dev'], envConfigServerUrl: '', envConfigServerProfile: 'dev',
      dmzrEnabled: false, dmzrVaultPolicies: true, dmzrHelmChart: true,
      dmzrVaultRole: '', dmzrVaultSecretPath: '', dmzrK8sNamespace: 'default',
      dmzrDockerImage: '', dmzrEnvironments: ['dev', 'prod']
    }));
    this.packageNameTouched = false;
    this.nameTouched = false;
    this.dbUrlTouched = false;
    this.dbUsernameTouched = false;
    this.errorMessage.set(null);
    this.successMessage.set(null);
  }

  changeLanguage(newLang: string): void {
    const meta = this.metadata();
    if (!meta) return;
    const lang = meta.languageMetadata.find(l => l.id === newLang);
    if (!lang) return;
    // Reset env config when switching to python (not supported there)
    if (newLang !== 'java') {
      this.form.update(f => ({ ...f, envEnabled: false }));
    }
    this.applyLanguageDefaults(lang);
  }

  updateForm<K extends keyof FormState>(field: K, value: FormState[K]) {
    this.form.update((f) => ({ ...f, [field]: value }));
    const f = this.form();
    if (field === 'groupId' || field === 'artifactId') {
      if (!this.packageNameTouched) {
        this.form.update((cur) => ({ ...cur, packageName: this.derivePackageName(f.groupId, f.artifactId) }));
      }
    }
    if (field === 'artifactId') {
      if (!this.nameTouched) {
        this.form.update((cur) => ({ ...cur, name: f.artifactId }));
      }
    }
  }

  onPackageNameInput(v: string) { this.packageNameTouched = true; this.updateForm('packageName', v); }
  onNameInput(v: string) { this.nameTouched = true; this.updateForm('name', v); }
  onDbUrlInput(v: string) { this.dbUrlTouched = true; this.updateForm('dbUrl', v); }
  onDbUsernameInput(v: string) { this.dbUsernameTouched = true; this.updateForm('dbUsername', v); }

  changeDatabaseType(newType: string): void {
    const opt = DATABASE_OPTIONS.find(o => o.id === newType);
    this.form.update(f => {
      const next = { ...f, dbType: newType };
      if (newType === 'none') {
        next.dbUrl = ''; next.dbUsername = ''; next.dbPassword = '';
        this.dbUrlTouched = false; this.dbUsernameTouched = false;
      } else if (opt) {
        if (!this.dbUrlTouched) {
          next.dbUrl = opt.defaultUrl.replace(/\/demo(\?|;|$)/, `/${f.artifactId}$1`);
        }
        if (!this.dbUsernameTouched) {
          next.dbUsername = opt.defaultUsername;
        }
      }
      return next;
    });
  }

  toggleEnvSelected(env: string): void {
    const cur = new Set(this.form().envSelected);
    if (cur.has(env)) cur.delete(env); else cur.add(env);
    this.form.update(f => ({ ...f, envSelected: Array.from(cur) }));
  }

  toggleDmzrEnv(env: string): void {
    const cur = new Set(this.form().dmzrEnvironments);
    if (cur.has(env)) cur.delete(env); else cur.add(env);
    this.form.update(f => ({ ...f, dmzrEnvironments: Array.from(cur) }));
  }

  isEnvSelected(env: string): boolean { return this.form().envSelected.includes(env); }
  isDmzrEnvSelected(env: string): boolean { return this.form().dmzrEnvironments.includes(env); }

  private derivePackageName(groupId: string, artifactId: string): string {
    const g = (groupId || '').toLowerCase().trim();
    const a = (artifactId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!g) return a;
    if (!a) return g;
    return `${g}.${a}`;
  }

  openDependencyModal(): void {
    this.modalOpen.set(true);
    this.searchQuery.set('');
    this.highlightedIndex.set(0);
    setTimeout(() => {
      const el = document.getElementById('dependency-search') as HTMLInputElement | null;
      el?.focus();
    }, 30);
  }
  closeDependencyModal(): void { this.modalOpen.set(false); }
  showSummary(): void { this.summaryOpen.set(true); }

  toggleDependency(id: string): void {
    const next = new Set(this.selectedIds());
    if (next.has(id)) next.delete(id); else next.add(id);
    this.selectedIds.set(next);
  }
  removeDependency(id: string): void {
    const next = new Set(this.selectedIds());
    next.delete(id);
    this.selectedIds.set(next);
  }
  isSelected(id: string): boolean { return this.selectedIds().has(id); }

  filteredCategories = computed<DependencyCategory[]>(() => {
    const cats = this.dependencyCatalog();
    const q = this.searchQuery().toLowerCase().trim();
    if (!q) return cats;
    const out: DependencyCategory[] = [];
    for (const cat of cats) {
      const deps = cat.dependencies.filter(d =>
        d.name.toLowerCase().includes(q) ||
        d.id.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q)
      );
      if (deps.length) out.push({ name: cat.name, dependencies: deps });
    }
    return out;
  });

  filteredDepsFlat(): Dependency[] {
    const flat: Dependency[] = [];
    for (const c of this.filteredCategories()) flat.push(...c.dependencies);
    return flat;
  }
  flatIndexOf(dep: Dependency): number {
    return this.filteredDepsFlat().findIndex(d => d.id === dep.id);
  }

  private moveHighlight(delta: number) {
    const flat = this.filteredDepsFlat();
    if (!flat.length) return;
    const i = this.highlightedIndex();
    const next = (i + delta + flat.length) % flat.length;
    this.highlightedIndex.set(next);
    setTimeout(() => {
      const el = document.querySelector(`[data-dep-index="${next}"]`);
      el?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, 0);
  }

  generate(): void {
    if (this.generating()) return;
    const errors = this.validate();
    if (errors.length) {
      this.errorMessage.set(errors.join('. '));
      return;
    }
    this.errorMessage.set(null);
    this.successMessage.set(null);
    this.generating.set(true);

    const f = this.form();
    const request: ProjectRequest = {
      type: f.type, language: f.language, bootVersion: f.bootVersion,
      groupId: f.groupId, artifactId: f.artifactId, name: f.name,
      description: f.description, packageName: f.packageName,
      packaging: f.packaging, javaVersion: f.javaVersion,
      dependencies: Array.from(this.selectedIds()),
      database: {
        type: f.dbType, url: f.dbUrl, username: f.dbUsername,
        password: f.dbPassword, ddlAuto: f.dbDdlAuto
      },
      environments: {
        enabled: f.envEnabled,
        environments: f.envSelected,
        configServerUrl: f.envConfigServerUrl,
        configServerProfile: f.envConfigServerProfile
      },
      dmzr: {
        enabled: f.dmzrEnabled,
        vaultPolicies: f.dmzrVaultPolicies,
        helmChart: f.dmzrHelmChart,
        vaultRole: f.dmzrVaultRole,
        vaultSecretPath: f.dmzrVaultSecretPath,
        kubernetesNamespace: f.dmzrK8sNamespace,
        dockerImage: f.dmzrDockerImage,
        environments: f.dmzrEnvironments
      }
    };

    this.api.generateProject(request).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${f.artifactId}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.generating.set(false);
        this.successMessage.set(`Downloaded ${f.artifactId}.zip`);
        setTimeout(() => this.successMessage.set(null), 4000);
      },
      error: (err) => {
        this.generating.set(false);
        let msg = 'Generation failed';
        if (err?.error instanceof Blob) {
          err.error.text().then((t: string) => {
            try { this.errorMessage.set(JSON.parse(t).message || msg); }
            catch { this.errorMessage.set(t || msg); }
          });
        } else if (err?.error?.message) {
          this.errorMessage.set(err.error.message);
        } else {
          this.errorMessage.set(msg);
        }
      }
    });
  }

  validate(): string[] {
    const f = this.form();
    const errors: string[] = [];
    if (!f.groupId || !/^[a-zA-Z][a-zA-Z0-9_.\-]*$/.test(f.groupId)) errors.push('Group is invalid');
    if (!f.artifactId || !/^[a-zA-Z][a-zA-Z0-9_\-]*$/.test(f.artifactId)) errors.push('Artifact is invalid');
    if (!f.packageName || !/^[a-zA-Z][a-zA-Z0-9_.]*$/.test(f.packageName)) errors.push('Package name is invalid');
    if (!f.name) errors.push('Name is required');
    if (f.language === 'java' && !f.bootVersion) errors.push('Spring Boot version is required for Java');
    if (f.envEnabled && f.envSelected.length === 0) errors.push('Pick at least one environment');
    if (f.dmzrEnabled && !f.dmzrVaultPolicies && !f.dmzrHelmChart) errors.push('Enable Vault policies or Helm chart for DMZR');
    return errors;
  }

  languageLabel(l: string): string { return l.charAt(0).toUpperCase() + l.slice(1); }
  databaseLabel(id: string): string { return DATABASE_OPTIONS.find(o => o.id === id)?.label ?? id; }
  hasDatabase(): boolean { return this.form().dbType !== 'none'; }
  hasJpa(): boolean { return this.selectedIds().has('data-jpa'); }
  hasFastapi(): boolean { return this.selectedIds().has('fastapi'); }

  trackById = (_: number, item: { id: string }) => item.id;
  trackByName = (_: number, item: { name: string }) => item.name;
  trackByValue = (_: number, item: string) => item;
}
