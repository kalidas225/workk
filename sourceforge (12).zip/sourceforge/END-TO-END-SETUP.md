# Sourceforge — End-to-End Setup (company JDK + Artifactory + Qwen LLM)

Everything is configurable; nothing company-specific is baked into the image.

## What you provide
1. Company JDK  -> backend/runtime/jdk/   (its cacerts already trusts Artifactory)
2. settings.xml -> backend/runtime/settings.xml   (Artifactory mirror + servers)
3. Qwen LLM endpoint (OpenAI-compatible) + API key   (the one you use via Roocode)

See backend/runtime/README.md for exact file layout.

## Run with Docker (recommended)
    cp .env.example .env          # fill in Artifactory creds + Qwen endpoint/key
    # place company JDK under backend/runtime/jdk/ and settings.xml at backend/runtime/settings.xml
    docker compose up --build
    # open http://localhost:8080

## Run locally (no Docker)
    cd backend
    export SOURCEFORGE_JAVA_HOME=$PWD/runtime/jdk
    export SOURCEFORGE_MAVEN_SETTINGS=$PWD/runtime/settings.xml
    export ARTIFACTORY_USER=...  ARTIFACTORY_TOKEN=...
    export SOURCEFORGE_LLM_ENABLED=true
    export SOURCEFORGE_LLM_PROVIDER=openai
    export SOURCEFORGE_LLM_BASE_URL=https://your-qwen-endpoint/v1
    export SOURCEFORGE_LLM_API_KEY=sk-...
    export SOURCEFORGE_LLM_MODEL=qwen2.5-coder
    mvn spring-boot:run
    # frontend: cd ../frontend && npm install && npm start  (proxies /api to :8080)

## How the pieces connect
- Full build ("MVN INSTALL" button / before generate): runs `mvn -B clean install
  -s <settings.xml>` with JAVA_HOME = company JDK. Because that JDK's cacerts
  trusts your Artifactory TLS, dependency downloads succeed with no cert import.
  The complete log streams live to the UI over SSE until BUILD SUCCESS.
- Python build: `poetry install` or `pip install . && python -m compileall`,
  matching the chosen build type; log streams the same way.
- Compatible-version dropdowns: backend calls your Qwen endpoint
  (OpenAI-compatible /v1/chat/completions, Bearer auth). Key stays server-side.
  If the LLM is unreachable/disabled, the static version catalog is used.

## LLM = Qwen via OpenAI-compatible API (as used in Roocode)
provider=openai means the client posts to {base-url}/chat/completions with
Authorization: Bearer {api-key} and {"model": "...", "messages": [...]} — the
same shape Roocode uses. Set base-url/api-key/model to your Qwen gateway.

## Local toolchain resolution (Mac / Windows / Linux)
The full build uses your local JDK and Maven automatically, in this order:

  Maven : sourceforge.build.maven-home  ->  MAVEN_HOME / M2_HOME env  ->  mvn on PATH
  JDK   : sourceforge.build.java-home   ->  JAVA_HOME env             ->  java on PATH

So if you already have JAVA_HOME and MAVEN_HOME (or M2_HOME) set in your shell,
no extra configuration is needed — just run the backend from that shell. The
executable names are OS-correct (mvn.cmd / java.exe on Windows).

If a tool is missing, the build log shows exactly what was checked and how to fix
it, for example:
  [sourceforge] ERROR: Maven was not found.
  [sourceforge] Looked in: sourceforge.build.maven-home, the MAVEN_HOME / M2_HOME
                environment variables, and PATH.
  [sourceforge] Fix: install Maven and either add it to PATH, or set MAVEN_HOME
                (e.g. /opt/apache-maven-3.9.9), then restart this server.

## LLM timeouts (if you see connection timeouts)
The Qwen/OpenAI-compatible call has configurable timeouts:
  SOURCEFORGE_LLM_CONNECT_TIMEOUT=10    # seconds to establish the connection
  SOURCEFORGE_LLM_REQUEST_TIMEOUT=60    # seconds to wait for the full response
Raise request-timeout if your gateway/model is slow. On any timeout the version
dropdowns still work from the built-in catalog, and the UI shows a small amber
note explaining the fallback (e.g. "The LLM did not respond in time"). Check
/api/llm-status for the current reason. Common causes: wrong base-url, gateway
not reachable from the server, or a proxy/firewall between the backend and the
LLM endpoint.

## Version-aware toolchain (this is how JDK/Maven get picked)
- Selecting Java 17/21/25/26 in the UI runs the build with backend/runtime/jdk/jdk-<that version>
  as JAVA_HOME. Its cacerts trusts Artifactory, so no cert import.
- Maven is chosen from backend/runtime/maven/ by Boot+Java compatibility: Spring
  Boot 3.5+/4.x (and Java 25+) use Maven 3.9+; otherwise the newest available.
- The live log shows the choices, e.g.:
    [sourceforge] Maven 3.9.9 selected for Boot 4.0.6 / Java 21
    [sourceforge] JDK (runtime/jdk for Java 21): /app/runtime/jdk/jdk-21
- Default Maven group for new projects: com.bnpparibas.cib2s

## LLM request shape (matches your company client)
provider=openai posts to {base-url}{chat-endpoint} (default /chat/completions) with
  Authorization: Bearer {api-key}
  { "model": <model>, "messages": [{"role":"user","content": <prompt>}],
    "temperature": 0.2, "max_tokens": 128000 }
and reads choices[0].message.content — identical to the generateText() method you
provided. Tune with SOURCEFORGE_LLM_TEMPERATURE / SOURCEFORGE_LLM_MAX_TOKENS /
SOURCEFORGE_LLM_CHAT_ENDPOINT. On timeout the dropdowns fall back to the built-in
catalog and the UI shows the reason.
