package com.sourceforge.starter;

import com.sourceforge.starter.model.DatabaseConfig;
import com.sourceforge.starter.model.CosConfig;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.EnvironmentSetting;
import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.ProjectGeneratorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ProjectGeneratorServiceTests {

    @Autowired
    ProjectGeneratorService generator;

    @Test
    void generatesJavaMavenZipWithEnvAndChart() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21", "standard",
                List.of("web", "data-jpa", "lombok"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("h2", "", "sa", "", "update"),
                new EnvironmentConfig(true, List.of("dev", "ist", "prod"), "https://config.example.com", "dev",
                        Map.of("prod", new EnvironmentSetting("UPM_BP2S/BP2SPROD/EC002I009999", "kubernetes_ku002i000844", "ns000999888"))),
                DmzrConfig.disabled(),
                "ap25701", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        assertNotNull(zip);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("demo/pom.xml"));
        assertTrue(entries.contains("demo/src/main/java/com/example/demo/DemoApplication.java"));
        assertTrue(entries.contains("demo/src/main/resources/application.properties"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-dev.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-prod.yaml"));
        // unified chart/ folder
        assertTrue(entries.contains("demo/chart/Chart.yaml"));
        assertTrue(entries.contains("demo/chart/helmfile.yaml"));
        assertTrue(entries.contains("demo/chart/files/httpd.conf"));
        assertTrue(entries.contains("demo/chart/values-production.yaml"));
        // removed: no vault, no dmzr/helm, no .mvn
        assertTrue(entries.stream().noneMatch(e -> e.contains("/dmzr/")));
        assertTrue(entries.stream().noneMatch(e -> e.contains("/vault/")));
        assertTrue(entries.stream().noneMatch(e -> e.contains("/.mvn/")));
        Map<String, String> files = generator.buildFiles(req);
        String prod = files.get("demo/src/main/resources/bootstrap-prod.yaml");
        // bootstrap Vault namespace carries the ecosystem (long path)
        assertTrue(prod.contains("namespace: UPM_BP2S/BP2SPROD/EC002I009999"));
        assertTrue(prod.contains("kubernetes_ku002i000844"));
        // chart deployment namespace is the short ns-id
        assertTrue(files.get("demo/chart/values-production.yaml").contains("namespace: ns000999888"));
        assertTrue(files.get("demo/chart/values-production.yaml").contains("ecosystem: UPM_BP2S/BP2SPROD/EC002I009999"));
        // removed blocks
        assertTrue(!prod.contains("jks-content"));
        assertTrue(!prod.contains("logback-"));
    }

    @Test
    void generatesPythonPoetryZip() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "poetry", "python", "",
                "com.example", "service", "service", "Python service",
                "com.example.service", "wheel", "3.12", "standard",
                List.of("fastapi", "uvicorn", "pydantic", "py-pytest"),
                Map.of(),
                Map.of(),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("service/pyproject.toml"));
        assertTrue(entries.contains("service/src/com_example_service/__init__.py"));
        assertTrue(entries.contains("service/src/com_example_service/main.py"));
        assertTrue(entries.contains("service/tests/test_smoke.py"));
        assertTrue(entries.contains("service/README.md"));
    }

    @Test
    void generatesPythonPipZipWithPostgres() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "pip", "python", "",
                "com.example", "api", "api", "API",
                "com.example.api", "wheel", "3.11", "standard",
                List.of("fastapi", "uvicorn", "sqlalchemy"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("postgresql", "", "postgres", "secret", "update"),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("api/requirements.txt"));
        assertTrue(entries.contains("api/setup.py"));
    }

    @Test
    void generatesMvcArchitectureSources() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "shop", "shop", "Shop",
                "com.example.shop", "jar", "21", "mvc",
                List.of(),
                Map.of(),
                Map.of(),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/controller/GreetingController.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/service/GreetingService.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/repository/GreetingRepository.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/model/Greeting.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/dto/GreetingRequest.java"));
    }

    @Test
    void appliesDependencyVersionAndEditedFileOverrides() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "vo", "vo", "Version override",
                "com.example.vo", "jar", "21", "standard",
                List.of("web"),
                Map.of("web", "9.9.9"),
                Map.of("vo/README.md", "# CUSTOM EDITED\n"),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        Map<String, String> files = generator.buildFiles(req);
        assertTrue(files.get("vo/pom.xml").contains("<version>9.9.9</version>"));
        assertTrue(files.get("vo/README.md").equals("# CUSTOM EDITED\n"));
    }

    @Test
    void generatesCosAndChartAssets() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "srs-back", "srs-back", "SRS Backend",
                "com.example.srsback", "jar", "21", "microservice",
                List.of("web", "data-jpa"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("oracle", "", "srs_user", "srs_pass", "none"),
                new EnvironmentConfig(true, List.of("dev", "prod"), "", "dev",
                        Map.of("dev", new EnvironmentSetting("UPM_BP2S/BP2SCLOUD/EC002I002789", "kubernetes_ku002i000843", "ns000123224",
                                        List.of("co002i007156", "co002i007157"),
                                        List.of("bu002i012751", "bu002i012752")))),
                DmzrConfig.disabled(),
                "ap10346",
                new CosConfig(true, List.of(), "s3.eu-de.cloud-object-storage.appdomain.cloud:4208", "")
        );
        Map<String, String> files = generator.buildFiles(req);
        String boot = files.get("srs-back/src/main/resources/bootstrap-dev.yaml");
        assertNotNull(boot);
        assertTrue(boot.contains("secret/ap10346/srs-back/dev"));
        // per-env COS: both instance objsto paths present
        assertTrue(boot.contains("objsto/co002i007156"));
        assertTrue(boot.contains("objsto/co002i007157"));
        // multiple buckets emitted as a list
        assertTrue(boot.contains("buckets:"));
        assertTrue(boot.contains("\"bu002i012751\""));
        assertTrue(boot.contains("\"bu002i012752\""));
        assertTrue(boot.contains("authentication: KUBERNETES"));
        // bootstrap Vault namespace carries the ecosystem (long path)
        assertTrue(boot.contains("namespace: UPM_BP2S/BP2SCLOUD/EC002I002789"));
        // removed blocks
        assertTrue(!boot.contains("jks-content"));
        assertTrue(!boot.contains("logback-"));
        // chart deployment namespace is the short ns-id, plus per-env COS
        String devVals = files.get("srs-back/chart/values-development.yaml");
        assertTrue(devVals.contains("namespace: ns000123224"));
        assertTrue(devVals.contains("ecosystem: UPM_BP2S/BP2SCLOUD/EC002I002789"));
        assertTrue(devVals.contains("bu002i012751"));
        // unified chart/ folder with files/ and templates/
        assertTrue(files.containsKey("srs-back/chart/Chart.yaml"));
        assertTrue(files.containsKey("srs-back/chart/helmfile.yaml"));
        assertTrue(files.containsKey("srs-back/chart/service-account.yaml"));
        assertTrue(files.containsKey("srs-back/chart/values-production.yaml"));
        assertTrue(files.containsKey("srs-back/chart/chart-dependencies.info"));
        assertTrue(files.containsKey("srs-back/chart/files/httpd.conf"));
        assertTrue(files.containsKey("srs-back/chart/templates/deployment.yaml"));
        assertTrue(files.get("srs-back/chart/files/httpd.conf").contains("ServerName"));
        assertTrue(files.containsKey("srs-back/Dockerfile"));
        assertTrue(files.get("srs-back/Dockerfile").contains("ENTRYPOINT [\"/usr/local/instances/srs-back/bin/entrypoint.sh\"]"));
        // removed: no vault, no dmzr, no .mvn, no gitkeep
        assertTrue(files.keySet().stream().noneMatch(k -> k.contains("/dmzr/")));
        assertTrue(files.keySet().stream().noneMatch(k -> k.contains("/vault/")));
        assertTrue(files.keySet().stream().noneMatch(k -> k.contains("/.mvn/")));
        assertTrue(files.keySet().stream().noneMatch(k -> k.endsWith(".gitkeep")));
    }

    private Set<String> unzip(byte[] zipBytes) throws Exception {
        Set<String> entries = new HashSet<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) entries.add(e.getName());
        }
        return entries;
    }
}
