package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

/**
 * Generates the Dockerfile (outside src) using the BNP UBI9 OpenJDK base image,
 * with the application name substituted from the request.
 */
@Component
public class DockerfileBuilder {

    public String build(ProjectRequest req) {
        String app = req.artifactId();          // e.g. sts-backend
        String desc = req.description() == null || req.description().isBlank()
                ? ("Microservice Application for " + app)
                : req.description();
        String runtimeTag = "17".equals(req.javaVersion()) ? "openjdk-17-runtime"
                : "21".equals(req.javaVersion()) ? "openjdk-21-runtime"
                : "openjdk-17-runtime"; // base catalog only ships 17/21 runtimes

        return ""
                + "FROM base-images-catalog.artifactory-dogen.group.echonet/ubi9/" + runtimeTag + ":1.24-2.1777025880\n\n"
                + "ARG OPEN_PREF\n\n"
                + "LABEL description=\"" + titleCase(app) + "\"\n"
                + "LABEL $OPEN_PREF.description=\"" + desc + "\"\n\n"
                + "ARG JAR_FILE=\"target/" + app + ".jar\"\n"
                + "ARG APPLI_NAME=\"" + app + "\"\n"
                + "ENV APP_NAME=${APPLI_NAME}\n"
                + "ARG PUID=5050\n"
                + "ARG PGID=5050\n\n"
                + "USER root\n\n"
                + "RUN groupadd -g ${PGID} web && \\\n"
                + "    useradd -u ${PUID} -g web -M -s /sbin/nologin webadmin && \\\n"
                + "    mkdir -p /usr/local/web \\\n"
                + "             /usr/local/applications \\\n"
                + "             /usr/local/instances/${APPLI_NAME}/{bin,conf,logs,ssjs} \\\n"
                + "             /usr/local/certs && \\\n"
                + "    chown -R webadmin:web /usr/local/\n\n"
                + "COPY ${JAR_FILE} /usr/local/applications/${APPLI_NAME}.jar\n"
                + "COPY entrypoint.sh /usr/local/instances/${APPLI_NAME}/bin/entrypoint.sh\n"
                + "COPY src/main/resources/logback.xml /usr/local/instances/${APPLI_NAME}/logs/logback.xml\n"
                + "COPY src/main/resources/ssjs /usr/local/instances/${APPLI_NAME}/ssjs\n\n"
                + "COPY 2014-2029-BNPP-Applications.cer $JAVA_HOME/lib/security/\n"
                + "COPY 2014-2044-BNPP-Root.cer $JAVA_HOME/lib/security/\n\n"
                + "RUN $JAVA_HOME/bin/keytool -import \\\n"
                + "        -file $JAVA_HOME/lib/security/2014-2029-BNPP-Applications.cer \\\n"
                + "        -alias bnpp-applications \\\n"
                + "        -keystore $JAVA_HOME/lib/security/cacerts \\\n"
                + "        -trustcacerts -storepass changeit -noprompt && \\\n"
                + "    $JAVA_HOME/bin/keytool -import \\\n"
                + "        -file $JAVA_HOME/lib/security/2014-2044-BNPP-Root.cer \\\n"
                + "        -alias bnpp-root \\\n"
                + "        -keystore $JAVA_HOME/lib/security/cacerts \\\n"
                + "        -trustcacerts -storepass changeit -noprompt\n\n"
                + "# Set file permissions\n"
                + "RUN chmod +x /usr/local/instances/${APPLI_NAME}/bin/entrypoint.sh && \\\n"
                + "    chmod 644 /usr/local/instances/${APPLI_NAME}/logs/logback.xml && \\\n"
                + "    chown -R webadmin:web /usr/local/applications \\\n"
                + "                          /usr/local/instances \\\n"
                + "                          /usr/local/web\n\n"
                + "EXPOSE 8080\n\n"
                + "USER webadmin:web\n\n"
                + "ENTRYPOINT [\"/usr/local/instances/" + app + "/bin/entrypoint.sh\"]\n";
    }

    public String entrypointSh(ProjectRequest req) {
        String app = req.artifactId();
        return ""
                + "#!/bin/sh\n"
                + "# entrypoint.sh for " + app + "\n"
                + "set -e\n\n"
                + "JAR=/usr/local/applications/${APP_NAME}.jar\n"
                + "PROFILE=${SPRING_PROFILES_ACTIVE:-dev}\n\n"
                + "exec java \\\n"
                + "  -Dspring.profiles.active=${PROFILE} \\\n"
                + "  -Dlogging.config=/usr/local/instances/${APP_NAME}/logs/logback.xml \\\n"
                + "  ${JAVA_OPTS} \\\n"
                + "  -jar ${JAR}\n";
    }

    private String titleCase(String app) {
        StringBuilder sb = new StringBuilder();
        boolean cap = true;
        for (char c : app.toCharArray()) {
            if (c == '-' || c == '_') { sb.append(' '); cap = true; }
            else if (cap) { sb.append(Character.toUpperCase(c)); cap = false; }
            else sb.append(c);
        }
        return sb.toString();
    }
}
