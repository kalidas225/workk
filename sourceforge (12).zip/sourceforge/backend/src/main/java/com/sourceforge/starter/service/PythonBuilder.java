package com.sourceforge.starter.service;

import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PythonBuilder {

    /** Build pyproject.toml for Poetry. */
    public String buildPoetryPyproject(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("[tool.poetry]\n");
        sb.append("name = \"").append(req.artifactId()).append("\"\n");
        sb.append("version = \"0.1.0\"\n");
        sb.append("description = \"").append(escapeToml(req.description())).append("\"\n");
        sb.append("authors = [\"").append(escapeToml(req.groupId())).append("\"]\n");
        sb.append("readme = \"README.md\"\n");
        sb.append("packages = [{ include = \"").append(req.packageName().replace('.', '_')).append("\", from = \"src\" }]\n\n");

        sb.append("[tool.poetry.dependencies]\n");
        sb.append("python = \"^").append(req.javaVersion()).append("\"\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append(d.artifactId()).append(" = \"").append(d.version() != null ? d.version() : "*").append("\"\n");
        }

        List<Dependency> devDeps = devDeps(deps);
        if (!devDeps.isEmpty()) {
            sb.append("\n[tool.poetry.group.dev.dependencies]\n");
            for (Dependency d : devDeps) {
                sb.append(d.artifactId()).append(" = \"").append(d.version() != null ? d.version() : "*").append("\"\n");
            }
        }

        sb.append("\n[build-system]\n");
        sb.append("requires = [\"poetry-core>=1.0.0\"]\n");
        sb.append("build-backend = \"poetry.core.masonry.api\"\n\n");

        // Tool configs that play nicely if user picked them
        if (deps.stream().anyMatch(d -> "py-ruff".equals(d.id()))) {
            sb.append("[tool.ruff]\nline-length = 100\ntarget-version = \"py").append(pyTarget(req)).append("\"\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-black".equals(d.id()))) {
            sb.append("[tool.black]\nline-length = 100\ntarget-version = [\"py").append(pyTarget(req)).append("\"]\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-mypy".equals(d.id()))) {
            sb.append("[tool.mypy]\npython_version = \"").append(req.javaVersion()).append("\"\nstrict = true\n\n");
        }
        if (deps.stream().anyMatch(d -> "py-pytest".equals(d.id()))) {
            sb.append("[tool.pytest.ini_options]\ntestpaths = [\"tests\"]\nasyncio_mode = \"auto\"\n");
        }
        return sb.toString();
    }

    /** Build requirements.txt for pip-based projects. */
    public String buildRequirementsTxt(List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Runtime dependencies\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Build requirements-dev.txt for pip-based projects with dev tools. */
    public String buildRequirementsDevTxt(List<Dependency> deps) {
        List<Dependency> devDeps = devDeps(deps);
        if (devDeps.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("-r requirements.txt\n\n");
        sb.append("# Development dependencies\n");
        for (Dependency d : devDeps) {
            sb.append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Minimal setup.py for pip-style projects (gives `pip install -e .` support). */
    public String buildSetupPy(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("from setuptools import setup, find_packages\n\n");
        sb.append("setup(\n");
        sb.append("    name=\"").append(req.artifactId()).append("\",\n");
        sb.append("    version=\"0.1.0\",\n");
        sb.append("    description=\"").append(req.description().replace("\"", "\\\"")).append("\",\n");
        sb.append("    package_dir={\"\": \"src\"},\n");
        sb.append("    packages=find_packages(where=\"src\"),\n");
        sb.append("    python_requires=\">=").append(req.javaVersion()).append("\",\n");
        sb.append("    install_requires=[\n");
        for (Dependency d : runtimeDeps(deps)) {
            sb.append("        \"").append(d.artifactId());
            if (d.version() != null && !d.version().isBlank()) {
                sb.append(toPipVersion(d.version()));
            }
            sb.append("\",\n");
        }
        sb.append("    ],\n");
        sb.append(")\n");
        return sb.toString();
    }

    /** Main module — different per framework. */
    public String buildMainModule(ProjectRequest req, List<Dependency> deps) {
        boolean fastapi = deps.stream().anyMatch(d -> "fastapi".equals(d.id()));
        boolean flask   = deps.stream().anyMatch(d -> "flask".equals(d.id()));

        if (fastapi) {
            return ""
                    + "\"\"\"" + req.name() + " — main entry point.\"\"\"\n"
                    + "from fastapi import FastAPI\n\n"
                    + "app = FastAPI(title=\"" + req.name() + "\", description=\"" + escapeQuotes(req.description()) + "\")\n\n"
                    + "@app.get(\"/\")\n"
                    + "def root() -> dict[str, str]:\n"
                    + "    return {\"message\": \"Hello from " + req.name() + "\"}\n\n"
                    + "@app.get(\"/healthz\")\n"
                    + "def healthz() -> dict[str, str]:\n"
                    + "    return {\"status\": \"ok\"}\n";
        }
        if (flask) {
            return ""
                    + "\"\"\"" + req.name() + " — Flask app entry point.\"\"\"\n"
                    + "from flask import Flask\n\n"
                    + "app = Flask(__name__)\n\n"
                    + "@app.route(\"/\")\n"
                    + "def root():\n"
                    + "    return {\"message\": \"Hello from " + req.name() + "\"}\n\n"
                    + "@app.route(\"/healthz\")\n"
                    + "def healthz():\n"
                    + "    return {\"status\": \"ok\"}\n\n"
                    + "if __name__ == \"__main__\":\n"
                    + "    app.run(host=\"0.0.0.0\", port=8080)\n";
        }
        // Plain library / CLI
        return ""
                + "\"\"\"" + req.name() + " — main module.\"\"\"\n\n"
                + "def main() -> None:\n"
                + "    print(\"Hello from " + req.name() + "\")\n\n"
                + "if __name__ == \"__main__\":\n"
                + "    main()\n";
    }

    public String buildInitPy(ProjectRequest req) {
        return "\"\"\"" + req.name() + " package.\"\"\"\n__version__ = \"0.1.0\"\n";
    }

    /** A generated Python source file relative to the package dir. */
    public record PySourceFile(String relativePath, String content) {}

    /**
     * Architecture-specific Python modules. FastAPI-based router/service/repository
     * layering for "mvc"; adds an httpx-based client + settings for "microservice".
     * Returns empty for "standard".
     */
    public List<PySourceFile> architectureSources(ProjectRequest req) {
        if ("standard".equals(req.architecture())) return List.of();
        // The generator auto-adds FastAPI for any non-standard architecture, so the
        // FastAPI router is always generated for mvc/microservice projects.
        boolean fastapi = true;
        List<PySourceFile> files = new ArrayList<>();

        // Domain model (plain dataclass — no external deps required)
        files.add(new PySourceFile("models.py",
                "\"\"\"Domain models.\"\"\"\n" +
                "from dataclasses import dataclass\n" +
                "from typing import Optional\n\n\n" +
                "@dataclass\n" +
                "class Greeting:\n" +
                "    id: Optional[int]\n" +
                "    message: str\n"));

        // In-memory repository
        files.add(new PySourceFile("repository.py",
                "\"\"\"In-memory repository so the project runs without a database.\"\"\"\n" +
                "from typing import Optional\n\n" +
                "from .models import Greeting\n\n\n" +
                "class GreetingRepository:\n" +
                "    def __init__(self) -> None:\n" +
                "        self._store: dict[int, Greeting] = {}\n" +
                "        self._seq = 0\n\n" +
                "    def find_all(self) -> list[Greeting]:\n" +
                "        return list(self._store.values())\n\n" +
                "    def find_by_id(self, greeting_id: int) -> Optional[Greeting]:\n" +
                "        return self._store.get(greeting_id)\n\n" +
                "    def save(self, message: str) -> Greeting:\n" +
                "        self._seq += 1\n" +
                "        greeting = Greeting(id=self._seq, message=message)\n" +
                "        self._store[self._seq] = greeting\n" +
                "        return greeting\n"));

        // Service layer
        files.add(new PySourceFile("service.py",
                "\"\"\"Business logic layer.\"\"\"\n" +
                "from typing import Optional\n\n" +
                "from .models import Greeting\n" +
                "from .repository import GreetingRepository\n\n\n" +
                "class GreetingService:\n" +
                "    def __init__(self, repository: GreetingRepository) -> None:\n" +
                "        self._repository = repository\n\n" +
                "    def find_all(self) -> list[Greeting]:\n" +
                "        return self._repository.find_all()\n\n" +
                "    def find_by_id(self, greeting_id: int) -> Optional[Greeting]:\n" +
                "        return self._repository.find_by_id(greeting_id)\n\n" +
                "    def create(self, message: str) -> Greeting:\n" +
                "        return self._repository.save(message)\n"));

        if (fastapi) {
            // Router wiring service + repository
            files.add(new PySourceFile("router.py",
                    "\"\"\"HTTP routes — presentation layer.\"\"\"\n" +
                    "from dataclasses import asdict\n\n" +
                    "from fastapi import APIRouter, HTTPException\n" +
                    "from pydantic import BaseModel\n\n" +
                    "from .repository import GreetingRepository\n" +
                    "from .service import GreetingService\n\n\n" +
                    "router = APIRouter(prefix=\"/api/greetings\", tags=[\"greetings\"])\n" +
                    "_service = GreetingService(GreetingRepository())\n\n\n" +
                    "class GreetingRequest(BaseModel):\n" +
                    "    message: str\n\n\n" +
                    "@router.get(\"\")\n" +
                    "def list_greetings() -> list[dict]:\n" +
                    "    return [asdict(g) for g in _service.find_all()]\n\n\n" +
                    "@router.get(\"/{greeting_id}\")\n" +
                    "def get_greeting(greeting_id: int) -> dict:\n" +
                    "    greeting = _service.find_by_id(greeting_id)\n" +
                    "    if greeting is None:\n" +
                    "        raise HTTPException(status_code=404, detail=\"Not found\")\n" +
                    "    return asdict(greeting)\n\n\n" +
                    "@router.post(\"\")\n" +
                    "def create_greeting(request: GreetingRequest) -> dict:\n" +
                    "    return asdict(_service.create(request.message))\n"));
        }

        if ("microservice".equals(req.architecture())) {
            files.add(new PySourceFile("settings.py",
                    "\"\"\"Externalised settings.\"\"\"\n" +
                    "import os\n\n\n" +
                    "class Settings:\n" +
                    "    downstream_url: str = os.getenv(\"APP_DOWNSTREAM_URL\", \"http://localhost:9090\")\n\n\n" +
                    "settings = Settings()\n"));

            files.add(new PySourceFile("client.py",
                    "\"\"\"Outbound client to a downstream service.\"\"\"\n" +
                    "import urllib.request\n\n" +
                    "from .settings import settings\n\n\n" +
                    "def fetch_status() -> str:\n" +
                    "    try:\n" +
                    "        with urllib.request.urlopen(f\"{settings.downstream_url}/status\", timeout=2) as resp:\n" +
                    "            return resp.read().decode(\"utf-8\")\n" +
                    "    except Exception:\n" +
                    "        # Downstream not reachable in local dev — degrade gracefully.\n" +
                    "        return \"unknown\"\n"));
        }

        return files;
    }

    /** Main module that wires the architecture router when present. */
    public String buildArchitectureMain(ProjectRequest req) {
        // Generator guarantees FastAPI is present for non-standard architectures.
        boolean fastapi = true;
        String pkg = req.packageName().replace('.', '_');
        if (fastapi) {
            StringBuilder sb = new StringBuilder();
            sb.append("\"\"\"").append(req.name()).append(" — main entry point.\"\"\"\n");
            sb.append("from fastapi import FastAPI\n\n");
            sb.append("from .router import router\n");
            if ("microservice".equals(req.architecture())) {
                sb.append("from .client import fetch_status\n");
            }
            sb.append("\napp = FastAPI(title=\"").append(req.name()).append("\")\n");
            sb.append("app.include_router(router)\n\n");
            sb.append("@app.get(\"/healthz\")\n");
            sb.append("def healthz() -> dict[str, str]:\n");
            sb.append("    return {\"status\": \"ok\"}\n");
            if ("microservice".equals(req.architecture())) {
                sb.append("\n@app.get(\"/api/status\")\n");
                sb.append("def status() -> dict[str, str]:\n");
                sb.append("    return {\"service\": \"UP\", \"downstream\": fetch_status()}\n");
            }
            return sb.toString();
        }
        // Non-FastAPI: a simple main that exercises the service layer
        return "\"\"\"" + req.name() + " — main module.\"\"\"\n" +
                "from .repository import GreetingRepository\n" +
                "from .service import GreetingService\n\n\n" +
                "def main() -> None:\n" +
                "    service = GreetingService(GreetingRepository())\n" +
                "    created = service.create(\"Hello from " + req.name() + "\")\n" +
                "    print(created)\n\n\n" +
                "if __name__ == \"__main__\":\n" +
                "    main()\n";
    }

    public String buildTestModule(ProjectRequest req, List<Dependency> deps) {
        boolean fastapi = deps.stream().anyMatch(d -> "fastapi".equals(d.id()));
        boolean flask   = deps.stream().anyMatch(d -> "flask".equals(d.id()));

        if (fastapi) {
            return ""
                    + "\"\"\"Smoke tests.\"\"\"\n"
                    + "from fastapi.testclient import TestClient\n"
                    + "from " + req.packageName().replace('.', '_') + ".main import app\n\n"
                    + "client = TestClient(app)\n\n"
                    + "def test_root():\n"
                    + "    r = client.get(\"/\")\n"
                    + "    assert r.status_code == 200\n";
        }
        if (flask) {
            return ""
                    + "\"\"\"Smoke tests.\"\"\"\n"
                    + "from " + req.packageName().replace('.', '_') + ".main import app\n\n"
                    + "def test_root():\n"
                    + "    with app.test_client() as c:\n"
                    + "        r = c.get(\"/\")\n"
                    + "        assert r.status_code == 200\n";
        }
        return ""
                + "def test_smoke():\n"
                + "    assert 1 + 1 == 2\n";
    }

    public String buildGitignore() {
        return ""
                + "# Byte-compiled / optimized / DLL files\n"
                + "__pycache__/\n*.py[cod]\n*$py.class\n\n"
                + "# Distribution / packaging\n"
                + "build/\ndist/\n*.egg-info/\n.eggs/\n\n"
                + "# Virtual environments\n"
                + ".venv/\nvenv/\nenv/\n\n"
                + "# Testing & coverage\n"
                + ".pytest_cache/\n.coverage\nhtmlcov/\n\n"
                + "# Type checkers\n"
                + ".mypy_cache/\n.ruff_cache/\n\n"
                + "# IDE\n.idea/\n.vscode/\n*.iml\n\n"
                + "# OS\n.DS_Store\nThumbs.db\n";
    }

    public String buildPythonReadme(ProjectRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(req.name()).append("\n\n");
        if (!req.description().isBlank()) sb.append(req.description()).append("\n\n");
        sb.append("Generated with the Sourceforge.\n\n");
        sb.append("## Setup\n\n");
        if ("poetry".equals(req.type())) {
            sb.append("```bash\npoetry install\npoetry run python -m ").append(req.packageName().replace('.', '_')).append(".main\n```\n\n");
        } else {
            sb.append("```bash\npython -m venv .venv && source .venv/bin/activate\npip install -r requirements.txt\npython -m ").append(req.packageName().replace('.', '_')).append(".main\n```\n\n");
        }
        sb.append("## Run tests\n\n```bash\n");
        if ("poetry".equals(req.type())) sb.append("poetry run pytest\n");
        else                              sb.append("pytest\n");
        sb.append("```\n");
        return sb.toString();
    }

    // ===== helpers =====
    private List<Dependency> runtimeDeps(List<Dependency> deps) {
        List<Dependency> out = new ArrayList<>();
        for (Dependency d : deps) {
            if (!"dev".equals(d.scope())) out.add(d);
        }
        return out;
    }

    private List<Dependency> devDeps(List<Dependency> deps) {
        List<Dependency> out = new ArrayList<>();
        for (Dependency d : deps) {
            if ("dev".equals(d.scope())) out.add(d);
        }
        return out;
    }

    /** Convert poetry-style version ("^0.115.0", "*") to pip-style (">=0.115.0,<0.116.0"). */
    private String toPipVersion(String v) {
        if (v == null || v.isBlank() || "*".equals(v)) return "";
        if (v.startsWith("^")) {
            String bare = v.substring(1);
            return ">=" + bare;
        }
        if (v.startsWith("~")) return ">=" + v.substring(1);
        if (v.startsWith(">=") || v.startsWith("<=") || v.startsWith("==") || v.startsWith(">") || v.startsWith("<")) {
            return v;
        }
        return "==" + v;
    }

    private String pyTarget(ProjectRequest req) {
        // "3.12" -> "312"
        return req.javaVersion().replace(".", "");
    }

    private String escapeToml(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String escapeQuotes(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
