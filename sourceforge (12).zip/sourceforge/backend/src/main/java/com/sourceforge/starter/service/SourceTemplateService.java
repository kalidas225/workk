package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

@Component
public class SourceTemplateService {

    public String mainClass(ProjectRequest req) {
        String className = toClassName(req.artifactId()) + "Application";
        return switch (req.language()) {
            case "kotlin" -> kotlinMain(req, className);
            case "groovy" -> groovyMain(req, className);
            default -> javaMain(req, className);
        };
    }

    public String testClass(ProjectRequest req) {
        String className = toClassName(req.artifactId()) + "ApplicationTests";
        return switch (req.language()) {
            case "kotlin" -> kotlinTest(req, className);
            case "groovy" -> groovyTest(req, className);
            default -> javaTest(req, className);
        };
    }

    public String mainClassName(ProjectRequest req) {
        return toClassName(req.artifactId()) + "Application";
    }

    public String testClassName(ProjectRequest req) {
        return toClassName(req.artifactId()) + "ApplicationTests";
    }

    public String applicationProperties(ProjectRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("spring.application.name=").append(req.artifactId()).append("\n");
        sb.append("server.port=8080\n");

        var db = req.database();
        if (db != null && !"none".equals(db.type())) {
            sb.append("\n# ===== Datasource =====\n");
            String url = db.url();
            if (url == null || url.isBlank()) {
                url = defaultJdbcUrl(db.type(), req.artifactId());
            }
            sb.append("spring.datasource.url=").append(url).append("\n");
            if (db.username() != null && !db.username().isBlank()) {
                sb.append("spring.datasource.username=").append(db.username()).append("\n");
            }
            if (db.password() != null && !db.password().isBlank()) {
                sb.append("spring.datasource.password=").append(db.password()).append("\n");
            }
            String driver = jdbcDriverClass(db.type());
            if (driver != null) {
                sb.append("spring.datasource.driver-class-name=").append(driver).append("\n");
            }
            // JPA / Hibernate settings — only emitted if data-jpa is selected; harmless otherwise
            if (req.dependencies() != null && req.dependencies().contains("data-jpa")) {
                sb.append("\n# ===== JPA / Hibernate =====\n");
                sb.append("spring.jpa.hibernate.ddl-auto=").append(db.ddlAuto()).append("\n");
                sb.append("spring.jpa.show-sql=true\n");
                String dialect = hibernateDialect(db.type());
                if (dialect != null) {
                    sb.append("spring.jpa.properties.hibernate.dialect=").append(dialect).append("\n");
                }
            }
            // H2 console — convenience
            if ("h2".equals(db.type())) {
                sb.append("\n# ===== H2 Console =====\n");
                sb.append("spring.h2.console.enabled=true\n");
                sb.append("spring.h2.console.path=/h2-console\n");
            }
        }
        return sb.toString();
    }

    public static String defaultJdbcUrl(String dbType, String artifactId) {
        return switch (dbType) {
            case "h2" -> "jdbc:h2:mem:" + artifactId + ";DB_CLOSE_DELAY=-1;MODE=PostgreSQL";
            case "postgresql" -> "jdbc:postgresql://localhost:5432/" + artifactId;
            case "mysql" -> "jdbc:mysql://localhost:3306/" + artifactId + "?useSSL=false&serverTimezone=UTC";
            case "oracle" -> "jdbc:oracle:thin:@localhost:1521:XE";
            case "mssql" -> "jdbc:sqlserver://localhost:1433;databaseName=" + artifactId + ";encrypt=false";
            default -> "";
        };
    }

    public static String jdbcDriverClass(String dbType) {
        return switch (dbType) {
            case "h2" -> "org.h2.Driver";
            case "postgresql" -> "org.postgresql.Driver";
            case "mysql" -> "com.mysql.cj.jdbc.Driver";
            case "oracle" -> "oracle.jdbc.OracleDriver";
            case "mssql" -> "com.microsoft.sqlserver.jdbc.SQLServerDriver";
            default -> null;
        };
    }

    public static String hibernateDialect(String dbType) {
        return switch (dbType) {
            case "h2" -> "org.hibernate.dialect.H2Dialect";
            case "postgresql" -> "org.hibernate.dialect.PostgreSQLDialect";
            case "mysql" -> "org.hibernate.dialect.MySQLDialect";
            case "oracle" -> "org.hibernate.dialect.OracleDialect";
            case "mssql" -> "org.hibernate.dialect.SQLServerDialect";
            default -> null;
        };
    }

    public String gitignore(String type) {
        boolean maven = "maven".equals(type);
        StringBuilder sb = new StringBuilder();
        sb.append("HELP.md\n");
        if (maven) {
            sb.append("target/\n");
            sb.append("!.mvn/wrapper/maven-wrapper.jar\n");
            sb.append("!**/src/main/**/target/\n");
            sb.append("!**/src/test/**/target/\n\n");
        } else {
            sb.append(".gradle\n");
            sb.append("build/\n");
            sb.append("!gradle/wrapper/gradle-wrapper.jar\n");
            sb.append("!**/src/main/**/build/\n");
            sb.append("!**/src/test/**/build/\n\n");
        }
        sb.append("### STS ###\n.apt_generated\n.classpath\n.factorypath\n.project\n.settings\n.springBeans\n.sts4-cache\n\n");
        sb.append("### IntelliJ IDEA ###\n.idea\n*.iws\n*.iml\n*.ipr\n\n");
        sb.append("### NetBeans ###\n/nbproject/private/\n/nbbuild/\n/dist/\n/nbdist/\n/.nb-gradle/\nbuild/\n!**/src/main/**/build/\n!**/src/test/**/build/\n\n");
        sb.append("### VS Code ###\n.vscode/\n");
        return sb.toString();
    }

    public String readme(ProjectRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(req.name()).append("\n\n");
        if (req.description() != null && !req.description().isBlank()) {
            sb.append(req.description()).append("\n\n");
        }
        sb.append("Generated with the Sourceforge.\n\n");
        sb.append("## Quick Start\n\n");
        if ("maven".equals(req.type())) {
            sb.append("```bash\n./mvnw spring-boot:run\n```\n\n");
        } else {
            sb.append("```bash\n./gradlew bootRun\n```\n\n");
        }
        sb.append("## Build\n\n");
        if ("maven".equals(req.type())) {
            sb.append("```bash\n./mvnw clean package\n```\n");
        } else {
            sb.append("```bash\n./gradlew build\n```\n");
        }
        return sb.toString();
    }

    // --- Java templates ---
    private String javaMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + ";\n\n" +
                "import org.springframework.boot.SpringApplication;\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication;\n\n" +
                "@SpringBootApplication\n" +
                "public class " + className + " {\n\n" +
                "    public static void main(String[] args) {\n" +
                "        SpringApplication.run(" + className + ".class, args);\n" +
                "    }\n" +
                "}\n";
    }

    private String javaTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + ";\n\n" +
                "import org.junit.jupiter.api.Test;\n" +
                "import org.springframework.boot.test.context.SpringBootTest;\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    void contextLoads() {\n" +
                "    }\n\n" +
                "}\n";
    }

    private String kotlinMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication\n" +
                "import org.springframework.boot.runApplication\n\n" +
                "@SpringBootApplication\n" +
                "class " + className + "\n\n" +
                "fun main(args: Array<String>) {\n" +
                "    runApplication<" + className + ">(*args)\n" +
                "}\n";
    }

    private String kotlinTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.junit.jupiter.api.Test\n" +
                "import org.springframework.boot.test.context.SpringBootTest\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    fun contextLoads() {\n" +
                "    }\n" +
                "}\n";
    }

    private String groovyMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.springframework.boot.SpringApplication\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication\n\n" +
                "@SpringBootApplication\n" +
                "class " + className + " {\n\n" +
                "    static void main(String[] args) {\n" +
                "        SpringApplication.run(" + className + ", args)\n" +
                "    }\n" +
                "}\n";
    }

    private String groovyTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.junit.jupiter.api.Test\n" +
                "import org.springframework.boot.test.context.SpringBootTest\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    void contextLoads() {\n" +
                "    }\n" +
                "}\n";
    }

    private static String toClassName(String artifactId) {
        StringBuilder sb = new StringBuilder();
        boolean upper = true;
        for (char c : artifactId.toCharArray()) {
            if (c == '-' || c == '_' || c == '.') {
                upper = true;
                continue;
            }
            if (upper) {
                sb.append(Character.toUpperCase(c));
                upper = false;
            } else {
                sb.append(c);
            }
        }
        if (sb.length() == 0) return "Application";
        return sb.toString();
    }
}
