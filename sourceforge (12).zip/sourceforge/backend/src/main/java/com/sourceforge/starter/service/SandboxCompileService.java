package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.ToolProvider;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Compiles the generated Java sources in-memory using the JDK's built-in
 * compiler (javac via the Java Compiler API), returning structured diagnostics
 * so the UI can show precise, fixable error messages before download.
 *
 * Notes / honest scope:
 *  - This performs a real javac compile of the generated *.java sources. It
 *    catches the mistakes users actually introduce when editing in Explore
 *    (syntax errors, type errors, undefined symbols, bad signatures).
 *  - It compiles against the classpath available to the running server. Symbols
 *    from Spring/third-party starters resolve only if those jars are on that
 *    classpath; otherwise such references are reported as "cannot find symbol".
 *    The UI labels these as informational so they aren't confused with real
 *    user errors. A full dependency-aware compile is delegated to Maven at build
 *    time in the generated project.
 */
@Service
public class SandboxCompileService {

    private static final Logger log = LoggerFactory.getLogger(SandboxCompileService.class);

    private final ProjectGeneratorService generator;

    public SandboxCompileService(ProjectGeneratorService generator) {
        this.generator = generator;
    }

    public record CompileDiagnostic(String kind, String path, long line, long column, String message) {}

    public record CompileResult(boolean ok, boolean compilerAvailable,
                                int errorCount, int warningCount,
                                List<CompileDiagnostic> diagnostics, String summary) {}

    /** Build the project (honouring edits) and syntax/type-check its sources. */
    public CompileResult compile(ProjectRequest request) {
        Map<String, String> files = generator.buildFiles(request);
        if (request.isPython()) {
            return compilePython(files);
        }
        return compileJava(request, files);
    }

    /** Java: real javac via the Compiler API. */
    private CompileResult compileJava(ProjectRequest request, Map<String, String> files) {
        // Collect only Java sources under any src/main/java or src/test/java
        List<JavaFileObject> units = new ArrayList<>();
        for (var e : files.entrySet()) {
            String path = e.getKey();
            if (path.endsWith(".java")) {
                units.add(new InMemoryJavaSource(deriveClassUri(path), e.getValue()));
            }
        }
        if (units.isEmpty()) {
            return new CompileResult(true, true, 0, 0, List.of(), "No Java sources to compile.");
        }

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            log.warn("No system Java compiler available (JRE without JDK).");
            return new CompileResult(false, false, 0, 0, List.of(),
                    "Compiler not available on the server runtime.");
        }

        DiagnosticCollector<JavaFileObject> collector = new DiagnosticCollector<>();
        var fileManager = compiler.getStandardFileManager(collector, null, java.nio.charset.StandardCharsets.UTF_8);

        // Compile to nowhere: we only care about diagnostics, not output classes.
        List<String> options = List.of("-proc:none", "-implicit:none");
        JavaCompiler.CompilationTask task = compiler.getTask(
                null, new NullFileManager(fileManager), collector, options, null, units);
        task.call();

        List<CompileDiagnostic> diags = new ArrayList<>();
        int errors = 0, warnings = 0, dependencyNotes = 0;
        // First pass: find source files that reference a missing dependency package.
        java.util.Set<String> filesWithDepGaps = new java.util.HashSet<>();
        for (Diagnostic<? extends JavaFileObject> d : collector.getDiagnostics()) {
            String msg = d.getMessage(null) == null ? "" : d.getMessage(null);
            if (d.getKind() == Diagnostic.Kind.ERROR
                    && msg.contains("package ") && msg.contains(" does not exist")
                    && d.getSource() != null) {
                filesWithDepGaps.add(d.getSource().getName());
            }
        }
        for (Diagnostic<? extends JavaFileObject> d : collector.getDiagnostics()) {
            String msg = d.getMessage(null) == null ? "" : d.getMessage(null);
            String src = d.getSource() != null ? d.getSource().getName() : "";
            // A reference into a dependency that isn't on the verify classpath (resolved by
            // Maven at build time) is not a mistake in the user's code. These appear as
            // "package ... does not exist" plus knock-on "cannot find symbol" in the same file.
            boolean dependencyGap = d.getKind() == Diagnostic.Kind.ERROR && (
                    (msg.contains("package ") && msg.contains(" does not exist"))
                    || (msg.contains("cannot find symbol") && filesWithDepGaps.contains(src)));
            String kind;
            if (dependencyGap) {
                kind = "INFO";
                dependencyNotes++;
            } else if (d.getKind() == Diagnostic.Kind.ERROR) {
                kind = "ERROR";
                errors++;
            } else if (d.getKind() == Diagnostic.Kind.WARNING || d.getKind() == Diagnostic.Kind.MANDATORY_WARNING) {
                kind = "WARNING";
                warnings++;
            } else {
                kind = d.getKind().name();
            }
            diags.add(new CompileDiagnostic(kind, src, d.getLineNumber(), d.getColumnNumber(), msg));
        }

        // "ok" means no real user errors. Dependency gaps don't fail the verify.
        boolean ok = errors == 0;
        String summary = ok
                ? (dependencyNotes > 0
                    ? "No code errors. " + dependencyNotes + " reference(s) resolve via Maven dependencies at build time."
                    : "Compiled successfully (" + units.size() + " source file(s), " + warnings + " warning(s)).")
                : errors + " error(s), " + warnings + " warning(s) across " + units.size() + " source file(s).";
        log.info("sandbox compile  artifact={}  ok={}  errors={}  warnings={}  depNotes={}",
                request.artifactId(), ok, errors, warnings, dependencyNotes);
        return new CompileResult(ok, true, errors, warnings, diags, summary);
    }

    /**
     * Python: byte-compile each .py source with `python3 -m py_compile` to catch
     * syntax errors. This is a real syntax/parse check (the equivalent of javac's
     * front-end) and reports file:line with the interpreter's message. It does not
     * resolve third-party imports — those are installed by Poetry/pip in the
     * generated project — so import errors are not raised here.
     */
    private CompileResult compilePython(Map<String, String> files) {
        List<String> pyFiles = new ArrayList<>();
        for (var e : files.entrySet()) {
            if (e.getKey().endsWith(".py")) pyFiles.add(e.getKey());
        }
        if (pyFiles.isEmpty()) {
            return new CompileResult(true, true, 0, 0, List.of(), "No Python sources to check.");
        }

        java.nio.file.Path tmp = null;
        try {
            tmp = java.nio.file.Files.createTempDirectory("sf-pycompile-");
            // write all .py files into the temp dir, preserving relative paths
            for (var e : files.entrySet()) {
                if (!e.getKey().endsWith(".py")) continue;
                java.nio.file.Path p = tmp.resolve(e.getKey());
                java.nio.file.Files.createDirectories(p.getParent());
                java.nio.file.Files.writeString(p, e.getValue());
            }

            String python = resolvePython();
            if (python == null) {
                return new CompileResult(false, false, 0, 0, List.of(),
                        "Python interpreter not available on the server runtime.");
            }

            List<CompileDiagnostic> diags = new ArrayList<>();
            int errors = 0;
            for (String rel : pyFiles) {
                java.nio.file.Path abs = tmp.resolve(rel);
                ProcessBuilder pb = new ProcessBuilder(python, "-m", "py_compile", abs.toString());
                pb.redirectErrorStream(true);
                Process proc = pb.start();
                String out = new String(proc.getInputStream().readAllBytes(),
                        java.nio.charset.StandardCharsets.UTF_8);
                boolean finished = proc.waitFor(20, java.util.concurrent.TimeUnit.SECONDS);
                if (!finished) { proc.destroyForcibly(); continue; }
                if (proc.exitValue() != 0) {
                    errors++;
                    diags.add(parsePyError(rel, out));
                }
            }
            boolean ok = errors == 0;
            String summary = ok
                    ? "Syntax check passed (" + pyFiles.size() + " Python file(s))."
                    : errors + " syntax error(s) across " + pyFiles.size() + " Python file(s).";
            log.info("sandbox compile (python)  files={}  ok={}  errors={}", pyFiles.size(), ok, errors);
            return new CompileResult(ok, true, errors, 0, diags, summary);
        } catch (Exception ex) {
            log.warn("Python syntax check failed: {}", ex.getMessage());
            return new CompileResult(false, true, 0, 0, List.of(),
                    "Could not run the Python syntax check: " + ex.getMessage());
        } finally {
            if (tmp != null) deleteRecursive(tmp);
        }
    }

    private String resolvePython() {
        for (String cmd : new String[]{"python3", "python"}) {
            try {
                Process p = new ProcessBuilder(cmd, "--version").redirectErrorStream(true).start();
                if (p.waitFor(5, java.util.concurrent.TimeUnit.SECONDS) && p.exitValue() == 0) {
                    return cmd;
                }
            } catch (Exception ignore) { /* try next */ }
        }
        return null;
    }

    /** Parse py_compile output into a structured diagnostic (file:line + message). */
    private CompileDiagnostic parsePyError(String relPath, String output) {
        long line = 0;
        String message = output.strip();
        // typical: '  File "....py", line 12' then later 'SyntaxError: ...'
        var lineMatcher = java.util.regex.Pattern.compile("line (\\d+)").matcher(output);
        if (lineMatcher.find()) {
            try { line = Long.parseLong(lineMatcher.group(1)); } catch (NumberFormatException ignore) {}
        }
        var errMatcher = java.util.regex.Pattern.compile("(\\w*Error: .*)").matcher(output);
        if (errMatcher.find()) {
            message = errMatcher.group(1).strip();
        }
        return new CompileDiagnostic("ERROR", relPath, line, 0, message);
    }

    private void deleteRecursive(java.nio.file.Path root) {
        try {
            java.nio.file.Files.walk(root)
                    .sorted(java.util.Comparator.reverseOrder())
                    .forEach(p -> { try { java.nio.file.Files.deleteIfExists(p); } catch (Exception ignore) {} });
        } catch (Exception ignore) { /* best effort */ }
    }

    private URI deriveClassUri(String path) {
        // strip up to .../java/ so the URI looks like a normal source path
        int idx = path.indexOf("/java/");
        String rel = idx >= 0 ? path.substring(idx + 6) : path;
        return URI.create("string:///" + rel);
    }

    /** In-memory .java source for the compiler. */
    static final class InMemoryJavaSource extends SimpleJavaFileObject {
        private final String code;
        InMemoryJavaSource(URI uri, String code) {
            super(uri, Kind.SOURCE);
            this.code = code;
        }
        @Override public CharSequence getCharContent(boolean ignoreEncodingErrors) {
            return code;
        }
    }

    /**
     * Wraps the standard file manager but discards generated class output,
     * so the compile is a pure diagnostic pass with no disk writes.
     */
    static final class NullFileManager extends javax.tools.ForwardingJavaFileManager<javax.tools.StandardJavaFileManager> {
        NullFileManager(javax.tools.StandardJavaFileManager fm) { super(fm); }
        @Override
        public JavaFileObject getJavaFileForOutput(Location location, String className,
                                                   JavaFileObject.Kind kind, javax.tools.FileObject sibling) {
            return new SimpleJavaFileObject(URI.create("string:///" + className.replace('.', '/') + kind.extension), kind) {
                @Override public java.io.OutputStream openOutputStream() {
                    return java.io.OutputStream.nullOutputStream();
                }
            };
        }
    }
}
