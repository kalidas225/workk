package com.sourceforge.starter.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.util.List;
import java.util.Map;

/**
 * Incoming request from the frontend describing the project to generate.
 *
 * For Java/Kotlin/Groovy: type is maven | gradle-groovy | gradle-kotlin, language is java
 * For Python: type is poetry | pip, language is python, bootVersion is ignored (kept blank or "n/a")
 */
public record ProjectRequest(
        @NotBlank @Pattern(regexp = "maven|poetry|pip",
                message = "type must be maven, poetry or pip")
        String type,

        @NotBlank @Pattern(regexp = "java|python",
                message = "language must be java or python")
        String language,

        String bootVersion,             // optional for python projects

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.\\-]*$", message = "groupId is invalid")
        String groupId,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_\\-]*$", message = "artifactId is invalid")
        String artifactId,

        @NotBlank
        String name,

        String description,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.]*$", message = "packageName is invalid")
        String packageName,

        @NotBlank @Pattern(regexp = "jar|war|wheel|sdist", message = "packaging must be jar, war, wheel or sdist")
        String packaging,

        @NotBlank
        String javaVersion,             // for java: 17/21/25/26 ; for python: 3.10/3.11/3.12/3.13

        String architecture,            // standard | mvc | microservice (defaults to standard)

        @NotNull
        List<String> dependencies,

        Map<String, String> dependencyVersions,   // depId -> version override (blank = managed)

        Map<String, String> editedFiles,          // relativePath -> edited content (regeneration)

        DatabaseConfig database,

        EnvironmentConfig environments,

        DmzrConfig dmzr,

        String applicationCode,        // e.g. ap25701 — Vault/COS namespace identifier (blank = placeholder)

        CosConfig cos                  // Cloud Object Storage config (optional)
) {
    public ProjectRequest {
        if (dependencies == null) dependencies = List.of();
        if (dependencyVersions == null) dependencyVersions = Map.of();
        if (editedFiles == null) editedFiles = Map.of();
        if (description == null) description = "";
        if (database == null) database = DatabaseConfig.none();
        if (environments == null) environments = EnvironmentConfig.disabled();
        if (dmzr == null) dmzr = DmzrConfig.disabled();
        if (bootVersion == null) bootVersion = "";
        if (architecture == null || architecture.isBlank()) architecture = "standard";
        if (applicationCode == null) applicationCode = "";
        if (cos == null) cos = CosConfig.disabled();
    }

    /** The Vault/COS application code, or a sensible placeholder when not provided. */
    public String effectiveApplicationCode() {
        return (applicationCode == null || applicationCode.isBlank()) ? "ap00000" : applicationCode;
    }

    public boolean isPython() {
        return "python".equals(language);
    }

    public boolean isJava() {
        return "java".equals(language);
    }

    public boolean isMvc() {
        return "mvc".equals(architecture);
    }

    public boolean isMicroservice() {
        return "microservice".equals(architecture);
    }
}
