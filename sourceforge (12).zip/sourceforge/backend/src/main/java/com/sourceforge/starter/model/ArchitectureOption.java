package com.sourceforge.starter.model;

/**
 * A code-generation architecture option shown as a radio button in the UI.
 */
public record ArchitectureOption(
        String id,            // standard | mvc | microservice
        String label,         // human label
        String description    // short explanation
) {
}
