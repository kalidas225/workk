package com.sourceforge.starter.service;

import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.DependencyCategory;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * In-memory catalog of Spring Boot starter dependencies, mirroring the
 * grouping used by start.spring.io. Kept in code (no external metadata
 * file) so the service is self-contained and works offline.
 */
@Service
public class DependencyCatalogService {

    private final List<DependencyCategory> javaCategories;
    private final List<DependencyCategory> pythonCategories;
    private final Map<String, Dependency> byId;

    public DependencyCatalogService() {
        this.javaCategories = buildCatalog();
        this.pythonCategories = buildPythonCatalog();
        this.byId = new LinkedHashMap<>();
        for (DependencyCategory cat : javaCategories) {
            for (Dependency dep : cat.dependencies()) byId.put(dep.id(), dep);
        }
        for (DependencyCategory cat : pythonCategories) {
            for (Dependency dep : cat.dependencies()) byId.put(dep.id(), dep);
        }
    }

    /** @deprecated kept for backward compatibility; prefer getJavaCategories() */
    @Deprecated
    public List<DependencyCategory> getCategories() {
        return javaCategories;
    }

    public List<DependencyCategory> getJavaCategories() {
        return javaCategories;
    }

    public List<DependencyCategory> getPythonCategories() {
        return pythonCategories;
    }

    public List<DependencyCategory> getCategoriesFor(String language) {
        return "python".equals(language) ? pythonCategories : javaCategories;
    }

    public Optional<Dependency> findById(String id) {
        return Optional.ofNullable(byId.get(id));
    }

    public List<Dependency> resolve(List<String> ids) {
        return ids.stream()
                .map(byId::get)
                .filter(java.util.Objects::nonNull)
                .toList();
    }

    private List<DependencyCategory> buildCatalog() {
        List<DependencyCategory> list = new java.util.ArrayList<>();

        list.add(new DependencyCategory("Developer Tools", List.of(
                dep("devtools", "Spring Boot DevTools",
                        "Provides fast application restarts, LiveReload, and configurations for enhanced development experience.",
                        "org.springframework.boot", "spring-boot-devtools", null, "runtime", "Developer Tools"),
                dep("lombok", "Lombok",
                        "Java annotation library which helps to reduce boilerplate code.",
                        "org.projectlombok", "lombok", null, "provided", "Developer Tools"),
                dep("configuration-processor", "Spring Configuration Processor",
                        "Generate metadata for developers to offer contextual help and code completion for @ConfigurationProperties classes.",
                        "org.springframework.boot", "spring-boot-configuration-processor", null, "provided", "Developer Tools"),
                dep("docker-compose", "Docker Compose Support",
                        "Provides Docker Compose support for enhanced development experience.",
                        "org.springframework.boot", "spring-boot-docker-compose", null, "runtime", "Developer Tools")
        )));

        list.add(new DependencyCategory("Web", List.of(
                dep("web", "Spring Web",
                        "Build web, including RESTful, applications using Spring MVC. Uses Apache Tomcat as the default embedded container.",
                        "org.springframework.boot", "spring-boot-starter-web", null, "compile", "Web"),
                dep("webflux", "Spring Reactive Web",
                        "Build reactive web applications with Spring WebFlux and Netty.",
                        "org.springframework.boot", "spring-boot-starter-webflux", null, "compile", "Web"),
                dep("graphql", "Spring for GraphQL",
                        "Build GraphQL applications with Spring for GraphQL and GraphQL Java.",
                        "org.springframework.boot", "spring-boot-starter-graphql", null, "compile", "Web"),
                dep("websocket", "WebSocket",
                        "Build WebSocket and STOMP messaging applications.",
                        "org.springframework.boot", "spring-boot-starter-websocket", null, "compile", "Web"),
                dep("data-rest", "Spring Data REST",
                        "Expose Spring Data repositories over REST via Spring Data REST.",
                        "org.springframework.boot", "spring-boot-starter-data-rest", null, "compile", "Web"),
                dep("session", "Spring Session",
                        "Provides an API and implementations for managing user session information.",
                        "org.springframework.session", "spring-session-core", null, "compile", "Web"),
                dep("springdoc-openapi", "OpenAPI / Swagger UI",
                        "Generates OpenAPI 3 documentation and serves Swagger UI for Spring Boot REST APIs (springdoc).",
                        "org.springdoc", "springdoc-openapi-starter-webmvc-ui", "2.6.0", "compile", "Web")
        )));

        list.add(new DependencyCategory("Template Engines", List.of(
                dep("thymeleaf", "Thymeleaf",
                        "A modern server-side Java template engine for both web and standalone environments.",
                        "org.springframework.boot", "spring-boot-starter-thymeleaf", null, "compile", "Template Engines"),
                dep("freemarker", "Apache Freemarker",
                        "Java library to generate text output (HTML web pages, e-mails, configuration files, source code, etc.) based on templates and changing data.",
                        "org.springframework.boot", "spring-boot-starter-freemarker", null, "compile", "Template Engines"),
                dep("mustache", "Mustache",
                        "Logic-less templates with separation of view from logic.",
                        "org.springframework.boot", "spring-boot-starter-mustache", null, "compile", "Template Engines"),
                dep("groovy-templates", "Groovy Templates",
                        "Groovy templating engine.",
                        "org.springframework.boot", "spring-boot-starter-groovy-templates", null, "compile", "Template Engines")
        )));

        list.add(new DependencyCategory("Security", List.of(
                dep("security", "Spring Security",
                        "Highly customizable authentication and access-control framework for Spring applications.",
                        "org.springframework.boot", "spring-boot-starter-security", null, "compile", "Security"),
                dep("oauth2-client", "OAuth2 Client",
                        "Spring Boot integration for Spring Security's OAuth2/OpenID Connect client features.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-client", null, "compile", "Security"),
                dep("oauth2-resource-server", "OAuth2 Resource Server",
                        "Spring Boot integration for Spring Security's OAuth2 resource server features.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-resource-server", null, "compile", "Security"),
                dep("oauth2-authorization-server", "OAuth2 Authorization Server",
                        "Spring Boot integration for Spring Authorization Server.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-authorization-server", null, "compile", "Security")
        )));

        list.add(new DependencyCategory("SQL", List.of(
                dep("data-jpa", "Spring Data JPA",
                        "Persist data in SQL stores with Java Persistence API using Spring Data and Hibernate.",
                        "org.springframework.boot", "spring-boot-starter-data-jpa", null, "compile", "SQL"),
                dep("data-jdbc", "Spring Data JDBC",
                        "Persist data in SQL stores with plain JDBC using Spring Data.",
                        "org.springframework.boot", "spring-boot-starter-data-jdbc", null, "compile", "SQL"),
                dep("jdbc", "JDBC API",
                        "Database Connectivity API that defines how a client may connect and query a database.",
                        "org.springframework.boot", "spring-boot-starter-jdbc", null, "compile", "SQL"),
                dep("mysql", "MySQL Driver",
                        "MySQL JDBC driver.",
                        "com.mysql", "mysql-connector-j", null, "runtime", "SQL"),
                dep("postgresql", "PostgreSQL Driver",
                        "A JDBC and R2DBC driver that allows Java programs to connect to a PostgreSQL database using standard, database independent Java code.",
                        "org.postgresql", "postgresql", null, "runtime", "SQL"),
                dep("h2", "H2 Database",
                        "Provides a fast in-memory database that supports JDBC API and R2DBC access, with a small (2mb) footprint.",
                        "com.h2database", "h2", null, "runtime", "SQL"),
                dep("hsql", "HyperSQL Database",
                        "Lightweight 100% Java SQL Database Engine.",
                        "org.hsqldb", "hsqldb", null, "runtime", "SQL"),
                dep("derby", "Apache Derby Database",
                        "An open source relational database implemented entirely in Java.",
                        "org.apache.derby", "derby", null, "runtime", "SQL"),
                dep("mssql", "MS SQL Server Driver",
                        "JDBC driver for Microsoft SQL Server.",
                        "com.microsoft.sqlserver", "mssql-jdbc", null, "runtime", "SQL"),
                dep("oracle", "Oracle Driver",
                        "JDBC driver for Oracle Database.",
                        "com.oracle.database.jdbc", "ojdbc11", null, "runtime", "SQL"),
                dep("flyway", "Flyway Migration",
                        "Version control for your database so you can migrate from any version (incl. an empty database) to the latest version of the schema.",
                        "org.flywaydb", "flyway-core", null, "compile", "SQL"),
                dep("liquibase", "Liquibase Migration",
                        "Liquibase database migration and source control library.",
                        "org.liquibase", "liquibase-core", null, "compile", "SQL")
        )));

        list.add(new DependencyCategory("NoSQL", List.of(
                dep("data-redis", "Spring Data Redis (Access+Driver)",
                        "Advanced and thread-safe Java Redis client for synchronous, asynchronous, and reactive usage.",
                        "org.springframework.boot", "spring-boot-starter-data-redis", null, "compile", "NoSQL"),
                dep("data-mongodb", "Spring Data MongoDB",
                        "Store data in flexible, JSON-like documents, meaning fields can vary from document to document.",
                        "org.springframework.boot", "spring-boot-starter-data-mongodb", null, "compile", "NoSQL"),
                dep("data-elasticsearch", "Spring Data Elasticsearch (Access+Driver)",
                        "A distributed, RESTful search and analytics engine with support for Spring Data.",
                        "org.springframework.boot", "spring-boot-starter-data-elasticsearch", null, "compile", "NoSQL"),
                dep("data-cassandra", "Spring Data for Apache Cassandra",
                        "A free and open-source, distributed, NoSQL database management system that offers high scalability and high availability without compromising performance.",
                        "org.springframework.boot", "spring-boot-starter-data-cassandra", null, "compile", "NoSQL"),
                dep("data-neo4j", "Spring Data Neo4j",
                        "Provides graph data persistence with Neo4j, the most popular graph database.",
                        "org.springframework.boot", "spring-boot-starter-data-neo4j", null, "compile", "NoSQL")
        )));

        list.add(new DependencyCategory("Messaging", List.of(
                dep("amqp", "Spring for RabbitMQ",
                        "Gives your applications a common platform to send and receive messages, and your messages a safe place to live until received.",
                        "org.springframework.boot", "spring-boot-starter-amqp", null, "compile", "Messaging"),
                dep("kafka", "Spring for Apache Kafka",
                        "Publish, subscribe, store, and process streams of records.",
                        "org.springframework.kafka", "spring-kafka", null, "compile", "Messaging"),
                dep("kafka-streams", "Spring for Apache Kafka Streams",
                        "Building stream processing applications with Apache Kafka Streams.",
                        "org.apache.kafka", "kafka-streams", null, "compile", "Messaging"),
                dep("activemq", "Spring for Apache ActiveMQ 5",
                        "Spring JMS support with Apache ActiveMQ 'Classic'.",
                        "org.springframework.boot", "spring-boot-starter-activemq", null, "compile", "Messaging"),
                dep("artemis", "Spring for Apache ActiveMQ Artemis",
                        "Spring JMS support with Apache ActiveMQ Artemis.",
                        "org.springframework.boot", "spring-boot-starter-artemis", null, "compile", "Messaging")
        )));

        list.add(new DependencyCategory("I/O", List.of(
                dep("batch", "Spring Batch",
                        "Batch applications with transactions, retry/skip and chunk based processing.",
                        "org.springframework.boot", "spring-boot-starter-batch", null, "compile", "I/O"),
                dep("integration", "Spring Integration",
                        "Adds support for Enterprise Integration Patterns. Enables lightweight messaging and supports integration with external systems via declarative adapters.",
                        "org.springframework.boot", "spring-boot-starter-integration", null, "compile", "I/O"),
                dep("validation", "Validation",
                        "Bean Validation with Hibernate validator.",
                        "org.springframework.boot", "spring-boot-starter-validation", null, "compile", "I/O"),
                dep("mail", "Java Mail Sender",
                        "Send email using Java Mail and Spring Framework's JavaMailSender.",
                        "org.springframework.boot", "spring-boot-starter-mail", null, "compile", "I/O"),
                dep("quartz", "Quartz Scheduler",
                        "Schedule jobs using Quartz.",
                        "org.springframework.boot", "spring-boot-starter-quartz", null, "compile", "I/O")
        )));

        list.add(new DependencyCategory("Ops", List.of(
                dep("actuator", "Spring Boot Actuator",
                        "Supports built in (or custom) endpoints that let you monitor and manage your application - such as application health, metrics, sessions, etc.",
                        "org.springframework.boot", "spring-boot-starter-actuator", null, "compile", "Ops"),
                dep("prometheus", "Prometheus",
                        "Expose Actuator metrics in the Prometheus format via Micrometer.",
                        "io.micrometer", "micrometer-registry-prometheus", null, "runtime", "Ops"),
                dep("cloud-config-client", "Config Client",
                        "Client that connects to a Spring Cloud Config Server to fetch the application's configuration.",
                        "org.springframework.cloud", "spring-cloud-starter-config", null, "compile", "Ops"),
                dep("cloud-eureka", "Eureka Discovery Client",
                        "A REST based service for locating services for the purpose of load balancing and failover of middle-tier servers.",
                        "org.springframework.cloud", "spring-cloud-starter-netflix-eureka-client", null, "compile", "Ops")
        )));

        list.add(new DependencyCategory("Testing", List.of(
                dep("testcontainers", "Testcontainers",
                        "Provides lightweight, throwaway instances of common databases, Selenium web browsers, or anything else that can run in a Docker container.",
                        "org.testcontainers", "junit-jupiter", null, "test", "Testing"),
                dep("restdocs", "Spring REST Docs",
                        "Document RESTful services by combining hand-written and auto-generated documentation.",
                        "org.springframework.restdocs", "spring-restdocs-mockmvc", null, "test", "Testing")
        )));

        return list;
    }

    private static Dependency dep(String id, String name, String description,
                                  String groupId, String artifactId, String version,
                                  String scope, String category) {
        return new Dependency(id, name, description, groupId, artifactId, version, scope, category,
                List.of(), null, null);
    }

    // ============================================================
    //   Python catalog
    //   groupId is left empty; artifactId carries the PyPI name;
    //   version may be set explicitly (caret-style) or kept null
    // ============================================================

    private List<DependencyCategory> buildPythonCatalog() {
        List<DependencyCategory> list = new java.util.ArrayList<>();

        list.add(new DependencyCategory("Web", List.of(
                pyDep("fastapi", "FastAPI",
                        "Modern, fast (high-performance) web framework for building APIs with Python, based on standard Python type hints.",
                        "fastapi", "^0.115.0", "Web"),
                pyDep("uvicorn", "Uvicorn",
                        "Lightning-fast ASGI server, built on uvloop and httptools. Standard runtime for FastAPI in production.",
                        "uvicorn", "^0.32.0", "Web"),
                pyDep("flask", "Flask",
                        "Lightweight WSGI web application framework. Easy to get started, scales to complex applications.",
                        "flask", "^3.0.0", "Web"),
                pyDep("django", "Django",
                        "High-level Python web framework that encourages rapid development and clean, pragmatic design.",
                        "django", "^5.1.0", "Web"),
                pyDep("starlette", "Starlette",
                        "Lightweight ASGI framework/toolkit, ideal for building async web services.",
                        "starlette", "^0.41.0", "Web")
        )));

        list.add(new DependencyCategory("SQL", List.of(
                pyDep("sqlalchemy", "SQLAlchemy",
                        "The Python SQL toolkit and Object Relational Mapper. Industry-standard ORM for Python.",
                        "sqlalchemy", "^2.0.36", "SQL"),
                pyDep("alembic", "Alembic",
                        "Lightweight database migration tool for SQLAlchemy.",
                        "alembic", "^1.13.0", "SQL"),
                pyDep("py-psycopg2", "psycopg2-binary (PostgreSQL)",
                        "PostgreSQL adapter for Python. The binary distribution is convenient for local dev.",
                        "psycopg2-binary", "^2.9.10", "SQL"),
                pyDep("py-pymysql", "PyMySQL (MySQL)",
                        "Pure-Python MySQL client.",
                        "pymysql", "^1.1.1", "SQL"),
                pyDep("py-cx-oracle", "oracledb (Oracle)",
                        "Python driver for Oracle Database.",
                        "oracledb", "^2.5.0", "SQL"),
                pyDep("py-pyodbc", "pyodbc (SQL Server)",
                        "ODBC interface for Python, used with Microsoft SQL Server.",
                        "pyodbc", "^5.2.0", "SQL"),
                pyDep("py-aiosqlite", "aiosqlite",
                        "Asyncio bridge to the standard sqlite3 module.",
                        "aiosqlite", "^0.20.0", "SQL")
        )));

        list.add(new DependencyCategory("NoSQL", List.of(
                pyDep("py-redis", "redis-py",
                        "Python client for Redis. Synchronous and asyncio APIs included.",
                        "redis", "^5.2.0", "NoSQL"),
                pyDep("py-pymongo", "PyMongo",
                        "Official Python driver for MongoDB.",
                        "pymongo", "^4.10.0", "NoSQL"),
                pyDep("py-motor", "Motor (async MongoDB)",
                        "Async Python driver for MongoDB, built on PyMongo.",
                        "motor", "^3.6.0", "NoSQL")
        )));

        list.add(new DependencyCategory("Validation & Serialization", List.of(
                pyDep("pydantic", "Pydantic v2",
                        "Data validation using Python type hints. Required by FastAPI; useful standalone.",
                        "pydantic", "^2.9.0", "Validation & Serialization"),
                pyDep("pydantic-settings", "Pydantic Settings",
                        "Settings management using Pydantic — load configuration from env, .env files, or secrets.",
                        "pydantic-settings", "^2.6.0", "Validation & Serialization"),
                pyDep("marshmallow", "marshmallow",
                        "ORM/ODM/framework-agnostic library for converting complex datatypes to and from native Python.",
                        "marshmallow", "^3.23.0", "Validation & Serialization")
        )));

        list.add(new DependencyCategory("Security", List.of(
                pyDep("py-passlib", "passlib[bcrypt]",
                        "Password hashing library with broad algorithm support.",
                        "passlib[bcrypt]", "^1.7.4", "Security"),
                pyDep("py-pyjwt", "PyJWT",
                        "JSON Web Token implementation in Python.",
                        "pyjwt", "^2.10.0", "Security"),
                pyDep("py-authlib", "Authlib",
                        "OAuth 1, OAuth 2, OpenID Connect, and JWT for Python.",
                        "authlib", "^1.3.2", "Security"),
                pyDep("py-cryptography", "cryptography",
                        "Cryptographic recipes and primitives for Python developers.",
                        "cryptography", "^43.0.0", "Security")
        )));

        list.add(new DependencyCategory("HTTP Clients", List.of(
                pyDep("py-requests", "Requests",
                        "Synchronous HTTP library for humans.",
                        "requests", "^2.32.0", "HTTP Clients"),
                pyDep("py-httpx", "HTTPX",
                        "Next generation HTTP client with sync and async support.",
                        "httpx", "^0.27.0", "HTTP Clients"),
                pyDep("py-aiohttp", "aiohttp",
                        "Async HTTP client/server framework based on asyncio.",
                        "aiohttp", "^3.11.0", "HTTP Clients")
        )));

        list.add(new DependencyCategory("Messaging", List.of(
                pyDep("py-celery", "Celery",
                        "Distributed task queue based on message passing.",
                        "celery", "^5.4.0", "Messaging"),
                pyDep("py-kafka", "kafka-python",
                        "Python client for Apache Kafka.",
                        "kafka-python", "^2.0.2", "Messaging"),
                pyDep("py-pika", "pika (RabbitMQ)",
                        "Pure-Python implementation of the AMQP 0-9-1 protocol for RabbitMQ.",
                        "pika", "^1.3.2", "Messaging"),
                pyDep("py-aio-pika", "aio-pika",
                        "Asyncio AMQP/RabbitMQ client.",
                        "aio-pika", "^9.5.0", "Messaging")
        )));

        list.add(new DependencyCategory("Ops & Observability", List.of(
                pyDep("py-loguru", "loguru",
                        "Python logging made simple — single import, no config required.",
                        "loguru", "^0.7.2", "Ops & Observability"),
                pyDep("py-structlog", "structlog",
                        "Structured logging for Python.",
                        "structlog", "^24.4.0", "Ops & Observability"),
                pyDep("py-prometheus", "prometheus-client",
                        "Official Python client for Prometheus.",
                        "prometheus-client", "^0.21.0", "Ops & Observability"),
                pyDep("py-opentelemetry", "OpenTelemetry SDK",
                        "OpenTelemetry instrumentation SDK for Python.",
                        "opentelemetry-sdk", "^1.28.0", "Ops & Observability"),
                pyDep("py-sentry", "Sentry SDK",
                        "Python client for Sentry error monitoring.",
                        "sentry-sdk", "^2.18.0", "Ops & Observability")
        )));

        list.add(new DependencyCategory("Data & ML", List.of(
                pyDep("py-numpy", "NumPy",
                        "Fundamental package for scientific computing with Python.",
                        "numpy", "^2.1.0", "Data & ML"),
                pyDep("py-pandas", "pandas",
                        "Powerful Python data analysis toolkit.",
                        "pandas", "^2.2.0", "Data & ML"),
                pyDep("py-scikit-learn", "scikit-learn",
                        "Machine learning in Python — simple and efficient tools for data mining and analysis.",
                        "scikit-learn", "^1.5.0", "Data & ML"),
                pyDep("py-pyarrow", "pyarrow",
                        "Python bindings for Apache Arrow — efficient columnar data interchange.",
                        "pyarrow", "^18.0.0", "Data & ML")
        )));

        list.add(new DependencyCategory("Testing", List.of(
                pyDep("py-pytest", "pytest",
                        "Simple, scalable Python testing framework.",
                        "pytest", "^8.3.0", "Testing", "dev"),
                pyDep("py-pytest-asyncio", "pytest-asyncio",
                        "Pytest plugin for testing asyncio code.",
                        "pytest-asyncio", "^0.24.0", "Testing", "dev"),
                pyDep("py-pytest-cov", "pytest-cov",
                        "Coverage plugin for pytest.",
                        "pytest-cov", "^6.0.0", "Testing", "dev"),
                pyDep("py-httpx-test", "httpx (test client)",
                        "Sync/async HTTP client — useful for testing FastAPI endpoints in tests.",
                        "httpx", "^0.27.0", "Testing", "dev")
        )));

        list.add(new DependencyCategory("Developer Tools", List.of(
                pyDep("py-ruff", "ruff",
                        "Extremely fast Python linter and formatter, written in Rust.",
                        "ruff", "^0.7.0", "Developer Tools", "dev"),
                pyDep("py-black", "black",
                        "The uncompromising Python code formatter.",
                        "black", "^24.10.0", "Developer Tools", "dev"),
                pyDep("py-mypy", "mypy",
                        "Optional static type checker for Python.",
                        "mypy", "^1.13.0", "Developer Tools", "dev"),
                pyDep("py-pre-commit", "pre-commit",
                        "Framework for managing and maintaining multi-language pre-commit hooks.",
                        "pre-commit", "^4.0.0", "Developer Tools", "dev")
        )));

        return list;
    }

    private static Dependency pyDep(String id, String name, String description,
                                    String pypiName, String version, String category) {
        return pyDep(id, name, description, pypiName, version, category, "compile");
    }

    /**
     * Python dep helper.
     * groupId is left blank because PyPI has no group concept;
     * scope is "compile" (runtime) or "dev" (dev-dependency).
     */
    private static Dependency pyDep(String id, String name, String description,
                                    String pypiName, String version, String category, String scope) {
        return new Dependency(id, name, description, "", pypiName, version, scope, category,
                List.of(), null, null);
    }
}
