package com.sourceforge.starter.model;

import java.util.List;
import java.util.Map;

/**
 * Top-level metadata: a list of language bundles plus the default language id.
 * Frontend renders UI based on the active language bundle.
 */
public record MetadataResponse(
        List<String> languages,                       // ["java","python"]
        String defaultLanguage,
        List<LanguageMetadata> languageMetadata,
        List<String> environments,                    // ["dev","ist","uat","ppd","prod"] for env config UI
        List<ArchitectureOption> architectures,       // standard / mvc / microservice
        Map<String, List<String>> versionSuggestions  // depId -> suggested versions (dropdown)
) {
}
