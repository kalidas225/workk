package com.sourceforge.starter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Resolves the list of dependency versions that are compatible with a given
 * Spring Boot + Java selection, for populating the per-dependency version
 * dropdown in the UI.
 *
 * Resolution order (hybrid):
 *   1. Static {@link VersionCatalog} suggestions (deterministic, offline).
 *   2. If the company LLM is enabled, ask it to refine/extend the list for the
 *      specific Boot + Java combination. LLM answers are cached.
 * The first entry is always "managed" for BOM-managed Java starters.
 */
@Service
public class VersionCompatibilityService {

    private static final Logger log = LoggerFactory.getLogger(VersionCompatibilityService.class);

    private final CompanyLlmClient llm;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, List<String>> cache = new ConcurrentHashMap<>();

    public VersionCompatibilityService(CompanyLlmClient llm) {
        this.llm = llm;
    }

    /**
     * @param depId      catalog dependency id
     * @param language   "java" | "python"
     * @param bootVersion Spring Boot version (java only; may be blank)
     * @param javaVersion runtime version
     * @return ordered, de-duplicated list of versions for the dropdown
     */
    public List<String> compatibleVersions(String depId, String language, String bootVersion, String javaVersion) {
        String cacheKey = depId + "|" + language + "|" + bootVersion + "|" + javaVersion;
        List<String> cached = cache.get(cacheKey);
        if (cached != null) return cached;

        // 1. Static base list
        List<String> base = new ArrayList<>(VersionCatalog.suggestionsFor(depId));

        // 2. Optional LLM refinement
        if (llm.isEnabled() && "java".equals(language) && !bootVersion.isBlank()) {
            llmVersions(depId, bootVersion, javaVersion).ifPresent(list -> {
                for (String v : list) if (!base.contains(v)) base.add(v);
            });
        }

        // Ensure "managed" stays first when present
        if (base.remove(VersionCatalog.MANAGED)) {
            base.add(0, VersionCatalog.MANAGED);
        }
        List<String> result = base.isEmpty() ? List.of(VersionCatalog.MANAGED) : List.copyOf(base);
        cache.put(cacheKey, result);
        return result;
    }

    private Optional<List<String>> llmVersions(String depId, String bootVersion, String javaVersion) {
        String system = "You are a build-tooling assistant for a Java/Spring Boot project generator. "
                + "Given a dependency and a Spring Boot + Java version, reply with ONLY a JSON array of "
                + "the most appropriate, currently-available version strings (newest first, max 5). "
                + "If the version is managed by the Spring Boot BOM, include the string \"managed\" first. "
                + "No prose, no markdown, just the JSON array.";
        String user = "Dependency id: " + depId + "\nSpring Boot: " + bootVersion + "\nJava: " + javaVersion;
        Optional<String> resp = llm.complete(system, user);
        if (resp.isEmpty()) return Optional.empty();
        try {
            String text = resp.get().trim();
            // tolerate code fences
            text = text.replaceAll("^```(json)?", "").replaceAll("```$", "").trim();
            JsonNode arr = mapper.readTree(text);
            if (!arr.isArray()) return Optional.empty();
            List<String> out = new ArrayList<>();
            arr.forEach(n -> { if (n.isTextual()) out.add(n.asText()); });
            log.debug("LLM returned {} versions for dep={} boot={} java={}", out.size(), depId, bootVersion, javaVersion);
            return out.isEmpty() ? Optional.empty() : Optional.of(out);
        } catch (Exception e) {
            log.warn("Could not parse LLM version response: {}", e.getMessage());
            return Optional.empty();
        }
    }

    /** Resolve dropdowns for many dependencies at once (one map entry per dep). */
    public Map<String, List<String>> compatibleVersionsBatch(List<String> depIds, String language,
                                                              String bootVersion, String javaVersion) {
        Map<String, List<String>> out = new LinkedHashMap<>();
        for (String id : depIds) {
            out.put(id, compatibleVersions(id, language, bootVersion, javaVersion));
        }
        return out;
    }
}
