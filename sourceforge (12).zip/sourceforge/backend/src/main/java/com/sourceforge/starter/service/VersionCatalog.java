package com.sourceforge.starter.service;

import java.util.List;
import java.util.Map;

/**
 * Suggested versions per dependency, surfaced in the UI as a dropdown.
 *
 * For Spring-managed Java starters the only "version" is the BOM-managed one,
 * represented by the literal "managed" (which the frontend treats as: emit no
 * explicit &lt;version&gt;). Third-party Java libs and all Python packages list a
 * few concrete versions, newest first.
 */
public final class VersionCatalog {

    public static final String MANAGED = "managed";

    private VersionCatalog() {}

    private static final Map<String, List<String>> SUGGESTIONS = Map.ofEntries(
            // ---- Java third-party (non-BOM-managed) ----
            Map.entry("springdoc-openapi", List.of("2.6.0", "2.5.0", "2.4.0")),
            Map.entry("postgresql", List.of(MANAGED, "42.7.4", "42.7.3")),
            Map.entry("mysql", List.of(MANAGED, "9.1.0", "8.4.0")),
            Map.entry("h2", List.of(MANAGED, "2.3.232", "2.2.224")),
            Map.entry("oracle", List.of("23.5.0.24.07", "21.9.0.0")),
            Map.entry("mssql", List.of("12.8.1.jre11", "12.6.1.jre11")),
            Map.entry("lombok", List.of(MANAGED, "1.18.34")),

            // ---- Python web ----
            Map.entry("fastapi", List.of("^0.115.0", "^0.114.0", "^0.111.0")),
            Map.entry("uvicorn", List.of("^0.32.0", "^0.31.0", "^0.30.0")),
            Map.entry("flask", List.of("^3.0.0", "^2.3.0")),
            Map.entry("django", List.of("^5.1.0", "^5.0.0", "^4.2.0")),
            Map.entry("starlette", List.of("^0.41.0", "^0.40.0")),
            // ---- Python SQL ----
            Map.entry("sqlalchemy", List.of("^2.0.36", "^2.0.30")),
            Map.entry("alembic", List.of("^1.13.0", "^1.12.0")),
            Map.entry("py-psycopg2", List.of("^2.9.10", "^2.9.9")),
            Map.entry("py-pymysql", List.of("^1.1.1", "^1.1.0")),
            Map.entry("py-cx-oracle", List.of("^2.5.0", "^2.4.0")),
            Map.entry("py-pyodbc", List.of("^5.2.0", "^5.1.0")),
            Map.entry("py-aiosqlite", List.of("^0.20.0", "^0.19.0")),
            // ---- Python others ----
            Map.entry("pydantic", List.of("^2.9.0", "^2.8.0")),
            Map.entry("pydantic-settings", List.of("^2.6.0", "^2.5.0")),
            Map.entry("py-redis", List.of("^5.2.0", "^5.1.0")),
            Map.entry("py-pymongo", List.of("^4.10.0", "^4.9.0")),
            Map.entry("py-httpx", List.of("^0.27.0", "^0.26.0")),
            Map.entry("py-requests", List.of("^2.32.0", "^2.31.0")),
            Map.entry("py-pytest", List.of("^8.3.0", "^8.2.0")),
            Map.entry("py-ruff", List.of("^0.7.0", "^0.6.0")),
            Map.entry("py-black", List.of("^24.10.0", "^24.8.0")),
            Map.entry("py-mypy", List.of("^1.13.0", "^1.11.0"))
    );

    /**
     * Returns suggested versions for a dependency id. Falls back to a single
     * "managed" entry for Spring-managed starters not listed above.
     */
    public static List<String> suggestionsFor(String depId) {
        return SUGGESTIONS.getOrDefault(depId, List.of(MANAGED));
    }

    public static Map<String, List<String>> all() {
        return SUGGESTIONS;
    }
}
