package com.sourceforge.starter.model;

import java.util.List;

/**
 * Per-environment deployment settings supplied by the user.
 * Each selected profile (dev, ist, uat, ppd, prod) can have its own values,
 * which are substituted into bootstrap-{env}.yaml and the Helm values-*.yaml
 * everywhere namespace / ecosystem / COS are referenced.
 *
 * namespace is the short BP2S namespace id, e.g. ns000123224 (NOT a long path).
 * Each environment may have multiple COS buckets and instance ids.
 */
public record EnvironmentSetting(
        String ecosystem,            // e.g. EC002I002789
        String kubernetesPath,       // Vault kubernetes auth path, e.g. kubernetes_ku002i000843
        String namespace,            // short namespace id, e.g. ns000123224
        List<String> cosInstanceIds, // e.g. [co002i007156, co002i007157]
        List<String> cosBuckets      // e.g. [bu002i012751, bu002i012752]
) {
    public EnvironmentSetting {
        if (ecosystem == null) ecosystem = "";
        if (kubernetesPath == null) kubernetesPath = "";
        if (namespace == null) namespace = "";
        if (cosInstanceIds == null) cosInstanceIds = List.of();
        if (cosBuckets == null) cosBuckets = List.of();
    }

    /** Convenience constructor without COS (kept for tests / simple cases). */
    public EnvironmentSetting(String ecosystem, String kubernetesPath, String namespace) {
        this(ecosystem, kubernetesPath, namespace, List.of(), List.of());
    }

    public boolean hasCos() {
        return !cosInstanceIds.isEmpty() || !cosBuckets.isEmpty();
    }

    public boolean isEmpty() {
        return ecosystem.isBlank() && kubernetesPath.isBlank() && namespace.isBlank() && !hasCos();
    }
}
