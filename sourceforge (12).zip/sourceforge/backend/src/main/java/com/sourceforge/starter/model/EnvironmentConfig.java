package com.sourceforge.starter.model;

import java.util.List;
import java.util.Map;

/**
 * Configures generation of bootstrap-{env}.yaml files for Java projects.
 * Only emitted when enabled is true and language is java.
 *
 * settings holds per-environment values (ecosystem, kubernetes path, namespace)
 * keyed by profile id (dev/ist/uat/ppd/prod). Values differ per environment and
 * are substituted into both the bootstrap YAML and the Helm values files.
 */
public record EnvironmentConfig(
        boolean enabled,
        List<String> environments,                       // subset of: dev, ist, uat, ppd, prod
        String configServerUrl,                          // optional Spring Cloud Config Server URL
        String configServerProfile,                      // optional default profile
        Map<String, EnvironmentSetting> settings         // profile id -> per-env settings
) {
    public static final List<String> ALLOWED = List.of("dev", "ist", "uat", "ppd", "prod");

    public EnvironmentConfig {
        if (environments == null) environments = List.of();
        if (configServerUrl == null) configServerUrl = "";
        if (configServerProfile == null) configServerProfile = "";
        if (settings == null) settings = Map.of();
        // Defensive: only keep known environment ids
        environments = environments.stream().filter(ALLOWED::contains).toList();
    }

    /** Returns the settings for a profile, or an empty setting if none supplied. */
    public EnvironmentSetting settingFor(String env) {
        EnvironmentSetting s = settings.get(env);
        return s != null ? s : new EnvironmentSetting("", "", "");
    }

    public static EnvironmentConfig disabled() {
        return new EnvironmentConfig(false, List.of(), "", "", Map.of());
    }
}
