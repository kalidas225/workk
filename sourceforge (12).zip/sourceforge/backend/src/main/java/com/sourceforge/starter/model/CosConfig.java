package com.sourceforge.starter.model;

import java.util.List;

/**
 * Cloud Object Storage (COS) configuration.
 * When enabled, the generated bootstrap-{env}.yaml gains a COS object-storage
 * block (endpoint, access/secret keys via Vault, bucket) and the Vault paths
 * list gains the COS instance objstore path(s).
 */
public record CosConfig(
        boolean enabled,
        List<String> instanceIds,   // e.g. ["co002i007156"] — Vault objsto path segment(s)
        String endpoint,            // e.g. s3.<region>.cloud-object-storage.appdomain.cloud:4208
        String bucket               // e.g. bu002i012751
) {
    public CosConfig {
        if (instanceIds == null) instanceIds = List.of();
        if (endpoint == null) endpoint = "";
        if (bucket == null) bucket = "";
    }

    public static CosConfig disabled() {
        return new CosConfig(false, List.of(), "", "");
    }
}
