import { Component, OnInit, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, registerables } from 'chart.js';
import { ApiService } from './api.service';
import { DropdownComponent, DropdownOption } from './dropdown.component';
import {
  Release, Checkpoints, Subject, ReleaseSummary, Page, ARTIFACT_LABELS,
  ReleaseHealth, ConnectionStatus, ServiceNowTicket, CTask, ReleaseChanges, SubjectCheckConfig, ChecksConfig, Milestone,
} from './models';

Chart.register(...registerables);

type Tab = 'dashboard' | 'servicenow' | 'config';
const ENVS = ['DEV', 'IST', 'UAT'];
const SP_ITEMS = ['PR_EXCEL', 'OCTANE_REVIEW_DOC', 'OCTANE_EXECUTION_DOC'];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, DropdownComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, AfterViewChecked {
  releases: Release[] = [];
  selected = '';
  checkpoints?: Checkpoints;
  summary?: ReleaseSummary;
  health?: ReleaseHealth;
  systems: ConnectionStatus[] = [];
  subjectsPage?: Page<Subject>;
  tickets: ServiceNowTicket[] = [];
  checks?: ChecksConfig;

  page = 0; size = 20;
  loading = false; toast = ''; sendingKey = ''; mailingAll = false; mailingSummary = false;
  // per-section loading flags so each panel can show its own spinner
  loadingTimeline = false; loadingHealth = false; loadingCharts = false; loadingSubjects = false;
  tab: Tab = 'dashboard';
  theme: 'light' | 'dark' = 'light';
  artifactLabels = ARTIFACT_LABELS;
  envs = ENVS; spItems = SP_ITEMS;

  // per-system refresh state
  sysLoading: Record<string, boolean> = {};
  // dropdown open state

  // filters
  filterText = '';
  filterStatus = '';
  filterReadiness = ''; // '', 'ready', 'gaps'
  filterDev = '';

  @ViewChild('devChart') devChartRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('readyChart') readyChartRef?: ElementRef<HTMLCanvasElement>;
  private devChart?: Chart; private readyChart?: Chart;
  private chartsDirty = false;
  devLegend: { name: string; count: number; color: string }[] = [];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    const saved = (typeof localStorage !== 'undefined' && localStorage.getItem('rc-theme')) as any;
    this.setTheme(saved === 'dark' ? 'dark' : 'light');
    this.api.getStatus().subscribe(s => this.systems = s);
    this.api.getConfig().subscribe(cfg => {
      if (cfg.jiraBaseUrl) this.jiraBase = cfg.jiraBaseUrl;
      this.spConfig = cfg;
      this.api.getReleases().subscribe(r => {
        this.releases = r;
        this.buildReleaseOptions();
        const def = cfg.defaultRelease && r.find(x => x.name === cfg.defaultRelease);
        if (def) { this.selected = def.name; this.load(); this.pollScanStatus(); }
        this.booting = false;
      }, () => this.booting = false);
    }, () => this.booting = false);
  }

  ngAfterViewChecked(): void {
    if (this.chartsDirty && this.summary && this.tab === 'dashboard'
        && this.readyChartRef) {
      this.renderCharts();
      this.chartsDirty = false;
    }
  }

  setTheme(t: 'light' | 'dark'): void {
    this.theme = t;
    if (typeof document !== 'undefined') document.documentElement.setAttribute('data-theme', t);
    if (typeof localStorage !== 'undefined') localStorage.setItem('rc-theme', t);
    this.chartsDirty = true;
  }

  setTab(t: Tab): void {
    this.tab = t;
    // ServiceNow tab: changes are already loaded; CTASKs load per-change on expand
    // (never eagerly — that froze the page).
    if (t === 'dashboard') this.chartsDirty = true;
    // Load incidents & problems as soon as the ServiceNow tab is opened (once).
    if (t === 'servicenow' && !this.issues && !this.loadingIssues) this.loadIssues();
    if (t === 'config' && !this.cfgLoaded && !this.cfgLoading) {
      this.loadConfigTab();
    }
    if (t === 'config') this.loadEnvLinks();
  }

  cfgLoaded = false;
  private loadConfigTab(): void {
    this.cfgLoading = true;
    // Load this release's check overrides (release-scoped). Never let a failure
    // hang the tab — always clear the spinner.
    this.api.getChecks(this.selected).subscribe({
      next: c => { this.checks = c; this.recomputeCfgKeys(); },
      error: () => { this.checks = this.checks ?? { default: { octaneEnvironments: ['DEV','IST','UAT'], bcmEndToEnd: false, skipSharePoint: [], note: '' }, overrides: {} } as any; this.recomputeCfgKeys(); },
    });
    // Reuse already-loaded subjects if present; else fetch once.
    if (this.allSubjects && this.allSubjects.length) {
      this.cfgLoading = false; this.cfgLoaded = true; this.recomputeCfgKeys();
      return;
    }
    this.api.getSubjects(this.selected, 0, 500).subscribe({
      next: p => { this.allSubjects = p.content; this.cfgLoading = false; this.cfgLoaded = true; this.recomputeCfgKeys(); },
      error: () => { this.allSubjects = []; this.cfgLoading = false; this.cfgLoaded = true; this.flash('Could not load subjects — try Refresh'); },
    });
  }

  /**
   * Clears EVERY piece of per-release state so the next load starts from a clean
   * slate. Used by both the release switch and the Refresh button — refresh must
   * rebuild everything from scratch, not patch the currently displayed data.
   */
  private resetReleaseState(): void {
    this.page = 0;
    this.tickets = [];
    this.allSubjects = [];
    this.subjectsPage = undefined;
    this.envLinks = {};
    this.statusOverrides = {};
    this.releaseChanges = undefined;
    this.changeGroups = [];
    this.changeOpen = {};
    this.ctaskLoading = {};
    this.issues = undefined;
    this.loadingIssues = false;
    this.cfgKeys = [];          // reset the Check config count immediately
    this.checks = undefined as any;
    this.cfgLoaded = false;
    this.summary = undefined;
    this.health = undefined;
    this.checkpoints = undefined;
    this.devLegend = [];
    this.displayTimeline = [];
    this.milestones = [];
    this.whyOpen = {};
    this.spOpen = {};
    this.refreshingKey = '';
    this.chartsDirty = true;
    // Show the skeletons again while everything reloads.
    this.loadingTimeline = this.loadingHealth = this.loadingCharts = this.loadingSubjects = true;
  }

  onRelease(): void {
    this.tab = 'dashboard';   // always land on dashboard when the release changes
    this.resetReleaseState();
    // Force a fresh LIVE scan for the newly selected release (evict cache), so
    // switching releases never shows stale cached data.
    this.loading = true;
    this.api.refreshRelease(this.selected).subscribe({
      next: () => { this.load(); this.pollScanStatus(); },
      error: () => { this.load(); this.pollScanStatus(); },
    });
  }

  load(): void {
    if (!this.selected) return;
    this.loading = true;
    this.loadingTimeline = this.loadingHealth = this.loadingCharts = this.loadingSubjects = true;
    this.api.getCheckpoints(this.selected).subscribe(c => { this.checkpoints = c; this.loadingTimeline = false; this.recomputeMilestones(); this.rebuildTimeline(); });
    this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; this.loadingCharts = false; });
    this.api.getHealth(this.selected).subscribe(h => { this.health = h; this.loadingHealth = false; });
    // Populate the Check config count up-front (independent of opening the tab),
    // so the badge is correct on first load and every release change.
    this.api.getChecks(this.selected).subscribe({
      next: c => { this.checks = c; this.recomputeCfgKeys(); },
      error: () => {},
    });
    this.loadEnvLinks();
    this.loadSubjects();
  }
  loadSubjects(): void {
    this.loadingSubjects = true;
    // Load ALL subjects for the release once, then filter + paginate on the client
    // so the filters (status / readiness / developer) persist across page changes.
    this.api.getSubjects(this.selected, 0, 500).subscribe(p => {
      this.allSubjects = p.content;
      this.loading = false;
      this.loadingSubjects = false;
      this.applyFilters();          // recompute the filtered view
      this.rebuildSubjectDerived();
      this.recomputeCfgKeys();
    });
  }
  refresh(): void {
    if (!this.selected) { this.flash('Pick a release first'); return; }
    this.flash('Refreshing from source…');
    this.tab = 'dashboard';            // always return to dashboard on refresh
    // FULL refresh: wipe all in-memory state first so nothing stale can survive,
    // then re-probe connections, force a fresh backend scan and reload every
    // section (checkpoints, summary, health, checks, subjects, ServiceNow).
    this.resetReleaseState();
    this.loading = true;
    // Re-probe the connection tiles too.
    this.api.getStatus().subscribe({ next: s => this.systems = s, error: () => {} });
    const reloadAll = () => {
      this.load();                 // checkpoints + summary + health + checks + env links + subjects
      this.pollScanStatus();        // progress strip until the scan completes
      this.loadChanges(true);       // ServiceNow changes, cache-bypassed
    };
    // Evict the backend cache and force a fresh live scan, THEN reload + poll.
    this.api.refreshRelease(this.selected).subscribe({
      next: reloadAll,
      error: reloadAll,
    });
  }

  // Per-system refresh. ServiceNow is independent (just reload its changes).
  // Jira / Octane / SharePoint are all evaluated together in the subject scan, so
  // refreshing any of them forces a fresh scan of that release, then reloads.
  refreshSystem(sys: string): void {
    this.sysLoading[sys] = true;
    const stopSpin = () => { this.sysLoading[sys] = false; };
    // Always re-probe the connection status tile.
    this.api.getStatus().subscribe({
      next: all => {
        const one = all.find(s => s.system === sys);
        if (one) { const idx = this.systems.findIndex(x => x.system === sys); if (idx >= 0) this.systems[idx] = one; }
      },
      error: () => {},
    });

    if (sys === 'SERVICENOW') {
      // Independent: force-refresh the changes (bypasses backend cache) + timeline.
      this.releaseChanges = undefined; this.changeGroups = [];
      this.api.getReleaseChanges(this.selected, true).subscribe({
        next: c => {
          this.releaseChanges = c; this.rebuildChangeGroups();
          this.recomputeStageLinks(); this.rebuildTimeline();
          this.loadingChanges = false; stopSpin(); this.flash('ServiceNow refreshed');
        },
        error: () => { this.loadingChanges = false; stopSpin(); this.flash('ServiceNow refresh failed'); },
      });
      // Also refresh incidents/problems if that section is loaded.
      if (this.issues) this.loadIssues();
      return;
    }

    // JIRA / OCTANE / SHAREPOINT share the subject scan → force a fresh rescan.
    this.loadingSubjects = true;
    this.api.refreshRelease(this.selected).subscribe({
      next: () => {
        // Re-pull the scan-derived views once the background scan finishes.
        this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; });
        this.api.getHealth(this.selected).subscribe(h => this.health = h);
        this.pollScanStatus();
        this.loadSubjects();
        stopSpin(); this.flash(sys + ' refreshed');
      },
      error: () => { stopSpin(); this.loadingSubjects = false; this.flash(sys + ' refresh failed'); },
    });
  }

  // ---- dropdown ----
  pick(name: string): void { if (name !== this.selected) { this.selected = name; this.onRelease(); } }

  // ---- filtering (precomputed fields — NOT getters — to avoid CD loops) ----
  filtered: Subject[] = [];
  statusFilterOptions: DropdownOption[] = [{ value: '', label: 'All status' }];
  devFilterOptions: DropdownOption[] = [{ value: '', label: 'All developers' }];
  readinessFilterOptions: DropdownOption[] = [
    { value: '', label: 'All readiness' },
    { value: 'ready', label: 'Ready' },
    { value: 'gaps', label: 'Has gaps' },
  ];
  releaseOptions: DropdownOption[] = [];

  private rebuildSubjectDerived(): void {
    const all = this.allSubjects ?? [];
    const statuses = Array.from(new Set(all.map(s => s.status))).sort();
    const devs = Array.from(new Set(all.map(s => s.developerName))).sort();
    this.statusFilterOptions = [{ value: '', label: 'All status' }, ...statuses.map(s => ({ value: s, label: s }))];
    this.devFilterOptions = [{ value: '', label: 'All developers' }, ...devs.map(d => ({ value: d, label: d }))];
    this.applyFilters();
  }

  applyFilters(): void {
    let list = this.allSubjects ?? [];
    const q = this.filterText.trim().toLowerCase();
    if (q) list = list.filter(s =>
      s.key.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) ||
      s.developerName.toLowerCase().includes(q) || s.reporterName.toLowerCase().includes(q) ||
      s.developerEmail.toLowerCase().includes(q));
    if (this.filterStatus) list = list.filter(s => s.status === this.filterStatus);
    if (this.filterDev) list = list.filter(s => s.developerName === this.filterDev);
    if (this.filterReadiness === 'ready') list = list.filter(s => s.readiness.missingCount === 0);
    if (this.filterReadiness === 'gaps') list = list.filter(s => s.readiness.missingCount > 0);
    this.filtered = list;
    // Keep the current page in range after filtering.
    if (this.page >= this.totalPages) this.page = Math.max(0, this.totalPages - 1);
  }
  // The subjects visible on the current page (client-side pagination of the
  // filtered list, so filters persist across page changes).
  get pagedSubjects(): Subject[] {
    const start = this.page * this.size;
    return this.filtered.slice(start, start + this.size);
  }
  setStatusFilter(v: string): void { this.filterStatus = v; this.page = 0; this.applyFilters(); }
  setReadinessFilter(v: string): void { this.filterReadiness = v; this.page = 0; this.applyFilters(); }
  setDevFilter(v: string): void { this.filterDev = v; this.page = 0; this.applyFilters(); }
  clearFilters(): void { this.filterText = ''; this.filterStatus = ''; this.filterReadiness = ''; this.filterDev = ''; this.page = 0; this.applyFilters(); }
  get hasFilters(): boolean { return !!(this.filterText || this.filterStatus || this.filterReadiness || this.filterDev); }

  private buildReleaseOptions(): void {
    const currentYear = new Date().getFullYear();
    const yearOf = (r: Release): number => {
      if (r.releaseDate) { const y = new Date(r.releaseDate).getFullYear(); if (!isNaN(y)) return y; }
      const m = r.name.match(/(20\d{2})/); // e.g. STS-2026-R6
      return m ? parseInt(m[1], 10) : 0;
    };
    // Hide archived: only show current year and future (drop older years).
    const visible = this.releases.filter(r => {
      const y = yearOf(r);
      return y === 0 || y >= currentYear;
    });
    // Sort: active (unreleased) first, then by year (current year first), then name.
    visible.sort((a, b) => {
      if (a.released !== b.released) return a.released ? 1 : -1;     // active first
      const ya = yearOf(a), yb = yearOf(b);
      if (ya !== yb) return yb - ya;                                  // newer year first
      return b.name.localeCompare(a.name);
    });
    this.releaseOptions = visible.map(r => ({
      value: r.name, label: r.name,
      tag: r.released ? 'Released' : 'Active', tagLive: !r.released,
    }));
  }

  private buildDevLegend(): void {
    const pal = ['#00A36F', '#3E63DD', '#D98E04', '#6E56CF', '#E5484D', '#12A594', '#E93D82', '#5B6472'];
    const d = this.summary?.developerDistribution ?? [];
    this.devLegend = d.map((x, i) => ({ name: x.developer, count: x.subjectCount, color: pal[i % pal.length] }));
  }

  nextPage(): void { if (this.page + 1 < this.totalPages) { this.page++; } }
  prevPage(): void { if (this.page > 0) { this.page--; } }
  goPage(p: number): void { this.page = p; }
  get totalPages(): number { return Math.max(1, Math.ceil(this.filtered.length / this.size)); }
  get pageNumbers(): number[] { return Array.from({ length: this.totalPages }, (_, i) => i); }
  get selRelease(): Release | undefined { return this.releases.find(r => r.name === this.selected); }

  sendMail(s: Subject): void {
    this.sendingKey = s.key;
    this.api.sendMail(this.selected, s.key).subscribe(r => { this.sendingKey = ''; this.flash('Email queued for ' + s.developerName + ' + reporter'); });
  }
  mailAll(): void { this.mailingAll = true; this.api.mailAll(this.selected).subscribe({ next: r => { this.mailingAll = false; this.flash('Queued ' + r.sent + ' email(s) to developers with gaps'); }, error: () => { this.mailingAll = false; this.flash('Failed to send — check backend logs'); } }); }
  mailSummary(): void { this.mailingSummary = true; this.api.mailSummary(this.selected).subscribe({ next: r => { this.mailingSummary = false; this.flash(r.status || 'Summary email sent'); }, error: () => { this.mailingSummary = false; this.flash('Failed to send summary — check backend logs'); } }); }

  missingLabels(s: Subject): string[] { return s.readiness.missing.map(m => this.artifactLabels[m] ?? m); }
  gapLabel(key: string): string { return this.artifactLabels[key] ?? key; }
  statusClass(st: string): string {
    return st === 'ACTIVE' ? 's-active' : st === 'DUE_SOON' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : 's-active';
  }
  gradeClass(g?: string): string { return g === 'EXCELLENT' ? 'g-ex' : g === 'GOOD' ? 'g-gd' : g === 'AT_RISK' ? 'g-rk' : g === 'CRITICAL' ? 'g-cr' : 'g-gd'; }
  objectKeys(o: Record<string, string> | undefined | null): string[] { return o ? Object.keys(o) : []; }
  isMissing(s: Subject, key: string): boolean { return !!s.readiness?.missing?.includes(key); }
  whyOpen: Record<string, boolean> = {};
  toggleWhy(key: string): void { this.whyOpen[key] = !this.whyOpen[key]; }
  spOpen: Record<string, boolean> = {};
  toggleSp(key: string): void { this.spOpen[key] = !this.spOpen[key]; }
  // True if the subject has a yellow Octane needs-attention flag.
  hasNeedsAttention(s: Subject): boolean {
    return (s.readiness?.octaneMissingEnvs || []).some(e => (e || '').toLowerCase().includes('needs attention'));
  }
  // Per-subject refresh: re-check just one subject and update its row.
  refreshingKey = '';
  refreshSubject(s: Subject): void {
    this.refreshingKey = s.key;
    // Collapse any expanded evidence panels for this subject while it refreshes.
    this.whyOpen[s.key] = false;
    this.spOpen[s.key] = false;
    this.api.refreshSubject(this.selected, s.key).subscribe({
      next: fresh => {
        if (fresh) {
          const upd = (list: Subject[]) => { const i = list.findIndex(x => x.key === fresh.key); if (i >= 0) list[i] = fresh; };
          upd(this.allSubjects);
          this.applyFilters();
          this.rebuildSubjectDerived();
        }
        this.refreshingKey = '';
        this.flash('Refreshed ' + s.key);
      },
      error: () => { this.refreshingKey = ''; this.flash('Refresh failed for ' + s.key); },
    });
  }
  detailClass(d: string): string {
    const t = (d || '').toLowerCase();
    // The explanation line mentions multiple states — keep it neutral.
    if (t.startsWith('latest run per test overrides')) return 'd-note';
    if (t.endsWith(': skipped') || t.includes(': skipped')) return 'd-skip';
    // Overall + per-test lines: colour by the status word at the end.
    if (t.includes('— failed') || t.endsWith('failed') || t.includes(': failed') || t.includes('result: failed')) return 'd-fail';
    if (t.includes('needs attention') || t.includes('release not tagged')) return 'd-warn';
    if (t.includes('— passed') || t.includes('result: passed') || t.includes(': passed')) return 'd-ok';
    if (t.includes('no test') || t.includes('never run') || (t.includes('no run') && !t.includes('needs attention'))) return 'd-fail';
    return '';
  }
  detailText(d: string): string { return (d || '').split(' ||')[0]; }
  detailLink(d: string): string | null { const p = (d || '').split(' ||'); return p.length > 1 ? p[1] : null; }
  // Octane status dot: red if any failure/missing test, yellow if needs-attention
  // (and nothing worse), green if all clear.
  octaneDot(s: Subject): string {
    const envs = (s.readiness.octaneMissingEnvs || []).map(e => e.toLowerCase());
    // Release-tag issues carry "needs attention" and are yellow, not red.
    const hasFail = envs.some(e => (e.includes('failed') || e.includes('no test')
      || e.includes('never run') || e.includes('cannot verify')
      || (e.includes('not run') && !e.includes('needs attention')))
      && !e.includes('release not tagged') && !e.includes('needs attention'));
    if (hasFail || !s.readiness.octaneTestsLinked) return 'n';   // red
    const hasAttention = envs.some(e => e.includes('needs attention'));
    if (hasAttention) return 'w';                                // yellow
    return 'y';                                                   // green
  }

  savingCp = false;
  // Milestones editable in Config, including the Release cutoff date.
  milestones: { key: string; label: string; date: string; overridden: boolean; status: string }[] = [];
  private recomputeMilestones(): void {
    const tl = this.checkpoints?.timeline ?? [];
    // RELEASE is read-only (from Jira); DOC_CUTOFF is the editable document deadline.
    this.milestones = tl.filter(m => m.key !== 'RELEASE').map(m => ({
      key: m.key,
      label: m.key === 'DOC_CUTOFF' ? 'Document cutoff' : m.label,
      date: (m.date ?? '').substring(0, 10),
      overridden: !!m.overridden,
      status: m.status ?? '',
    }));
    this.rebuildEnvLinkDefs();
  }
  // Extra PPD stages currently on the timeline (PPD3, PPD4, …).
  get extraPpdKeys(): string[] {
    return this.milestones.filter(m => /^PPD[3-9]$/.test(m.key)).map(m => m.key);
  }
  // Add the next PPD stage (PPD-3, then PPD-4, …). Defaults its date to the day
  // after PPD-2 (or the last extra PPD), then the user can adjust it.
  addPpdStage(): void {
    const existing = new Set(this.extraPpdKeys);
    let n = 3;
    while (existing.has('PPD' + n) && n < 9) n++;
    if (n > 8) { this.flash('Maximum PPD stages reached'); return; }
    // Seed a date: day after the latest PPD currently on the timeline.
    const ppdDates = this.milestones
      .filter(m => /^PPD\d$/.test(m.key) && m.date)
      .map(m => new Date(m.date));
    let seed = ppdDates.length ? new Date(Math.max(...ppdDates.map(d => d.getTime()))) : new Date();
    seed.setDate(seed.getDate() + 1);
    const iso = seed.toISOString().substring(0, 10);
    this.onCheckpointDate('PPD' + n, iso);
  }
  removePpdStage(key: string): void {
    // Clearing the date removes the override, which removes the stage.
    this.onCheckpointDate(key, '');
  }
  isExtraPpd(key: string): boolean { return /^PPD[3-9]$/.test(key); }

  /**
   * The timeline shown on the dashboard, stored as a plain field (NOT a getter).
   * A getter here would run on every Angular change-detection cycle and return a
   * brand-new array each time, which caused the UI to freeze. Instead we rebuild
   * this only when the underlying data changes (rebuildTimeline()).
   */
  displayTimeline: Milestone[] = [];

  rebuildTimeline(): void {
    const tl = this.checkpoints?.timeline ?? [];
    const rc = this.releaseChanges;
    // Recompute every calculated node's status fresh from its own date, so a stale
    // or timezone-skewed status string can't mislabel a stage (e.g. End-UAT "today").
    const withFreshStatus = (m: Milestone): Milestone => {
      // Keep an explicit DONE / CANCELLED (a stage marked complete or cancelled
      // stays that way regardless of date). Everything else is recomputed fresh
      // from its own date so Today / Soon / Overdue are always accurate.
      if (m.status === 'DONE' || m.status === 'CANCELLED') return m;
      return { ...m, status: this.calcNodeStatus(m.date, this.isDeadlineStage(m.key)) };
    };

    const hasSnow = !!rc && ((rc.ppd1?.length || 0) + (rc.ppd2?.length || 0)
      + (rc.prod?.length || 0) + (rc.extraPpd?.length || 0) > 0);
    if (!hasSnow) {
      const hasExtraPpd = tl.some(m => this.isExtraPpd(m.key));
      const base = hasExtraPpd ? tl.filter(m => m.key !== 'PPD1_ROLLBACK') : tl;
      this.displayTimeline = base.map(withFreshStatus);
      return;
    }
    const now = new Date();
    const ymd = (s?: string) => (s || '').substring(0, 10);
    const nodes: Milestone[] = [];
    const keep = new Set(['END_UAT', 'DOC_CUTOFF', 'LCAB']);
    for (const m of tl) if (keep.has(m.key)) nodes.push(withFreshStatus(m));

    const addChangeNodes = (arr: ServiceNowTicket[] | undefined, baseLabel: string, key: string) => {
      (arr || []).forEach((t) => {
        if (!t.startDate) return;
        // Derive the label per-ticket from its own env, so PPD-3/PPD-4 etc. each
        // show their real stage number rather than the group's base label.
        const envN = /^PPD(\d+)$/.exec(t.env || '');
        const label = envN ? 'PPD-' + envN[1] : baseLabel;
        nodes.push({
          key: (t.env || key) + '_' + t.number, label,
          date: ymd(t.startDate), status: this.snowNodeStatus(t, now) as Milestone['status'],
          overridden: true, changeNumber: t.number, changeUrl: t.url,
        } as Milestone);
      });
    };
    addChangeNodes(rc!.ppd1, 'PPD-1', 'PPD1');
    addChangeNodes(rc!.ppd2, 'PPD-2', 'PPD2');
    addChangeNodes(rc!.extraPpd, 'PPD', 'PPD');   // PPD-3, PPD-4, … (label from env)
    addChangeNodes(rc!.prod, 'Release', 'RELEASE');
    nodes.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    this.displayTimeline = nodes;
  }
  // Manual environment links (PPD-1, PPD-2, Prod ServiceNow). Each has an optional
  // label (e.g. a ServiceNow change number) and a URL.
  envLinks: Record<string, {label: string; url: string}> = {};
  // Which timeline stage each env link maps to (for inline display).
  // The Prod ServiceNow change belongs to the production release, so it shows
  // under the RELEASE node — not PPD-1.
  envLinkStage: Record<string, string> = { PPD1: 'PPD1', PPD2: 'PPD2', PROD_SERVICENOW: 'RELEASE' };
  envLinkDefs: { key: string; label: string }[] = [
    { key: 'PPD1', label: 'PPD-1 environment' },
    { key: 'PPD2', label: 'PPD-2 environment' },
    { key: 'PROD_SERVICENOW', label: 'Prod ServiceNow change' },
  ];
  // Rebuild env-link inputs so each extra PPD stage gets its own link slot, mapped
  // to its own timeline node.
  private rebuildEnvLinkDefs(): void {
    const defs: { key: string; label: string }[] = [
      { key: 'PPD1', label: 'PPD-1 environment' },
      { key: 'PPD2', label: 'PPD-2 environment' },
    ];
    for (const k of this.extraPpdKeys) {
      const n = k.replace('PPD', '');
      defs.push({ key: k, label: 'PPD-' + n + ' environment' });
      this.envLinkStage[k] = k;   // maps to its own node
    }
    defs.push({ key: 'PROD_SERVICENOW', label: 'Prod ServiceNow change' });
    this.envLinkDefs = defs;
    this.recomputeStageLinks();
  }
  savingLink = '';
  loadEnvLinks(): void {
    if (!this.selected) return;
    this.api.getEnvLinks(this.selected).subscribe({ next: m => { this.envLinks = m || {}; this.recomputeStageLinks(); }, error: () => {} });
    this.api.getStatusOverrides(this.selected).subscribe({ next: m => this.statusOverrides = m || {}, error: () => {} });
    this.loadChanges(false);
  }

  /** Loads ServiceNow changes. refresh=true bypasses the backend cache. */
  loadChanges(refresh: boolean): void {
    if (!this.selected) return;
    this.loadingChanges = true;
    if (refresh) { this.releaseChanges = undefined; this.changeGroups = []; }
    this.api.getReleaseChanges(this.selected, refresh).subscribe({
      next: c => {
        this.releaseChanges = c;
        this.loadingChanges = false;
        this.rebuildChangeGroups();
        this.recomputeStageLinks();
        this.rebuildTimeline();
        // NOTE: no CTASK fetching here. CTASKs load only when a change is expanded.
      },
      error: () => { this.releaseChanges = undefined; this.changeGroups = []; this.loadingChanges = false; },
    });
  }
  releaseChanges?: ReleaseChanges;
  loadingChanges = false;

  // Per-change expand + lazy CTASK loading.
  changeOpen: Record<string, boolean> = {};
  ctaskLoading: Record<string, boolean> = {};
  toggleChange(c: ServiceNowTicket): void {
    const open = !this.changeOpen[c.number];
    this.changeOpen[c.number] = open;
    // Load CTASKs the first time it's expanded (if not already present).
    if (open && !c.ctasks?.length && !this.ctaskLoading[c.number]) {
      this.ctaskLoading[c.number] = true;
      this.api.getChangeCtasks(c.number).subscribe({
        next: tasks => { c.ctasks = tasks || []; this.ctaskLoading[c.number] = false; },
        error: () => { this.ctaskLoading[c.number] = false; },
      });
    }
  }

  // ---- ServiceNow change groups (PPD-1 / PPD-2 / PROD) with min/max ----
  changeGroups: { key: string; label: string; changes: ServiceNowTicket[] }[] = [];
  changeGroupOpen: Record<string, boolean> = { PPD1: true, PPD2: true, PROD: true };
  private rebuildChangeGroups(): void {
    const rc = this.releaseChanges;
    if (!rc) { this.changeGroups = []; return; }
    // Group the extra PPD changes (PPD-3+) by their env, one group per stage.
    const extraByEnv = new Map<string, ServiceNowTicket[]>();
    for (const t of rc.extraPpd || []) {
      const env = (t.env || 'PPD').toUpperCase();
      if (!extraByEnv.has(env)) extraByEnv.set(env, []);
      extraByEnv.get(env)!.push(t);
    }
    const extraGroups = [...extraByEnv.entries()]
      .sort((a, b) => a[0].localeCompare(b[0], undefined, { numeric: true }))
      .map(([env, changes]) => ({
        key: env,
        label: (/^PPD(\d+)$/.exec(env)?.[1]) ? 'PPD-' + /^PPD(\d+)$/.exec(env)![1] : env,
        changes,
      }));
    this.changeGroups = [
      { key: 'PPD1', label: 'PPD-1', changes: rc.ppd1 || [] },
      { key: 'PPD2', label: 'PPD-2', changes: rc.ppd2 || [] },
      ...extraGroups,
      { key: 'PROD', label: 'PROD', changes: rc.prod || [] },
    ];
  }
  toggleChangeGroup(key: string): void { this.changeGroupOpen[key] = !this.changeGroupOpen[key]; }
  snowStateClass(state: string): string {
    const s = (state || '').toLowerCase();
    if (s.includes('clos') || s.includes('complete') || s.includes('review')) return 'st-done';
    if (s.includes('implement') || s.includes('progress')) return 'st-active';
    if (s.includes('cancel') || s.includes('fail')) return 'st-bad';
    return 'st-new';
  }

  /** Derives a timeline node status from a change's state + end date. */
  private snowNodeStatus(t: ServiceNowTicket, now: Date): string {
    const state = (t.state || '').toLowerCase().trim();
    // Cancelled changes are terminal — never overdue.
    if (state.includes('cancel')) return 'CANCELLED';
    const isClosed = state === 'closed' || state === 'complete' || state === 'completed'
      || state === 'closed complete' || state.startsWith('clos');
    // A change in "Implement" (or in-progress) is actively running -> Ongoing,
    // regardless of the calendar date. Shown with a heartbeat pulse.
    if (!isClosed && (state.includes('implement') || state.includes('in progress') || state.includes('work in progress')))
      return 'ONGOING';
    // Compare by calendar DAY (not timestamp) to avoid timezone drift that made a
    // future date momentarily look like "today".
    const dayNum = (s?: string): number | null => {
      if (!s) return null;
      const d = s.substring(0, 10); // YYYY-MM-DD
      const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d);
      return m ? Number(m[1]) * 10000 + Number(m[2]) * 100 + Number(m[3]) : null;
    };
    const todayNum = now.getFullYear() * 10000 + (now.getMonth() + 1) * 100 + now.getDate();
    const endN = dayNum(t.endDate);
    const startN = dayNum(t.startDate);
    const deadlineN = endN ?? startN;
    if (!isClosed && deadlineN != null && deadlineN < todayNum) return 'OVERDUE';
    if (isClosed) return 'DONE';
    if (startN != null && startN <= todayNum) return 'ACTIVE'; // starts today / in progress
    // Future change: Today already handled above. Tomorrow / Soon / Upcoming.
    const d = this.daysUntilLocal(t.startDate);
    if (d === 1) return 'DUE_TOMORROW';
    if (d != null && d <= this.DUE_SOON_DAYS) return 'DUE_SOON';
    return 'UPCOMING';
  }

  // "Soon" threshold in days for calculated timeline stages (matches backend).
  private readonly DUE_SOON_DAYS = 4;

  /**
   * Whole calendar days from today to a YYYY-MM-DD date, built from components so
   * there is NO UTC-parse shift and NO time-of-day contamination. Negative = past.
   */
  private daysUntilLocal(dateStr?: string): number | null {
    if (!dateStr) return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(dateStr.substring(0, 10));
    if (!m) return null;
    const target = new Date(+m[1], +m[2] - 1, +m[3]);        // local midnight
    const n = new Date();
    const today = new Date(n.getFullYear(), n.getMonth(), n.getDate());
    return Math.round((target.getTime() - today.getTime()) / 86_400_000);
  }

  /**
   * Status for a CALCULATED timeline node, recomputed fresh from its own date so a
   * stale/timezone-skewed status string can never make e.g. End-UAT read "today".
   * Deadline stages (End-UAT, Document cutoff) are never ACTIVE ("today") — once
   * their date passes the window is simply DONE.
   */
  private calcNodeStatus(dateStr: string | undefined, isDeadline: boolean): Milestone['status'] {
    const d = this.daysUntilLocal(dateStr);
    if (d == null) return 'UPCOMING';
    if (d < 0) return 'OVERDUE';          // past and not done
    if (d === 0) return 'ACTIVE';         // Today
    if (d === 1) return 'DUE_TOMORROW';   // Tomorrow
    if (d <= this.DUE_SOON_DAYS) return 'DUE_SOON';  // 2..window days = Soon
    return 'UPCOMING';
  }

  private isDeadlineStage(key: string): boolean {
    return key === 'END_UAT' || key === 'DOC_CUTOFF';
  }

  /**
   * Formats the YYYY-MM-DD part of a date as "Fri 17 Jul" using the exact calendar
   * day (built from components, local) — NOT the Angular date pipe, which UTC-parses
   * the string and can render the day before/after in some timezones. This keeps the
   * printed date consistent with the status computed by calcNodeStatus/snowNodeStatus,
   * so a node can never show yesterday's date next to a "today" tag.
   */
  fmtDay(dateStr?: string): string {
    if (!dateStr) return '';
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(dateStr.substring(0, 10));
    if (!m) return dateStr;
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getDay()];
    const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()];
    return wd + ' ' + d.getDate() + ' ' + mon;
  }

  // Incidents/problems are shown once the release has gone to Prod.
  get hasAnyChange(): boolean {
    const rc = this.releaseChanges;
    return !!rc && ((rc.ppd1?.length || 0) + (rc.ppd2?.length || 0) + (rc.prod?.length || 0) > 0);
  }

  /** Overall release status from the PROD ServiceNow change:
   *  'ongoing' while it's being implemented (heartbeat), 'released' once closed,
   *  or null when there's no prod change activity yet (show the countdown). */
  get releaseDayState(): 'ongoing' | 'released' | null {
    const prod = this.releaseChanges?.prod || [];
    if (prod.length === 0) return null;
    const st = (s?: string) => (s || '').toLowerCase();
    const closed = (s?: string) => st(s).includes('clos') || st(s).includes('complete') || st(s).includes('review');
    const implementing = (s?: string) => st(s).includes('implement') || st(s).includes('in progress');
    if (prod.every(t => closed(t.state))) return 'released';
    if (prod.some(t => implementing(t.state))) return 'ongoing';
    return null;
  }

  // Incidents/problems for the ServiceNow tab (lazy).
  issues?: ReleaseChanges;
  loadingIssues = false;
  loadIssues(): void {
    if (!this.selected) return;
    this.loadingIssues = true;
    this.api.getServiceNowIssues(this.selected).subscribe({
      next: r => { this.issues = r; this.loadingIssues = false; },
      error: () => { this.loadingIssues = false; },
    });
  }

  // Incidents/problems are shown once the release has gone to Prod.
  get showPostRelease(): boolean {
    return !!this.releaseChanges && (this.checkpoints?.daysToRelease ?? 1) < 0
      && ((this.releaseChanges.incidents?.length || 0) + (this.releaseChanges.problems?.length || 0) > 0);
  }
  hasEnvLinks(): boolean { return Object.keys(this.envLinks || {}).length > 0; }
  onEnvLink(key: string, label: string, url: string): void {
    this.savingLink = key;
    this.api.setEnvLink(this.selected, key, label, url).subscribe({
      next: m => { this.envLinks = m || {}; this.recomputeStageLinks(); this.savingLink = ''; this.flash('Link saved'); },
      error: () => { this.savingLink = ''; this.flash('Failed to save link'); },
    });
  }
  // Env links attached to a given timeline stage (for inline rendering).
  // Precomputed into stageLinks whenever envLinks changes, so the template does
  // not call a method returning a new array on every change-detection cycle
  // (which caused the dashboard to freeze).
  stageLinks: Record<string, { key: string; label: string; url: string }[]> = {};
  private recomputeStageLinks(): void {
    const out: Record<string, { key: string; label: string; url: string }[]> = {};
    // 1) Auto changes from ServiceNow, grouped by env, under their stage node.
    const rc = this.releaseChanges;
    if (rc) {
      const add = (stage: string, tickets: ServiceNowTicket[] | undefined) => {
        for (const t of tickets || []) {
          (out[stage] = out[stage] || []).push({ key: t.number, label: t.number, url: t.url });
        }
      };
      add('PPD1', rc.ppd1);
      add('PPD2', rc.ppd2);
      add('RELEASE', rc.prod);   // Prod changes under the Release node
    }
    // 2) Manual env-links (both — manual entries are additive to the auto ones).
    for (const d of this.envLinkDefs) {
      const stage = this.envLinkStage[d.key];
      const link = this.envLinks[d.key];
      if (stage && link && link.url) {
        (out[stage] = out[stage] || []).push({ key: d.key, label: link.label || d.label, url: link.url });
      }
    }
    this.stageLinks = out;
  }
  linksForStage(stageKey: string): { key: string; label: string; url: string }[] {
    return this.stageLinks[stageKey] || [];
  }

  // Manual timeline status override (Done / In Progress / Overdue / Scheduled).
  statusOptions: DropdownOption[] = [
    { value: '', label: 'Auto (from dates)' },
    { value: 'DONE', label: 'Done' },
    { value: 'ACTIVE', label: 'In Progress' },
    { value: 'OVERDUE', label: 'Overdue' },
    { value: 'UPCOMING', label: 'Scheduled' },
  ];
  statusOverrides: Record<string, string> = {};
  onStatusOverride(stageKey: string, status: string): void {
    this.api.setStatusOverride(this.selected, stageKey, status).subscribe({
      next: r => {
        this.statusOverrides = r.overrides || {};
        if (r.checkpoints && (r.checkpoints as any).timeline) { this.checkpoints = r.checkpoints; this.recomputeMilestones(); this.rebuildTimeline(); }
        this.flash('Status updated');
      },
      error: () => this.flash('Failed to update status'),
    });
  }

  onCheckpointDate(stage: string, date: string): void {
    this.savingCp = true;
    this.api.setCheckpoint(this.selected, stage, date || null).subscribe({
      next: cp => { this.checkpoints = cp; this.savingCp = false; this.recomputeMilestones(); this.rebuildTimeline(); this.flash("Milestone date updated"); },
      error: () => { this.savingCp = false; this.flash('Failed to update date'); },
    });
  }
  resetCheckpoints(): void {
    this.savingCp = true;
    this.api.resetCheckpoints(this.selected).subscribe({
      next: cp => { this.checkpoints = cp; this.savingCp = false; this.recomputeMilestones(); this.rebuildTimeline(); this.flash("Milestone dates reset to Jira"); },
      error: () => { this.savingCp = false; this.flash('Failed to reset dates'); },
    });
  }
  barClass(score?: number): string { const s = score ?? 0; return s >= 80 ? 'bar-ok' : s >= 50 ? 'bar-warn' : 'bar-bad'; }
  // Classifies an Octane missing-env label for coloring: failed/never-run are the
  // strongest (fail), wrong-release amber, no-test default red.
  envSeverity(env: string): string {
    const e = (env || '').toLowerCase();
    if (e.includes('failed') || e.includes('never run')) return 'gap-fail';
    if (e.includes('needs attention') || e.includes('wrong release')) return 'gap-warn';
    return '';
  }
  msClass(st: string): string { return st === 'ACTIVE' ? 's-active' : st === 'ONGOING' ? 's-ongoing' : st === 'DUE_SOON' ? 's-warn' : st === 'DUE_TOMORROW' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : st === 'CANCELLED' ? 's-cancel' : 's-up'; }
  msTag(st: string): string { return st === 'ACTIVE' ? 'today' : st === 'ONGOING' ? 'ongoing' : st === 'DUE_SOON' ? 'soon' : st === 'DUE_TOMORROW' ? 'tomorrow' : st === 'OVERDUE' ? 'overdue' : st === 'DONE' ? 'done' : st === 'CANCELLED' ? 'cancelled' : 'upcoming'; }
  gradeLabel(g?: string): string { return g === 'EXCELLENT' ? 'Excellent' : g === 'GOOD' ? 'Good' : g === 'AT_RISK' ? 'At risk' : g === 'CRITICAL' ? 'Critical' : '—'; }

  sysDot(st: string): string { return st === 'UP' ? 'dot-ok' : st === 'DOWN' ? 'dot-bad' : st === 'DEGRADED' ? 'dot-warn' : st === 'NOT_CONFIGURED' ? 'dot-mock' : 'dot-info'; }
  sysLabel(st: string): string { return st === 'UP' ? 'Live' : st === 'DOWN' ? 'Down' : st === 'DEGRADED' ? 'Degraded' : st === 'NOT_CONFIGURED' ? 'Off' : 'Mock'; }
  sysBadgeStyle(st: string): any {
    const map: any = { UP: ['var(--ok-dim)', 'var(--ok)'], DOWN: ['var(--bad-dim)', 'var(--bad)'], DEGRADED: ['var(--warn-dim)', 'var(--warn)'], MOCK: ['var(--info-dim)', 'var(--info)'], NOT_CONFIGURED: ['var(--chip)', 'var(--muted)'] };
    const c = map[st] || map['MOCK']; return { background: c[0], color: c[1] };
  }

  readyPct(): number { return this.summary && this.summary.totalSubjects ? Math.round(this.summary.ready / this.summary.totalSubjects * 100) : 0; }

  // ---- config editing ----
  cfgFor(key: string): SubjectCheckConfig {
    return this.checks?.overrides[key] ?? this.checks?.default ?? { octaneEnvironments: ENVS, bcmEndToEnd: false, skipSharePoint: [], note: '' };  }
  // Check config lists ALL subjects of the selected release (from Jira). The
  // JSON (checks.overrides) only customises specific subjects; subjects without
  // an override use the default config.
  booting = true;
  spConfig: any = null;
  allSubjects: Subject[] = [];
  cfgLoading = false;
  // background scan status
  scanState: { scanning: boolean; lastChecked: string | null; nextCheck: string | null; subjectCount: number; progress?: string | null } | null = null;
  get scanPct(): number {
    const p = this.scanState?.progress;
    if (!p) return 0;
    const m = /^(\d+)\/(\d+)$/.exec(p);
    if (!m || +m[2] === 0) return 0;
    return Math.round((+m[1] / +m[2]) * 100);
  }
  private scanTimer: any = null;

  jiraBase = (typeof window !== 'undefined' && (window as any).__cockpit?.jiraBaseUrl) || 'https://jira.group.echonet';
  jiraUrl(key: string): string { return `${this.jiraBase}/browse/${key}`; }

  // Builds the absolute SharePoint folder URL where a given artifact's document
  // should be created, with {YEAR} filled from the selected release.
  sharePointUrl(artifactKey: string): string | null {
    const cfg = this.spConfig;
    if (!cfg || !cfg.sharePointBaseUrl) return null;
    const art = cfg.sharePointArtifacts?.[artifactKey];
    if (!art || !art.folder) return null;
    const year = this.yearOfSelected();
    const folder = String(art.folder).replace(/\{YEAR\}/g, String(year));
    // base-url already includes /sites/<site>; the library is a doc-lib path segment.
    const lib = cfg.sharePointLibrary ? '/' + encodeURI(cfg.sharePointLibrary) : '';
    return `${cfg.sharePointBaseUrl}${lib}${encodeURI(folder)}`;
  }
  private yearOfSelected(): number {
    const r = this.releases.find(x => x.name === this.selected);
    if (r?.releaseDate) { const y = new Date(r.releaseDate).getFullYear(); if (!isNaN(y)) return y; }
    const m = (this.selected || '').match(/(20\d{2})/);
    return m ? parseInt(m[1], 10) : new Date().getFullYear();
  }
  // Map a gap key to the artifact key used in config for the SharePoint link.
  gapArtifactKey(gap: string): string { return gap; }

  pollScanStatus(): void {
    if (this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; }
    let firstPoll = true;
    const refreshAll = () => {
      this.loadSubjects();
      this.loadingCharts = true; this.loadingHealth = true;
      this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; this.loadingCharts = false; });
      this.api.getHealth(this.selected).subscribe(h => { this.health = h; this.loadingHealth = false; });
    };
    const tick = () => {
      if (!this.selected) return;
      this.api.getScanStatus(this.selected).subscribe(st => {
        const wasScanning = this.scanState?.scanning;
        this.scanState = st;
        // Refresh when a scan finishes, OR when the very first poll already shows
        // a completed scan with data (scan finished before we started polling).
        if ((wasScanning && !st.scanning) ||
            (firstPoll && !st.scanning && (st.subjectCount ?? 0) > 0 && !this.summary)) {
          refreshAll();
        }
        firstPoll = false;
        if (!st.scanning && this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; }
      });
    };
    tick();
    this.scanTimer = setInterval(tick, 4000);
  }
  cfgKeys: string[] = [];
  // Accurate count for the Check config badge: full list once loaded, else the
  // release's total subject count from the summary (so it's right on first load).
  get cfgCount(): number {
    if (this.cfgKeys.length) return this.cfgKeys.length;
    if (this.summary?.totalSubjects) return this.summary.totalSubjects;
    return 0;
  }
  private recomputeCfgKeys(): void {
    // Prefer the full subject list (loaded when the config tab opens). Before that
    // is available, fall back to the current subjects page so the count is still
    // populated on first load / release change.
    let subjectKeys = this.allSubjects.map(s => s.key);
    if (subjectKeys.length) {
      const extra = this.checks ? Object.keys(this.checks.overrides).filter(k => !subjectKeys.includes(k)) : [];
      this.cfgKeys = [...subjectKeys, ...extra];
    } else {
      this.cfgKeys = this.checks ? Object.keys(this.checks.overrides) : [];
    }
  }

  toggleEnv(key: string, env: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.octaneEnvironments = cfg.octaneEnvironments.includes(env) ? cfg.octaneEnvironments.filter(e => e !== env) : [...cfg.octaneEnvironments, env];
    this.saveCfg(key, cfg);
  }
  toggleBcm(key: string): void { const cfg = { ...this.cfgFor(key) }; cfg.bcmEndToEnd = !cfg.bcmEndToEnd; this.saveCfg(key, cfg); }
  toggleSkip(key: string, item: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.skipSharePoint = cfg.skipSharePoint.includes(item) ? cfg.skipSharePoint.filter(s => s !== item) : [...cfg.skipSharePoint, item];
    this.saveCfg(key, cfg);
  }
  private saveCfg(key: string, cfg: SubjectCheckConfig): void {
    if (this.checks) this.checks.overrides[key] = cfg;
    this.api.putCheck(key, cfg, this.selected).subscribe(() => this.flash('Saved check config for ' + key));
  }

  private flash(m: string): void { this.toast = m; setTimeout(() => { if (this.toast === m) this.toast = ''; }, 3000); }

  private renderCharts(): void {
    if (!this.summary) return;
    const text = this.theme === 'dark' ? '#8A93A4' : '#6A7488';
    const grid = this.theme === 'dark' ? 'rgba(255,255,255,.06)' : 'rgba(17,24,39,.06)';
    const pal = ['#00A36F', '#3E63DD', '#D98E04', '#6E56CF', '#E5484D', '#12A594', '#E93D82', '#5B6472'];
    if (this.devChartRef) {
      this.devChart?.destroy();
      const d = this.summary.developerDistribution;
      const colors = d.map((_, i) => pal[i % pal.length]);
      this.devChart = new Chart(this.devChartRef.nativeElement, {
        type: 'doughnut',
        data: { labels: d.map(x => x.developer), datasets: [{ data: d.map(x => x.subjectCount), backgroundColor: colors, borderWidth: 0, hoverOffset: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '66%',
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: (ctx: any) => ` ${ctx.label}: ${ctx.parsed}` } }
          } },
      });
    }
    if (this.readyChartRef) {
      this.readyChart?.destroy();
      const b = this.summary.readinessBreakdown;
      this.readyChart = new Chart(this.readyChartRef.nativeElement, {
        type: 'bar',
        data: { labels: ['Octane', 'SharePoint'], datasets: [
          { label: 'Ready', data: [b.octaneOk, b.sharepointOk], backgroundColor: '#00A36F', borderRadius: 5, barPercentage: 0.55 },
          { label: 'Missing', data: [b.octaneMissing, b.sharepointMissing], backgroundColor: '#E5484D', borderRadius: 5, barPercentage: 0.55 } ] },
        options: { responsive: true, maintainAspectRatio: false,
          scales: { x: { stacked: true, grid: { display: false }, ticks: { color: text, font: { size: 11 } } },
                    y: { stacked: true, beginAtZero: true, grid: { color: grid }, ticks: { color: text, font: { size: 10 } } } },
          plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, boxHeight: 9, font: { size: 11 }, color: text, usePointStyle: true, pointStyle: 'circle' } } } },
      });
    }
  }
}
