package com.bnpparibas.releasecockpit.service;

import java.io.File;

/**
 * Resolves the directory used for runtime-editable JSON config: per-subject
 * check overrides, checkpoint/status overrides and environment links.
 *
 * WHY THIS EXISTS
 * ---------------
 * These files used to be written to a hard-coded relative "config/" directory,
 * i.e. inside the container's own filesystem. That filesystem is EPHEMERAL: when
 * the pod is recreated every edit made in the Check-config tab is lost and the
 * app silently falls back to the packaged defaults. That is why configuration
 * "was not taking" after a deployment.
 *
 * The directory is now resolvable at runtime, in this order:
 *   1. -Dcockpit.config-dir=/data/config     (JVM system property)
 *   2. COCKPIT_CONFIG_DIR=/data/config       (environment variable)
 *   3. "config"                              (previous behaviour; local dev)
 *
 * In Kubernetes point it at a mounted PersistentVolumeClaim, e.g.
 *
 *   env:
 *     - name: COCKPIT_CONFIG_DIR
 *       value: /data/config
 *   volumeMounts:
 *     - name: cockpit-config
 *       mountPath: /data/config
 *   volumes:
 *     - name: cockpit-config
 *       persistentVolumeClaim:
 *         claimName: release-cockpit-config
 *
 * so edits survive pod restarts and rescheduling.
 */
public final class ConfigStore {

    private ConfigStore() { }

    /** The (created-if-missing) directory holding runtime-editable config. */
    public static File dir() {
        String d = System.getProperty("cockpit.config-dir");
        if (isBlank(d)) d = System.getenv("COCKPIT_CONFIG_DIR");
        if (isBlank(d)) d = "config";
        File f = new File(d);
        if (!f.exists()) {
            // Best-effort: if the volume is read-only this simply fails and the
            // caller falls back to packaged defaults (logged by each service).
            f.mkdirs();
        }
        return f;
    }

    /** A file inside the runtime config directory. */
    public static File file(String name) {
        return new File(dir(), name);
    }

    /** True when the config directory is actually writable (for diagnostics). */
    public static boolean writable() {
        File d = dir();
        return d.exists() && d.canWrite();
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
