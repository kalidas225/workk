package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.SubjectCheckConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads and persists per-subject check overrides (subject-checks.json).
 *
 * Source of truth is the JSON file; the dashboard reads the resolved config and
 * the UI can update it via the controller. On update we write the file back so
 * the config survives restarts (in a container, mount this path on a volume).
 *
 * Resolution: a subject's effective config = its specific entry if present,
 * otherwise the "default" block.
 */
@Slf4j
@Service
public class SubjectConfigService {

    private static final String RESOURCE = "subject-checks.json";
    private final ObjectMapper mapper = new ObjectMapper();

    // In-memory model: default + per-RELEASE, per-subject map so overrides made
    // for one release never appear in another. Structure:
    //   { release -> { subjectKey -> config } }
    private SubjectCheckConfig defaults;
    private final Map<String, Map<String, SubjectCheckConfig>> byRelease = new LinkedHashMap<>();
    private File persistFile;

    public SubjectConfigService() {
        load();
    }

    private synchronized void load() {
        try {
            JsonNode root;
            File external = ConfigStore.file(RESOURCE);
            if (external.exists()) {
                root = mapper.readTree(external);
                persistFile = external;
            } else {
                try (InputStream is = new ClassPathResource(RESOURCE).getInputStream()) {
                    root = mapper.readTree(is);
                }
                persistFile = external;
            }
            defaults = parse(root.path("default"));
            byRelease.clear();
            // New format: releases -> { subjectKey -> config }.
            JsonNode releases = root.path("releases");
            if (releases.isObject()) {
                releases.fieldNames().forEachRemaining(rel -> {
                    Map<String, SubjectCheckConfig> subs = new LinkedHashMap<>();
                    JsonNode relNode = releases.path(rel);
                    relNode.fieldNames().forEachRemaining(key -> subs.put(key, parse(relNode.path(key))));
                    byRelease.put(rel, subs);
                });
            }
            // Back-compat: migrate a flat "subjects" block into an "_unassigned"
            // release bucket so nothing is lost on first load of an old file.
            JsonNode legacy = root.path("subjects");
            if (legacy.isObject() && legacy.size() > 0) {
                Map<String, SubjectCheckConfig> subs =
                        byRelease.computeIfAbsent("_unassigned", r -> new LinkedHashMap<>());
                legacy.fieldNames().forEachRemaining(key -> subs.put(key, parse(legacy.path(key))));
            }
            log.info("Loaded subject checks for {} release(s) from {} (config dir '{}', writable={})",
                    byRelease.size(),
                    external.exists() ? external.getAbsolutePath() : "classpath:" + RESOURCE,
                    ConfigStore.dir().getAbsolutePath(), ConfigStore.writable());
            if (!ConfigStore.writable()) {
                log.warn("Config directory {} is NOT writable — Check-config edits will be lost on restart. "
                        + "Set COCKPIT_CONFIG_DIR to a mounted volume.", ConfigStore.dir().getAbsolutePath());
            }
        } catch (Exception e) {
            log.warn("Could not load {} ({}); using built-in defaults", RESOURCE, e.getMessage());
            defaults = new SubjectCheckConfig(List.of("IST", "DEV", "UAT"), false, List.of(), null);
        }
    }

    private SubjectCheckConfig parse(JsonNode n) {
        // IMPORTANT: distinguish "key absent" (fall back to the standard envs)
        // from "key present but EMPTY" (the user deliberately unchecked every
        // Octane environment = skip Octane for this subject).
        //
        // Previously an empty list was silently replaced with IST/DEV/UAT, so a
        // "skip all Octane" choice was reverted on every reload and every pod
        // restart — the config looked like it "didn't take".
        List<String> envs = n.has("octaneEnvironments")
                ? strList(n.path("octaneEnvironments"))   // may legitimately be empty
                : List.of("IST", "DEV", "UAT");
        boolean bcm = n.path("bcmEndToEnd").asBoolean(false);
        List<String> skip = strList(n.path("skipSharePoint"));
        String note = n.path("note").asText(null);
        return new SubjectCheckConfig(envs, bcm, skip, note);
    }

    private List<String> strList(JsonNode n) {
        List<String> out = new ArrayList<>();
        if (n != null && n.isArray()) n.forEach(e -> out.add(e.asText()));
        return out;
    }

    /** Effective config for a subject in a release (its override, else default). */
    public SubjectCheckConfig forSubject(String release, String key) {
        Map<String, SubjectCheckConfig> subs = byRelease.get(release);
        return (subs != null && subs.containsKey(key)) ? subs.get(key) : defaults;
    }

    public SubjectCheckConfig getDefault() { return defaults; }

    /** Overrides for a single release (empty map if none). */
    public Map<String, SubjectCheckConfig> getOverrides(String release) {
        return byRelease.getOrDefault(release, Map.of());
    }

    /** Update one subject's override within a release and persist. */
    public synchronized SubjectCheckConfig update(String release, String key, SubjectCheckConfig cfg) {
        byRelease.computeIfAbsent(release, r -> new LinkedHashMap<>()).put(key, cfg);
        persist();
        return cfg;
    }

    /** Remove a subject override within a release (reverts to default) and persist. */
    public synchronized void remove(String release, String key) {
        Map<String, SubjectCheckConfig> subs = byRelease.get(release);
        if (subs != null) {
            subs.remove(key);
            if (subs.isEmpty()) byRelease.remove(release);
            persist();
        }
    }

    private void persist() {
        try {
            ObjectNode root = mapper.createObjectNode();
            root.set("default", toNode(defaults));
            ObjectNode releases = mapper.createObjectNode();
            byRelease.forEach((rel, subs) -> {
                ObjectNode subsNode = mapper.createObjectNode();
                subs.forEach((k, v) -> subsNode.set(k, toNode(v)));
                releases.set(rel, subsNode);
            });
            root.set("releases", releases);
            File target = persistFile != null ? persistFile : ConfigStore.file(RESOURCE);
            if (target.getParentFile() != null) target.getParentFile().mkdirs();
            mapper.writerWithDefaultPrettyPrinter().writeValue(target, root);
            persistFile = target;
            log.info("Persisted subject checks to {}", target.getPath());
        } catch (IOException e) {
            log.error("Failed to persist subject checks: {}", e.getMessage());
        }
    }

    private ObjectNode toNode(SubjectCheckConfig c) {
        ObjectNode n = mapper.createObjectNode();
        ArrayNode envs = n.putArray("octaneEnvironments");
        c.octaneEnvironments().forEach(envs::add);
        n.put("bcmEndToEnd", c.bcmEndToEnd());
        ArrayNode skip = n.putArray("skipSharePoint");
        c.skipSharePoint().forEach(skip::add);
        if (c.note() != null) n.put("note", c.note());
        return n;
    }
}
