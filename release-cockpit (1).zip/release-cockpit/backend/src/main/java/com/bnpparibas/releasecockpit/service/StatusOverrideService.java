package com.bnpparibas.releasecockpit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-release, per-stage MANUAL status overrides for the timeline milestones.
 * The timeline status is normally auto-derived from the dates; this lets a
 * release manager pin a stage's status (Done / In Progress / Overdue /
 * Scheduled) from the Config tab. Persisted to config/status-overrides.json.
 *
 * Keys are release-scoped: "{release}::{stageKey}" -> status string.
 * Recognised statuses map to the timeline's status vocabulary:
 *   DONE, ACTIVE (In Progress), OVERDUE, UPCOMING (Scheduled).
 */
@Service
public class StatusOverrideService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(StatusOverrideService.class);

    /** Allowed manual statuses shown in the UI dropdown. */
    public static final java.util.List<String> STATUSES =
            java.util.List.of("DONE", "ACTIVE", "OVERDUE", "UPCOMING");

    private final ObjectMapper mapper = new ObjectMapper();
    private final File store = ConfigStore.file("status-overrides.json");
    private final Map<String, String> statuses = new ConcurrentHashMap<>();

    public StatusOverrideService() { load(); }

    private void load() {
        try {
            if (store.exists()) {
                @SuppressWarnings("unchecked")
                Map<String, String> m = mapper.readValue(store, Map.class);
                statuses.putAll(m);
            }
        } catch (Exception e) { log.warn("Could not load status-overrides.json: {}", e.getMessage()); }
    }

    private synchronized void save() {
        try {
            store.getParentFile().mkdirs();
            Files.writeString(store.toPath(), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(statuses));
        } catch (Exception e) { log.warn("Could not save status-overrides.json: {}", e.getMessage()); }
    }

    /** All status overrides for a release, as stageKey -> status. */
    public Map<String, String> forRelease(String release) {
        Map<String, String> out = new LinkedHashMap<>();
        String prefix = release + "::";
        for (var e : statuses.entrySet()) {
            if (e.getKey().startsWith(prefix)) out.put(e.getKey().substring(prefix.length()), e.getValue());
        }
        return out;
    }

    /** Sets (or clears when blank/null) a stage's manual status. Returns the map. */
    public synchronized Map<String, String> set(String release, String stageKey, String status) {
        String k = release + "::" + stageKey;
        if (status == null || status.isBlank()) {
            statuses.remove(k);
        } else {
            String up = status.trim().toUpperCase();
            if (!STATUSES.contains(up)) throw new IllegalArgumentException("Unknown status: " + status);
            statuses.put(k, up);
        }
        save();
        return forRelease(release);
    }
}
