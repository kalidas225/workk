package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.connector.HttpClientFactory;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sends HTML readiness emails.
 *
 * Two delivery paths:
 *   - EMA SMTP (default / production): JavaMailSender via EmailMessageFactory.
 *     Recipients = developer + reporter, managers CC'd.
 *   - SecuredMail REST API (local dev only): used when
 *     cockpit.mail.secured-mail-url is set. Recipients = the configured
 *     fallback address only, no CC (manual forwarding).
 *
 * The SecuredMail URL being present is what selects the local-dev path, so the
 * production EMA configuration stays untouched.
 */
@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final EmailMessageFactory factory;     // null if no JavaMailSender
    private final HttpClient http;                  // for SecuredMail REST
    private final ObjectMapper mapper = new ObjectMapper();
    private final String jiraBaseUrl;
    private final ArtifactConfigService artifacts;

    public MailService(CockpitProperties props,
                       ObjectProvider<JavaMailSender> mailSenderProvider,
                       HttpClientFactory clients,
                       ArtifactConfigService artifacts) {
        this.props = props;
        this.artifacts = artifacts;
        JavaMailSender sender = mailSenderProvider.getIfAvailable();
        this.factory = (sender != null) ? new EmailMessageFactory(sender) : null;
        this.http = clients.proxied();
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
        if (useSecuredMail()) {
            log.info("Mail: using SecuredMail REST API (local-dev path) at {}",
                    props.getMail().getSecuredMailUrl());
        } else if (factory == null) {
            log.warn("Mail: no JavaMailSender and no SecuredMail URL — emails will be logged, not sent.");
        } else {
            log.info("Mail: using EMA SMTP relay (JavaMailSender).");
        }
    }

    /** Builds a SharePoint folder-URL resolver for a release's year. */
    private EmailTemplate.LinkResolver linkResolver(String releaseName) {
        var sp = props.getSharepoint();
        String base = sp.getBaseUrl() == null ? "" : sp.getBaseUrl();
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        int year = java.time.Year.now().getValue();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(20\\d{2})").matcher(releaseName == null ? "" : releaseName);
        if (m.find()) year = Integer.parseInt(m.group(1));
        final int yr = year;
        return artifactKey -> {
            var spec = artifacts.sharePointArtifacts().stream()
                    .filter(a -> a.key.equals(artifactKey)).findFirst().orElse(null);
            if (spec == null || spec.folder == null || spec.folder.isBlank()) return null;
            String folder = spec.folder.replace("{YEAR}", String.valueOf(yr));
            String libSeg = lib.isBlank() ? "" : "/" + enc(lib);
            return base + libSeg + encPath(folder);
        };
    }

    private static String enc(String s) { return java.net.URLEncoder.encode(s, java.nio.charset.StandardCharsets.UTF_8).replace("+", "%20"); }
    private static String encPath(String path) {
        StringBuilder sb = new StringBuilder();
        for (String seg : path.split("/")) {
            if (seg.isEmpty()) continue;
            sb.append("/").append(enc(seg));
        }
        return sb.toString();
    }

    private boolean useSecuredMail() {
        String url = props.getMail().getSecuredMailUrl();
        return url != null && !url.isBlank();
    }

    /** True if the subject has a yellow Octane "needs attention" flag. */
    private boolean hasNeedsAttention(Subject subject) {
        var envs = subject.readiness() == null ? null : subject.readiness().octaneMissingEnvs();
        return envs != null && envs.stream().anyMatch(m -> m != null && m.toLowerCase().contains("needs attention"));
    }

    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        // Email when there are gaps OR a needs-attention flag. A fully-clean subject
        // (no gaps, no attention) gets no mail.
        boolean attention = hasNeedsAttention(subject);
        if (subject.readiness() == null
                || (subject.readiness().missingCount() == 0 && !attention)) {
            log.info("Skipping mail for {} — no gaps and no attention (subject is clean)", subject.key());
            return "Skipped — " + subject.key() + " is clean";
        }
        List<String> to = recipientsFor(subject);
        List<String> cc = ccList();
        int gaps = subject.readiness().missingCount();
        // Count Octane needs-attention envs (yellow) separately from missing items.
        long attnCount = subject.readiness().octaneMissingEnvs() == null ? 0
                : subject.readiness().octaneMissingEnvs().stream()
                    .filter(m -> m != null && m.toLowerCase().contains("needs attention")).count();
        StringBuilder subj = new StringBuilder("[Release ").append(releaseName).append("] ");
        java.util.List<String> parts = new java.util.ArrayList<>();
        if (gaps > 0) parts.add(gaps + " missing");
        if (attnCount > 0) parts.add(attnCount + " needs attention");
        if (gaps > 0) subj.append("Action needed on ").append(subject.key());
        else subj.append("Octane needs attention on ").append(subject.key());
        if (!parts.isEmpty()) subj.append(" - ").append(String.join(", ", parts));
        String subjectLine = subj.toString();
        // The "cutoff" shown to developers is the document cutoff (defaults to the
        // The document cutoff (what the developer must hit) and the actual release
        // date are shown separately in the email.
        String cutoff = cp != null && cp.docCutoff() != null ? cp.docCutoff().toString()
                : (cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "");
        String relDate = cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "";
        String html = EmailTemplate.gapEmail(
                companyName(), releaseName, cutoff, relDate,
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key(), linkResolver(releaseName),
                artifacts.sharePointArtifacts());
        return send(to, cc, subjectLine, html, "gap:" + subject.key());
    }

    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0 || hasNeedsAttention(s)) {
                sendSubjectAlert(releaseName, s, cp); sent++;
            }
        }
        return sent;
    }

    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = summaryRecipients();
        // Subjects in ASCENDING order by Jira key (natural order, e.g.
        // TCAAS1484-1447 before TCAAS1484-4869), so the list reads predictably.
        List<Subject> allSorted = subjects.stream()
                .sorted(Comparator.comparing(Subject::key, String.CASE_INSENSITIVE_ORDER))
                .toList();
        String subjectLine = "[Release " + releaseName + "] Status - " + gradeLabel(health.grade())
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.docCutoff() != null ? cp.docCutoff().toString() : "",
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, allSorted, linkResolver(releaseName), jiraBaseUrl);
        return send(to, List.of(), subjectLine, html, "summary:" + releaseName);
    }

    private String gradeLabel(String g) {
        return switch (g == null ? "" : g) {
            case "GOOD", "EXCELLENT" -> "Good";
            case "AT_RISK" -> "At Risk";
            case "CRITICAL" -> "Critical";
            default -> g;
        };
    }

    // ── recipients ─────────────────────────────────────────────────────────
    private List<String> recipientsFor(Subject s) {
        // Local-dev SecuredMail path: send only to the configured address.
        if (useSecuredMail()) return fallbackList();
        // TO = the Jira subject's DEVELOPER (assignee) only. The managers go in CC
        // (see ccList()). The reporter is intentionally NOT addressed — re-add the
        // reporterEmail line below if you want them on TO as well.
        List<String> to = new ArrayList<>();
        if (s.developerEmail() != null && !s.developerEmail().isBlank()) to.add(s.developerEmail());
        // No developer e-mail on the Jira subject -> fall back so nothing is lost.
        if (to.isEmpty()) to.addAll(fallbackList());
        return to;
    }

    private List<String> summaryRecipients() {
        if (useSecuredMail()) return fallbackList();
        List<String> to = new ArrayList<>();
        for (String m : props.getMail().getSummaryTo()) if (m != null && !m.isBlank()) to.add(m.trim());
        for (String m : props.getMail().getManagersCc()) if (m != null && !m.isBlank()) to.add(m.trim());
        if (to.isEmpty()) to.addAll(fallbackList());
        return to;
    }

    private List<String> ccList() {
        // No CC on the SecuredMail local-dev path.
        if (useSecuredMail()) return List.of();
        List<String> cc = new ArrayList<>();
        for (String m : props.getMail().getManagersCc()) if (m != null && !m.isBlank()) cc.add(m.trim());
        return cc;
    }

    private List<String> fallbackList() {
        List<String> to = new ArrayList<>();
        String fb = props.getMail().getFallbackTo();
        if (fb != null && !fb.isBlank()) for (String a : fb.split(",")) if (!a.isBlank()) to.add(a.trim());
        return to;
    }

    // ── delivery ───────────────────────────────────────────────────────────
    private String send(List<String> to, List<String> cc, String subjectLine, String html, String tag) {
        if (props.isMockMode()) {
            log.info("MOCK MAIL [{}] to={} cc={} subject='{}' ({} chars)", tag, to, cc, subjectLine, html.length());
            return "Simulated send to " + String.join(", ", to);
        }
        return useSecuredMail()
                ? sendViaSecuredMail(to, subjectLine, html, tag)
                : sendViaSmtp(to, cc, subjectLine, html, tag);
    }

    private String sendViaSmtp(List<String> to, List<String> cc, String subjectLine, String html, String tag) {
        if (factory == null) {
            log.warn("UNSENT MAIL [{}] (no JavaMailSender) to={} subject='{}'", tag, to, subjectLine);
            return "Mail not configured";
        }
        try {
            String from = props.getMail().getFromAddress();
            MimeMessage msg = factory.createMessage(from, props.getMail().getReplyTo(), to, cc, subjectLine, html);
            factory.send(msg);
            log.info("EMA sent [{}] from {} to {} (cc {})", tag, from, to, cc);
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("EMA send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String sendViaSecuredMail(List<String> to, String subjectLine, String html, String tag) {
        var mail = props.getMail();
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("FromEmail", mail.getFromAddress());
            payload.put("ToEmail", to);
            payload.put("CcEmail", List.of());
            payload.put("BccEmail", List.of());
            payload.put("Subject", subjectLine);
            payload.put("emailMessage", html);
            payload.put("Body", html);
            payload.put("ClientName", "Release Guardian");
            payload.put("IsBodyHtml", true);
            String body = mapper.writeValueAsString(payload);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(mail.getSecuredMailUrl()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.error("SecuredMail [{}] HTTP {} body={}", tag, r.statusCode(), r.body());
                return "Send failed: HTTP " + r.statusCode();
            }
            log.info("SecuredMail sent [{}] to {} (HTTP {})", tag, to, r.statusCode());
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("SecuredMail send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String companyName() { return "BNP Paribas"; }
}
