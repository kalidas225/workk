package com.bnpparibas.releasecockpit.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Startup diagnostic for runtime-editable configuration storage.
 *
 * WHY: every edit made in the Check-config tab is written to {@link ConfigStore#dir()}.
 * If that directory is NOT a mounted volume it lives inside the container's own
 * (ephemeral) filesystem, so a pod restart or recreation silently reverts every
 * edit back to the packaged defaults — which looks like "the config got
 * overridden again".
 *
 * This component makes that condition impossible to miss: it logs, once at
 * startup, exactly where config is being stored, whether it is writable, and a
 * prominent warning when the location looks ephemeral.
 */
@Component
public class ConfigStorageCheck {

    private static final Logger log = LoggerFactory.getLogger(ConfigStorageCheck.class);

    public ConfigStorageCheck() {
        report();
    }

    private void report() {
        File dir = ConfigStore.dir();
        String path = dir.getAbsolutePath();
        boolean explicit = System.getProperty("cockpit.config-dir") != null
                || System.getenv("COCKPIT_CONFIG_DIR") != null;
        boolean writable = ConfigStore.writable();
        boolean mounted = looksMounted(dir);

        log.info("Config storage: dir={} explicit={} writable={} mounted={}",
                path, explicit, writable, mounted);

        if (!writable) {
            log.error("CONFIG DIR NOT WRITABLE: {} — edits in the Check-config tab CANNOT be saved "
                    + "and the app will keep using packaged defaults. Mount a writable volume and set "
                    + "COCKPIT_CONFIG_DIR to it.", path);
            return;
        }
        if (!explicit || !mounted) {
            log.warn("=====================================================================");
            log.warn(" CONFIG IS STORED ON EPHEMERAL CONTAINER STORAGE: {}", path);
            log.warn(" Every pod restart/recreation will RESET config to packaged defaults.");
            log.warn(" Fix: mount a PersistentVolumeClaim and set COCKPIT_CONFIG_DIR to it,");
            log.warn("      e.g. COCKPIT_CONFIG_DIR=/data/config  (see k8s-config-persistence.yaml)");
            log.warn("=====================================================================");
        } else {
            log.info("Config persistence OK — edits will survive pod restarts.");
        }
    }

    /**
     * Heuristic: is this path backed by a mount rather than the container's own
     * root filesystem? Reads /proc/mounts (Linux) and checks for a mount point at
     * or above the directory. Never throws — diagnostics must not break startup.
     */
    private boolean looksMounted(File dir) {
        try {
            Path target = dir.toPath().toAbsolutePath().normalize();
            Path proc = Path.of("/proc/mounts");
            if (!Files.exists(proc)) return false;
            for (String line : Files.readAllLines(proc)) {
                String[] parts = line.split("\\s+");
                if (parts.length < 2) continue;
                String mp = parts[1];
                // Ignore the root filesystem and pseudo filesystems.
                if (mp.equals("/") || mp.startsWith("/proc") || mp.startsWith("/sys")
                        || mp.startsWith("/dev")) continue;
                Path mount = Path.of(mp).toAbsolutePath().normalize();
                if (target.startsWith(mount)) return true;
            }
        } catch (Exception ignored) {
            // Diagnostics only.
        }
        return false;
    }
}
