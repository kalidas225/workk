package com.sourceforge.starter;

import com.sourceforge.starter.model.DatabaseConfig;
import com.sourceforge.starter.model.CosConfig;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.ProjectGeneratorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ProjectGeneratorServiceTests {

    @Autowired
    ProjectGeneratorService generator;

    @Test
    void generatesJavaMavenZipWithEnvAndDmzr() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21", "standard",
                List.of("web", "data-jpa", "lombok"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("h2", "", "sa", "", "update"),
                new EnvironmentConfig(true, List.of("dev", "ist", "prod"), "https://config.example.com", "dev"),
                new DmzrConfig(true, true, true, "demo-role", "secret/data/demo", "demo-ns", "registry.example.com/demo:1.0", List.of("dev", "prod")),
                "ap25701", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        assertNotNull(zip);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("demo/pom.xml"));
        assertTrue(entries.contains("demo/src/main/java/com/example/demo/DemoApplication.java"));
        assertTrue(entries.contains("demo/src/main/resources/application.properties"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-dev.yaml"));
        assertTrue(entries.contains("demo/src/main/resources/bootstrap-prod.yaml"));
        assertTrue(entries.contains("demo/dmzr/vault/policies/demo-dev.hcl"));
        assertTrue(entries.contains("demo/dmzr/helm/chart/Chart.yaml"));
        assertTrue(entries.contains("demo/dmzr/helm/values-dev.yaml"));
    }

    @Test
    void generatesPythonPoetryZip() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "poetry", "python", "",
                "com.example", "service", "service", "Python service",
                "com.example.service", "wheel", "3.12", "standard",
                List.of("fastapi", "uvicorn", "pydantic", "py-pytest"),
                Map.of(),
                Map.of(),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("service/pyproject.toml"));
        assertTrue(entries.contains("service/src/com_example_service/__init__.py"));
        assertTrue(entries.contains("service/src/com_example_service/main.py"));
        assertTrue(entries.contains("service/tests/test_smoke.py"));
        assertTrue(entries.contains("service/README.md"));
    }

    @Test
    void generatesPythonPipZipWithPostgres() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "pip", "python", "",
                "com.example", "api", "api", "API",
                "com.example.api", "wheel", "3.11", "standard",
                List.of("fastapi", "uvicorn", "sqlalchemy"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("postgresql", "", "postgres", "secret", "update"),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("api/requirements.txt"));
        assertTrue(entries.contains("api/setup.py"));
    }

    @Test
    void generatesMvcArchitectureSources() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "shop", "shop", "Shop",
                "com.example.shop", "jar", "21", "mvc",
                List.of(),
                Map.of(),
                Map.of(),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = unzip(zip);
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/controller/GreetingController.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/service/GreetingService.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/repository/GreetingRepository.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/model/Greeting.java"));
        assertTrue(entries.contains("shop/src/main/java/com/example/shop/dto/GreetingRequest.java"));
    }

    @Test
    void appliesDependencyVersionAndEditedFileOverrides() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "vo", "vo", "Version override",
                "com.example.vo", "jar", "21", "standard",
                List.of("web"),
                Map.of("web", "9.9.9"),
                Map.of("vo/README.md", "# CUSTOM EDITED\n"),
                DatabaseConfig.none(),
                EnvironmentConfig.disabled(),
                DmzrConfig.disabled(),
                "", CosConfig.disabled()
        );
        Map<String, String> files = generator.buildFiles(req);
        assertTrue(files.get("vo/pom.xml").contains("<version>9.9.9</version>"));
        assertTrue(files.get("vo/README.md").equals("# CUSTOM EDITED\n"));
    }

    @Test
    void generatesCosAndChartAssets() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "srs-back", "srs-back", "SRS Backend",
                "com.example.srsback", "jar", "21", "microservice",
                List.of("web", "data-jpa"),
                Map.of(),
                Map.of(),
                new DatabaseConfig("oracle", "", "srs_user", "srs_pass", "none"),
                new EnvironmentConfig(true, List.of("dev", "prod"), "", "dev"),
                DmzrConfig.disabled(),
                "ap10346",
                new CosConfig(true, List.of("co002i007156"), "s3.eu-de.cloud-object-storage.appdomain.cloud:4208", "bu002i012751")
        );
        Map<String, String> files = generator.buildFiles(req);
        String boot = files.get("srs-back/src/main/resources/bootstrap-dev.yaml");
        assertNotNull(boot);
        assertTrue(boot.contains("secret/ap10346/srs-back/dev"));
        assertTrue(boot.contains("objsto/co002i007156"));
        assertTrue(boot.contains("bucket: \"bu002i012751\""));
        assertTrue(boot.contains("authentication: KUBERNETES"));
        assertTrue(files.containsKey("srs-back/chart/helmfile.yaml"));
        assertTrue(files.containsKey("srs-back/chart/service-account.yaml"));
        assertTrue(files.containsKey("srs-back/chart/values-production.yaml"));
        assertTrue(files.containsKey("srs-back/chart/chart-dependencies.info"));
        assertTrue(files.containsKey("srs-back/Dockerfile"));
        assertTrue(files.get("srs-back/Dockerfile").contains("ENTRYPOINT [\"/usr/local/instances/srs-back/bin/entrypoint.sh\"]"));
        assertTrue(files.keySet().stream().noneMatch(k -> k.endsWith(".gitkeep")));
    }

    private Set<String> unzip(byte[] zipBytes) throws Exception {
        Set<String> entries = new HashSet<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) entries.add(e.getName());
        }
        return entries;
    }
}
