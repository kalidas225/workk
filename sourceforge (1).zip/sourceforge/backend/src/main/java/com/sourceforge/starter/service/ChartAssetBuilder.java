package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Generates the deployment chart assets that live under a top-level chart/ folder
 * (outside src), following the BP2S helmfile layout:
 *   chart/chart-dependencies.info
 *   chart/helmfile.yaml
 *   chart/service-account.yaml
 *   chart/values-default.yaml
 *   chart/values-development.yaml
 *   chart/values-integration.yaml
 *   chart/values-staging.yaml
 *   chart/values-teststaging.yaml
 *   chart/values-pre-production.yaml
 *   chart/values-production.yaml
 */
@Component
public class ChartAssetBuilder {

    /** The deployment environments produced under chart/, in order. */
    public static final List<String> CHART_ENVS = List.of(
            "default", "development", "integration", "staging",
            "teststaging", "pre-production", "production");

    public String chartDependenciesInfo(ProjectRequest req) {
        return ""
                + "# chart-dependencies.info\n"
                + "# Resolved chart dependencies for " + req.artifactId() + " (" + req.effectiveApplicationCode() + ").\n"
                + "name: " + req.artifactId() + "\n"
                + "applicationCode: " + req.effectiveApplicationCode() + "\n"
                + "dependencies:\n"
                + "  - name: bp2s-microservice\n"
                + "    repository: https://artifactory-dogen.group.echonet/helm-charts\n"
                + "    version: 2.x\n";
    }

    public String helmfileYaml(ProjectRequest req) {
        String app = req.artifactId();
        StringBuilder sb = new StringBuilder();
        sb.append("# helmfile.yaml — environments for ").append(app).append("\n");
        sb.append("environments:\n");
        for (String env : CHART_ENVS) {
            sb.append("  ").append(env).append(":\n");
            sb.append("    values:\n");
            sb.append("      - values-").append(env).append(".yaml\n");
        }
        sb.append("---\n");
        sb.append("releases:\n");
        sb.append("  - name: ").append(app).append("\n");
        sb.append("    namespace: {{ .Environment.Name }}\n");
        sb.append("    chart: bp2s-microservice/bp2s-microservice\n");
        sb.append("    values:\n");
        sb.append("      - values-default.yaml\n");
        sb.append("      - values-{{ .Environment.Name }}.yaml\n");
        return sb.toString();
    }

    public String serviceAccountYaml(ProjectRequest req) {
        String app = req.artifactId();
        String appCode = req.effectiveApplicationCode();
        String shortName = shortName(app);
        return ""
                + "apiVersion: v1\n"
                + "kind: ServiceAccount\n"
                + "metadata:\n"
                + "  name: " + app + "\n"
                + "  labels:\n"
                + "    app.kubernetes.io/name: " + app + "\n"
                + "    bnpp.applicationCode: " + appCode + "\n"
                + "  annotations:\n"
                + "    # Bound to the Vault Kubernetes auth role for this application.\n"
                + "    vault.role: ns002i008682_" + shortName + "-" + appCode + "-application\n";
    }

    public String valuesForEnv(ProjectRequest req, String env) {
        String app = req.artifactId();
        String appCode = req.effectiveApplicationCode();
        if ("default".equals(env)) {
            return ""
                    + "# values-default.yaml — shared defaults for " + app + "\n"
                    + "application:\n"
                    + "  name: " + app + "\n"
                    + "  code: " + appCode + "\n"
                    + "image:\n"
                    + "  repository: base-images-catalog.artifactory-dogen.group.echonet/" + app + "\n"
                    + "  pullPolicy: IfNotPresent\n"
                    + "service:\n"
                    + "  type: ClusterIP\n"
                    + "  port: 8080\n"
                    + "serviceAccount:\n"
                    + "  create: true\n"
                    + "  name: " + app + "\n"
                    + "resources:\n"
                    + "  requests:\n"
                    + "    cpu: 200m\n"
                    + "    memory: 512Mi\n"
                    + "  limits:\n"
                    + "    cpu: 1000m\n"
                    + "    memory: 1Gi\n"
                    + "probes:\n"
                    + "  liveness: /actuator/health/liveness\n"
                    + "  readiness: /actuator/health/readiness\n";
        }
        return ""
                + "# values-" + env + ".yaml — overrides for the " + env + " environment\n"
                + "replicaCount: " + replicasFor(env) + "\n"
                + "springProfile: " + profileFor(env) + "\n"
                + "image:\n"
                + "  tag: " + tagFor(env) + "\n"
                + "ingress:\n"
                + "  enabled: " + ingressFor(env) + "\n"
                + "  host: " + app + "-" + env + ".apps.echonet\n";
    }

    private int replicasFor(String env) {
        return switch (env) {
            case "production" -> 3;
            case "pre-production" -> 2;
            default -> 1;
        };
    }

    private String profileFor(String env) {
        return switch (env) {
            case "development" -> "dev";
            case "integration" -> "ist";
            case "staging", "teststaging" -> "uat";
            case "pre-production" -> "ppd";
            case "production" -> "prod";
            default -> "dev";
        };
    }

    private String tagFor(String env) {
        return "production".equals(env) ? "stable" : "latest";
    }

    private boolean ingressFor(String env) {
        return !"default".equals(env);
    }

    private String shortName(String artifactId) {
        if (artifactId == null || artifactId.isBlank()) return "app";
        int dash = artifactId.indexOf('-');
        return dash > 0 ? artifactId.substring(0, dash) : artifactId;
    }
}
