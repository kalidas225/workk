package com.sourceforge.starter.service;

import com.sourceforge.starter.exception.GenerationException;
import com.sourceforge.starter.model.Dependency;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Assembles the project. Builds an ordered map of {relativePath -> content},
 * which is shared by both the preview endpoint and the zip generator. Any paths
 * present in request.editedFiles() override the generated content, enabling the
 * "edit in Explore, then regenerate" workflow.
 */
@Service
public class ProjectGeneratorService {

    private static final Logger log = LoggerFactory.getLogger(ProjectGeneratorService.class);

    private final DependencyCatalogService catalog;
    private final PomBuilder pomBuilder;
    private final GradleBuilder gradleBuilder;
    private final PythonBuilder pythonBuilder;
    private final SourceTemplateService templates;
    private final BootstrapYamlBuilder bootstrapBuilder;
    private final DmzrBuilder dmzrBuilder;
    private final ArchitectureTemplateService architecture;
    private final ChartAssetBuilder chartBuilder;
    private final DockerfileBuilder dockerfileBuilder;

    public ProjectGeneratorService(DependencyCatalogService catalog,
                                   PomBuilder pomBuilder,
                                   GradleBuilder gradleBuilder,
                                   PythonBuilder pythonBuilder,
                                   SourceTemplateService templates,
                                   BootstrapYamlBuilder bootstrapBuilder,
                                   DmzrBuilder dmzrBuilder,
                                   ArchitectureTemplateService architecture,
                                   ChartAssetBuilder chartBuilder,
                                   DockerfileBuilder dockerfileBuilder) {
        this.catalog = catalog;
        this.pomBuilder = pomBuilder;
        this.gradleBuilder = gradleBuilder;
        this.pythonBuilder = pythonBuilder;
        this.templates = templates;
        this.bootstrapBuilder = bootstrapBuilder;
        this.dmzrBuilder = dmzrBuilder;
        this.architecture = architecture;
        this.chartBuilder = chartBuilder;
        this.dockerfileBuilder = dockerfileBuilder;
    }

    /** Build the full file map (path -> content), applying any edited-file overrides. */
    public Map<String, String> buildFiles(ProjectRequest request) {
        validateLanguageBuildCombo(request);
        List<Dependency> resolved = resolveAndValidate(request);
        log.info("resolved {} dependencies for {} (requested {})",
                resolved.size(), request.artifactId(), request.dependencies().size());

        Map<String, String> files = new LinkedHashMap<>();
        String root = request.artifactId() + "/";

        if (request.isPython()) {
            writePythonProject(files, root, request, resolved);
            log.info("python project built  artifact={}  build={}", request.artifactId(), request.type());
        } else {
            writeJavaProject(files, root, request, resolved);
            log.info("java project built  artifact={}  build={}  boot={}",
                    request.artifactId(), request.type(), request.bootVersion());
        }

        if (request.dmzr().enabled()) {
            writeDmzrAssets(files, root, request);
            log.info("DMZR assets built  artifact={}  vault={}  helm={}",
                    request.artifactId(), request.dmzr().vaultPolicies(), request.dmzr().helmChart());
        }

        // Chart folder (helmfile + per-env values + service account) and Dockerfile,
        // both outside src, for Java projects with environments enabled.
        if (request.isJava() && request.environments().enabled()) {
            writeChartAssets(files, root, request);
            writeDockerAssets(files, root, request);
            log.info("chart + docker assets built  artifact={}  appCode={}",
                    request.artifactId(), request.effectiveApplicationCode());
        }

        put(files, root + "HELP.md", buildHelp(request, resolved));

        // Apply edited-file overrides (regeneration after editing in Explore)
        if (request.editedFiles() != null && !request.editedFiles().isEmpty()) {
            int applied = 0;
            for (var e : request.editedFiles().entrySet()) {
                if (files.containsKey(e.getKey())) {
                    files.put(e.getKey(), e.getValue());
                    applied++;
                }
            }
            if (applied > 0) {
                log.info("applied {} edited file override(s)  artifact={}", applied, request.artifactId());
            }
        }
        return files;
    }

    /** Preview: the file map, for the Explore UI. */
    public Map<String, String> previewFiles(ProjectRequest request) {
        return buildFiles(request);
    }

    public byte[] generate(ProjectRequest request) {
        Map<String, String> files = buildFiles(request);
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ZipOutputStream zip = new ZipOutputStream(baos)) {
            for (var entry : files.entrySet()) {
                ZipEntry ze = new ZipEntry(entry.getKey());
                zip.putNextEntry(ze);
                String content = entry.getValue();
                if (content != null && !content.isEmpty()) {
                    zip.write(content.getBytes(StandardCharsets.UTF_8));
                }
                zip.closeEntry();
            }
            zip.finish();
            log.info("zip generated  artifact={}  files={}", request.artifactId(), files.size());
            return baos.toByteArray();
        } catch (IOException e) {
            log.error("zip generation failed for artifact={}: {}", request.artifactId(), e.getMessage());
            throw new GenerationException("Failed to generate project zip: " + e.getMessage(), e);
        }
    }

    /** Cross-field validation rules between language and build type. */
    private void validateLanguageBuildCombo(ProjectRequest request) {
        String lang = request.language();
        String type = request.type();
        String pkg  = request.packaging();
        if ("java".equals(lang)) {
            if (!"maven".equals(type)) {
                log.warn("rejected request  artifact={}  reason=invalid build type for java: {}", request.artifactId(), type);
                throw new GenerationException("Java projects require build type maven (got '" + type + "')");
            }
            if (!List.of("jar", "war").contains(pkg)) {
                log.warn("rejected request  artifact={}  reason=invalid packaging for java: {}", request.artifactId(), pkg);
                throw new GenerationException("Java projects require packaging jar or war (got '" + pkg + "')");
            }
            if (request.bootVersion() == null || request.bootVersion().isBlank()) {
                log.warn("rejected request  artifact={}  reason=missing Spring Boot version", request.artifactId());
                throw new GenerationException("Java projects require a Spring Boot version");
            }
        } else if ("python".equals(lang)) {
            if (!List.of("poetry", "pip").contains(type)) {
                log.warn("rejected request  artifact={}  reason=invalid build type for python: {}", request.artifactId(), type);
                throw new GenerationException("Python projects require build type poetry or pip (got '" + type + "')");
            }
            if (!List.of("wheel", "sdist").contains(pkg)) {
                log.warn("rejected request  artifact={}  reason=invalid packaging for python: {}", request.artifactId(), pkg);
                throw new GenerationException("Python projects require packaging wheel or sdist (got '" + pkg + "')");
            }
        }
        if (request.environments().enabled() && !"java".equals(lang)) {
            log.warn("rejected request  artifact={}  reason=environments only supported for java", request.artifactId());
            throw new GenerationException("Environment configs (bootstrap-*.yaml) are only supported for Java projects");
        }
    }

    private void writeJavaProject(Map<String, String> files, String root, ProjectRequest request, List<Dependency> resolved) {
        String packagePath = request.packageName().replace('.', '/');
        String mainSrc = root + "src/main/java/" + packagePath + "/";
        String testSrc = root + "src/test/java/" + packagePath + "/";
        String resourcesDir = root + "src/main/resources/";

        put(files, root + "pom.xml", pomBuilder.build(request, resolved));
        put(files, root + ".mvn/wrapper/README.md",
                "Run `mvn -N wrapper:wrapper` to generate the Maven Wrapper files (mvnw, mvnw.cmd, .mvn/wrapper/maven-wrapper.properties).\n");

        put(files, mainSrc + templates.mainClassName(request) + ".java", templates.mainClass(request));
        put(files, testSrc + templates.testClassName(request) + ".java", templates.testClass(request));

        var archFiles = architecture.javaSources(request);
        for (var f : archFiles) {
            put(files, mainSrc + f.relativePath(), f.content());
        }
        if (!archFiles.isEmpty()) {
            log.info("architecture sources built  artifact={}  architecture={}  files={}",
                    request.artifactId(), request.architecture(), archFiles.size());
        }

        String appProps = templates.applicationProperties(request) + architecture.extraProperties(request);
        put(files, resourcesDir + "application.properties", appProps);

        if (request.environments().enabled() && !request.environments().environments().isEmpty()) {
            put(files, resourcesDir + "bootstrap.yaml",
                    bootstrapBuilder.buildBootstrapBase(request, request.environments()));
            for (String env : request.environments().environments()) {
                put(files, resourcesDir + "bootstrap-" + env + ".yaml",
                        bootstrapBuilder.buildBootstrapEnv(request, env));
            }
            log.info("bootstrap yamls built  artifact={}  profiles={}",
                    request.artifactId(), request.environments().environments());
        }

        put(files, root + ".gitignore", templates.gitignore(request.type()));
        put(files, root + "README.md", templates.readme(request));
    }

    private void writePythonProject(Map<String, String> files, String root, ProjectRequest request, List<Dependency> resolved) {
        String packageDir = request.packageName().replace('.', '_');
        String srcDir = root + "src/" + packageDir + "/";
        String testDir = root + "tests/";

        if ("poetry".equals(request.type())) {
            put(files, root + "pyproject.toml", pythonBuilder.buildPoetryPyproject(request, resolved));
        } else {
            put(files, root + "requirements.txt", pythonBuilder.buildRequirementsTxt(resolved));
            String devReqs = pythonBuilder.buildRequirementsDevTxt(resolved);
            if (!devReqs.isBlank()) {
                put(files, root + "requirements-dev.txt", devReqs);
            }
            put(files, root + "setup.py", pythonBuilder.buildSetupPy(request, resolved));
        }

        put(files, srcDir + "__init__.py", pythonBuilder.buildInitPy(request));

        var pyArch = pythonBuilder.architectureSources(request);
        if (pyArch.isEmpty()) {
            put(files, srcDir + "main.py", pythonBuilder.buildMainModule(request, resolved));
        } else {
            for (var f : pyArch) {
                put(files, srcDir + f.relativePath(), f.content());
            }
            put(files, srcDir + "main.py", pythonBuilder.buildArchitectureMain(request));
            log.info("architecture sources built  artifact={}  architecture={}  files={}",
                    request.artifactId(), request.architecture(), pyArch.size());
        }

        put(files, testDir + "__init__.py", "");
        put(files, testDir + "test_smoke.py", pythonBuilder.buildTestModule(request, resolved));

        put(files, root + ".gitignore", pythonBuilder.buildGitignore());
        put(files, root + "README.md", pythonBuilder.buildPythonReadme(request));
    }

    private void writeDmzrAssets(Map<String, String> files, String root, ProjectRequest request) {
        DmzrConfig dmzr = request.dmzr();
        String dmzrRoot = root + "dmzr/";
        List<String> envs = dmzr.environments().isEmpty()
                ? EnvironmentConfig.ALLOWED
                : dmzr.environments();

        if (dmzr.vaultPolicies()) {
            String vaultDir = dmzrRoot + "vault/";
            put(files, vaultDir + "kubernetes-auth.md", dmzrBuilder.vaultKubernetesAuth(request, dmzr));
            for (String env : envs) {
                put(files, vaultDir + "policies/" + request.artifactId() + "-" + env + ".hcl",
                        dmzrBuilder.vaultPolicy(request, dmzr, env));
                put(files, vaultDir + "secrets/" + env + ".yaml",
                        dmzrBuilder.vaultSecretStub(request, dmzr, env));
            }
        }

        if (dmzr.helmChart()) {
            String helmDir = dmzrRoot + "helm/";
            String chartDir = helmDir + "chart/";
            put(files, chartDir + "Chart.yaml", dmzrBuilder.helmChartYaml(request));
            put(files, chartDir + "values.yaml", dmzrBuilder.helmValuesYaml(request, dmzr));
            put(files, chartDir + "templates/deployment.yaml", dmzrBuilder.helmDeployment(request, dmzr));
            put(files, chartDir + "templates/service.yaml", dmzrBuilder.helmService(request));
            put(files, chartDir + "templates/serviceaccount.yaml", dmzrBuilder.helmServiceAccount(request));
            for (String env : envs) {
                put(files, helmDir + "values-" + env + ".yaml", dmzrBuilder.helmValuesForEnv(env));
            }
        }

        put(files, dmzrRoot + "README.md", dmzrBuilder.helmReadme(request, dmzr));
    }

    private List<Dependency> resolveAndValidate(ProjectRequest request) {
        Set<String> seen = new HashSet<>();
        List<Dependency> out = new ArrayList<>();
        List<String> unknown = new ArrayList<>();
        Map<String, String> versionOverrides = request.dependencyVersions();
        for (String id : request.dependencies()) {
            if (id == null || id.isBlank() || !seen.add(id)) continue;
            var match = catalog.findById(id);
            if (match.isEmpty()) {
                unknown.add(id);
            } else {
                out.add(applyVersionOverride(match.get(), versionOverrides));
            }
        }
        if (!unknown.isEmpty()) {
            log.warn("rejected request  artifact={}  unknown dependency ids: {}", request.artifactId(), unknown);
            throw new GenerationException("Unknown dependency id(s): " + String.join(", ", unknown));
        }

        if (request.database() != null && !"none".equals(request.database().type())) {
            String dbType = request.database().type();
            String driverId;
            if (request.isPython()) {
                driverId = switch (dbType) {
                    case "postgresql" -> "py-psycopg2";
                    case "mysql"      -> "py-pymysql";
                    case "oracle"     -> "py-cx-oracle";
                    case "mssql"      -> "py-pyodbc";
                    case "h2"         -> "py-aiosqlite";
                    default            -> null;
                };
            } else {
                driverId = switch (dbType) {
                    case "h2"         -> "h2";
                    case "postgresql" -> "postgresql";
                    case "mysql"      -> "mysql";
                    case "oracle"     -> "oracle";
                    case "mssql"      -> "mssql";
                    default            -> null;
                };
            }
            if (driverId != null && seen.add(driverId)) {
                catalog.findById(driverId).ifPresent(d -> {
                    out.add(applyVersionOverride(d, versionOverrides));
                    log.debug("auto-added db driver  artifact={}  db={}  driver={}", request.artifactId(), dbType, driverId);
                });
            }
        }

        if (!"standard".equals(request.architecture())) {
            if (request.isJava() && seen.add("web")) {
                catalog.findById("web").ifPresent(d -> {
                    out.add(applyVersionOverride(d, versionOverrides));
                    log.debug("auto-added web starter for {} architecture  artifact={}", request.architecture(), request.artifactId());
                });
            }
            // OpenAPI / springdoc for Java microservice
            if (request.isJava() && request.isMicroservice() && seen.add("springdoc-openapi")) {
                catalog.findById("springdoc-openapi").ifPresent(d -> {
                    out.add(applyVersionOverride(d, versionOverrides));
                    log.debug("auto-added springdoc-openapi for microservice  artifact={}", request.artifactId());
                });
            }
            if (request.isPython() && seen.add("fastapi")) {
                catalog.findById("fastapi").ifPresent(d -> out.add(applyVersionOverride(d, versionOverrides)));
                if (seen.add("uvicorn")) catalog.findById("uvicorn").ifPresent(d -> out.add(applyVersionOverride(d, versionOverrides)));
                if (seen.add("pydantic")) catalog.findById("pydantic").ifPresent(d -> out.add(applyVersionOverride(d, versionOverrides)));
            }
        }
        return out;
    }

    /** Returns a copy of the dependency with an overridden version if the user supplied one. */
    private Dependency applyVersionOverride(Dependency d, Map<String, String> overrides) {
        if (overrides == null) return d;
        String v = overrides.get(d.id());
        if (v == null || v.isBlank()) return d;
        // "managed" means: use the Spring-BOM-managed version (emit no explicit <version>)
        if ("managed".equalsIgnoreCase(v.trim())) {
            if (d.version() == null || d.version().isBlank()) return d;
            return new Dependency(d.id(), d.name(), d.description(), d.groupId(), d.artifactId(),
                    null, d.scope(), d.category(), d.incompatibleWith(), d.minBootVersion(), d.maxBootVersion());
        }
        return new Dependency(d.id(), d.name(), d.description(), d.groupId(), d.artifactId(),
                v.trim(), d.scope(), d.category(), d.incompatibleWith(), d.minBootVersion(), d.maxBootVersion());
    }

    private String buildHelp(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Getting Started\n\n");
        sb.append("This project was generated by **sourceforge**.\n\n");
        sb.append("## Project metadata\n\n");
        sb.append("- **Group**: ").append(req.groupId()).append("\n");
        sb.append("- **Artifact**: ").append(req.artifactId()).append("\n");
        sb.append("- **Name**: ").append(req.name()).append("\n");
        sb.append("- **Package**: ").append(req.packageName()).append("\n");
        sb.append("- **Language**: ").append(req.language()).append("\n");
        sb.append("- **Runtime version**: ").append(req.javaVersion()).append("\n");
        sb.append("- **Build**: ").append(req.type()).append("\n");
        sb.append("- **Packaging**: ").append(req.packaging()).append("\n");
        sb.append("- **Architecture**: ").append(req.architecture()).append("\n");
        if (req.isJava()) {
            sb.append("- **Spring Boot**: ").append(req.bootVersion()).append("\n");
        }
        if (req.database() != null && !"none".equals(req.database().type())) {
            sb.append("- **Database**: ").append(req.database().type()).append("\n");
        }
        if (req.environments().enabled()) {
            sb.append("- **Bootstrap profiles**: ").append(String.join(", ", req.environments().environments())).append("\n");
        }
        if (req.dmzr().enabled()) {
            sb.append("- **DMZR**: ");
            List<String> bits = new ArrayList<>();
            if (req.dmzr().vaultPolicies()) bits.add("Vault policies");
            if (req.dmzr().helmChart())     bits.add("Helm chart");
            sb.append(String.join(" + ", bits)).append("\n");
        }
        sb.append("\n## Dependencies\n\n");
        if (deps.isEmpty()) {
            sb.append("_No starters were selected._\n");
        } else {
            for (Dependency d : deps) {
                sb.append("### ").append(d.name()).append("\n");
                sb.append(d.description()).append("\n\n");
                if (!d.groupId().isBlank()) {
                    sb.append("- Coordinates: `").append(d.groupId()).append(":").append(d.artifactId());
                    if (d.version() != null && !d.version().isBlank()) sb.append(":").append(d.version());
                    sb.append("`\n");
                } else {
                    sb.append("- Package: `").append(d.artifactId());
                    if (d.version() != null && !d.version().isBlank()) sb.append(" ").append(d.version());
                    sb.append("`\n");
                }
                sb.append("- Scope: `").append(d.scope()).append("`\n\n");
            }
        }
        return sb.toString();
    }

    /** chart/ folder (outside src): helmfile, per-env values, service account, deps info. */
    private void writeChartAssets(Map<String, String> files, String root, ProjectRequest request) {
        String chartDir = root + "chart/";
        put(files, chartDir + "chart-dependencies.info", chartBuilder.chartDependenciesInfo(request));
        put(files, chartDir + "helmfile.yaml", chartBuilder.helmfileYaml(request));
        put(files, chartDir + "service-account.yaml", chartBuilder.serviceAccountYaml(request));
        for (String env : ChartAssetBuilder.CHART_ENVS) {
            put(files, chartDir + "values-" + env + ".yaml", chartBuilder.valuesForEnv(request, env));
        }
    }

    /** Dockerfile + entrypoint.sh (outside src). */
    private void writeDockerAssets(Map<String, String> files, String root, ProjectRequest request) {
        put(files, root + "Dockerfile", dockerfileBuilder.build(request));
        put(files, root + "entrypoint.sh", dockerfileBuilder.entrypointSh(request));
    }

    private void put(Map<String, String> files, String name, String content) {
        files.put(name, content == null ? "" : content);
    }
}
