export interface Dependency {
  id: string;
  name: string;
  description: string;
  groupId: string;
  artifactId: string;
  version: string | null;
  scope: string;
  category: string;
  incompatibleWith: string[];
  minBootVersion: string | null;
  maxBootVersion: string | null;
}

export interface DependencyCategory {
  name: string;
  dependencies: Dependency[];
}

export interface ProjectDefaults {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
}

export interface LanguageMetadata {
  id: string;                       // "java" or "python"
  label: string;
  buildTypes: string[];
  runtimeVersions: string[];
  packagings: string[];
  frameworkVersions: string[];      // Boot versions for java; empty for python
  defaults: ProjectDefaults;
  dependencies: DependencyCategory[];
}

export interface ArchitectureOption {
  id: string;            // standard | mvc | microservice
  label: string;
  description: string;
}

export interface MetadataResponse {
  languages: string[];
  defaultLanguage: string;
  languageMetadata: LanguageMetadata[];
  environments: string[];           // ["dev","ist","uat","ppd","prod"]
  architectures: ArchitectureOption[];
  versionSuggestions: Record<string, string[]>;   // depId -> suggested versions
}

export interface DatabaseConfig {
  type: string;
  url: string;
  username: string;
  password: string;
  ddlAuto: string;
}

export interface EnvironmentConfig {
  enabled: boolean;
  environments: string[];
  configServerUrl: string;
  configServerProfile: string;
}

export interface DmzrConfig {
  enabled: boolean;
  vaultPolicies: boolean;
  helmChart: boolean;
  vaultRole: string;
  vaultSecretPath: string;
  kubernetesNamespace: string;
  dockerImage: string;
  environments: string[];
}

export interface CosConfig {
  enabled: boolean;
  instanceIds: string[];
  endpoint: string;
  bucket: string;
}

export interface ProjectRequest {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
  architecture: string;
  dependencies: string[];
  dependencyVersions: Record<string, string>;
  editedFiles: Record<string, string>;
  database: DatabaseConfig;
  environments: EnvironmentConfig;
  dmzr: DmzrConfig;
  applicationCode: string;
  cos: CosConfig;
}

export interface DatabaseOption {
  id: string;
  label: string;
  defaultUrl: string;
  defaultUsername: string;
}

export const DATABASE_OPTIONS: DatabaseOption[] = [
  { id: 'none',       label: 'None',         defaultUrl: '',                                                       defaultUsername: '' },
  { id: 'h2',         label: 'H2 (in-mem)',  defaultUrl: 'jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1;MODE=PostgreSQL',     defaultUsername: 'sa' },
  { id: 'postgresql', label: 'PostgreSQL',   defaultUrl: 'jdbc:postgresql://localhost:5432/demo',                  defaultUsername: 'postgres' },
  { id: 'mysql',      label: 'MySQL',        defaultUrl: 'jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC', defaultUsername: 'root' },
  { id: 'oracle',     label: 'Oracle',       defaultUrl: 'jdbc:oracle:thin:@localhost:1521:XE',                    defaultUsername: 'system' },
  { id: 'mssql',      label: 'SQL Server',   defaultUrl: 'jdbc:sqlserver://localhost:1433;databaseName=demo;encrypt=false', defaultUsername: 'sa' }
];

export const DDL_AUTO_OPTIONS = [
  { id: 'none', label: 'none' },
  { id: 'validate', label: 'validate' },
  { id: 'update', label: 'update' },
  { id: 'create', label: 'create' },
  { id: 'create-drop', label: 'create-drop' }
];

export function buildTypeLabel(t: string): string {
  return ({
    maven: 'Maven',
    'gradle-groovy': 'Gradle - Groovy',
    'gradle-kotlin': 'Gradle - Kotlin',
    poetry: 'Poetry',
    pip: 'pip + setup.py'
  } as Record<string, string>)[t] ?? t;
}

export function packagingLabel(p: string): string {
  return ({
    jar: 'Jar',
    war: 'War',
    wheel: 'Wheel',
    sdist: 'sdist'
  } as Record<string, string>)[p] ?? p;
}
