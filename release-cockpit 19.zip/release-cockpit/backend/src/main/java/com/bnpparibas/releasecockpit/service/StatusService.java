package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ConnectionStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.List;

/**
 * Reports the live connection status of the upstream systems so the UI can show
 * a single "systems" panel.
 *
 * Uses the JDK's built-in java.net.http.HttpClient (no Spring WebFlux / WebClient
 * dependency), so it builds with only spring-boot-starter-web on the classpath.
 *
 * In mock mode it returns MOCK statuses (no network). In live mode it does a
 * cheap probe per system and reports UP / DOWN / NOT_CONFIGURED with latency.
 */
@Slf4j
@Service
public class StatusService {

    private final CockpitProperties props;
    private final HttpClient http;   // direct (Jira)
    private final HttpClient saas;   // proxied (Octane/SharePoint/ServiceNow)
    private final ServiceNowService serviceNowService;

    public StatusService(CockpitProperties props,
                         com.bnpparibas.releasecockpit.connector.HttpClientFactory clients,
                         ServiceNowService serviceNowService) {
        this.props = props;
        this.http = clients.direct();
        this.saas = clients.proxied();
        this.serviceNowService = serviceNowService;
    }

    public List<ConnectionStatus> all() {
        return List.of(jira(), sharepoint(), octane(), servicenow());
    }

    public ConnectionStatus jira() {
        if (props.isMockMode()) return mock("JIRA", "Mock data — not connecting to Jira");
        long t0 = System.currentTimeMillis();
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + "/rest/api/2/myself"))
                    .timeout(Duration.ofSeconds(8)).GET();
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            return r.statusCode() < 400
                    ? up("JIRA", "", System.currentTimeMillis() - t0)
                    : down("JIRA", "HTTP " + r.statusCode(), System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("JIRA", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus sharepoint() {
        if (props.isMockMode()) return mock("SHAREPOINT", "Mock data — not connecting to SharePoint");
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) {
            return new ConnectionStatus("SHAREPOINT", "NOT_CONFIGURED",
                    "Set sharepoint base-url + fed-auth/rt-fa cookies", 0);
        }
        long t0 = System.currentTimeMillis();
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(sp.getBaseUrl() + "/_api/web?$select=Title"))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(12)).GET().build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            return r.statusCode() < 400
                    ? up("SHAREPOINT", "", System.currentTimeMillis() - t0)
                    : down("SHAREPOINT", "HTTP " + r.statusCode()
                        + (r.statusCode() == 401 || r.statusCode() == 302 ? " — cookies likely expired" : ""),
                        System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("SHAREPOINT", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus octane() {
        if (props.isMockMode()) return mock("OCTANE", "Mock data — not connecting to Octane");
        long t0 = System.currentTimeMillis();
        try {
            var o = props.getOctane();
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(10))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            return r.statusCode() < 400
                    ? up("OCTANE", "",
                        System.currentTimeMillis() - t0)
                    : down("OCTANE", "HTTP " + r.statusCode(), System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("OCTANE", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus servicenow() {
        var sn = props.getServicenow();
        if (!sn.isEnabled()) {
            return new ConnectionStatus("SERVICENOW", "NOT_CONFIGURED",
                    "Not connected yet — enable in config to link release tickets", 0);
        }
        if (props.isMockMode()) return mock("SERVICENOW", "Mock data — not connecting to ServiceNow");
        long t0 = System.currentTimeMillis();
        try {
            // Use the OAuth2 gateway (same path the app really uses), NOT the legacy
            // /api/now/table endpoint — that returns 404 on the BNP gateway.
            boolean ok = serviceNowService.ping();
            return ok
                    ? up("SERVICENOW", "", System.currentTimeMillis() - t0)
                    : down("SERVICENOW", "Token or /changes call failed — see logs",
                        System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("SERVICENOW", brief(e), System.currentTimeMillis() - t0);
        }
    }

    // ---- helpers ----
    private ConnectionStatus up(String sys, String detail, long ms) {
        return new ConnectionStatus(sys, "UP", detail, ms);
    }
    private ConnectionStatus down(String sys, String detail, long ms) {
        log.warn("{} status DOWN: {}", sys, detail);
        return new ConnectionStatus(sys, "DOWN", detail, ms);
    }
    private ConnectionStatus mock(String sys, String detail) {
        return new ConnectionStatus(sys, "MOCK", detail, 0);
    }
    private String brief(Exception e) {
        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        return m.length() > 140 ? m.substring(0, 140) : m;
    }
    private String nz(String s) { return s == null ? "" : s; }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
}
