import { RouteCountKey } from './execution-status.constants';

/**
 * Contracts for GET /v1/job-executions/{jobId}
 * (JobExecutionListResponse / JobExecutionListItem / StsReport).
 */

export interface StsReport {
  jobId?: string;
  reportId?: string;
  reportName?: string;
  fileName?: string;
  bucket?: string;
  key?: string;
  type?: string;
}

export interface ExecutionRouteRef {
  routeId?: string;
  name?: string;
  description?: string;
}

/** Mirrors the cnt_* columns of the executions roll-up query. */
export interface ProcessSummary {
  new?: number;
  running?: number;
  waiting?: number;
  success?: number;
  crashed?: number;
  blockingFailed?: number;
  nonBlockingFailed?: number;
}

export interface JobExecutionListItem {
  executionId?: string;
  created?: string;
  started?: string;
  updated?: string;
  ended?: string;
  /** Already resolved server-side (exec_display_status). */
  status?: string;
  errorMessage?: string | null;
  businessContext?: string;
  route?: ExecutionRouteRef;
  processSummary?: ProcessSummary;
  report?: StsReport;
  sequence?: number;
  [key: string]: any;
}

export interface JobExecutionListResponse {
  data?: JobExecutionListItem[];
}

/** Flattened row shown in the standalone detail grid. */
export interface JobExecutionDetailRow {
  isDetail: true;
  executionId: string;
  routeId?: string;
  routeName: string;
  description: string;
  status?: string;
  statusKey: string;
  statusLabel: string;
  errorMessage?: string | null;
  /** dd/MM/yyyy HH:mm:ss */
  ended: string;
  reportId?: string;
  reportName: string;
  fileName: string;
  bucket?: string;
  key?: string;
  type?: string;
}

/**
 * Roll-up columns returned by the job list query for the Route column.
 * These arrive flat on each job row alongside JOB_ID, STATUS, etc.
 * Oracle numerics may surface as strings depending on the driver, hence
 * the union type.
 */
export interface JobRouteCountColumns {
  EXEC_COUNT?: number | string;
  CNT_TERMINATED?: number | string;
  CNT_RUNNING?: number | string;
  CNT_WAITING?: number | string;
  CNT_ERROR?: number | string;
}

/**
 * Normalised per-job roll-up rendered as circles in the Route column.
 * `total` is the execution count; the bucket counts are process counts
 * aggregated across every execution of that job.
 */
export interface RouteExecutionSummary {
  total: number;
  counts: Record<RouteCountKey, number>;
}

/** The synthetic full-width row injected beneath an expanded parent. */
export interface JobExecutionDetailEntry {
  isDetail: true;
  parentId: string;
  loading: boolean;
  error: string | null;
  details: JobExecutionDetailRow[];
  openRouteMonitoring: (executionId: string) => void;
}

/** Coerces an Oracle numeric column (which may arrive as a string) to a count. */
export function toCount(value: number | string | null | undefined): number {
  if (value === null || value === undefined || value === '') {
    return 0;
  }
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

/**
 * Builds the Route column summary from the flat SQL roll-up columns.
 *
 * Returns undefined when the job has no dispatcher executions so the cell
 * renders empty rather than showing a zero — a job that never went through
 * the dispatcher is different from one whose processes all finished.
 */
export function buildRouteSummaryFromRow(
  row: JobRouteCountColumns | null | undefined
): RouteExecutionSummary | undefined {
  if (!row) {
    return undefined;
  }

  const total = toCount(row.EXEC_COUNT);
  if (total <= 0) {
    return undefined;
  }

  return {
    total,
    counts: {
      TERMINATED: toCount(row.CNT_TERMINATED),
      RUNNING: toCount(row.CNT_RUNNING),
      WAITING: toCount(row.CNT_WAITING),
      ERROR: toCount(row.CNT_ERROR)
    }
  };
}

/**
 * Aggregates the executions payload into the same shape, used to refresh the
 * Route column after a row has been expanded (the executions call returns
 * live data that may be newer than the job list snapshot).
 */
export function buildRouteSummaryFromExecutions(
  executions: JobExecutionListItem[]
): RouteExecutionSummary | undefined {
  if (!executions?.length) {
    return undefined;
  }

  const counts: Record<RouteCountKey, number> = {
    TERMINATED: 0,
    RUNNING: 0,
    WAITING: 0,
    ERROR: 0
  };

  executions.forEach(execution => {
    const ps: ProcessSummary = execution?.processSummary ?? {};
    counts.TERMINATED += toCount(ps.success);
    counts.RUNNING += toCount(ps.running);
    counts.WAITING += toCount(ps.waiting) + toCount(ps.new);
    counts.ERROR += toCount(ps.crashed)
      + toCount(ps.blockingFailed)
      + toCount(ps.nonBlockingFailed);
  });

  return { total: executions.length, counts };
}
