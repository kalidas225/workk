import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ColDef, GridReadyEvent, RowClickedEvent } from 'ag-grid-community';
import {
  EXECUTION_STATUS_META,
  escapeHtml,
  getStatusMeta,
  normalizeStatusKey
} from './execution-status.constants';
import { JobExecutionDetailRow } from './job-execution.model';

/**
 * Full-width row rendered beneath an expanded Job List row.
 *
 * Deliberately standalone: it has its own header row and its own column
 * widths, and does not track the parent grid's column state or horizontal
 * scroll position. Columns are Execution ID, Route Name, Description,
 * Status and Ended.
 *
 * Clicking a row opens Route Monitoring in a new tab, filtered on that
 * execution id.
 */
@Component({
  selector: 'app-job-executions-detail',
  standalone: false,
  template: `
    <div class="detail-shell">
      <div class="detail-state loader-wrapper" *ngIf="params?.data?.loading">
        <coras-loader type="small-indeterminate"></coras-loader>
        <span class="detail-state-text">Loading executions&hellip;</span>
      </div>

      <div class="detail-state detail-error"
           *ngIf="!params?.data?.loading && params?.data?.error">
        <coras-icon class="detail-state-icon">neo_caution</coras-icon>
        <span class="detail-state-text">{{ params.data.error }}</span>
      </div>

      <div class="detail-state detail-empty"
           *ngIf="!params?.data?.loading && !params?.data?.error && !hasRows">
        <coras-icon class="detail-state-icon">neo_info</coras-icon>
        <span class="detail-state-text">No executions found for this job.</span>
      </div>

      <ag-grid-angular
        *ngIf="!params?.data?.loading && !params?.data?.error && hasRows"
        class="ag-theme-coras ag-theme job-exec-detail-grid"
        [rowData]="params.data.details"
        [columnDefs]="columnDefs"
        [defaultColDef]="defaultColDef"
        [rowHeight]="26"
        [headerHeight]="26"
        [rowClassRules]="rowClassRules"
        [suppressRowClickSelection]="true"
        [suppressRowDeselection]="true"
        [gridOptions]="{ enableCellTextSelection: true, suppressCellFocus: true }"
        [domLayout]="'autoHeight'"
        (gridReady)="onDetailGridReady($event)"
        (rowClicked)="onRowClicked($event)">
      </ag-grid-angular>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      overflow: visible;
    }

    .detail-shell {
      margin: 2px 0 2px 45px;   /* indent under the expander column */
      border: 1.5px solid var(--grey-01, #dfe3e8);
      background-color: var(--grey-03, #f4f6f8);
    }

    .detail-state {
      height: 36px;
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 0 10px;
      font-size: 12px;
      color: var(--grey-08, #455a64);
    }

    .detail-error {
      color: var(--error-05, #c62828);
    }

    .detail-state-icon {
      font-size: 15px !important;
      line-height: 1;
    }

    .job-exec-detail-grid ::ng-deep .ag-row {
      background-color: var(--grey-03, #f4f6f8) !important;
      cursor: pointer;
    }

    .job-exec-detail-grid ::ng-deep .ag-row:hover {
      background-color: var(--grey-04, #e8ecef) !important;
    }

    .job-exec-detail-grid ::ng-deep .ag-header {
      background-color: var(--grey-02, #eceff1) !important;
      border-bottom: 1px solid var(--grey-01, #dfe3e8);
    }

    .job-exec-detail-grid ::ng-deep .ag-header-cell-text {
      font-size: 11px;
      font-weight: 600;
    }

    .job-exec-detail-grid ::ng-deep .exec-link {
      text-decoration: underline;
      cursor: pointer;
    }

    .job-exec-detail-grid ::ng-deep .exec-cell-status {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      line-height: 1;
    }

    .job-exec-detail-grid ::ng-deep .exec-cell-status .coras-icons {
      font-size: 13px !important;
      line-height: 1;
    }

    .job-exec-detail-grid ::ng-deep .exec-error-icon {
      font-size: 13px !important;
      color: var(--error-05, #c62828);
      margin-left: 4px;
    }
  `]
})
export class JobExecutionsDetailComponent implements ICellRendererAngularComp {

  params: any;

  defaultColDef: ColDef = {
    sortable: false,
    filter: false,
    resizable: true,
    suppressMovable: true
  };

  columnDefs: ColDef[] = [
    {
      headerName: 'Execution ID',
      field: 'executionId',
      width: 260,
      tooltipValueGetter: () => 'Open in Route Monitoring',
      cellRenderer: (p: any) => `<span class="exec-link">${escapeHtml(p.value)}</span>`
    },
    {
      headerName: 'Route Name',
      field: 'routeName',
      width: 240,
      tooltipValueGetter: (p: any) => p.value
    },
    {
      headerName: 'Status',
      field: 'status',
      width: 200,
      tooltipValueGetter: (p: any) => p.data?.errorMessage || p.data?.statusLabel,
      cellRenderer: (p: any) => {
        const meta = getStatusMeta(p.value);
        const errorFlag = p.data?.errorMessage
          ? `<em class="coras-icons exec-error-icon" title="${escapeHtml(p.data.errorMessage)}">neo_caution</em>`
          : '';
        return `<span class="exec-cell-status">` +
          `<em class="coras-icons">${meta.icon}</em>` +
          `<span>${escapeHtml(meta.label)}</span>` +
          `</span>${errorFlag}`;
      }
    },
    {
      headerName: 'Ended',
      field: 'ended',
      width: 170
    },
    {
      headerName: 'Description',
      field: 'description',
      flex: 1,
      minWidth: 200,
      tooltipValueGetter: (p: any) => p.value
    }
  ];

  rowClassRules = {
    'e-forecolor-blue': (p: any) =>
      EXECUTION_STATUS_META[normalizeStatusKey(p.data?.status)].rowClass === 'e-forecolor-blue',
    'e-forecolor-green': (p: any) =>
      EXECUTION_STATUS_META[normalizeStatusKey(p.data?.status)].rowClass === 'e-forecolor-green',
    'e-forecolor-orange': (p: any) =>
      EXECUTION_STATUS_META[normalizeStatusKey(p.data?.status)].rowClass === 'e-forecolor-orange',
    'e-forecolor-red': (p: any) =>
      EXECUTION_STATUS_META[normalizeStatusKey(p.data?.status)].rowClass === 'e-forecolor-red',
    'e-forecolor-black': (p: any) =>
      EXECUTION_STATUS_META[normalizeStatusKey(p.data?.status)].rowClass === 'e-forecolor-black'
  };

  get hasRows(): boolean {
    return (this.params?.data?.details?.length ?? 0) > 0;
  }

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params: any): boolean {
    this.params = params;
    return true;
  }

  onRowClicked(event: RowClickedEvent): void {
    const row = event?.data as JobExecutionDetailRow | undefined;
    if (!row?.executionId) {
      return;
    }
    this.params?.data?.openRouteMonitoring?.(row.executionId);
  }

  onDetailGridReady(_event: GridReadyEvent): void {
    // Standalone grid: nothing to sync with the parent.
  }
}
