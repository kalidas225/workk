import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  BodyScrollEvent,
  ColDef,
  ColumnResizedEvent,
  GetRowIdParams,
  GridApi,
  PostSortRowsParams
} from 'ag-grid-community';
import { RoutesMonitoringDetailsComponent } from '../routes-monitoring-details/routes-monitoring-details.component';
import { ApplicationMessages, estars } from 'src/app/common/strings';
import { ProcessRendererComponent } from './app-process-render.component';
import { RouteMonitoringService } from '../service/route-monitoring.service';
import { take } from 'rxjs';
import { CommonFilterService, DispatcherFilterModel } from '@components/filter-chips/filter-chips.service';
import { StatusRendererComponent } from './app-status-render.component';
import { CustomCheckboxFilterComponent } from '@components/ag-grid-filters/ag-grid-checkbox.component.filter';

const SORT_FIELD_MAP: Record<string, string> = {
  created_date: 'created_date',
  execution_id: 'execution_id',
  route_name: 'route_name',
  status: 'status',
  start_date: 'start_date',
  end_date: 'end_date',
  description: 'description'
};

const DEFAULT_SORT_BY: string = 'created_date';
const DEFAULT_SORT_ORDER = 'desc' as const;
const DEFAULT_PAGE_SIZE: number = 200;

/** Query param used when deep-linking from Report Monitoring. */
const EXECUTION_ID_QUERY_PARAM = 'execution_id';

@Component({
  selector: 'app-routes-monitoring',
  standalone: false,
  templateUrl: './routes-monitoring.component.html',
  styleUrl: './routes-monitoring.component.scss'
})
export class RoutesMonitoringComponent implements OnInit {

  commonPropertiesWithFilterString: any = {};
  commonPropertiesWithFilterDate: any = {};

  constructor(
    private readonly routeMonitoringService: RouteMonitoringService,
    private readonly filterService: CommonFilterService,
    private readonly activatedRoute: ActivatedRoute
  ) {
    this.commonPropertiesWithFilterString = this.routeMonitoringService.commonPropertiesWithFilterString;
    this.commonPropertiesWithFilterDate =
      this.routeMonitoringService.commonPropertiesWithFilterDate('DATETIME', 'dd/MM/yyyy HH:mm');
  }

  /** Execution id supplied via ?execution_id=... on load. */
  private incomingExecutionId: string | null = null;

  ngOnInit(): void {
    this.incomingExecutionId =
      this.activatedRoute.snapshot.queryParamMap.get(EXECUTION_ID_QUERY_PARAM);

    this.initializeAgGrid();

    this.filterService.setDispatcherService(this.routeListGridId, {
      loadGrid: (model: DispatcherFilterModel) => this.createData(model)
    });
  }

  private currentSortBy: string = DEFAULT_SORT_BY;
  private currentSortOrder: 'asc' | 'desc' = DEFAULT_SORT_ORDER;
  private readonly expandedDetails: Map<string, any> = new Map();
  private expandedParentId: string | null = null;
  private currentScrollLeft: number = 0;
  private readonly DETAIL_ROW_HEIGHT = 26;
  private readonly DETAIL_HEIGHT_BUFFER = 10;

  page = 1;
  paginationConfig = {
    totalDataCount: 0,
    pageSize: DEFAULT_PAGE_SIZE,
    firstChange: true,
    dirtyCheck: false,
    recordsPerPage: true
  };
  routeGridApi!: GridApi;
  routeListGridId: string = 'routeListGridId';
  noRowsTemplate = '<span class="ag-overlay-no-rows-center">No route executions at present.</span>';
  detailRenderer = RoutesMonitoringDetailsComponent;
  rowData: any[] = [];
  isPageLoading: boolean = false;
  loadingText: string = ApplicationMessages.loadMsg;
  statusFilterList: any[] = [
    { displayField: 'New', valueField: 'NEW' },
    { displayField: 'Waiting', valueField: 'WAITING' },
    { displayField: 'Running', valueField: 'RUNNING' },
    { displayField: 'Terminated', valueField: 'TERMINATED' },
    { displayField: 'Terminated with error(s)', valueField: 'TERMINATED_WITH_ERRORS' },
    { displayField: 'Crashed', valueField: 'CRASHED' },
    { displayField: 'Failed', valueField: 'FAILED' }
  ];

  columnDefs: ColDef[] = [];

  initializeAgGrid(): void {
    this.columnDefs = [
      {
        width: 50,
        sortable: false,
        headerName: '',
        filter: false,
        cellRenderer: (p: any) => this.expandRenderer(p)
      },
      { field: 'created_date', headerName: 'Created Date', flex: 0.75, sort: 'desc', ...this.commonPropertiesWithFilterDate },
      { field: 'execution_id', headerName: 'Execution ID', flex: 1.35, ...this.commonPropertiesWithFilterString },
      { field: 'route_name', headerName: 'Route Name', flex: 1, ...this.commonPropertiesWithFilterString },
      {
        headerName: 'Status', field: 'status', flex: 1,
        cellRenderer: StatusRendererComponent,
        filter: CustomCheckboxFilterComponent,
        filterParams: {
          type: 'list',
          list: this.statusFilterList,
          backendFilter: true
        }
      },
      { field: 'start_date', headerName: 'Started', flex: 0.75, ...this.commonPropertiesWithFilterDate },
      { field: 'end_date', headerName: 'Ended', flex: 0.75, ...this.commonPropertiesWithFilterDate },
      { headerName: 'Progress', flex: 1, cellRenderer: ProcessRendererComponent, sortable: false, filter: false },
      { field: 'description', headerName: 'Description', flex: 1.75, ...this.commonPropertiesWithFilterString }
    ];
  }

  defaultColDef: ColDef = {
    resizable: true,
    sortable: true,
    comparator: () => 0
  };

  getRowId = (params: GetRowIdParams) => {
    return params.data.isDetail
      ? `detail__${params.data.parentId}`
      : String(params.data.execution_id);
  };

  postSortRows = (params: PostSortRowsParams) => {
    if (this.expandedDetails.size === 0) return;
    const rows = params.nodes;
    for (let i = 0; i < rows.length; i++) {
      const node = rows[i];
      if (node.data?.isDetail) { rows.splice(i, 1); i--; continue; }
      const parentId = node.data?.execution_id;
      if (parentId && this.expandedDetails.has(String(parentId))) {
        const detailNode = params.nodes.find(
          n => n.data?.isDetail && n.data?.parentId === String(parentId)
        );
        if (detailNode) { rows.splice(i + 1, 0, detailNode); i++; }
      }
    }
  };

  paginate(event: number) {
    this.page = event === 0 ? 1 : event;
    this.createData();
  }

  filterEvent(gridId: any, event: any) {
    this.filterService.onFilterChanged(gridId, event.api);
  }

  onGridReady(params: any) {
    this.routeGridApi = params.api;
    this.routeGridApi?.setGridOption('columnDefs', this.columnDefs);

    // Deep link from Report Monitoring: pre-seed the execution_id filter chip.
    const presetFilters = this.incomingExecutionId
      ? [{
          FCOLUMN: 'execution_id',
          FOPERATOR: 'eq',
          FVALUES: this.incomingExecutionId,
          FTYPE: 'string'
        }]
      : [];

    this.filterService.setFilters(
      this.routeListGridId,
      presetFilters,
      true,
      this.routeGridApi,
      'loadGrid',
      true
    );

    // setFilters triggers loadGrid when it applies a non-empty filter set;
    // only fire the initial load ourselves when there was nothing to apply.
    if (presetFilters.length === 0) {
      this.createData();
    }
  }

  onBodyScroll(event: BodyScrollEvent) {
    if (event.direction !== 'horizontal') return;
    this.currentScrollLeft = event.left;
    this.expandedDetails.forEach((entry) => {
      if (entry.scrollContainer) entry.scrollContainer.scrollLeft = event.left;
    });
  }

  onSortChanged() {
    const sortedCols = this.routeGridApi.getColumnState().filter(c => c.sort != null);
    if (sortedCols.length > 0) {
      const col = sortedCols[0];
      const colId = col.colId ?? '';
      this.currentSortBy = SORT_FIELD_MAP[colId] ?? DEFAULT_SORT_BY;
      this.currentSortOrder = (col.sort as 'asc' | 'desc') ?? DEFAULT_SORT_ORDER;
    } else {
      this.currentSortBy = DEFAULT_SORT_BY;
      this.currentSortOrder = DEFAULT_SORT_ORDER;
    }
    this.page = 1;
    this.createData();
  }

  onFilterChanged() {
    this.page = 1;
    this.removeOrphanedDetailRows();
  }

  onColumnResized(event: ColumnResizedEvent) {
    if (!event.finished) return;
    const currentColumnState = this.routeGridApi.getColumnState();
    this.expandedDetails.forEach((entry) => {
      entry.parentColumnState = currentColumnState;
      if (entry.detailGridApi) this.syncDetailColumnWidths(entry.detailGridApi, currentColumnState);
    });
  }

  syncDetailColumnWidths(detailApi: GridApi, parentColumnState: any[]) {
    const detailColumnState = detailApi.getColumnState();
    const syncedState = detailColumnState.map((detailCol: any, index: number) => {
      const parentCol = parentColumnState[index];
      return parentCol ? { ...detailCol, width: parentCol.width } : detailCol;
    });
    detailApi.applyColumnState({ state: syncedState });
  }

  isFullWidthRow = (params: any) => params.rowNode.data?.isDetail === true;

  getRowHeight = (params: any): number => {
    if (!params.data?.isDetail) return 30;
    if (params.data.loading) return 40;
    const count = params.data.details?.length ?? 0;
    return count * this.DETAIL_ROW_HEIGHT + this.DETAIL_HEIGHT_BUFFER;
  };

  rowClassRules = {
    'e-forecolor-blue': (params: { data: { status: any; }; }) => {
      const status = this.normalizeStatus(params.data?.status);
      return status === 'new';
    },

    'e-forecolor-green': (params: { data: { status: any; }; }) => {
      const status = this.normalizeStatus(params.data?.status);
      return [
        'terminated',
        'terminated with error(s)',
        'terminated with errors'
      ].includes(status);
    },

    'e-forecolor-orange': (params: { data: { status: any; }; }) => {
      const status = this.normalizeStatus(params.data?.status);
      return ['running', 'waiting'].includes(status);
    },

    'e-forecolor-red': (params: { data: { status: any; }; }) => {
      const status = this.normalizeStatus(params.data?.status);
      return ['failed', 'crashed'].includes(status);
    },

    'e-forecolor-black': (params: { data: { status: any; }; }) => {
      const status = this.normalizeStatus(params.data?.status);
      return ![
        'new',
        'terminated',
        'terminated with error(s)',
        'terminated with errors',
        'running',
        'waiting',
        'failed',
        'crashed'
      ].includes(status);
    }
  };

  private normalizeStatus(status: any): string {
    return String(status ?? '')
      .toLowerCase()
      .replace(/_/g, ' ')
      .trim();
  }

  expandRenderer(params: any) {
    if (params.data?.isDetail) return '';
    const icon = document.createElement('div');
    icon.className = 'expand-icon';
    const update = () => {
      icon.innerHTML = params.data.expanded
        ? `<em class="coras-icons" style="cursor:pointer">arrow_down</em>`
        : `<em class="coras-icons" style="cursor:pointer">arrow_right</em>`;
    };
    update();
    icon.onclick = () => {
      this.toggleRow(params);
      params.api.refreshCells({ force: true });
      update();
    };
    return icon;
  }

  toggleRow(params: any) {
    const parent = params.node.data;
    const parentId = String(parent.execution_id);
    if (this.expandedParentId && this.expandedParentId !== parentId) {
      this.collapseRow(this.expandedParentId);
    }
    if (this.expandedDetails.has(parentId)) {
      this.collapseRow(parentId);
      return;
    }
    this.expandRow(params, parentId, parent);
  }

  private expandRow(_params: any, parentId: string, parent: any) {
    const entry: any = {
      isDetail: true,
      parentId,
      loading: true,
      details: [] as any[],
      parentColumnState: this.routeGridApi.getColumnState(),
      detailGridApi: null as GridApi | null,
      scrollContainer: null as HTMLElement | null,
      initialScrollLeft: this.currentScrollLeft,
      registerScrollContainer: (el: HTMLElement) => {
        entry.scrollContainer = el;
        el.scrollLeft = this.currentScrollLeft;
      },
      registerDetailGridApi: (api: GridApi) => { entry.detailGridApi = api; }
    };
    this.routeGridApi.applyTransaction({ add: [entry] });
    this.expandedDetails.set(parentId, entry);
    this.expandedParentId = parentId;
    parent.expanded = true;
    this.routeGridApi.refreshClientSideRowModel('sort');
    this.loadProcessDetails(parentId, entry);
  }

  private collapseRow(parentId: string) {
    const entry = this.expandedDetails.get(parentId);
    if (!entry) return;
    this.routeGridApi.applyTransaction({ remove: [entry] });
    this.expandedDetails.delete(parentId);
    if (this.expandedParentId === parentId) this.expandedParentId = null;
    this.routeGridApi.forEachNode((node: any) => {
      if (!node.data?.isDetail && String(node.data?.execution_id) === parentId) {
        node.data.expanded = false;
      }
    });
  }

  collapseAllDetails() {
    const ids = [...this.expandedDetails.keys()];
    ids.forEach(execution_id => this.collapseRow(execution_id));
  }

  private removeOrphanedDetailRows() {
    const visibleParentIds = new Set<string>();
    this.routeGridApi.forEachNodeAfterFilter((node: any) => {
      if (!node.data?.isDetail && node.data?.execution_id != null) {
        visibleParentIds.add(String(node.data.execution_id));
      }
    });
    const orphanedIds = [...this.expandedDetails.keys()]
      .filter(execution_id => !visibleParentIds.has(execution_id));
    orphanedIds.forEach(execution_id => this.collapseRow(execution_id));
  }

  prepareRowData(data: any[]): any[] {
    return data.map(r => {
      const ps = r.processSummary;
      const total = ps.running + ps.waiting + ps.success + ps.crashed + ps.nonBlockingFailed + ps.blockingFailed + ps.new;
      const completed = ps.success + ps.nonBlockingFailed + ps.blockingFailed + ps.crashed;
      const percent = total ? Math.round((completed / total) * 100) : 0;
      return {
        execution_id: r.executionId,
        route_name: r.route?.name,
        description: r.route?.description,
        created_date: estars.formatDate(r.created),
        start_date: estars.formatDate(r.started),
        end_date: estars.formatDate(r.ended),
        routeId: r.route?.routeId,
        status: this.normaliseStatus(r),
        errorMessage: r.errorMessage,
        processSummary: ps,
        progress: { total, completed, percent },
        expanded: false
      };
    });
  }

  normaliseStatus(r: any) {
    if (estars.isEmpty(r.status)) return null;
    const normaliseCapital = estars.capitalize(r.status);
    if (normaliseCapital) {
      if (normaliseCapital === 'Terminated_with_errors') return 'Terminated with error(s)';
      return normaliseCapital;
    }
  }

  loadProcessDetails(procId: string, entry: any) {
    if (estars.isEmpty(procId)) return;
    this.routeMonitoringService
      .getProcessesByExecutions(procId)
      .pipe(take(1))
      .subscribe({
        next: (res: any) => {
          if (!estars.isEmpty(res) && !estars.isEmpty(res.processes)) {
            entry.details = res.processes
              .sort((a: any, b: any) => a.sequence - b.sequence)
              .map((p: any, i: any) => ({
                name: p.type,
                isDetail: true,
                executionProcessId: p.executionProcessId,
                processOrder: i + 1,
                errorMessage: p.errorMessage,
                sequence: p.sequence,
                description: p.description,
                timestamp: estars.formatDate(p.created),
                start: estars.formatDate(p.started),
                end: estars.formatDate(p.ended),
                status: estars.capitalize(p.status),
                payload: p.payload
              }));
          }
          entry.loading = false;
          const detailNode = this.routeGridApi.getRowNode(`detail__${entry.parentId}`);
          if (detailNode) {
            this.routeGridApi.resetRowHeights();
            this.routeGridApi.redrawRows({ rowNodes: [detailNode] });
          }
        },
        error: () => { this.isPageLoading = false; }
      });
  }

  createData(dispatcherModel?: DispatcherFilterModel) {
    this.isPageLoading = true;
    this.collapseAllDetails();
    const model = dispatcherModel ?? this.filterService.buildDispatcherModel(this.routeListGridId);

    const queryParams = {
      page: this.page,
      pageSize: this.paginationConfig.pageSize,
      sortBy: this.currentSortBy,
      sortOrder: this.currentSortOrder,
      filters: model.filters
    };

    this.routeMonitoringService
      .getExecutions(queryParams)
      .pipe(take(1))
      .subscribe({
        next: (res: any) => {
          this.rowData = !estars.isEmpty(res?.data) ? this.prepareRowData(res.data) : [];
          this.paginationConfig = {
            ...this.paginationConfig,
            totalDataCount: res?.pagination?.totalRecords
          };
          this.isPageLoading = false;
          this.routeGridApi?.refreshCells({ force: true });
        },
        error: () => { this.isPageLoading = false; }
      });
  }
}
