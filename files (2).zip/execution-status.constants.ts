/**
 * Shared metadata for execution status rendering and process-count roll-ups.
 *
 * Backend contract notes:
 *  - `status` on the execution payload is `exec_display_status` from the SQL,
 *    i.e. SUCCESS has already been resolved into TERMINATED /
 *    TERMINATED_WITH_ERRORS / FAILED based on the blocking-failure counts.
 *  - `processSummary` mirrors the cnt_* columns of that same query.
 */

export interface ExecutionStatusMeta {
  label: string;
  rowClass: string;   // ag-grid row forecolor class
  icon: string;       // coras icon ligature
  order: number;
}

export const EXECUTION_STATUS_META: Record<string, ExecutionStatusMeta> = {
  NEW: {
    label: 'New',
    rowClass: 'e-forecolor-blue',
    icon: 'neo_add_circle',
    order: 10
  },
  WAITING: {
    label: 'Waiting',
    rowClass: 'e-forecolor-orange',
    icon: 'neo_clock',
    order: 20
  },
  RUNNING: {
    label: 'Running',
    rowClass: 'e-forecolor-orange',
    icon: 'neo_refresh',
    order: 30
  },
  SUCCESS: {
    label: 'Success',
    rowClass: 'e-forecolor-green',
    icon: 'neo_check_circle',
    order: 40
  },
  TERMINATED: {
    label: 'Terminated',
    rowClass: 'e-forecolor-green',
    icon: 'neo_check_circle',
    order: 50
  },
  TERMINATED_WITH_ERRORS: {
    label: 'Terminated with error(s)',
    rowClass: 'e-forecolor-green',
    icon: 'neo_caution',
    order: 60
  },
  FAILED: {
    label: 'Failed',
    rowClass: 'e-forecolor-red',
    icon: 'neo_close_circle',
    order: 70
  },
  CRASHED: {
    label: 'Crashed',
    rowClass: 'e-forecolor-red',
    icon: 'neo_error',
    order: 80
  },
  UNKNOWN: {
    label: 'Unknown',
    rowClass: 'e-forecolor-black',
    icon: 'neo_info',
    order: 999
  }
};

export const UNKNOWN_STATUS_KEY = 'UNKNOWN';

/**
 * Normalises any backend status spelling into a known key.
 * Handles lower/upper case, spaces, hyphens and the
 * "TERMINATED WITH ERROR(S)" wording variants.
 */
export function normalizeStatusKey(status: unknown): string {
  const raw = String(status ?? '')
    .toUpperCase()
    .replace(/[\s\-]+/g, '_')
    .replace(/_{2,}/g, '_')
    .trim();

  if (!raw) {
    return UNKNOWN_STATUS_KEY;
  }

  if (
    raw === 'TERMINATED_WITH_ERROR(S)' ||
    raw === 'TERMINATED_WITH_ERROR' ||
    raw === 'TERMINATED_WITH_ERRORS'
  ) {
    return 'TERMINATED_WITH_ERRORS';
  }

  return EXECUTION_STATUS_META[raw] ? raw : UNKNOWN_STATUS_KEY;
}

export function getStatusMeta(status: unknown): ExecutionStatusMeta {
  return EXECUTION_STATUS_META[normalizeStatusKey(status)];
}

/* ------------------------------------------------------------------
   Route column — process-count buckets
   ------------------------------------------------------------------ */

/** The four buckets surfaced as circles on the Report Monitoring grid. */
export type RouteCountKey = 'TERMINATED' | 'RUNNING' | 'WAITING' | 'ERROR';

export interface RouteCountMeta {
  key: RouteCountKey;
  label: string;
  cssClass: string;
  order: number;
}

export const ROUTE_COUNT_META: RouteCountMeta[] = [
  { key: 'TERMINATED', label: 'Terminated', cssClass: 'route-circle-green',  order: 10 },
  { key: 'RUNNING',    label: 'Running',    cssClass: 'route-circle-orange', order: 20 },
  { key: 'WAITING',    label: 'Waiting',    cssClass: 'route-circle-amber',  order: 30 },
  { key: 'ERROR',      label: 'Error',      cssClass: 'route-circle-red',    order: 40 }
];

export const ROUTE_COUNT_META_BY_KEY: Record<RouteCountKey, RouteCountMeta> =
  ROUTE_COUNT_META.reduce((acc, meta) => {
    acc[meta.key] = meta;
    return acc;
  }, {} as Record<RouteCountKey, RouteCountMeta>);

/** Escapes a value before injecting into an innerHTML cell renderer string. */
export function escapeHtml(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Formats an ISO timestamp as dd/MM/yyyy HH:mm:ss without a locale dependency. */
export function formatIsoDateTime(value: unknown): string {
  if (value === null || value === undefined || value === '') {
    return '';
  }
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) {
    return String(value);
  }
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ` +
    `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}
