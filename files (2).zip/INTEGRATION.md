# Report Monitoring — Route column (complete file set)

## The two reported issues

### 1. SQL would not compile — this was a real bug

```sql
FROM MFTALU1.TA_DI_REP_JOBFILE J,
     MFTALU1.TA_DI_REP_DOC D
     LEFT JOIN ( ... ) X ON X.JOB_ID = J.JOB_ID   -- ORA-00904
```

A comma join cannot be interleaved with an ANSI join. The `LEFT JOIN`
associates with the table immediately preceding it — `D` — so `J` is not yet
in scope when its `ON` clause is parsed, and Oracle rejects `J.JOB_ID` as an
invalid identifier.

`job-list-query.sql` is now fully ANSI:

```sql
FROM       MFTALU1.TA_DI_REP_JOBFILE J
INNER JOIN MFTALU1.TA_DI_REP_DOC     D ON D.DOC_ID = J.JOB_DOC_ID
LEFT  JOIN ( ... ) X ON X.TAG_JOB_ID = TO_CHAR(J.JOB_ID)
```

Four further corrections went in while fixing it, all latent problems in the
version I gave you:

- The inline view's output column was renamed `JOB_ID` → `TAG_JOB_ID`. Two
  columns named `JOB_ID` on either side of a join is legal but one edit away
  from ORA-00918.
- Every select-list column is now alias-qualified. `SENDING_ON_DEMAND` was
  bare while also being referenced as `D.SENDING_ON_DEMAND` two lines below.
- Both scalar subqueries now use their own aliases and schema prefixes. The
  `REPORT_NAME` subquery selected from an unaliased `TA_DI_REP_DOC` while the
  outer query also had that table in scope as `D` — correlation was working by
  Oracle's scoping rules rather than by anything stated.
- `TO_CHAR` is applied to `J.JOB_ID`, never to `EI.TAG_EXTERNAL_JOB_ID`.
  Casting the indexed column would suppress the index.

If your `TAG_EXTERNAL_JOB_ID` is `NUMBER` rather than `VARCHAR2`, use
`ON X.TAG_JOB_ID = J.JOB_ID` — VARIANT B at the bottom of the .sql file, with
the `all_tab_columns` queries to confirm which case you're in.

### 2. `RouteCountKey` — not a bug, but check your copy

It is exported at **line 113** of `execution-status.constants.ts`:

```typescript
export type RouteCountKey = 'TERMINATED' | 'RUNNING' | 'WAITING' | 'ERROR';
```

If it isn't resolving, you're on the **first** version of that file — the one
where the status meta had a `cssClass` field and there was no Route section at
all. Open your copy: if line 113 isn't that type alias, re-copy
`execution-status.constants.ts` from this drop. I verified every local import
across all seven TypeScript files against the actual export lists; they all
resolve.

## Complete file set

Every file needed, so there is no ambiguity about which revision is current.

| File | Action |
|---|---|
| `job-list-query.sql` | **Replace** — the compile fix |
| `execution-status.constants.ts` | Copy fresh — source of `RouteCountKey` |
| `job-execution.model.ts` | Copy fresh |
| `route-executions-badge.component.ts` | Copy fresh |
| `job-executions-detail.component.ts` | Copy fresh |
| `report-monitoring.component.ts` | Copy fresh |
| `report-monitoring.component.html` | Copy fresh |
| `report-monitoring.additions.scss` | Append to `report-monitoring.component.scss` |
| `ReportMonitoring.service.additions.ts` | Merge into `service/ReportMonitoring.service.ts` |
| `routes-monitoring.component.ts` | Replace — adds the `execution_id` deep link |

Delete `execution-status-badge.component.ts` if you still have it from the
earlier drop, and remove it from your module declarations.

## Module registration

```typescript
import { RouteExecutionsBadgeComponent } from './.../route-executions-badge.component';
import { JobExecutionsDetailComponent } from './.../job-executions-detail.component';

@NgModule({
  declarations: [
    ReportMonitoringComponent,
    DownloadButtonRendererComponent,
    RouteExecutionsBadgeComponent,
    JobExecutionsDetailComponent,
  ],
  imports: [CommonModule, AgGridModule, /* ... */]
})
```

Both are instantiated dynamically by ag-grid, so `declarations` is required —
importing alone will not work.

## Behaviour

**Route column** renders on first paint from `EXEC_COUNT` / `CNT_*`. Buckets:

| Circle | Colour | Source |
|---|---|---|
| Terminated | green | `SUCCESS` |
| Running | orange | `RUNNING` |
| Waiting | amber | `WAITING` + `NEW` |
| Error | red | `CRASHED` + `FAILED` |

Zero-count circles are hidden; a job with no executions shows `–` rather than
a zero. Sorts on execution count.

**After expanding a row**, live counts from `/v1/job-executions` overlay the
SQL values, which are a snapshot from grid-load time. Kept in
`liveRouteSummaries` and re-applied across grid reloads.

**`toCount()`** coerces defensively — Oracle numerics may arrive as strings
depending on the driver, which would otherwise produce `NaN` and silently
empty circles.

## Before deploying

Three things I cannot verify from here, all detailed in the .sql notes:

1. Datatype of `TAG_EXTERNAL_JOB_ID` (drives which join variant you use).
2. Index on that column — `CREATE INDEX` statement is in the file.
3. The inline view aggregates all of `EXEC_PROCESSES` before joining. Fine
   while that table is small; get an EXPLAIN PLAN with realistic bind values
   before this reaches PPD.
