import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ApplicationMessages, MessageBoxIcons, estars, formats } from 'src/app/common/strings';
import { ToasterService } from 'src/app/core/toastercomponent/service/toaster.service';
import { commonComparator } from '../../parameters/table-selection/ag-grid-components/common-comparator';
import {
  ColDef,
  GetRowIdParams,
  GridApi,
  GridReadyEvent,
  PostSortRowsParams,
  RowNode
} from 'ag-grid-community';
import { Globals } from 'src/app/globals';
import { NumberFilterComponent } from 'src/app/common/components/ag-grid-filters/ag-grid-number.component.filter';
import { CustomDateFilterComponent } from 'src/app/common/components/ag-grid-filters/ag-grid-date.component.filter';
import { TextFilterComponent } from 'src/app/common/components/ag-grid-filters/ag-grid-text.component.filter';
import { CustomCheckboxFilterComponent } from 'src/app/common/components/ag-grid-filters/ag-grid-checkbox.component.filter';
import { CommonFilterService } from 'src/app/common/components/filter-chips/filter-chips.service';
import { ReportMonitoringService } from './service/ReportMonitoring.service';
import { map, combineLatest, lastValueFrom, EMPTY, Subject, takeUntil } from 'rxjs';
import { CorasModalsService } from 'src/app/common/components/modals/services/modals.service';
import { DateHelperService } from 'src/app/common/components/datehelper/date-helper.service';
import { DatePipe } from '@angular/common';
import { DownloadButtonRendererComponent } from './DownloadButtonRenderer.component';
import { DownloadProgressPanelComponent } from '@components/download-progress-panel/download-progress-panel.component';
import { backendApiUrl } from 'src/app/app.module';
import { ActivatedRoute } from '@angular/router';
import { DOWNLOAD_CONFIG } from '@components/download-progress-panel/download-blob-type';
import { HttpErrorResponse, HttpHeaders, HttpEventType } from '@angular/common/http';
import { from, defer, of } from 'rxjs';
import { mergeMap, take, finalize, catchError } from 'rxjs/operators';

import { JobExecutionsDetailComponent } from './job-executions-detail.component';
import { RouteExecutionsBadgeComponent } from './route-executions-badge.component';
import {
  formatIsoDateTime,
  getStatusMeta,
  normalizeStatusKey
} from './execution-status.constants';
import {
  JobExecutionDetailEntry,
  JobExecutionDetailRow,
  JobExecutionListItem,
  JobExecutionListResponse,
  RouteExecutionSummary,
  buildRouteSummaryFromExecutions,
  toCount
} from './job-execution.model';

@Component({
  selector: 'app-report-monitoring',
  templateUrl: './report-monitoring.component.html',
  styleUrl: './report-monitoring.component.scss',
  standalone: false
})
export class ReportMonitoringComponent implements OnInit, OnDestroy {

  // ----------------------------------------------------------------------
  // Constants
  // ----------------------------------------------------------------------
  readonly MAX_DOWNLOAD_LIMIT = 200;
  private readonly MAX_CONCURRENT_API_CALLS = 5;

  /** Adjust if the dispatcher module is mounted under a different prefix. */
  private readonly ROUTE_MONITORING_PATH = '/dispatcher/routemonitoring';
  private readonly ROUTE_MONITORING_QUERY_PARAM = 'execution_id';

  private readonly DETAIL_ROW_HEIGHT = 26;
  private readonly DETAIL_HEADER_HEIGHT = 26;
  private readonly DETAIL_CHROME_HEIGHT = 12;   // border + margins of .detail-shell
  private readonly DETAIL_STATE_HEIGHT = 42;
  private readonly PARENT_ROW_HEIGHT = 26;

  @ViewChild(DownloadProgressPanelComponent)
  downloadProgressComponent!: DownloadProgressPanelComponent;

  constructor(
    private readonly toastService: ToasterService,
    private readonly dateHelperService: DateHelperService,
    private readonly datePipe: DatePipe,
    private readonly activatedRoute: ActivatedRoute,
    private readonly filterService: CommonFilterService,
    private readonly modalService: CorasModalsService,
    private readonly reportMonitoringService: ReportMonitoringService
  ) { }

  // ----------------------------------------------------------------------
  // State
  // ----------------------------------------------------------------------
  private readonly destroy$ = new Subject<void>();

  enabledButtons: string[] = [];
  loadingData = false;
  routeData: any;
  jobListDataSource: any[] = [];
  jobDetailDataSource: any[] = [];
  jobListDataLength: number = 0;
  jobDetailDataLength: number = 0;
  errorPopup: any;
  loadMsg = ApplicationMessages.loadMsg;
  jobsMonitoringCollapse = true;
  lastSelectedRowNode: any;
  currentlySelectedRowIndex: any;
  lastSelectedRowIndex: any;
  isApiCalled: boolean = false;
  currentlySelectedRowNode: any;
  public jobListGridId: string = 'jobListGridId';
  public jobDetailGridId: string = 'jobDetailGridId';
  lastSelectedRowElement: HTMLElement | null = null;
  public jobListApi!: GridApi;
  public jobDetailApi!: GridApi;
  public lastClickedRow: any = null;

  /** parentId (JOB_ID) -> detail entry currently rendered in the grid. */
  private readonly expandedDetails = new Map<string, JobExecutionDetailEntry>();
  private expandedParentId: string | null = null;

  /**
   * Live Route summaries captured after a row was expanded. These override the
   * SQL roll-up columns, which are a snapshot from when the grid was loaded.
   */
  private readonly liveRouteSummaries = new Map<string, RouteExecutionSummary>();

  /** Full-width renderer used for expanded execution rows. */
  detailRenderer = JobExecutionsDetailComponent;

  // ----------------------------------------------------------------------
  // Lifecycle
  // ----------------------------------------------------------------------
  ngOnInit(): void {
    this.activatedRoute.data
      .pipe(takeUntil(this.destroy$))
      .subscribe(data => {
        this.routeData = data;
      });

    this.filterService.setDbridgeService(this.jobListGridId, {
      loadGrid: this.updateDataSource.bind(this)
    });

    this.toastService.addMessage('Report Monitoring - Ready!', 'info');
    this.loadGridFilterList();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.expandedDetails.clear();
    this.liveRouteSummaries.clear();
    if (this.jobListApi) { this.jobListApi.destroy(); }
    if (this.jobDetailApi) { this.jobDetailApi.destroy(); }
  }

  // ----------------------------------------------------------------------
  // Column definitions
  // ----------------------------------------------------------------------
  jobListColDefs: ColDef[] = [
    {
      headerName: '',
      colId: 'expander',
      field: '',
      width: 45,
      minWidth: 45,
      maxWidth: 45,
      sortable: false,
      filter: false,
      resizable: false,
      suppressMovable: true,
      cellRenderer: (params: any) => this.expandRenderer(params)
    },
    {
      headerName: 'Select',
      headerCheckboxSelection: () => this.checkPrev(),
      checkboxSelection: (params: any) => this.checkPrev() && !params?.data?.isDetail,
      showDisabledCheckboxes: true,
      field: '',
      sortable: false,
      width: 80
    },
    {
      headerName: 'Job ID',
      field: 'JOB_ID',
      sortable: true,
      width: 90,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'number', backendFilter: true }
    },
    {
      headerName: 'Creation Date',
      field: 'JOB_TMSTMP',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: CustomDateFilterComponent,
      filterParams: {
        type: 'DATETIME',
        format: 'dd/MM/yyyy HH:mm',
        mandatory: true,
        backendFilter: true
      },
      valueFormatter: this.dateformatter.bind(this)
    },
    {
      headerName: 'Report Name',
      field: 'REPORT_NAME',
      sortable: true,
      width: 350,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    /* --- Status: unchanged legacy renderer --- */
    {
      headerName: 'Status',
      field: 'STATUS',
      sortable: true,
      width: 150,
      resizable: true,
      comparator: commonComparator,
      filter: CustomCheckboxFilterComponent,
      filterParams: { type: 'list', backendFilter: true },
      cellRenderer: (params: any) => {
        const data = params.data;
        if (data.JOB_TRAITE == 'T') {
          return '<span class="e-status-terminated-icon">' + data.STATUS + '</span>';
        } else if (data.JOB_TRAITE == 'W') {
          return '<span class="e-status-warning-icon">' + data.STATUS + '</span>';
        } else if (data.JOB_TRAITE == 'E' || data.JOB_TRAITE == 'Q' || data.JOB_TRAITE == 'U' || data.JOB_TRAITE == 'K' || data.JOB_TRAITE == 'Z' || data.JOB_TRAITE == 'B' || data.JOB_TRAITE == 'O') {
          return '<span class="e-status-error-icon">' + data.STATUS + '</span>';
        } else if (data.JOB_TRAITE == 'S' || data.JOB_TRAITE == 'N' || data.JOB_TRAITE == 'M' || data.JOB_TRAITE == 'L' || data.JOB_TRAITE == 'X' || data.JOB_TRAITE == 'Z' || data.JOB_TRAITE == 'B' || data.JOB_TRAITE == 'D' || data.JOB_TRAITE == 'G') {
          return '<span class="e-status-sent-icon">' + data.STATUS + '</span>';
        } else {
          return '<span class="e-status-info-icon">' + data.STATUS + '</span>';
        }
      }
    },
    /**
     * Route: execution count + coloured process circles.
     * Populated on first paint from the EXEC_COUNT / CNT_* roll-up columns
     * of the job list query; refreshed with live values after expansion.
     * Sorts by execution count.
     */
    {
      headerName: 'Route',
      colId: 'ROUTE_EXEC',
      field: 'EXEC_COUNT',
      sortable: true,
      filter: false,
      width: 190,
      minWidth: 140,
      resizable: true,
      comparator: commonComparator,
      valueGetter: (params: any) => {
        const live = params?.data?.ROUTE_EXEC_SUMMARY as RouteExecutionSummary | undefined;
        return live ? live.total : toCount(params?.data?.EXEC_COUNT);
      },
      cellRenderer: RouteExecutionsBadgeComponent
    },
    {
      headerName: 'Finished Time',
      field: 'JOB_ENDTIME',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: CustomDateFilterComponent,
      filterParams: {
        type: 'DATETIME',
        format: 'dd/MM/yyyy HH:mm',
        backendFilter: true
      },
      valueFormatter: this.dateformatter.bind(this)
    },
    {
      headerName: 'Download',
      cellRenderer: DownloadButtonRendererComponent,
      cellRendererParams: {
        onDownloadClick: this.onDownloadClick.bind(this)
      },
      cellStyle: { textAlign: 'center' },
      width: 90
    },
    {
      headerName: 'File Name',
      field: 'JOB_DESNAME',
      sortable: true,
      width: 450,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Creator',
      field: 'JOB_OPRN',
      sortable: true,
      width: 80,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Channel',
      field: 'JOB_CHANEL',
      sortable: true,
      width: 80,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Execution Date',
      field: 'JOB_DOC_FRQ',
      sortable: true,
      width: 115,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Addressee',
      field: 'JOB_DES_NUMERO',
      sortable: true,
      width: 95,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'int', backendFilter: true }
    },
    {
      headerName: 'File Format',
      field: 'JOB_DESFORMAT',
      sortable: true,
      width: 150,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Source Type',
      field: 'JOB_DESTYPE',
      sortable: true,
      width: 100,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Copy Addressee',
      field: 'JOB_COP',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'int', backendFilter: true }
    },
    {
      headerName: 'Operator',
      field: 'JOB_OPRN_ID',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Language',
      field: 'JOB_LNG_ID',
      sortable: true,
      width: 90,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Fax Number',
      field: 'JOB_DES_FAX',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'TFC',
      field: 'JOB_NTFC',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'int', backendFilter: true }
    },
    {
      headerName: 'Addresse Type',
      field: 'JOB_REG',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Start Date',
      field: 'JOB_DATE_INF',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: CustomDateFilterComponent,
      filterParams: {
        type: 'DATETIME',
        format: 'dd/MM/yyyy HH:mm',
        backendFilter: true
      }
    },
    {
      headerName: 'End Date',
      field: 'JOB_DATE_SUP',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: CustomDateFilterComponent,
      filterParams: {
        type: 'DATETIME',
        format: 'dd/MM/yyyy HH:mm',
        backendFilter: true
      }
    },
    {
      headerName: 'Process ID',
      field: 'JOB_EOD_ID',
      sortable: true,
      width: 95,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'int', backendFilter: true }
    },
    {
      headerName: 'Email',
      field: 'JOB_EMAIL',
      sortable: true,
      width: 150,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'File Directory',
      field: 'JOB_DIR',
      sortable: true,
      width: 150,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Report Parameters',
      field: 'JOB_PARAMETER_STRING',
      sortable: true,
      width: 350,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Reporting Queue',
      field: 'JOB_QUEUE',
      sortable: true,
      width: 105,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: true }
    },
    {
      headerName: 'Executions',
      field: 'JOB_NB_EXEC',
      sortable: true,
      width: 90,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'int', backendFilter: true }
    }
  ];

  jobDetailColDefs: ColDef[] = [
    {
      headerName: 'Sequence',
      field: 'SEQ_ID',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: NumberFilterComponent,
      filterParams: { type: 'number', backendFilter: false }
    },
    {
      headerName: 'Process Name',
      field: 'LOG_PROC_NAME',
      sortable: true,
      width: 250,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: false }
    },
    {
      headerName: 'Log Status',
      field: 'LOG_STATUS',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: false }
    },
    {
      headerName: 'Process Status',
      field: 'EVT_PROCESS_STATUS',
      sortable: true,
      width: 250,
      resizable: true,
      comparator: commonComparator,
      filter: CustomCheckboxFilterComponent,
      filterParams: { type: 'list', backendFilter: false }
    },
    {
      headerName: 'User',
      field: 'LOG_UID',
      sortable: true,
      width: 120,
      resizable: true,
      comparator: commonComparator,
      filter: TextFilterComponent,
      filterParams: { type: 'string', backendFilter: false }
    },
    {
      headerName: 'Timestamp',
      field: 'LOG_TMSTMP',
      sortable: true,
      width: 140,
      resizable: true,
      comparator: commonComparator,
      filter: CustomDateFilterComponent,
      filterParams: {
        type: 'DATE',
        format: formats.smallDateFormat,
        backendFilter: false
      },
      valueFormatter: this.dateformatter.bind(this)
    },
    {
      headerName: 'Log Message',
      field: 'LOG_MSG_ERR',
      sortable: true,
      width: 528,
      resizable: true,
      comparator: commonComparator,
      autoHeight: true,
      filter: TextFilterComponent,
      cellRenderer: (params: any) => {
        const data = params.data;
        return '<div style="white-space:normal !important;">' +
          (data.LOG_MSG_ERR === null ? '' : data.LOG_MSG_ERR) + '</div>';
      },
      valueFormatter: this.textFormatter.bind(this),
      filterParams: { type: 'string', backendFilter: false }
    }
  ];

  // ----------------------------------------------------------------------
  // Grid plumbing for full-width detail rows
  // ----------------------------------------------------------------------
  getRowId = (params: GetRowIdParams): string => {
    return params.data?.isDetail
      ? `detail__${params.data.parentId}`
      : String(params.data?.JOB_ID);
  };

  isFullWidthRow = (params: any): boolean => params?.rowNode?.data?.isDetail === true;

  getRowHeight = (params: any): number => {
    if (!params?.data?.isDetail) {
      return this.PARENT_ROW_HEIGHT;
    }
    if (params.data.loading || params.data.error) {
      return this.DETAIL_STATE_HEIGHT;
    }
    const count = params.data.details?.length ?? 0;
    if (count === 0) {
      return this.DETAIL_STATE_HEIGHT;
    }
    return count * this.DETAIL_ROW_HEIGHT
      + this.DETAIL_HEADER_HEIGHT
      + this.DETAIL_CHROME_HEIGHT;
  };

  /**
   * Keeps each detail row directly beneath its parent after any sort.
   *
   * Two passes: strip every detail node out into a map keyed by parent id,
   * then walk the sorted parents and re-insert. Searching `params.nodes` for
   * a detail node while also splicing that same array is what made the old
   * implementation lose the expansion on sort.
   */
  postSortRows = (params: PostSortRowsParams): void => {
    if (this.expandedDetails.size === 0) {
      return;
    }

    const rows = params.nodes;

    const detachedDetails = new Map<string, any>();
    for (let i = rows.length - 1; i >= 0; i--) {
      const node: any = rows[i];
      if (node?.data?.isDetail) {
        detachedDetails.set(String(node.data.parentId), node);
        rows.splice(i, 1);
      }
    }

    if (detachedDetails.size === 0) {
      return;
    }

    for (let i = 0; i < rows.length; i++) {
      const node: any = rows[i];
      const parentId = node?.data?.JOB_ID;
      if (parentId == null) {
        continue;
      }
      const key = String(parentId);
      const detailNode = detachedDetails.get(key);
      if (detailNode && this.expandedDetails.has(key)) {
        rows.splice(i + 1, 0, detailNode);
        detachedDetails.delete(key);
        i++;
      }
    }
  };

  // ----------------------------------------------------------------------
  // Expand / collapse
  // ----------------------------------------------------------------------
  expandRenderer(params: any): string | HTMLElement {
    if (params.data?.isDetail) {
      return '';
    }
    const icon = document.createElement('div');
    icon.className = 'expand-icon';

    const update = () => {
      const expanded = this.expandedDetails.has(String(params.data?.JOB_ID));
      icon.innerHTML = expanded
        ? `<em class="coras-icons" style="cursor:pointer" title="Collapse">arrow_down</em>`
        : `<em class="coras-icons" style="cursor:pointer" title="Show executions">arrow_right</em>`;
    };
    update();

    icon.onclick = (evt: MouseEvent) => {
      evt.stopPropagation();
      this.toggleRow(params);
      params.api.refreshCells({ force: true, columns: ['expander'] });
      update();
    };

    return icon;
  }

  toggleRow(params: any): void {
    const parent = params?.node?.data;
    const parentId = String(parent?.JOB_ID ?? '');
    if (!parentId || parentId === 'undefined' || parentId === 'null') {
      return;
    }

    // Accordion behaviour: only one expanded row at a time.
    if (this.expandedParentId && this.expandedParentId !== parentId) {
      this.collapseRow(this.expandedParentId);
    }

    if (this.expandedDetails.has(parentId)) {
      this.collapseRow(parentId);
      return;
    }

    this.expandRow(parentId, parent);
  }

  private expandRow(parentId: string, parent: any): void {
    const entry: JobExecutionDetailEntry = {
      isDetail: true,
      parentId,
      loading: true,
      error: null,
      details: [],
      openRouteMonitoring: (executionId: string) => this.openRouteMonitoring(executionId)
    };

    this.jobListApi.applyTransaction({ add: [entry] });
    this.expandedDetails.set(parentId, entry);
    this.expandedParentId = parentId;
    parent.expanded = true;
    this.jobListApi.refreshClientSideRowModel('sort');

    this.loadJobExecutions(parentId, entry);
  }

  private collapseRow(parentId: string): void {
    const entry = this.expandedDetails.get(parentId);
    if (!entry) {
      return;
    }
    this.jobListApi.applyTransaction({ remove: [entry] });
    this.expandedDetails.delete(parentId);
    if (this.expandedParentId === parentId) {
      this.expandedParentId = null;
    }
    this.jobListApi.forEachNode((node: RowNode | any) => {
      if (!node.data?.isDetail && String(node.data?.JOB_ID) === parentId) {
        node.data.expanded = false;
      }
    });
  }

  collapseAllDetails(): void {
    if (!this.jobListApi || this.expandedDetails.size === 0) {
      this.expandedDetails.clear();
      this.expandedParentId = null;
      return;
    }
    [...this.expandedDetails.keys()].forEach(id => this.collapseRow(id));
  }

  /** Drops detail rows whose parent has been filtered out of view. */
  private removeOrphanedDetailRows(): void {
    if (!this.jobListApi || this.expandedDetails.size === 0) {
      return;
    }
    const visibleParentIds = new Set<string>();
    this.jobListApi.forEachNodeAfterFilter((node: any) => {
      if (!node.data?.isDetail && node.data?.JOB_ID != null) {
        visibleParentIds.add(String(node.data.JOB_ID));
      }
    });
    [...this.expandedDetails.keys()]
      .filter(id => !visibleParentIds.has(id))
      .forEach(id => this.collapseRow(id));
  }

  // ----------------------------------------------------------------------
  // Executions loading + Route column refresh
  // ----------------------------------------------------------------------
  private loadJobExecutions(jobId: string, entry: JobExecutionDetailEntry): void {
    this.reportMonitoringService.getJobExecutions(jobId)
      .pipe(take(1), takeUntil(this.destroy$))
      .subscribe({
        next: (res: JobExecutionListResponse) => {
          const list: JobExecutionListItem[] = Array.isArray(res?.data) ? res.data : [];

          entry.details = list.map(item => this.mapExecutionRow(item));
          entry.loading = false;
          entry.error = null;

          this.applyLiveRouteSummary(jobId, list);
          this.refreshDetailRow(entry);
        },
        error: (err: HttpErrorResponse | any) => {
          entry.loading = false;
          entry.details = [];
          entry.error =
            err?.error?.message ??
            err?.message ??
            'Unable to load executions for this job.';
          this.refreshDetailRow(entry);
          this.toastService.addMessage(
            `Job ${jobId} - Failed to load executions: ${entry.error}`,
            'error'
          );
        }
      });
  }

  private mapExecutionRow(item: JobExecutionListItem): JobExecutionDetailRow {
    return {
      isDetail: true,
      executionId: String(item?.executionId ?? ''),
      routeId: item?.route?.routeId,
      routeName: item?.route?.name ?? '',
      description: item?.route?.description ?? '',
      status: item?.status,
      statusKey: normalizeStatusKey(item?.status),
      statusLabel: getStatusMeta(item?.status).label,
      errorMessage: item?.errorMessage ?? null,
      ended: formatIsoDateTime(item?.ended),
      reportId: item?.report?.reportId,
      reportName: item?.report?.reportName ?? '',
      fileName: item?.report?.fileName ?? '',
      bucket: item?.report?.bucket,
      key: item?.report?.key,
      type: item?.report?.type
    };
  }

  private refreshDetailRow(entry: JobExecutionDetailEntry): void {
    if (!this.jobListApi) {
      return;
    }
    const node = this.jobListApi.getRowNode(`detail__${entry.parentId}`);
    if (!node) {
      return;
    }
    this.jobListApi.resetRowHeights();
    this.jobListApi.redrawRows({ rowNodes: [node] });
  }

  /**
   * Overlays the Route column with live counts from the executions call.
   * The SQL roll-up is a snapshot taken when the grid loaded, so a job whose
   * processes progressed since then shows stale circles until expanded.
   */
  private applyLiveRouteSummary(jobId: string, executions: JobExecutionListItem[]): void {
    const summary = buildRouteSummaryFromExecutions(executions);

    if (summary) {
      this.liveRouteSummaries.set(jobId, summary);
    } else {
      this.liveRouteSummaries.delete(jobId);
    }

    const parentNode = this.jobListApi?.getRowNode(jobId);
    if (!parentNode) {
      return;
    }
    parentNode.data.ROUTE_EXEC_SUMMARY = summary;
    this.jobListApi.refreshCells({
      rowNodes: [parentNode],
      columns: ['ROUTE_EXEC'],
      force: true
    });
  }

  /**
   * Re-applies live Route summaries after a grid reload so a row the user
   * already inspected does not regress to the SQL snapshot.
   */
  private rehydrateRouteSummaries(rows: any[]): any[] {
    if (this.liveRouteSummaries.size === 0) {
      return rows;
    }
    rows.forEach(row => {
      const live = this.liveRouteSummaries.get(String(row?.JOB_ID));
      if (live) {
        row.ROUTE_EXEC_SUMMARY = live;
      }
    });
    return rows;
  }

  /** Opens Route Monitoring in a new tab, filtered on the execution. */
  private openRouteMonitoring(executionId: string): void {
    if (estars.isEmpty(executionId)) {
      this.toastService.addMessage('Execution ID is not available for this row.', 'warning');
      return;
    }
    const url =
      `${this.ROUTE_MONITORING_PATH}` +
      `?${this.ROUTE_MONITORING_QUERY_PARAM}=${encodeURIComponent(executionId)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  // ----------------------------------------------------------------------
  // Existing behaviour (guarded against detail rows)
  // ----------------------------------------------------------------------
  isButtonEnabled(buttonId: string): boolean {
    return this.enabledButtons.includes(buttonId);
  }

  onJobListFilterChanged(gridId: any, event: any): void {
    this.filterService.onFilterChanged(gridId, event.api);
    this.removeOrphanedDetailRows();
    this.jobListDataLength = Math.max(
      0,
      event.api.getDisplayedRowCount() - this.expandedDetails.size
    );
  }

  onJobDetailFilterChanged(gridId: any, event: any): void {
    this.filterService.onFilterChanged(gridId, event.api);
    this.jobDetailDataLength = event.api.getDisplayedRowCount();
  }

  onJobListGridReady(params: GridReadyEvent): void {
    this.jobListApi = params.api;
    const filters = [{
      FCOLUMN: 'JOB_TMSTMP',
      FOPERATOR: 'gt',
      FVALUES: new Date(new Date().setHours(0, 0, 0, 0)),
      FTYPE: 'DATETIME'
    }];
    this.filterService.setFilters(
      this.jobListGridId,
      filters,
      true,
      params.api,
      'loadGrid'
    );
  }

  onDownloadClick(rowData: any): void {
    this.toastService.addMessage('Report Download Started', 'info');
    this.downloadSingleRow(rowData, false);
  }

  onJobListSelChanged(): void {
    const selectedRows: any[] = (this.jobListApi.getSelectedRows() ?? [])
      .filter((row: any) => !row?.isDetail);
    if (selectedRows.length > 0) {
      this.setActions(['Process', 'Send']);
    } else {
      this.setActions([]);
    }
  }

  onJobDetailGridReady(params: GridReadyEvent): void {
    this.jobDetailApi = params.api;
    this.filterService.registerGrid(this.jobDetailApi, this.jobDetailGridId, [], '');
  }

  dateformatter(params: any): string {
    if (!estars.isEmpty(params.value)) {
      return this.datePipe.transform(
        this.dateHelperService.dbDateLux(params.value),
        formats.longDateFormat
      ) ?? '';
    }
    return '';
  }

  textFormatter(params: any): string {
    if (params.value) {
      const doc = new DOMParser().parseFromString(params.value, 'text/html');
      return doc.documentElement.textContent ?? '';
    }
    return '';
  }

  async loadGridFilterList(): Promise<void> {
    const jobStatusApi = this.reportMonitoringService.getJobsStatusList();
    const processStatusListAPi = this.reportMonitoringService.getProcessStatusList({});

    try {
      const responses = await lastValueFrom(combineLatest([jobStatusApi, processStatusListAPi]));
      const jobStatusResult: any = responses[0];
      const processStatusListResult: any = responses[1];

      if (jobStatusResult) {
        if (jobStatusResult.message) {
          this.showErrorPopup(jobStatusResult.message);
        }
        if (jobStatusResult.P_REC_DATA) {
          const field = this.jobListColDefs.find(col => col.field == 'STATUS');
          if (field) {
            (field.filterParams as any).list = jobStatusResult.P_REC_DATA?.map((report: any) => ({
              displayField: report.VALUE,
              valueField: report.VALUE
            }));
          }
          this.jobListApi?.setGridOption('columnDefs', this.jobListColDefs);
        }
      }

      if (processStatusListResult) {
        if (processStatusListResult.message) {
          this.showErrorPopup(processStatusListResult.message);
        }
        if (processStatusListResult.P_REC_DATA) {
          const field = this.jobDetailColDefs.find(col => col.field == 'EVT_PROCESS_STATUS');
          if (field) {
            (field.filterParams as any).list = processStatusListResult.P_REC_DATA?.map((report: any) => ({
              displayField: report.VALUE,
              valueField: report.VALUE
            }));
          }
          this.jobDetailApi?.setGridOption('columnDefs', this.jobDetailColDefs);
        }
      }
    } catch (error: any) {
      this.toastService.addMessage(error, 'error');
    }
  }

  updateDataSource(): void {
    this.loadingData = true;
    this.collapseAllDetails();

    this.reportMonitoringService.getJobsMonitoringList(
      this.filterService.getFiltersDB(this.jobListGridId, this.jobListApi)
    )
      .pipe(
        map((res: any) => {
          if (res.message) {
            this.showErrorPopup(res.message);
          }
          if (res.P_REC_DATA) {
            this.jobListDataSource = this.rehydrateRouteSummaries(res.P_REC_DATA);
            this.jobListDataLength = this.jobListDataSource.length;
            this.currentlySelectedRowNode = null;
            this.jobDetailDataSource = [];
            this.jobDetailDataLength = 0;
          }
        }),
        catchError(async () => {
          this.loadingData = false;
          return of(null);
        }),
        finalize(() => this.loadingData = false)
      )
      .pipe(take(1))
      .subscribe(() => { });
  }

  setActions(buttonIds: string[]): void {
    if (this.checkPrev()) {
      this.enabledButtons = buttonIds;
    }
  }

  disableAllButtons(): void {
    this.enabledButtons = [];
  }

  jobListClicked(event: any): void {
    if (event?.data?.isDetail) {
      return;
    }
    this.currentlySelectedRowNode = event.node;
    this.lastSelectedRowNode = event.node;
    this.currentlySelectedRowIndex = event.node.rowIndex;

    const isCheckbox = event.event?.target?.classList?.contains('ag-selection-checkbox');
    if (!isCheckbox) {
      const rowIndex = this.currentlySelectedRowIndex;
      const rowElement = this.getRowElement(rowIndex);
      const oldElement = this.getRowElement(this.lastSelectedRowIndex);
      if (oldElement) {
        oldElement.classList.remove('jobs-monitoring-selected');
      }
      if (rowElement) {
        rowElement.classList.add('jobs-monitoring-selected');
        this.lastSelectedRowElement = rowElement;
        this.lastSelectedRowIndex = event.node.rowIndex;
      }
    }
  }

  getRowElement(rowIndex: any): HTMLElement | null {
    if (rowIndex === null || rowIndex === undefined) {
      return null;
    }
    return document.querySelector(`.ag-row[row-index="${rowIndex}"]`) as HTMLElement;
  }

  jobListRowDblClick(event: any): void {
    if (event?.data?.isDetail) {
      return;
    }
    this.loadExpandedRec(event?.data);
    this.changeCollapseState();
  }

  jobDetailRowDblClick(event: any): void {
    if (!estars.isEmpty(event?.data)) {
      const data = event?.data;
      if (
        data?.LOG_MSG_ERR !== null &&
        (data?.LOG_MSG_ERR?.startsWith('http://') || data?.LOG_MSG_ERR?.startsWith('https://'))
      ) {
        window.open(data.LOG_MSG_ERR, '_blank', 'noopener,noreferrer');
      }
    }
  }

  getRowClass = (params: any): string[] => {
    if (params?.data?.isDetail) {
      return ['job-exec-detail-row'];
    }
    const jobType = params.data?.JOB_TRAITE;
    const classes: string[] = [];
    if (params.node === this.lastSelectedRowNode) {
      classes.push('highlighted-row');
    }
    if (jobType == 'T') {
      classes.push('e-forecolor-blue');
    } else if (jobType == 'W') {
      classes.push('e-forecolor-orange');
    } else if (['E', 'Q', 'U', 'K', 'Z', 'B', '6', 'O'].includes(jobType)) {
      classes.push('e-forecolor-red');
    } else if (['S', 'N', 'M', 'L', 'X', 'Z', 'B', 'D', 'G'].includes(jobType)) {
      classes.push('e-forecolor-green');
    } else {
      classes.push('e-forecolor-black');
    }
    return classes;
  };

  changeCollapseState(): void {
    this.jobsMonitoringCollapse = !this.jobsMonitoringCollapse;
    if (!this.jobsMonitoringCollapse && !this.isApiCalled) {
      this.loadExpandedRec(this.currentlySelectedRowNode?.data);
    }
  }

  resetApiCallFlag(): void {
    this.isApiCalled = false;
  }

  loadExpandedRec(data: any): void {
    this.filterService.resetFilters(this.jobDetailGridId, '', false);
    if (!estars.isEmpty(data)) {
      this.isApiCalled = true;
      this.loadingData = true;
      this.jobDetailDataSource = [];
      this.jobDetailDataLength = 0;

      this.reportMonitoringService.getJobDetailData(data.JOB_ID)
        .pipe(take(1), takeUntil(this.destroy$))
        .subscribe({
          next: (res: any) => {
            if (res.message) {
              this.showErrorPopup(res.message);
            } else if (res.P_REC_DATA) {
              this.jobDetailDataSource = res.P_REC_DATA;
              this.jobDetailDataLength = res.P_REC_DATA.length;
              this.loadingData = false;
              setTimeout(this.resetApiCallFlag.bind(this), 500);
            }
          },
          error: () => {
            this.loadingData = false;
          }
        });
    }
  }

  checkPrev(): boolean {
    const writePrev = Globals.priviliges.findIndex((element: any) => element.ID === 'W');
    return writePrev != -1;
  }

  showErrorPopup(errorMessage: any): void {
    if (!this.errorPopup) {
      this.errorPopup = true;
      this.modalService
        .openPassive('', errorMessage, MessageBoxIcons.error, false)
        .pipe(take(1))
        .subscribe(() => {
          this.errorPopup = false;
        });
    }
    this.loadingData = false;
  }

  actionProcess(): void {
    const selectRecs = (this.jobListApi.getSelectedRows() ?? [])
      .filter((row: any) => !row?.isDetail);

    const corasDialogRef = this.modalService.openTransictional(
      '',
      "You are trying to re-launch some reports.<br/>Only the reports with status 'Terminated' or 'FTP done' or 'Error' will be restarted.<br/>Are you sure you want to continue ?",
      MessageBoxIcons.process,
      false
    );

    corasDialogRef.pipe(take(1)).subscribe((data) => {
      if (data !== 'yes') {
        return;
      }
      this.loadingData = true;
      const jobIds: any[] = [];
      selectRecs.forEach((rec: any) => {
        if (
          (rec?.JOB_TRAITE == 'E' || rec?.JOB_TRAITE == 'D' || rec?.JOB_TRAITE == 'T') &&
          rec?.JOB_DOC_RESTARTABLE == 'Y'
        ) {
          jobIds.push(rec?.JOB_ID);
        }
      });

      const filters: any = this.filterService.getFiltersDB(this.jobListGridId, this.jobListApi);
      this.reportMonitoringService.sendDataToProcess({
        PT_JOB_IDS: jobIds,
        p_filters_array: filters
      })
        .pipe(take(1))
        .subscribe({
          next: (res: any) => {
            if (res && res.ps_ok === 'Y') {
              this.toastService.addMessage("Report's request were save in the database.", 'success');
              this.updateData(res.P_REC_DATA);
              this.loadingData = false;
            } else {
              const errorMsg = res?.message ?? res?.PS_ERR_MSG ??
                "An error occurs when saving the report's request! Please try again.";
              this.toastService.addMessage(errorMsg, 'error');
              this.setActions(['Process']);
              this.loadingData = false;
            }
          },
          error: (err: any) => {
            this.loadingData = false;
            this.toastService.addMessage(err.message ?? err, 'error');
          }
        });
    });
  }

  actionSend(): void {
    const selectRecs = (this.jobListApi.getSelectedRows() ?? [])
      .filter((row: any) => !row?.isDetail);

    let li_cpt = 0;
    let li_non_cpt = 0;
    const jobIds: any[] = [];

    selectRecs.forEach((rec: any) => {
      if (rec?.SENDING_ON_DEMAND == 'Y' && rec?.SENDING_REP_COPY_FLG == 'Y') {
        jobIds.push(rec.JOB_ID);
        li_cpt++;
      } else {
        li_non_cpt++;
      }
    });

    if (li_cpt > 0) {
      const corasDialogRef = this.modalService.openTransictional(
        '',
        'You are trying to copy some reports.<br/>' + li_cpt +
        ' report(s) will be copied and ' + li_non_cpt +
        ' report(s) are not elegible to be copied.<br/>Are you sure you want to continue ?',
        MessageBoxIcons.process,
        false
      );

      corasDialogRef.pipe(take(1)).subscribe((data) => {
        if (data !== 'yes') {
          return;
        }
        this.loadingData = true;
        const filters: any = this.filterService.getFiltersDB(this.jobListGridId, this.jobListApi);
        this.reportMonitoringService
          .sendJobs({ PS_JOB_IDS: jobIds.join(), p_filters_array: filters })
          .pipe(take(1))
          .subscribe({
            next: (res: any) => {
              if (res && res.ps_ok === 'Y') {
                this.toastService.addMessage(li_cpt + ' copy request were save in the database.', 'success');
                this.setActions([]);
                this.updateData(res.P_REC_DATA);
                this.loadingData = false;
              } else {
                const errorMsg = res?.message ?? res?.PS_ERR_MSG ??
                  'An error occurs when saving the copy request! Please try again.';
                this.toastService.addMessage(errorMsg, 'error');
                this.setActions(['Send']);
                this.loadingData = false;
              }
            },
            error: (err: any) => {
              this.loadingData = false;
              this.toastService.addMessage(err.message ?? err, 'error');
            }
          });
      });
    } else {
      this.modalService.openPassive(
        'Report Monitoring',
        "There isn't any report eligible to send function.",
        MessageBoxIcons.info,
        false
      );
    }
  }

  isMultiDownloadEnabled(): boolean {
    if (!this.jobListApi) {
      return false;
    }
    const count = (this.jobListApi.getSelectedRows() ?? [])
      .filter((row: any) => !row?.isDetail).length;
    return count > 0;
  }

  onMultiDownloadClick(): void {
    const selectedRows = (this.jobListApi?.getSelectedRows() ?? [])
      .filter((row: any) => !row?.isDetail);

    if (estars.isEmpty(selectedRows)) {
      this.toastService.addMessage('Please select at least one row to download', 'warning');
      return;
    }

    if (selectedRows.length > this.MAX_DOWNLOAD_LIMIT) {
      const errMessage =
        `Maximum ${this.MAX_DOWNLOAD_LIMIT} reports can be downloaded at once. You selected ${selectedRows.length}.`;
      this.modalService
        .openPassive('', errMessage, MessageBoxIcons.error, false)
        .pipe(take(1))
        .subscribe(() => {
          this.errorPopup = false;
        });
      this.toastService.addMessage(errMessage, 'error');
      return;
    }

    const validRows: any[] = [];
    const invalidRows: any[] = [];

    selectedRows.forEach((row: any) => {
      if (estars.isEmpty(row?.COS_ID)) {
        invalidRows.push(row);
      } else {
        validRows.push(row);
      }
    });

    if (invalidRows.length > 0) {
      invalidRows.forEach(row => {
        const errorMsg =
          `Job ${row?.JOB_ID}, Report: ${row?.JOB_DESNAME ?? 'N/A'} - Skipped: COS ID not available`;
        this.toastService.addMessage(errorMsg, 'info');
        const fileDetails = {
          id: `invalid-${row?.JOB_ID}-${Date.now()}-${Math.random()}`,
          fileHalfName: row?.JOB_DESNAME ?? `Job ${row?.JOB_ID}`,
          sizeInByte: 0,
          jobId: row?.JOB_ID
        };
        this.downloadProgressComponent.handleValidationError(fileDetails, errorMsg, true);
      });
    }

    if (validRows.length === 0) {
      this.toastService.addMessage(
        'No valid reports to download. All selected rows are missing COS ID.',
        'error'
      );
      return;
    }

    this.toastService.addMessage(
      `Starting download of ${validRows.length} report(s)` +
      `${invalidRows.length > 0 ? ` (${invalidRows.length} skipped)` : ''}`,
      'info'
    );

    from(validRows)
      .pipe(
        mergeMap(
          (row: any) =>
            defer(() => {
              this.downloadSingleRow(row, true);
              return of(row);
            }).pipe(
              catchError(err => {
                console.error(`Download failed for Job ${row?.JOB_ID}`, err);
                return of(null);
              })
            ),
          this.MAX_CONCURRENT_API_CALLS
        ),
        takeUntil(this.destroy$)
      )
      .subscribe();
  }

  updateData(data: any): void {
    this.collapseAllDetails();
    this.jobListDataSource = this.rehydrateRouteSummaries(data ?? []);
    this.jobListDataLength = this.jobListDataSource.length;
    this.currentlySelectedRowNode = null;
  }

  private downloadSingleRow(rowData: any, isMultiContext: boolean): void {
    const cosId = rowData?.COS_ID;
    const jobId = rowData?.JOB_ID;

    if (estars.isEmpty(cosId)) {
      const errorMsg =
        `Job ${jobId} - Report: ${rowData?.JOB_DESNAME ?? 'N/A'} - Skipped: COS ID not available`;
      const fileDetails = {
        id: `invalid-${jobId}-${Date.now()}`,
        fileHalfName: rowData?.JOB_DESNAME ?? `Job ${jobId}`,
        sizeInByte: 0,
        jobId
      };
      this.downloadProgressComponent.handleValidationError(fileDetails, errorMsg, isMultiContext);
      return;
    }

    const fileDetails = {
      id: `${jobId}-${cosId}`,
      fileHalfName: rowData?.JOB_DESNAME,
      sizeInByte: rowData?.COS_FILE_SIZE,
      jobId
    };

    const url: any =
      `${backendApiUrl.reportApiBaseUrl}/v1/files/${cosId}/download` +
      `?screenId=${this?.routeData?.screenId}&jobId=${jobId}`;

    let headers: HttpHeaders = new HttpHeaders();
    if (isMultiContext) {
      headers = headers.set(DOWNLOAD_CONFIG.SKIP_INTERCEPTOR_HEADER, 'true');
    }

    this.reportMonitoringService.downloadFile(url, headers).pipe(
      map(response => {
        this.downloadProgressComponent.handleResponseTime(response, fileDetails, isMultiContext);
        if (response.type === HttpEventType.Response) {
          const successMsg =
            `Job ${jobId} - Report: ${rowData?.JOB_DESNAME ?? 'N/A'} - Downloaded successfully`;
          this.toastService.addMessage(successMsg, 'success');
        }
        return response;
      }),
      catchError((error: HttpErrorResponse) => {
        if (error.error instanceof Blob && error.error.type?.includes('application/json')) {
          this.downloadProgressComponent.extractBlobErrorMessage(error).then(msg => {
            const fullErrorMsg =
              `Job ${jobId} - Report: ${rowData?.JOB_DESNAME ?? 'N/A'} - Failed: ${msg}`;
            this.toastService.addMessage(fullErrorMsg, 'error');
            this.downloadProgressComponent.handleDownloadError(
              { ...error, _resolvedMessage: msg } as any, fileDetails, isMultiContext
            );
          });
        } else {
          const errorMsg = this.downloadProgressComponent.extractErrorMessage(error);
          const fullErrorMsg =
            `Job ${jobId} - Report: ${rowData?.JOB_DESNAME ?? 'N/A'} - Failed: ${errorMsg}`;
          this.toastService.addMessage(fullErrorMsg, 'error');
          this.downloadProgressComponent.handleDownloadError(error, fileDetails, isMultiContext);
        }
        return EMPTY;
      }),
      takeUntil(this.destroy$)
    ).subscribe();
  }
}
