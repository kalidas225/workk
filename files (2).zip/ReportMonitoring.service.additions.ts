/* ------------------------------------------------------------------
   Add to ReportMonitoring.service.ts

   Required imports (add if not already present):
     import { Observable } from 'rxjs';
     import { backendApiUrl } from 'src/app/app.module';
     import { JobExecutionListResponse } from '../job-execution.model';
   ------------------------------------------------------------------ */

/**
 * GET /v1/job-executions/{jobId}
 * Returns every execution linked to the given STS report job,
 * each carrying its route reference and StsReport payload.
 */
getJobExecutions(jobId: string | number): Observable<JobExecutionListResponse> {
  const encodedJobId = encodeURIComponent(String(jobId));
  return this.http.get<JobExecutionListResponse>(
    `${backendApiUrl.reportApiBaseUrl}/v1/job-executions/${encodedJobId}`
  );
}
