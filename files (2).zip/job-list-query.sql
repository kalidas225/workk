--------------------------------------------------------------------------------
-- Report Monitoring — job list query with dispatcher process-count roll-up.
--
-- Adds five columns consumed by the "Route" column of the Job List grid:
--   EXEC_COUNT      number of dispatcher executions for the job
--   CNT_TERMINATED  processes in SUCCESS
--   CNT_RUNNING     processes in RUNNING
--   CNT_WAITING     processes in WAITING or NEW
--   CNT_ERROR       processes in CRASHED or FAILED (blocking and non-blocking)
--
-- Join path:
--   MFTALU1.TA_DI_REP_JOBFILE.JOB_ID
--     = DISPATCHER.EXECUTION_INPUT.TAG_EXTERNAL_JOB_ID
--     -> DISPATCHER.EXEC_PROCESSES.EXEC_ID
--
-- FIX (previous revision would not compile):
--   The old statement mixed a comma join (FROM J, D) with an ANSI LEFT JOIN.
--   In that form the LEFT JOIN associates with the table immediately
--   preceding it (D), so J is NOT yet in scope in its ON clause and Oracle
--   raises ORA-00904 "J"."JOB_ID": invalid identifier. Comma joins and ANSI
--   joins cannot be interleaved like that. The whole FROM clause is now ANSI,
--   which both compiles and makes the outer-join semantics explicit.
--
-- NOTE ON TYPES: TAG_EXTERNAL_JOB_ID is a tag column and is assumed VARCHAR2
--   while JOB_ID is NUMBER. The join casts the NUMBER side with TO_CHAR so the
--   index on the VARCHAR2 column remains usable. If your schema has both as
--   NUMBER, drop the TO_CHAR — see VARIANT B at the bottom.
--------------------------------------------------------------------------------

SELECT
    0 AS SELECT_STATUS,
    J.JOB_ID,
    J.JOB_TMSTMP,
    (
        SELECT DOC.DOC_USR_DEF
        FROM   MFTALU1.TA_DI_REP_DOC DOC
        WHERE  DOC.DOC_STAT = 'Y'
          AND  DOC.DOC_ID   = J.JOB_DOC_ID
    ) AS REPORT_NAME,
    J.JOB_OPRN_ID,
    J.JOB_DOC_FRQ,
    CASE J.JOB_TRAITE
        WHEN 'Q' THEN 'EMAIL'
        WHEN 'M' THEN 'EMAIL'
        WHEN 'Z' THEN 'CFT'
        WHEN 'X' THEN 'CFT'
        WHEN 'U' THEN 'MQSeries'
        WHEN 'L' THEN 'MQSeries'
        WHEN 'O' THEN 'FAX'
        WHEN 'D' THEN 'FTP'
        WHEN 'G' THEN 'FTP'
        WHEN 'B' THEN 'FTP'
        WHEN 'K' THEN 'FTP'
        END AS JOB_CHANEL,
    (
        SELECT TIP.VALUE
        FROM   MFTALU1.TA_LU_TRANS_ITEM          TI,
               MFTALU1.TA_LU_TRANS_ITEM_PROPERTY TIP
        WHERE  TIP.ITEM_ID   = TI.ITEM_ID
          AND  TI.TABLE_ID   = 'JOBFILE_STATUS'
          AND  TIP.STATUS    = 'Y'
          AND  TI.STATUS     = 'Y'
          AND  TI.ITEM_CODE  = J.JOB_TRAITE
    ) AS STATUS,
    J.JOB_ENDTIME,
    J.JOB_DES_NUMERO,
    J.JOB_DESNAME,
    J.JOB_DESFORMAT,
    J.JOB_DESTYPE,
    J.JOB_COP,
    J.JOB_OPRN,
    J.JOB_LNG_ID,
    J.JOB_DES_FAX,
    J.JOB_NTFC,
    J.JOB_REG,
    J.JOB_DATE_INF,
    J.JOB_DATE_SUP,
    J.JOB_EOD_ID,
    J.JOB_EMAIL,
    J.JOB_DIR,
    J.JOB_PARAMETER_STRING,
    J.JOB_QUEUE,
    J.JOB_NB_EXEC,
    D.SENDING_ON_DEMAND,
    CASE
        WHEN D.SENDING_ON_DEMAND = 'N' THEN 'N'
        ELSE MFTALU1.PKG_UTILS_REPORT.FS_GETCOPYREPORT_FLG(J.JOB_ID)
        END AS SENDING_REP_COPY_FLG,
    J.JOB_TRAITE,
    J.JOB_DOC_RESTARTABLE,
    J.COS_ID,
    J.COS_FILE_SIZE,
    ---------------------------------------------------------------------------
    -- Dispatcher roll-up for the Route column
    ---------------------------------------------------------------------------
    COALESCE(X.EXEC_COUNT,     0) AS EXEC_COUNT,
    COALESCE(X.CNT_TERMINATED, 0) AS CNT_TERMINATED,
    COALESCE(X.CNT_RUNNING,    0) AS CNT_RUNNING,
    COALESCE(X.CNT_WAITING,    0) AS CNT_WAITING,
    COALESCE(X.CNT_ERROR,      0) AS CNT_ERROR
FROM       MFTALU1.TA_DI_REP_JOBFILE J
INNER JOIN MFTALU1.TA_DI_REP_DOC     D
        ON D.DOC_ID = J.JOB_DOC_ID
LEFT  JOIN (
    SELECT
        EI.TAG_EXTERNAL_JOB_ID                                                      AS TAG_JOB_ID,
        COUNT(DISTINCT EI.EXEC_ID)                                                  AS EXEC_COUNT,
        SUM(CASE WHEN EP.EXEC_PROCESS_STATUS = 'SUCCESS'             THEN 1 ELSE 0 END) AS CNT_TERMINATED,
        SUM(CASE WHEN EP.EXEC_PROCESS_STATUS = 'RUNNING'             THEN 1 ELSE 0 END) AS CNT_RUNNING,
        SUM(CASE WHEN EP.EXEC_PROCESS_STATUS IN ('WAITING','NEW')    THEN 1 ELSE 0 END) AS CNT_WAITING,
        SUM(CASE WHEN EP.EXEC_PROCESS_STATUS IN ('CRASHED','FAILED') THEN 1 ELSE 0 END) AS CNT_ERROR
    FROM       DISPATCHER.EXECUTION_INPUT EI
    INNER JOIN DISPATCHER.EXEC_PROCESSES  EP
            ON EP.EXEC_ID = EI.EXEC_ID
    GROUP BY   EI.TAG_EXTERNAL_JOB_ID
) X
        ON X.TAG_JOB_ID = TO_CHAR(J.JOB_ID)
ORDER BY J.JOB_TMSTMP DESC NULLS LAST;


--------------------------------------------------------------------------------
-- WHAT CHANGED, AND WHY
--------------------------------------------------------------------------------
--
-- 1. FROM clause converted entirely to ANSI joins.
--    This is the actual compile fix. `FROM A, B LEFT JOIN C ON C.x = A.x`
--    fails because the LEFT JOIN binds to B, leaving A out of scope in the ON
--    clause. Oracle reports ORA-00904 on the A-side column.
--
-- 2. The inline view's output column was renamed JOB_ID -> TAG_JOB_ID.
--    Having a projected column called JOB_ID on both sides of the join is
--    legal but makes ORA-00918 (column ambiguously defined) easy to trip on
--    the next edit. The distinct name removes that class of error.
--
-- 3. Every column in the SELECT list is now alias-qualified (J. / D.).
--    Previously they were bare, which compiles only while no column name is
--    duplicated across the two tables. SENDING_ON_DEMAND in particular is
--    read from D but was written unqualified while also being referenced as
--    D.SENDING_ON_DEMAND in the CASE two lines below — a latent ambiguity.
--
-- 4. The two scalar subqueries now use table aliases (DOC, TI/TIP) instead of
--    relying on outer-scope name resolution. The REPORT_NAME subquery
--    previously selected from TA_DI_REP_DOC unaliased while the outer query
--    also had TA_DI_REP_DOC in scope as D; correlation there depended on
--    Oracle's scoping rules rather than being stated. It also had no schema
--    prefix, unlike its sibling. Both are now explicit.
--
-- 5. TO_CHAR is applied to J.JOB_ID (the NUMBER side), not to
--    EI.TAG_EXTERNAL_JOB_ID (the indexed VARCHAR2 side). Casting the indexed
--    column would suppress the index; casting the other side does not.
--
--------------------------------------------------------------------------------
-- VARIANT B — use this join instead if TAG_EXTERNAL_JOB_ID is NUMBER
--------------------------------------------------------------------------------
--
--        ON X.TAG_JOB_ID = J.JOB_ID
--
-- Confirm with:
--
--        SELECT column_name, data_type, data_length
--        FROM   all_tab_columns
--        WHERE  owner = 'DISPATCHER'
--          AND  table_name = 'EXECUTION_INPUT'
--          AND  column_name = 'TAG_EXTERNAL_JOB_ID';
--
--        SELECT column_name, data_type
--        FROM   all_tab_columns
--        WHERE  owner = 'MFTALU1'
--          AND  table_name = 'TA_DI_REP_JOBFILE'
--          AND  column_name = 'JOB_ID';
--
-- If TAG_EXTERNAL_JOB_ID is VARCHAR2 and may hold non-numeric tags, keep the
-- TO_CHAR form: comparing NUMBER to a VARCHAR2 column makes Oracle coerce the
-- COLUMN to NUMBER row by row, which both kills the index and raises
-- ORA-01722 the moment a single non-numeric tag exists in the table.
--
--------------------------------------------------------------------------------
-- PERFORMANCE — verify before deploying
--------------------------------------------------------------------------------
--
-- 1. Index on the join column:
--
--        CREATE INDEX DISPATCHER.IX_EXEC_INPUT_TAG_JOB_ID
--            ON DISPATCHER.EXECUTION_INPUT (TAG_EXTERNAL_JOB_ID);
--
--    EXEC_PROCESSES.EXEC_ID should already be indexed as an FK; confirm.
--
-- 2. The inline view aggregates ALL of EXECUTION_INPUT x EXEC_PROCESSES before
--    the join. The outer query is filtered (typically JOB_TMSTMP > today) but
--    the view is not, so the cost does not scale with what the user asked for.
--    Once EXEC_PROCESSES is large, push the filter in:
--
--        WHERE EI.TAG_EXTERNAL_JOB_ID IN (
--            SELECT TO_CHAR(JOB_ID)
--            FROM   MFTALU1.TA_DI_REP_JOBFILE
--            WHERE  JOB_TMSTMP > :p_from_date
--        )
--
--    Get an EXPLAIN PLAN with realistic bind values before choosing.
--
-- 3. COUNT(DISTINCT EI.EXEC_ID) is required, not decorative: the join to
--    EXEC_PROCESSES fans out one row per process, so a plain COUNT(*) would
--    report process count where the UI expects execution count.
--
-- 4. CNT_ERROR deliberately merges blocking and non-blocking FAILED with
--    CRASHED into one bucket, matching the four circles in the UI. The
--    executions detail endpoint still separates them via
--    cnt_blocking_failed / cnt_non_blocking_failed, which is what drives
--    exec_display_status.
--
--------------------------------------------------------------------------------
