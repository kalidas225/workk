import { Component, EventEmitter, Input, Output, signal, computed, HostListener, ElementRef, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';

export interface SelectOption { value: string; label: string; hint?: string; protected?: boolean; }

@Component({
  selector: 'app-searchable-select',
  standalone: true,
  imports: [FormsModule],
  template: `
  <div class="ss" [class.open]="open()">
    <button type="button" class="ss-trigger" (click)="toggle()">
      <span class="ss-value" [class.placeholder]="!selectedLabel()">{{ selectedLabel() || placeholder }}</span>
      @if (selectedProtected()) { <span class="ss-shield" title="protected">🛡</span> }
      <svg class="ss-caret" viewBox="0 0 24 24" width="14" height="14"><path fill="currentColor" d="M7 10l5 5 5-5z"/></svg>
    </button>
    @if (open()) {
      <div class="ss-pop">
        <div class="ss-search">
          <svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M10 2a8 8 0 1 0 4.9 14.3l5.4 5.4 1.4-1.4-5.4-5.4A8 8 0 0 0 10 2zm0 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12z"/></svg>
          <input #searchBox [ngModel]="query()" (ngModelChange)="query.set($event)" placeholder="Search branches…" (click)="$event.stopPropagation()" />
        </div>
        <div class="ss-list">
          @for (o of filtered(); track o.value) {
            <button type="button" class="ss-opt" [class.sel]="o.value === value" (click)="pick(o)">
              <span class="ss-opt-label">{{ o.label }}</span>
              @if (o.protected) { <span class="ss-opt-tag">protected</span> }
              @if (o.hint) { <span class="ss-opt-hint">{{ o.hint }}</span> }
            </button>
          }
          @if (filtered().length === 0) { <div class="ss-empty">No matches</div> }
        </div>
      </div>
    }
  </div>
  `,
  styleUrl: './searchable-select.component.css',
})
export class SearchableSelectComponent {
  private host = inject(ElementRef);
  @Input() options: SelectOption[] = [];
  @Input() value = '';
  @Input() placeholder = 'Choose…';
  @Output() valueChange = new EventEmitter<string>();

  open = signal(false);
  query = signal('');

  filtered = computed(() => {
    const q = this.query().trim().toLowerCase();
    if (!q) return this.options;
    return this.options.filter((o) => o.label.toLowerCase().includes(q) || o.value.toLowerCase().includes(q));
  });
  selectedLabel = computed(() => this.options.find((o) => o.value === this.value)?.label ?? '');
  selectedProtected = computed(() => this.options.find((o) => o.value === this.value)?.protected ?? false);

  toggle() { this.open.set(!this.open()); this.query.set(''); }
  pick(o: SelectOption) { this.value = o.value; this.valueChange.emit(o.value); this.open.set(false); }

  @HostListener('document:click', ['$event'])
  onDocClick(e: Event) { if (!this.host.nativeElement.contains(e.target)) this.open.set(false); }
}
