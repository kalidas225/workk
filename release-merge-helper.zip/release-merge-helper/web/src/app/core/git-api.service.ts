import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  Branch, CherryPickState, CommitsResponse, ConnectResponse, DryResponse,
  PushResponse, ReposResponse, MrResponse,
} from './models';

@Injectable({ providedIn: 'root' })
export class GitApi {
  private http = inject(HttpClient);
  private base = '/api';

  gitlabCheck() {
    return this.http.post<{ ok: boolean; username: string; name: string }>(`${this.base}/gitlab/check`, {});
  }
  repos() { return this.http.get<ReposResponse>(`${this.base}/repos`); }
  connect(repoKey: string) { return this.http.post<ConnectResponse>(`${this.base}/connect`, { repoKey }); }
  fetchAll(repoKey: string) { return this.http.post<{ ok: boolean; output: string }>(`${this.base}/fetch`, { repoKey }); }
  branches(repoKey: string) { return this.http.get<{ branches: Branch[] }>(`${this.base}/branches`, { params: { repoKey } }); }
  protectedCheck(repoKey: string, branch: string) {
    return this.http.get<{ branch: string; isProtected: boolean }>(`${this.base}/protected`, { params: { repoKey, branch } });
  }
  commits(repoKey: string, source: string, target: string, limit = 200, offset = 0) {
    return this.http.get<CommitsResponse>(`${this.base}/commits`, { params: { repoKey, source, target, limit: String(limit), offset: String(offset) } });
  }
  warm(repoKey: string) { return this.http.post<{ ok: boolean; warmed: boolean }>(`${this.base}/warm`, { repoKey }); }
  dryRun(body: { repoKey: string; target: string; commits: string[]; newBranch?: string }) {
    return this.http.post<DryResponse>(`${this.base}/dry-run`, body);
  }
  start(body: { repoKey: string; target: string; commits: string[]; forceNewBranch: boolean; newBranch?: string }) {
    return this.http.post<CherryPickState>(`${this.base}/cherry-pick/start`, body);
  }
  resolve(body: { repoKey: string; workBranch: string; resolutions: { file: string; content?: string; side?: "ours" | "theirs" | "delete" }[] }) {
    return this.http.post<CherryPickState>(`${this.base}/cherry-pick/resolve`, body);
  }
  abort(body: { repoKey: string; workBranch: string }) {
    return this.http.post<{ ok: boolean; aborted: boolean }>(`${this.base}/cherry-pick/abort`, body);
  }
  push(body: { repoKey: string; branch: string; setUpstream: boolean }) {
    return this.http.post<PushResponse>(`${this.base}/push`, body);
  }
  commitDiff(repoKey: string, sha: string) {
    return this.http.get<{ sha: string; files: { file: string; patch: string; additions: number; deletions: number; rows: any[] }[] }>(
      `${this.base}/commit-diff`, { params: { repoKey, sha } });
  }
  branchDiff(repoKey: string, base: string, head: string) {
    return this.http.get<{ files: { file: string; patch: string; additions: number; deletions: number; rows: any[] }[] }>(
      `${this.base}/branch-diff`, { params: { repoKey, base, head } });
  }
  mergeRequest(body: { repoKey: string; sourceBranch: string; targetBranch: string; title: string; description: string; removeSourceBranch: boolean; squash: boolean; labels: string[] }) {
    return this.http.post<MrResponse>(`${this.base}/merge-request`, body);
  }
  fixSql(repoKey: string, file: string) {
    return this.http.post<{ ok: boolean; file: string; fixed: boolean }>(`${this.base}/fix-sql`, { repoKey, file });
  }
}
