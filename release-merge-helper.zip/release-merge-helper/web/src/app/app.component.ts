import { Component, computed, inject, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { GitApi } from './core/git-api.service';
import {
  Branch, CherryPickState, ConflictFile, DryItem, MrResponse, ProjectGroup, PushResponse,
  RepoRef, SqlWarning, SubjectGroup,
} from './core/models';
import { ThemeToggleComponent } from './shared/theme-toggle.component';
import { ConflictEditorComponent } from './shared/conflict-editor.component';
import { SettingsPanelComponent } from './shared/settings-panel.component';
import { SettingsService } from './core/settings.service';
import { SearchableSelectComponent, SelectOption } from './shared/searchable-select.component';

type Step = 'repos' | 'pick';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, ThemeToggleComponent, ConflictEditorComponent, SettingsPanelComponent, SearchableSelectComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  private api = inject(GitApi);
  settings = inject(SettingsService);
  showSettings = signal(false);
  gitlabError = signal<string | null>(null);

  step = signal<Step>('repos');
  busy = signal(false);
  error = signal<string | null>(null);
  toast = signal<string | null>(null);

  projectGroups = signal<ProjectGroup[]>([]);
  gitlabOn = signal(false);
  repoFilter = signal('');
  activeRepo = signal<RepoRef | null>(null);
  repoRoot = signal('');
  get repoKey() { return this.repoRoot() || ''; }

  branches = signal<Branch[]>([]);
  source = signal('develop');
  target = signal('');

  groups = signal<SubjectGroup[]>([]);
  total = signal(0);
  selected = signal<Set<string>>(new Set());
  filter = signal('');
  collapsed = signal<Set<string>>(new Set());

  targetProtected = signal(false);
  forceNewBranch = signal(false);
  newBranch = signal('');

  dryResults = signal<DryItem[] | null>(null);
  state = signal<CherryPickState | null>(null); // active cherry-pick (conflict or done)
  pushed = signal<PushResponse | null>(null);
  sqlFixed = signal<Set<string>>(new Set());

  // merge request
  showMr = signal(false);
  mrTitle = signal('');
  mrDesc = signal('');
  mrTarget = signal('');
  mrLabels = signal('');
  mrRemoveSource = signal(false);
  mrSquash = signal(false);
  mrResult = signal<MrResponse | null>(null);

  // commit diff viewer
  diffSha = signal<string | null>(null);
  diffFiles = signal<{ file: string; patch: string; additions: number; deletions: number; rows: { type: string; left: string | null; right: string | null; leftNo: number | null; rightNo: number | null }[] }[] | null>(null);
  diffTitle = signal('');

  conflictFiles = computed<ConflictFile[]>(() => this.state()?.files ?? []);
  inConflict = computed(() => this.state()?.status === 'conflict');
  done = computed(() => this.state()?.status === 'done');

  filteredRepoGroups = computed(() => {
    const q = this.repoFilter().trim().toLowerCase();
    if (!q) return this.projectGroups();
    return this.projectGroups()
      .map((g) => ({ ...g, repos: g.repos.filter((r) => r.name.toLowerCase().includes(q) || r.path.toLowerCase().includes(q)) }))
      .filter((g) => g.repos.length > 0 || g.group.toLowerCase().includes(q));
  });

  // Only local branches; never show remotes (origin/...). Dedupe by name.
  branchOptions = computed<SelectOption[]>(() => {
    const seen = new Set<string>();
    const opts: SelectOption[] = [];
    for (const b of this.branches()) {
      if (b.remote) continue;
      const name = b.name.replace(/^origin\//, '');
      if (seen.has(name)) continue;
      seen.add(name);
      opts.push({ value: name, label: name, hint: b.date, protected: b.protectedBranch });
    }
    return opts;
  });

  filteredGroups = computed(() => {
    const q = this.filter().trim().toLowerCase();
    if (!q) return this.groups();
    return this.groups()
      .map((g) => ({ ...g, commits: g.commits.filter((c) =>
        c.subject.toLowerCase().includes(q) || c.subjectKey.toLowerCase().includes(q) ||
        c.author.toLowerCase().includes(q) || c.shortHash.includes(q)) }))
      .filter((g) => g.commits.length > 0 || g.key.toLowerCase().includes(q));
  });

  selectedCount = computed(() => this.selected().size);
  selectedCommitsOrdered = computed(() => {
    const out: string[] = [];
    for (const g of this.groups()) for (const c of g.commits) if (this.selected().has(c.hash)) out.push(c.hash);
    return out;
  });
  mustBranch = computed(() => this.targetProtected() || this.forceNewBranch());
  canRun = computed(() => {
    if (this.selectedCount() === 0 || !this.target()) return false;
    if (this.mustBranch() && !this.newBranch().trim()) return false;
    return true;
  });

  ngOnInit() { this.loadRepos(); }
  loadRepos() {
    this.busy.set(true); this.error.set(null);
    this.api.repos().subscribe({
      next: (r) => { this.busy.set(false); this.projectGroups.set(r.groups); this.gitlabOn.set(r.gitlab); this.gitlabError.set(r.gitlabError ?? null); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Failed to load repos.'); },
    });
  }
  openSettings() { this.showSettings.set(true); }
  onSettingsSaved() { this.loadRepos(); }

  loadingMsg = signal<string | null>(null);
  chooseRepo(r: RepoRef) {
    if (!r.operable) { this.error.set(`"${r.name}" can't be operated on.`); return; }
    // full reset so nothing from the previous repo leaks in
    this.activeRepo.set(r);
    this.branches.set([]);
    this.groups.set([]); this.total.set(0);
    this.source.set(''); this.target.set('');
    this.selected.set(new Set());
    this.resetBranchState();
    const key = r.localPath ?? (r.gitlabId != null ? String(r.gitlabId) : r.path);
    this.repoRoot.set(key);
    this.busy.set(true); this.error.set(null);
    this.loadingMsg.set(r.cached ? 'Opening repository…' : 'Cloning repository for the first time — this can take a moment…');
    this.api.connect(key).subscribe({
      next: (res) => {
        this.busy.set(false); this.loadingMsg.set(null);
        this.repoRoot.set(res.repoKey || res.root);
        this.source.set(res.currentBranch || 'develop');
        this.loadBranches(() => { if (!this.branches().some((b) => b.name === this.source())) this.source.set(res.currentBranch || 'develop'); });
        this.step.set('pick');
      },
      error: (e) => { this.busy.set(false); this.loadingMsg.set(null); this.error.set(e?.error?.error || 'Connect failed.'); },
    });
  }
  resetBranchState() {
    this.forceNewBranch.set(false);
    this.newBranchEdited.set(false);
    this.newBranch.set('');
    this.targetProtected.set(false);
    this.dryResults.set(null);
    this.state.set(null);
    this.pushed.set(null);
    this.mrResult.set(null);
    this.showMr.set(false);
  }
  changeRepo() {
    // go back to repo list and clear everything from the current repo
    this.step.set('repos');
    this.activeRepo.set(null);
    this.repoRoot.set('');
    this.branches.set([]);
    this.groups.set([]); this.total.set(0);
    this.source.set(''); this.target.set('');
    this.selected.set(new Set());
    this.resetBranchState();
  }

  loadBranches(then?: () => void) { this.run(this.api.branches(this.repoKey), (r) => { this.branches.set(r.branches); then?.(); }); }
  fetchAll() { this.run(this.api.fetchAll(this.repoKey), (r) => { this.flash(r.output || 'Fetched.'); this.loadBranches(); }); }
  onSourceChange(v: string) { this.source.set(v); this.resetBranchState(); this.loadCommits(); }
  onTargetChange(v: string) { this.target.set(v); this.resetBranchState(); this.loadCommits(); }
  loadCommits() {
    if (!this.source()) return;
    this.run(this.api.commits(this.repoKey, this.source(), this.target()), (r) => {
      this.groups.set(r.groups); this.total.set(r.total);
      this.selected.set(new Set()); this.dryResults.set(null); this.state.set(null); this.pushed.set(null);
    });
    if (this.target()) this.checkProtection();
  }
  checkProtection() {
    if (!this.target()) { this.targetProtected.set(false); return; }
    this.api.protectedCheck(this.repoKey, this.target()).subscribe({
      next: (r) => {
        this.targetProtected.set(r.isProtected);
        // always refresh the suggested branch name for the CURRENT target (fixes stale name)
        if (r.isProtected || this.forceNewBranch()) this.newBranch.set(this.suggestBranchName());
        else this.newBranch.set('');
      },
      error: () => {},
    });
  }
  // Selected subject keys (e.g. TCAAS1484-3055), in order.
  selectedSubjects = computed(() => {
    const keys: string[] = [];
    for (const g of this.groups()) {
      if (g.commits.some((c) => this.selected().has(c.hash)) && !keys.includes(g.key)) keys.push(g.key);
    }
    return keys;
  });
  suggestBranchName() {
    const subs = this.selectedSubjects();
    if (subs.length === 1) return `release/${subs[0]}`;
    if (subs.length > 1) return `release/${subs[0]}-and-${subs.length - 1}-more`;
    const t = this.target().replace(/^remotes\/[^/]+\//, '').replace(/[^\w./-]/g, '-');
    return `release/${t}-${new Date().toISOString().slice(0, 10)}`;
  }

  newBranchEdited = signal(false);
  private refreshBranchName() {
    if (this.mustBranch() && !this.newBranchEdited()) this.newBranch.set(this.suggestBranchName());
  }
  onNewBranchInput(v: string) { this.newBranch.set(v); this.newBranchEdited.set(true); }
  toggleCommit(h: string) { const s = new Set(this.selected()); s.has(h) ? s.delete(h) : s.add(h); this.selected.set(s); this.refreshBranchName(); }
  isSelected(h: string) { return this.selected().has(h); }
  toggleGroup(g: SubjectGroup) {
    const s = new Set(this.selected());
    const allOn = g.commits.every((c) => s.has(c.hash));
    for (const c of g.commits) allOn ? s.delete(c.hash) : s.add(c.hash);
    this.selected.set(s); this.refreshBranchName();
  }
  groupState(g: SubjectGroup): 'all' | 'some' | 'none' {
    const on = g.commits.filter((c) => this.selected().has(c.hash)).length;
    if (on === 0) return 'none'; return on === g.commits.length ? 'all' : 'some';
  }
  toggleCollapse(k: string) { const s = new Set(this.collapsed()); s.has(k) ? s.delete(k) : s.add(k); this.collapsed.set(s); }
  selectAll() { const s = new Set<string>(); for (const g of this.filteredGroups()) for (const c of g.commits) s.add(c.hash); this.selected.set(s); this.refreshBranchName(); }
  clearAll() { this.selected.set(new Set()); this.refreshBranchName(); }

  dryRun() {
    if (!this.canRun()) return;
    this.run(this.api.dryRun({ repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(), newBranch: this.newBranch() }),
      (r) => this.dryResults.set(r.results));
  }

  apply() {
    if (!this.canRun()) return;
    this.busy.set(true); this.error.set(null); this.dryResults.set(null);
    this.api.start({
      repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(),
      forceNewBranch: this.forceNewBranch(), newBranch: this.mustBranch() ? this.newBranch().trim() : undefined,
    }).subscribe({
      next: (s) => { this.busy.set(false); this.state.set(s); if (s.status === 'done') { this.prefillMr(s); this.flash(`Applied ${s.applied} commit(s).`); } },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Cherry-pick failed.'); },
    });
  }

  onResolved(resolutions: { file: string; content: string }[]) {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.busy.set(true); this.error.set(null);
    this.api.resolve({ repoKey: this.repoKey, workBranch: wb, resolutions }).subscribe({
      next: (s) => { this.busy.set(false); this.state.set(s);
        if (s.status === 'done') { this.prefillMr(s); this.flash(`Resolved & applied ${s.applied} commit(s).`); }
        else this.flash('Resolved — next conflict.'); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Resolve failed.'); },
    });
  }
  onAbort() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.api.abort({ repoKey: this.repoKey, workBranch: wb }).subscribe({
      next: () => { this.state.set(null); this.flash('Cherry-pick aborted. Nothing applied.'); },
      error: (e) => this.error.set(e?.error?.error || 'Abort failed.'),
    });
  }

  prefillMr(s: CherryPickState) {
    this.mrTarget.set(this.target());
    this.mrTitle.set(`[${this.source()} → ${this.target()}] cherry-pick ${s.applied} commit(s)`);
    const subjects = (s.autoResolved ?? []).flatMap((a: any) => a.subjects ?? []);
    const subjLine = subjects.length ? subjects.join(', ') : 'see commits';
    this.mrDesc.set(
`## Summary
Cherry-picked **${s.applied} commit(s)** from \`${this.source()}\` into \`${this.target()}\` via Release Merge Helper.
Subjects: ${subjLine}

## ✅ Merge Request Acceptance Checklist
- [ ] Code reviewed and approved by at least one peer
- [ ] All impacted subjects verified against JIRA scope
- [ ] order_of_execution_release.info / develop.info updated for the right subjects
- [ ] SQL scripts end with a trailing \`/\` (Ansible-safe)
- [ ] Unit / integration tests pass on the source branch
- [ ] No unintended files included in the cherry-pick
- [ ] Deployment notes / runbook updated if required
- [ ] Rollback plan confirmed`
    );
    this.mrResult.set(null); this.showMr.set(false);
  }
  openMr() { this.showMr.set(true); }
  raiseMr() {
    const wb = this.state()?.workBranch; if (!wb || !this.mrTitle().trim() || !this.mrTarget().trim()) return;
    const labels = this.mrLabels().split(',').map((x) => x.trim()).filter(Boolean);
    this.busy.set(true); this.error.set(null);
    this.api.mergeRequest({ repoKey: this.repoKey, sourceBranch: wb, targetBranch: this.mrTarget().trim(),
      title: this.mrTitle().trim(), description: this.mrDesc(), removeSourceBranch: this.mrRemoveSource(),
      squash: this.mrSquash(), labels }).subscribe({
      next: (r) => { this.busy.set(false); this.mrResult.set(r); if (r.ok) this.flash(`MR !${r.iid} created.`); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'MR failed.'); },
    });
  }
  viewCommitDiff(sha: string, label: string) {
    this.diffSha.set(sha); this.diffTitle.set(label); this.diffFiles.set(null);
    this.busy.set(true);
    this.api.commitDiff(this.repoKey, sha).subscribe({
      next: (r) => { this.busy.set(false); this.diffFiles.set(r.files); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Could not load diff.'); this.diffSha.set(null); },
    });
  }
  viewMergedDiff() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.diffSha.set('__merged__'); this.diffTitle.set(`What changed on ${wb}`); this.diffFiles.set(null);
    this.busy.set(true);
    this.api.branchDiff(this.repoKey, this.target(), wb).subscribe({
      next: (r) => { this.busy.set(false); this.diffFiles.set(r.files); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Could not load diff.'); this.diffSha.set(null); },
    });
  }
  closeDiff() { this.diffSha.set(null); this.diffFiles.set(null); }
  push() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.busy.set(true); this.error.set(null);
    this.api.push({ repoKey: this.repoKey, branch: wb, setUpstream: true }).subscribe({
      next: (r) => { this.busy.set(false); this.pushed.set(r); this.flash(`Pushed ${wb}.`); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Push failed.'); },
    });
  }
  fixSql(w: SqlWarning) {
    this.api.fixSql(this.repoKey, w.file).subscribe({
      next: () => { const s = new Set(this.sqlFixed()); s.add(w.file); this.sqlFixed.set(s); this.flash(`Added trailing / to ${w.file}`); },
      error: (e) => this.error.set(e?.error?.error || 'Fix failed.'),
    });
  }
  isFixed(f: string) { return this.sqlFixed().has(f); }
  copy(t: string) { navigator.clipboard?.writeText(t); this.flash('Copied.'); }

  private run<T>(obs: Observable<T>, ok: (r: T) => void) {
    this.busy.set(true); this.error.set(null);
    obs.subscribe({ next: (r: T) => { this.busy.set(false); ok(r); },
      error: (e: any) => { this.busy.set(false); this.error.set(e?.error?.error || 'Request failed.'); } });
  }
  private flash(m: string) { this.toast.set(m); setTimeout(() => this.toast.set(null), 3200); }
}
