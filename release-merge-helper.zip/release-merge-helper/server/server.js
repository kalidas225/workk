// Release Merge Helper server — plain Node, zero dependencies.
// Load .env first so GITLAB_CA_FILE / GITLAB_INSECURE etc. are available everywhere.
require('./lib/loadEnv').loadEnv();
// GitLab config (URL, group, per-developer PAT) comes from request headers:
//   X-GitLab-Url, X-GitLab-Group, X-GitLab-Token
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const gs = require('./lib/gitService');
const disc = require('./lib/repoDiscovery');
const gl = require('./lib/gitlab');
const { fixSqlFile } = require('./lib/sqlLint');

const PORT = process.env.PORT || 5173;
const DIST = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function send(res, code, body, type = 'application/json') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-GitLab-Url,X-GitLab-Group,X-GitLab-Token',
  });
  res.end(data);
}
function readBody(req) { return new Promise((resolve) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } }); }); }

// per-request GitLab context from headers
function ctxOf(req) {
  return {
    baseUrl: req.headers['x-gitlab-url'] || '',
    group: req.headers['x-gitlab-group'] || '',
    token: req.headers['x-gitlab-token'] || '',
  };
}

async function wt(ctx, repoKey, forWrite = false) {
  const lp = await disc.resolveWorkingTree(ctx, repoKey, forWrite);
  if (!lp) throw new gs.GitError(`Could not resolve a working copy for: ${repoKey}`);
  return lp;
}

const routes = {
  'POST /api/gitlab/check': async (ctx) => gl.checkToken(ctx),
  'GET /api/repos': async (ctx) => { const d = await disc.discover(ctx); return { groups: d.groups, gitlab: gl.gitlabEnabled(ctx), gitlabError: d.gitlabError }; },

  'POST /api/connect': async (ctx, q, body) => {
    const lp = await wt(ctx, body.repoKey);
    return { ok: true, root: await gs.root(lp), currentBranch: await gs.currentBranch(lp), repoKey: body.repoKey, workingCopy: lp };
  },
  'GET /api/branches': async (ctx, q) => ({ branches: await gs.branches(await wt(ctx, q.repoKey)) }),
  'POST /api/fetch': async (ctx, q, body) => ({ ok: true, output: await gs.fetchAll(await wt(ctx, body.repoKey)) }),
  'GET /api/protected': async (ctx, q) => ({ branch: q.branch, isProtected: await gs.isProtected(await wt(ctx, q.repoKey), q.branch) }),
  'GET /api/commits': async (ctx, q) => gs.commits(await wt(ctx, q.repoKey), q.source || 'develop', q.target || ''),
  'POST /api/dry-run': async (ctx, q, body) => gs.dryRun(await wt(ctx, body.repoKey), body),
  'POST /api/cherry-pick/start': async (ctx, q, body) => gs.startCherryPick(await wt(ctx, body.repoKey, true), body),
  'POST /api/cherry-pick/resolve': async (ctx, q, body) => gs.resolveAndContinue(await wt(ctx, body.repoKey), body.workBranch, body.resolutions || []),
  'POST /api/cherry-pick/abort': async (ctx, q, body) => gs.abortCherryPick(await wt(ctx, body.repoKey), body.workBranch),
  'POST /api/push': async (ctx, q, body) => gs.push(await wt(ctx, body.repoKey), body.branch, !!body.setUpstream),
  'GET /api/commit-diff': async (ctx, q) => gs.commitDiff(await wt(ctx, q.repoKey), q.sha),
  'GET /api/branch-diff': async (ctx, q) => gs.branchDiff(await wt(ctx, q.repoKey), q.base, q.head),
  'POST /api/merge-request': async (ctx, q, body) => {
    const projectId = await disc.gitlabIdFor(ctx, body.repoKey);
    if (!projectId) throw new gs.GitError('No GitLab project id for this repo — can\'t raise an MR.');
    return gl.createMergeRequest(ctx, projectId, body);
  },
  'POST /api/fix-sql': async (ctx, q, body) => ({ ok: true, file: body.file, fixed: fixSqlFile(await wt(ctx, body.repoKey), body.file) }),
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const key = `${req.method} ${u.pathname}`;
  if (routes[key]) {
    try {
      const ctx = ctxOf(req);
      const q = Object.fromEntries(u.searchParams.entries());
      const body = req.method === 'POST' ? await readBody(req) : {};
      return send(res, 200, await routes[key](ctx, q, body));
    } catch (e) {
      return send(res, e instanceof gs.GitError ? 400 : 500, { error: e.message || 'Unexpected error' });
    }
  }
  if (req.method === 'GET' && !u.pathname.startsWith('/api/')) {
    let fp = path.join(DIST, u.pathname === '/' ? 'index.html' : u.pathname.slice(1));
    if (!fs.existsSync(fp) || !fs.statSync(fp).isFile()) fp = path.join(DIST, 'index.html');
    if (fs.existsSync(fp)) return send(res, 200, fs.readFileSync(fp), MIME[path.extname(fp)] || 'application/octet-stream');
    return send(res, 404, 'UI not built.', 'text/plain');
  }
  send(res, 404, { error: 'Not found' });
});
server.listen(PORT, () => {
  console.log(`Release Merge Helper on http://localhost:${PORT}`);
  if (String(process.env.GITLAB_INSECURE || '').toLowerCase() === 'true') {
    console.warn('⚠  GITLAB_INSECURE=true — TLS certificate verification is OFF. Use GITLAB_CA_FILE for production.');
  } else if (process.env.GITLAB_CA_FILE) {
    console.log(`✓ Trusting GitLab CA bundle: ${process.env.GITLAB_CA_FILE}`);
  }
  if (process.env.PROXY_HOST) {
    console.log(`✓ Using proxy ${process.env.PROXY_HOST}:${process.env.PROXY_PORT || 8080}${process.env.PROXY_USER ? ' (authenticated)' : ''}`);
  }
});
