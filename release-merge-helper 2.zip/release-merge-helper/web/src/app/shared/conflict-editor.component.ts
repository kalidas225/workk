import { Component, EventEmitter, Input, Output, computed, signal } from '@angular/core';
import { ConflictFile, Segment, Side } from '../core/models';

interface Choice { side: Side; }

@Component({
  selector: 'app-conflict-editor',
  standalone: true,
  template: `
  <div class="ce">
    <div class="ce-head">
      <div>
        <strong>Resolve conflicts</strong>
        <small>commit <code>{{ sha }}</code> · {{ files.length }} file(s) · choose a side for each conflict</small>
      </div>
      <div class="ce-progress">{{ resolvedCount() }} / {{ totalConflicts() }} resolved</div>
    </div>

    @for (f of files; track f.file; let fi = $index) {
      <div class="ce-file">
        <div class="ce-file-head">
          <span class="fname mono">{{ f.file }}</span>
          <span class="fbadge">{{ conflictsIn(f).length }} conflict(s)</span>
        </div>

        @for (seg of f.segments; track $index; let si = $index) {
          @if (seg.type === 'context') {
            @if (nonEmpty(seg.lines)) {
              <pre class="ctx mono">{{ joinLines(seg.lines) }}</pre>
            }
          } @else {
            <div class="hunk" [attr.data-side]="choiceFor(fi, si)?.side ?? 'none'">
              <div class="hunk-bar">
                <span class="hunk-n">conflict #{{ conflictOrdinal(f, si) }}</span>
                <div class="hunk-actions">
                  <button class="side-btn ours" [class.on]="choiceFor(fi, si)?.side === 'ours'" (click)="pick(fi, si, 'ours')">
                    ◀ Keep {{ seg.oursLabel || 'ours' }}
                  </button>
                  <button class="side-btn theirs" [class.on]="choiceFor(fi, si)?.side === 'theirs'" (click)="pick(fi, si, 'theirs')">
                    Keep {{ seg.theirsLabel || 'incoming' }} ▶
                  </button>
                  <button class="side-btn both" [class.on]="choiceFor(fi, si)?.side === 'both'" (click)="pick(fi, si, 'both')">
                    Both
                  </button>
                </div>
              </div>
              <div class="hunk-cols">
                <div class="col ours" [class.dim]="choiceFor(fi, si)?.side === 'theirs'">
                  <div class="col-tag">ours · release</div>
                  <pre class="mono">{{ joinLines(seg.ours) || '(empty)' }}</pre>
                </div>
                <div class="col theirs" [class.dim]="choiceFor(fi, si)?.side === 'ours'">
                  <div class="col-tag">theirs · incoming</div>
                  <pre class="mono">{{ joinLines(seg.theirs) || '(empty)' }}</pre>
                </div>
              </div>
            </div>
          }
        }
      </div>
    }

    <div class="ce-foot">
      <button class="btn ghost" (click)="cancelled.emit()">Abort cherry-pick</button>
      <button class="btn primary" [disabled]="!allResolved()" (click)="emitResolved()">
        @if (allResolved()) { Apply &amp; continue } @else { Resolve all to continue }
      </button>
    </div>
  </div>
  `,
  styleUrl: './conflict-editor.component.css',
})
export class ConflictEditorComponent {
  @Input({ required: true }) files: ConflictFile[] = [];
  @Input() sha = '';
  @Output() resolved = new EventEmitter<{ file: string; content: string }[]>();
  @Output() cancelled = new EventEmitter<void>();

  // choices keyed "fileIndex:segIndex"
  private choices = signal<Map<string, Choice>>(new Map());

  private k(fi: number, si: number) { return `${fi}:${si}`; }
  choiceFor(fi: number, si: number) { return this.choices().get(this.k(fi, si)); }
  pick(fi: number, si: number, side: Side) {
    const m = new Map(this.choices()); m.set(this.k(fi, si), { side }); this.choices.set(m);
  }

  conflictsIn(f: ConflictFile) { return f.segments.filter((s) => s.type === 'conflict'); }
  nonEmpty(lines?: string[]) { return !!lines && lines.some((l) => l.trim() !== ''); }
  joinLines(lines?: string[]) { return (lines || []).join('\n'); }
  conflictOrdinal(f: ConflictFile, si: number) {
    let n = 0; for (let i = 0; i <= si; i++) if (f.segments[i].type === 'conflict') n++; return n;
  }

  totalConflicts = computed(() =>
    this.files.reduce((a, f) => a + f.segments.filter((s) => s.type === 'conflict').length, 0));
  resolvedCount = computed(() => this.choices().size);
  allResolved = computed(() => this.resolvedCount() === this.totalConflicts() && this.totalConflicts() > 0);

  emitResolved() {
    const out: { file: string; content: string }[] = [];
    this.files.forEach((f, fi) => {
      const lines: string[] = [];
      f.segments.forEach((seg, si) => {
        if (seg.type === 'context') lines.push(...(seg.lines || []));
        else {
          const c = this.choiceFor(fi, si)?.side ?? 'ours';
          if (c === 'ours') lines.push(...(seg.ours || []));
          else if (c === 'theirs') lines.push(...(seg.theirs || []));
          else lines.push(...(seg.ours || []), ...(seg.theirs || []));
        }
      });
      out.push({ file: f.file, content: lines.join('\n') });
    });
    this.resolved.emit(out);
  }
}
