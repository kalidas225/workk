package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.connector.ReleaseDataConnector;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Background scan + cache for the (slow) per-release readiness scan
 * (Jira subjects + Octane + SharePoint).
 *
 * Goals:
 *  - The dashboard NEVER blocks on a live scan. API reads return whatever is in
 *    cache instantly (possibly empty on first hit), and a background scan fills
 *    it in. Subsequent reads are instant.
 *  - Switching tabs/releases re-uses the cache; it does NOT re-scan.
 *  - The UI can show "last checked" and "next check" per release.
 *  - A single release scan runs at most once at a time (no stampede).
 */
@Slf4j
@Service
public class ScanService {

    public record ScanState(List<Subject> subjects, Instant lastChecked,
                            Instant nextCheck, boolean scanning) {}

    private final ReleaseDataConnector connector;
    private final Map<String, ScanState> cache = new ConcurrentHashMap<>();
    private final Map<String, Boolean> inFlight = new ConcurrentHashMap<>();
    // Releases for which a fresh scan was requested while one was already running,
    // so we re-scan immediately when the in-flight one finishes (reliable Refresh).
    private final java.util.Set<String> rescanRequested = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final ExecutorService pool = Executors.newFixedThreadPool(6);

    /** How long a cached scan is considered fresh (ms). Default 10 min. */
    private final long ttlMs;

    /**
     * When false (default), a stale cache is NOT auto-refreshed in the background —
     * the data only refreshes when the user clicks Refresh (or switches release with
     * no cache). Set cockpit.scheduler.auto-rescan-enabled=true to restore automatic
     * background refresh on staleness.
     */
    private final boolean autoRescanEnabled;

    public ScanService(ReleaseDataConnector connector,
                       @org.springframework.beans.factory.annotation.Value("${cockpit.scheduler.cache-ttl-ms:600000}") long ttlMs,
                       @org.springframework.beans.factory.annotation.Value("${cockpit.scheduler.auto-rescan-enabled:false}") boolean autoRescanEnabled) {
        this.connector = connector;
        this.ttlMs = ttlMs;
        this.autoRescanEnabled = autoRescanEnabled;
    }

    /**
     * Returns cached subjects immediately. If nothing is cached yet, kicks off a
     * background scan and returns an empty list (UI shows a loader). If the cache is
     * stale AND auto-rescan is enabled, refreshes in the background; otherwise the
     * stale data is returned as-is until the user refreshes.
     */
    public List<Subject> getSubjects(String releaseName) {
        ScanState st = cache.get(releaseName);
        if (st == null) {
            triggerScan(releaseName);
            return List.of();
        }
        if (autoRescanEnabled && isStale(st)) triggerScan(releaseName);
        return st.subjects();
    }

    /** Cached state for the UI (last/next check, scanning flag). */
    public ScanState state(String releaseName) {
        ScanState st = cache.get(releaseName);
        if (st == null) {
            return new ScanState(List.of(), null, null, Boolean.TRUE.equals(inFlight.get(releaseName)));
        }
        return st;
    }

    /** Force a background refresh (e.g. the Refresh button). If a scan is already
     *  running, queue a fresh one to start the moment it finishes — so Refresh
     *  always ends with up-to-date data instead of silently no-op'ing. */
    public void refresh(String releaseName) {
        cache.remove(releaseName);
        if (Boolean.TRUE.equals(inFlight.get(releaseName))) {
            rescanRequested.add(releaseName);   // will re-scan when the current one ends
        } else {
            triggerScan(releaseName);
        }
    }

    /** Re-scan a single subject only (used by Check config when one changes). */
    public void rescanSubject(String releaseName, String subjectKey) {
        // The connector scans per release; re-scan the release in the background
        // but only if not already running. (A true single-subject API would need
        // connector support; this keeps it cheap by reusing the in-flight guard.)
        triggerScan(releaseName);
    }

    /**
     * Synchronously refresh ONE subject via the connector's single-subject path and
     * splice the fresh row back into the cached scan state. Returns the fresh subject
     * (or null if not found). Does NOT clear the whole release cache, so other rows
     * and the dashboard stay intact.
     */
    public Subject refreshOneSubject(String releaseName, String subjectKey) {
        Subject fresh = connector.refreshSubject(releaseName, subjectKey);
        if (fresh == null) return null;
        ScanState st = cache.get(releaseName);
        List<Subject> current = st == null ? new java.util.ArrayList<>() : new java.util.ArrayList<>(st.subjects());
        boolean replaced = false;
        for (int i = 0; i < current.size(); i++) {
            if (current.get(i).key().equalsIgnoreCase(subjectKey)) { current.set(i, fresh); replaced = true; break; }
        }
        if (!replaced) current.add(fresh);
        cache.put(releaseName, new ScanState(current,
                st == null ? java.time.Instant.now() : st.lastChecked(),
                st == null ? null : st.nextCheck(),
                st != null && st.scanning()));
        return fresh;
    }

    private boolean isStale(ScanState st) {
        return st.lastChecked() == null
                || st.lastChecked().plusMillis(ttlMs).isBefore(Instant.now());
    }

    private void triggerScan(String releaseName) {
        if (inFlight.putIfAbsent(releaseName, Boolean.TRUE) != null) {
            return; // a scan for this release is already running
        }
        // mark scanning in the visible state
        ScanState prev = cache.get(releaseName);
        cache.put(releaseName, new ScanState(
                prev == null ? List.of() : prev.subjects(),
                prev == null ? null : prev.lastChecked(),
                prev == null ? null : prev.nextCheck(), true));
        pool.submit(() -> {
            long t0 = System.currentTimeMillis();
            try {
                List<Subject> subjects = connector.listSubjects(releaseName);
                Instant now = Instant.now();
                cache.put(releaseName, new ScanState(subjects, now, now.plusMillis(ttlMs), false));
                log.info("Scan {} complete: {} subjects in {} ms",
                        releaseName, subjects.size(), System.currentTimeMillis() - t0);
            } catch (Exception e) {
                log.warn("Scan {} failed: {}", releaseName, e.getMessage());
                ScanState p = cache.get(releaseName);
                cache.put(releaseName, new ScanState(
                        p == null ? List.of() : p.subjects(),
                        p == null ? null : p.lastChecked(),
                        p == null ? null : p.nextCheck(), false));
            } finally {
                inFlight.remove(releaseName);
                // If a Refresh came in mid-scan, run a fresh scan now.
                if (rescanRequested.remove(releaseName)) {
                    triggerScan(releaseName);
                }
            }
        });
    }
}
