package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.ArtifactSpec;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts;
    private final com.bnpparibas.releasecockpit.service.SubjectConfigService subjectConfig;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane session cookie (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    // Cache of Octane env buckets per feature path (stable during a scan) and a
    // semaphore that caps concurrent Octane SaaS calls to avoid rate-limiting.
    private final java.util.concurrent.ConcurrentHashMap<String, Map<String, EnvEval>> octaneBucketCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    // Latest-run pass/fail per Octane test id (so historical failures don't mask a
    // green re-run). Null value = undetermined; key present = already queried.
    private final java.util.concurrent.Semaphore octaneGate = new java.util.concurrent.Semaphore(8);
    // Dedicated small pool for the parallel latest-run lookups within a subject.
    private final ExecutorService runPool = Executors.newFixedThreadPool(8);

    // Cache of the raw subfolder list per base folder (e.g. the "Change request"
    // root). Without this, every subject re-lists the same hundreds of folders.
    private final java.util.concurrent.ConcurrentHashMap<String, List<FolderRef>> folderListCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    // Cache of file-name lists per folder (Quality shared folders are listed once
    // per scan instead of once per subject × artifact).
    private final java.util.concurrent.ConcurrentHashMap<String, List<String>> fileListCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    // Set true if any SharePoint call returns 401/403 during a scan, so we can
    // report "unverified (auth expired)" instead of a wall of false "missing".
    private final java.util.concurrent.atomic.AtomicBoolean spAuthFailed
            = new java.util.concurrent.atomic.AtomicBoolean(false);

    public LiveConnector(CockpitProperties props, HttpClientFactory clients,
                         com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts,
                         com.bnpparibas.releasecockpit.service.SubjectConfigService subjectConfig) {
        this.props = props;
        this.clients = clients;
        this.artifacts = artifacts;
        this.subjectConfig = subjectConfig;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira base-url not configured; returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();

        // 1) Explicit release names take priority (no project lookup needed).
        if (!isBlank(j.getReleaseNames())) {
            for (String name : j.getReleaseNames().split(",")) {
                name = name.trim();
                if (!name.isEmpty()) out.add(new Release(name, name, null, false, ""));
            }
            log.info("Using {} explicit release name(s) from config.", out.size());
            return out;
        }

        // 2) Otherwise scan project fixVersions.
        if (isBlank(j.getProjectKeys())) {
            log.warn("Neither release-names nor project-keys set; no releases. "
                    + "Set cockpit.jira.release-names (e.g. 25.07,25.08) or project-keys.");
            return List.of();
        }
        for (String project : j.getProjectKeys().split(",")) {
            project = project.trim();
            if (project.isEmpty()) continue;
            // Jira DC: project key is case-sensitive; numeric ids also work.
            String body = getJira("/rest/api/2/project/" + enc(project) + "/versions");
            if (body == null) {
                log.warn("Jira versions for project '{}' returned no body (check the key — "
                        + "it must be the PROJECT KEY, e.g. TCAAS1484, not the name).", project);
                continue;
            }
            try {
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        if (name.isEmpty()) continue;
                        LocalDate date = safeDate(v.path("releaseDate").asText(null));
                        boolean released = v.path("released").asBoolean(false);
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                } else {
                    // Jira returned an error object (e.g. 400) rather than an array.
                    log.warn("Jira versions for '{}' not an array — response: {}", project,
                            body.length() > 300 ? body.substring(0, 300) : body);
                }
            } catch (Exception e) {
                log.warn("Parsing Jira versions for '{}' failed: {}", project, e.getMessage());
            }
        }
        return out;
    }

    /** Single-subject refresh: check just one epic (by key) for the release. */
    @Override
    public Subject refreshSubject(String releaseName, String subjectKey) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) return null;
        try {
            String fields = "summary,status,assignee,reporter,created";
            if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank())
                fields += "," + j.getOctaneLinkField();
            if (j.getOctaneFeatureField() != null && !j.getOctaneFeatureField().isBlank())
                fields += "," + j.getOctaneFeatureField();
            String jql = "key=" + subjectKey;
            String url = "/rest/api/2/search?jql=" + enc(jql) + "&maxResults=1&fields=" + fields;
            String body = getJira(url);
            if (body == null) return null;
            JsonNode issues = mapper.readTree(body).path("issues");
            if (!issues.isArray() || issues.size() == 0) return null;
            JsonNode it = issues.get(0);
            JsonNode f = it.path("fields");
            String key = it.path("key").asText("");
            String issueId = it.path("id").asText("");
            List<String> octaneIds = new ArrayList<>();
            if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank()) {
                String raw = f.path(j.getOctaneLinkField()).asText("");
                for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
            }
            int relYear = releaseYearFor(releaseName);
            List<String> requiredEnvs = requiredOctaneEnvs(releaseName, key);
            OctaneResult octane = checkOctane(key, issueId, requiredEnvs, releaseName);
            Readiness r = buildReadiness(key, octane, relYear, releaseName);
            return new Subject(key, f.path("summary").asText(""), f.path("status").path("name").asText(""),
                    f.path("assignee").path("displayName").asText(""), f.path("assignee").path("emailAddress").asText(""),
                    f.path("reporter").path("displayName").asText(""), f.path("reporter").path("emailAddress").asText(""),
                    safeDate(f.path("created").asText("").replaceAll("T.*", "")), octaneIds, r);
        } catch (Exception e) {
            log.warn("refreshSubject failed for {} in {}: {}", subjectKey, releaseName, e.getMessage());
            return null;
        }
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        // Fresh scan → clear per-scan caches so SharePoint/Octane are re-read.
        folderListCache.clear();
        fileListCache.clear();
        octaneBucketCache.clear();
        latestRunInfoCache.clear();
        runInReleasesCache.clear();
        spAuthFailed.set(false);   // reset per scan; set true if SharePoint 401/403s
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String fields = "summary,status,assignee,reporter,created";
            if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank())
                fields += "," + j.getOctaneLinkField();
            if (j.getOctaneFeatureField() != null && !j.getOctaneFeatureField().isBlank())
                fields += "," + j.getOctaneFeatureField();
            String url = "/rest/api/2/search?jql=" + enc(jql) + "&maxResults=200&fields=" + fields;
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");

            // Parse all issues first (cheap, no network).
            record Raw(String key, String issueId, String summary, String status, String dev, String devEmail,
                       String rep, String repEmail, LocalDate created, List<String> octaneIds) {}
            List<Raw> raws = new ArrayList<>();
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                String issueId = it.path("id").asText("");   // Jira numeric id, e.g. 4048900
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank()) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                raws.add(new Raw(key, issueId, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        f.path("assignee").path("displayName").asText(""),
                        f.path("assignee").path("emailAddress").asText(""),
                        f.path("reporter").path("displayName").asText(""),
                        f.path("reporter").path("emailAddress").asText(""),
                        safeDate(f.path("created").asText("").replaceAll("T.*", "")),
                        octaneIds));
            }

            ExecutorService pool = Executors.newFixedThreadPool(
                    Math.min(10, Math.max(4, raws.size())));
            try {
                final int relYear = releaseYearFor(releaseName);
                List<Future<Subject>> futures = new ArrayList<>();
                for (Raw rw : raws) {
                    futures.add(pool.submit(() -> {
                        List<String> requiredEnvs = requiredOctaneEnvs(releaseName, rw.key());
                        OctaneResult octane = checkOctane(rw.key(), rw.issueId(), requiredEnvs, releaseName);
                        Readiness r = buildReadiness(rw.key(), octane, relYear, releaseName);
                        return new Subject(rw.key(), rw.summary(), rw.status(),
                                rw.dev(), rw.devEmail(), rw.rep(), rw.repEmail(),
                                rw.created(), rw.octaneIds(), r);
                    }));
                }
                for (Future<Subject> fut : futures) {
                    try { out.add(fut.get()); }
                    catch (Exception e) { log.warn("Subject check failed: {}", e.getMessage()); }
                }
            } finally {
                pool.shutdown();
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    /** Builds a SharePoint folder URL for an artifact spec (for detail links). */
    private String spFolderUrl(ArtifactSpec spec, String epicKey, int year) {
        try {
            var sp = props.getSharepoint();
            String base = sp.getBaseUrl() == null ? "" : sp.getBaseUrl();
            if (base.isBlank()) return null;
            // Build the SAME server-relative folder the check actually inspects, so
            // the evidence link opens the real folder instead of 404-ing.
            String y = String.valueOf(year);
            String root = (sp.getRootPath() == null ? "" : sp.getRootPath()).replace("{YEAR}", y);
            String sub = (spec.folder == null ? "" : spec.folder).replace("{YEAR}", y).replace("{EPIC}", epicKey);
            String serverRel = (siteAndLibrary(sp) + "/" + root + "/" + sub).replaceAll("/{2,}", "/");
            // Prefix the scheme+host from the base URL (siteAndLibrary is host-relative).
            String host = base.replaceFirst("(^https?://[^/]+).*", "$1");
            // Encode each path segment but keep the slashes (spaces -> %20, not +).
            StringBuilder enc = new StringBuilder();
            for (String seg : serverRel.split("/")) {
                if (seg.isEmpty()) continue;
                enc.append("/").append(encPath(seg));
            }
            return host + enc;
        } catch (Exception e) { return null; }
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject from artifacts.json. For each enabled
     * SharePoint artifact, resolves its folder, finds files (per goInside rules)
     * and requires minFiles. Per-subject skips are handled in subject-checks.json,
     * not here. The numeric subject id is the trailing number of the epic key.
     */
    private Readiness buildReadiness(String epicKey, OctaneResult octane, int year, String releaseName) {
        boolean octaneOk = octane.ok();
        java.util.Map<String, Boolean> results = new java.util.HashMap<>();
        for (ArtifactSpec spec : artifacts.sharePointArtifacts()) {
            results.put(spec.key, checkSharePointArtifact(epicKey, spec, year));
        }

        // Per-subject SharePoint skips: a skipped artifact is NEVER a gap. Read the
        // subject's check config and force any skipped artifact to "satisfied".
        java.util.Set<String> skip = new java.util.HashSet<>();
        try {
            var cfg = subjectConfig.forSubject(releaseName, epicKey);
            if (cfg != null && cfg.skipSharePoint() != null) {
                for (String s : cfg.skipSharePoint()) if (s != null && !s.isBlank()) skip.add(s.trim());
            }
        } catch (Exception e) {
            log.warn("Could not load skip config for {} in {}: {}", epicKey, releaseName, e.getMessage());
        }
        for (String s : skip) results.put(s, true); // skipped -> treated as present

        // If SharePoint auth is dead (401/403 during the scan), the file lists came
        // back empty for EVERY subject — which would otherwise show as a wall of
        // false "missing". Instead, treat SharePoint artifacts as UNVERIFIED (not a
        // gap) so the readiness isn't wrongly collapsed, and surface one clear note.
        boolean spDown = spAuthFailed.get();
        if (spDown) {
            for (ArtifactSpec spec : artifacts.sharePointArtifacts()) results.put(spec.key, true);
        }

        // Artifacts not enabled are absent from the map and default to satisfied
        // (so a disabled artifact never shows as a gap).
        boolean pr = results.getOrDefault("PR", true);
        boolean prExcel = results.getOrDefault("PR_EXCEL", true);
        boolean est = results.getOrDefault("ESTIMATION_SHEET", true);
        boolean rev = results.getOrDefault("OCTANE_REVIEW_DOC", true);
        boolean exec = results.getOrDefault("OCTANE_EXECUTION_DOC", true);
        boolean unit = results.getOrDefault("UNIT_TEST", true); // disabled by default

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");

        // Per-artifact SharePoint transparency lines (only enabled artifacts).
        // A skipped artifact is shown as "skipped" rather than found/missing.
        List<String> spDetail = new ArrayList<>();
        if (spDown) {
            spDetail.add("SharePoint unreachable (auth expired) — documents not verified this scan");
        }
        for (ArtifactSpec spec : artifacts.sharePointArtifacts()) {
            String folder = spFolderUrl(spec, epicKey, year);
            if (skip.contains(spec.key)) {
                spDetail.add(spec.label + ": skipped");
                continue;
            }
            if (spDown) {
                spDetail.add(spec.label + ": unverified"
                        + (folder != null ? " ||" + folder : ""));
                continue;
            }
            boolean ok = results.getOrDefault(spec.key, true);
            spDetail.add(spec.label + ": " + (ok ? "found" : "missing")
                    + (folder != null ? " ||" + folder : ""));
        }

        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing,
                octane.url(), octane.missingEnvs(),
                octane.totalRuns(), octane.passedRuns(), octane.failedRuns(), octane.envSummary(),
                octane.detail(), spDetail);
    }

    /**
     * Required Octane environments for a subject, from its release-scoped check
     * config: the configured octaneEnvironments (default IST/DEV/UAT), plus BCM
     * when bcmEndToEnd is enabled.
     */
    private List<String> requiredOctaneEnvs(String releaseName, String subjectKey) {
        var cfg = subjectConfig.forSubject(releaseName, subjectKey);
        List<String> envs = new ArrayList<>();
        if (cfg != null && cfg.octaneEnvironments() != null) {
            for (String e : cfg.octaneEnvironments()) if (e != null && !e.isBlank()) envs.add(e.trim().toUpperCase());
        }
        if (cfg != null && cfg.bcmEndToEnd() && !envs.contains("BCM")) envs.add("BCM");
        return envs;
    }

    /** Numeric subject id = trailing digits of the epic key (TCAAS1484-4971 -> 4971). */
    private String subjectIdOf(String epicKey) {
        var m = java.util.regex.Pattern.compile("(\\d+)$").matcher(epicKey);
        return m.find() ? m.group(1) : epicKey;
    }

    /** Year used for {YEAR} substitution — from the release's date, else current year. */
    private int releaseYearFor(String releaseName) {
        try {
            for (Release r : listReleases()) {
                if (r.name().equals(releaseName) && r.releaseDate() != null) {
                    return r.releaseDate().getYear();
                }
            }
        } catch (Exception ignore) { }
        return java.time.Year.now().getValue();
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    /**
     * Octane coverage for a Jira subject, via the Jira octane-coverage REST API:
     *   /rest/octane-coverage/1.0/coverage?project-key=..&issue-key=..&issue-id=..
     *       &workspace-config-id=..&workspace-id=..
     * The response gives totalTestsCount, totalExecutedTestsCount and coverage
     * groups (e.g. Passed count). This runs on the internal Jira client, so no
     * Octane sign-in is needed. Passes when there are tests and (if
     * require-runs-passed) all executed tests passed.
     */
    /** Rich Octane result: overall pass, the test-tab URL, and missing env buckets. */
    private record OctaneResult(boolean ok, String url, List<String> missingEnvs,
                                int totalRuns, int passedRuns, int failedRuns,
                                java.util.Map<String,String> envSummary,
                                List<String> detail) {   // per-test transparency lines
        OctaneResult(boolean ok, String url, List<String> missingEnvs) {
            this(ok, url, missingEnvs, 0, 0, 0, java.util.Map.of(), List.of());
        }
        OctaneResult(boolean ok, String url, List<String> missingEnvs,
                     int totalRuns, int passedRuns, int failedRuns, java.util.Map<String,String> envSummary) {
            this(ok, url, missingEnvs, totalRuns, passedRuns, failedRuns, envSummary, List.of());
        }
    }

    /**
     * Octane coverage for a Jira subject.
     * Step 1 — Jira octane-coverage REST API gives total/executed/passed counts,
     *   plus the Octane feature entity (its path + testTabUrl).
     * Step 2 — Octane tests query (by feature path) buckets tests by test_type
     *   (Unit Test->Dev, Acceptance->UAT, IST->IST, End to End->BCM) so we can
     *   report which REQUIRED environment has no tests.
     * requiredEnvs comes from the subject's check config (default IST/DEV/UAT,
     * plus BCM when bcmEndToEnd is on).
     */
    private OctaneResult checkOctane(String issueKey, String issueId, List<String> requiredEnvs, String releaseName) {
        var o = props.getOctane();
        var j = props.getJira();
        if (isBlank(j.getBaseUrl()) || isBlank(issueId)) {
            log.info("Octane: no Jira base/issue-id for {} — skipping", issueKey);
            return new OctaneResult(false, null, requiredEnvs);
        }
        try {
            String projectKey = firstProjectKey(j.getProjectKeys(), issueKey);
            String path = "/rest/octane-coverage/1.0/coverage"
                    + "?project-key=" + enc(projectKey)
                    + "&issue-key=" + enc(issueKey)
                    + "&issue-id=" + enc(issueId)
                    + (isBlank(o.getWorkspaceConfigId()) ? "" : "&workspace-config-id=" + enc(o.getWorkspaceConfigId()))
                    + (isBlank(o.getWorkspaceId()) ? "" : "&workspace-id=" + enc(o.getWorkspaceId()));
            String body = getJira(path);
            if (body == null) { log.info("Octane coverage {} -> no response", issueKey); return new OctaneResult(false, null, requiredEnvs); }
            JsonNode root = mapper.readTree(body);
            String status = root.path("status").asText("");
            int total = root.path("totalTestsCount").asInt(0);
            int executed = root.path("totalExecutedTestsCount").asInt(0);
            int passed = 0, covFailed = 0, covNeedsAtt = 0;
            StringBuilder covLog = new StringBuilder();
            for (JsonNode grp : root.path("coverageGroups")) {
                JsonNode fields = grp.path("fields");
                String gid = fields.path("id").asText("");
                String gname = fields.path("name").asText("");
                int gcount = fields.path("count").asInt(0);
                covLog.append(gname.isBlank() ? gid : gname).append("=").append(gcount).append(" ");
                if ("run_status_passed".equals(gid) || "Passed".equalsIgnoreCase(gname)) passed += gcount;
                else if ("run_status_failed".equals(gid) || "Failed".equalsIgnoreCase(gname)) covFailed += gcount;
                else if (gid.contains("needs") || gname.toLowerCase().contains("attention")) covNeedsAtt += gcount;
            }
            log.info("Octane coverage {} groups[{}] total={} executed={} passed={} failed={} needsAtt={}",
                    issueKey, covLog.toString().trim(), total, executed, passed, covFailed, covNeedsAtt);
            JsonNode entity = root.path("octaneEntity").path("fields");
            String testTabUrl = entity.path("testTabUrl").asText(entity.path("url").asText(null));
            String featurePath = entity.path("path").asText("");

            boolean hasTests = total > 0 && !"noData".equalsIgnoreCase(status);
            // Coverage API is the authoritative, release-scoped run signal.
            // "All passed" = something executed and NOTHING actually failed
            // (needsAttention is not a failure).
            boolean coverageRan = executed > 0;
            boolean coverageAllPassed = executed > 0 && covFailed == 0;

            Map<String, EnvEval> eval = (!featurePath.isBlank())
                    ? octaneEnvEval(featurePath, releaseName) : Map.of();

            // Per-env presence (one tests call). The pass/fail/attention verdict
            // comes from the coverage API totals below, not per-test parsing.
            List<String> missingEnvs = new ArrayList<>();

            // Coverage-level verdict (authoritative, release-scoped). The coverage
            // counts are LIFETIME within the release, so a test that failed once and
            // later passed still shows here as failed. We resolve that below.
            String coverageState;   // PASSED | FAILED | NEEDS_ATTENTION | NO_RUN
            if (!coverageRan) coverageState = "NO_RUN";
            else if (covFailed > 0) coverageState = "FAILED";
            else if (covNeedsAtt > 0) coverageState = "NEEDS_ATTENTION";
            else coverageState = "PASSED";

            // CUSTOM RULE — mixed runs: when coverage shows some passes AND some
            // failures/attention, the lifetime counts are ambiguous. Only then do we
            // call the runs API (per test) to check each test's LATEST run. If every
            // test's latest run passed, the subject is actually green. This is the
            // ONLY place the runs API is used, so the scan stays fast.
            boolean mixed = coverageRan && passed > 0 && (covFailed > 0 || covNeedsAtt > 0);
            int liveFailed = covFailed, liveNeedsAtt = covNeedsAtt;
            java.util.Map<String, RunInfo> runByTest = new java.util.LinkedHashMap<>();
            String flipNote = null;

            // ============================================================
            // RELEASE-SCOPED VERDICT — authoritative when release-assignment
            // checking is on. The Jira coverage counts are NOT filtered to the exact
            // release, so they can report "passed" from runs that happened in OTHER
            // releases (R6, X8, …). Per your rule, a subject is ready for THIS exact
            // release only when: (1) at least one test is TAGGED to it, (2) EVERY
            // tagged test has actually been RUN in it, and (3) every such test's
            // LATEST run in it PASSED with no error. We compute that here and it
            // overrides the coverage verdict.
            // ============================================================
            String matchRelExact = (o.getReleaseName() != null && !o.getReleaseName().isBlank())
                    ? o.getReleaseName() : releaseName;
            boolean releaseScoped = o.isCheckReleaseAssignment() && !featurePath.isBlank() && !eval.isEmpty();
            if (releaseScoped) {
                java.util.LinkedHashSet<String> inRelIds = new java.util.LinkedHashSet<>();
                for (EnvEval e : eval.values())
                    if (e.inReleaseTestIds() != null) inRelIds.addAll(e.inReleaseTestIds());

                if (inRelIds.isEmpty()) {
                    // Nothing tagged to this exact release -> cannot be "passed" for it.
                    coverageState = "NO_RELEASE";
                    log.info("  Octane {} release-scoped: NO test tagged to '{}' -> NO_RELEASE",
                            issueKey, matchRelExact);
                } else {
                    // ONE batched runs query for all in-release tests (fast path).
                    java.util.Map<String, RunInfo> batch = latestRunsBatch(inRelIds, matchRelExact);
                    int f = 0, na = 0, p = 0, noRun = 0, unknown = 0;
                    for (String tid : inRelIds) {
                        RunInfo ri = batch.get(tid);
                        if (ri == null) ri = latestRun(tid, matchRelExact); // fallback for misses
                        runByTest.put(tid, ri);
                        switch (ri.state()) {
                            case "FAILED" -> f++;
                            case "NEEDS_ATTENTION" -> na++;
                            case "PASSED" -> p++;
                            case "NO_RUN" -> noRun++;
                            default -> unknown++;
                        }
                    }
                    // Ready ONLY when every tagged test ran in this release and passed.
                    String scoped;
                    if (f > 0) scoped = "FAILED";
                    else if (noRun > 0) scoped = "NOT_RUN";              // tagged but not run here
                    else if (na > 0) scoped = "NEEDS_ATTENTION";
                    else if (unknown > 0) scoped = "NEEDS_ATTENTION";   // unresolved -> stay safe
                    else scoped = "PASSED";
                    coverageState = scoped;
                    liveFailed = f; liveNeedsAtt = na;
                    log.info("  Octane {} release-scoped '{}': tagged={} passed={} failed={} needsAtt={} notRun={} unknown={} => {}",
                            issueKey, matchRelExact, inRelIds.size(), p, f, na, noRun, unknown, scoped);
                }
            }

            if (!releaseScoped && mixed && !featurePath.isBlank() && !eval.isEmpty()) {
                var oc2 = props.getOctane();
                String matchRel = (oc2.getReleaseName() != null && !oc2.getReleaseName().isBlank())
                        ? oc2.getReleaseName() : releaseName;
                java.util.LinkedHashSet<String> testIds = new java.util.LinkedHashSet<>();
                for (EnvEval e : eval.values()) if (e.testIds() != null) testIds.addAll(e.testIds());

                // Query each test's latest run IN PARALLEL (cheap limit=1, cached).
                java.util.Map<String, Future<RunInfo>> futs = new java.util.LinkedHashMap<>();
                for (String tid : testIds) futs.put(tid, runPool.submit(() -> latestRun(tid, matchRel)));
                int f = 0, na = 0, p = 0, unknown = 0;
                for (var en : futs.entrySet()) {
                    RunInfo latest;
                    try { latest = en.getValue().get(); }
                    catch (Exception ex) { latest = new RunInfo("UNKNOWN", null); }
                    runByTest.put(en.getKey(), latest);
                    switch (latest.state()) {
                        case "FAILED" -> f++;
                        case "NEEDS_ATTENTION" -> na++;
                        case "PASSED" -> p++;
                        default -> unknown++;
                    }
                }
                // Resolve the verdict from the latest runs, but stay SAFE when some
                // tests couldn't be resolved (UNKNOWN): we must not claim "passed"
                // while an unresolved test might be failing / needing attention.
                if (p + f + na > 0) {
                    String newState;
                    if (f > 0) {
                        newState = "FAILED";
                    } else if (na > 0) {
                        newState = "NEEDS_ATTENTION";
                    } else if (unknown > 0) {
                        // Some tests unresolved — keep coverage's (worse) verdict
                        // rather than upgrading to PASSED and hiding a problem.
                        newState = "FAILED".equals(coverageState) ? "FAILED"
                                : ("NEEDS_ATTENTION".equals(coverageState) ? "NEEDS_ATTENTION" : "PASSED");
                        log.info("  Octane {} MIXED has {} unresolved run(s) -> keeping coverage verdict {}",
                                issueKey, unknown, coverageState);
                    } else {
                        newState = "PASSED";   // every test resolved and passed
                    }
                    liveFailed = f; liveNeedsAtt = Math.max(na, "NEEDS_ATTENTION".equals(newState) && na == 0 ? covNeedsAtt : na);
                    if (!newState.equals(coverageState) && (f > 0 || na > 0 || unknown == 0)) {
                        flipNote = "Latest run per test overrides the lifetime coverage counts: "
                                + "coverage showed " + covFailed + " failed / " + covNeedsAtt + " needs-attention over time, "
                                + "but the most recent run of each test is now "
                                + p + " passed / " + f + " failed / " + na + " needs-attention"
                                + (unknown > 0 ? " (" + unknown + " unresolved)" : "")
                                + " → " + newState.toLowerCase().replace("_", " ") + ".";
                    }
                    coverageState = newState;
                    log.info("  Octane {} MIXED coverage(f={} na={}) -> latest-run resolve: passed={} failed={} needsAtt={} unknown={} => {}",
                            issueKey, covFailed, covNeedsAtt, p, f, na, unknown, coverageState);
                }
            }

            // Per-env test presence check (missing test cases block).
            if (requiredEnvs != null && !requiredEnvs.isEmpty() && !featurePath.isBlank()) {
                for (String envRaw : requiredEnvs) {
                    String env = envRaw.toUpperCase();
                    EnvEval e = eval.get(env);
                    if (e == null || !e.hasTest()) { missingEnvs.add(env + " (no test)"); continue; }
                    if (o.isCheckReleaseAssignment()) {
                        // run_in_releases IS returned by the /tests API (a plain
                        // string like "STS-2026-X5"). If a test isn't tagged to this
                        // release — either tagged to a different one, or not tagged at
                        // all — flag it as a NON-BLOCKING warning (needs attention),
                        // so it shows yellow and is always mailed, but doesn't fail
                        // the subject outright.
                        if (e.releaseTagged() && !e.inRelease()) {
                            missingEnvs.add(env + " (release not tagged properly - needs attention)");
                        } else if (!e.releaseTagged()) {
                            missingEnvs.add(env + " (release not tagged - needs attention)");
                        }
                    }
                }
            }

            // Apply the (possibly runs-resolved) verdict as a subject-level flag.
            if ("FAILED".equals(coverageState)) {
                missingEnvs.add("Runs failed (" + liveFailed + " of " + executed + ")");
            } else if ("NOT_RUN".equals(coverageState)) {
                missingEnvs.add("Tagged tests not run in release " + matchRelExact);
            } else if ("NO_RELEASE".equals(coverageState)) {
                missingEnvs.add("No test tagged to release " + matchRelExact);
            } else if ("NEEDS_ATTENTION".equals(coverageState)) {
                // Report the ENVIRONMENTS that need attention (not a test count), so
                // the message matches the per-env marks the user sees. An env needs
                // attention if any of its tests' latest run resolved to NEEDS_ATTENTION.
                java.util.List<String> naEnvs = new ArrayList<>();
                for (String env : java.util.List.of("DEV", "IST", "UAT", "BCM")) {
                    EnvEval e = eval.get(env);
                    if (e == null || e.testIds() == null || runByTest.isEmpty()) continue;
                    boolean na = false;
                    for (String id : e.testIds()) {
                        RunInfo ri = runByTest.get(id);
                        if (ri != null && "NEEDS_ATTENTION".equals(ri.state())) { na = true; break; }
                    }
                    if (na) naEnvs.add(env);
                }
                if (!naEnvs.isEmpty()) {
                    missingEnvs.add("Needs attention in " + naEnvs.size() + " environment"
                            + (naEnvs.size() == 1 ? "" : "s") + ": " + String.join(", ", naEnvs));
                } else {
                    missingEnvs.add("Needs attention");
                }
            } else if ("NO_RUN".equals(coverageState) && hasTests) {
                missingEnvs.add("Not run yet (0 of " + total + " executed)");
            }
            if (requiredEnvs != null && !requiredEnvs.isEmpty() && featurePath.isBlank() && hasTests) {
                missingEnvs.add("Cannot verify test envs (no feature path)");
            }

            // Per-env summary. When we resolved latest runs per test (mixed case),
            // reflect EACH env's own worst state; otherwise fall back to the overall
            // coverage state for the env.
            java.util.Map<String,String> envSummary = new java.util.LinkedHashMap<>();
            for (String env : java.util.List.of("DEV", "IST", "UAT", "BCM")) {
                EnvEval e = eval.get(env);
                if (e == null) continue;
                int tc = e.testCount();
                String envState = coverageState;   // default
                // Release-assignment issues are warnings (yellow), not hard failures.
                boolean noRelease = o.isCheckReleaseAssignment() && e.hasTest() && !e.releaseTagged();
                boolean wrongRelease = o.isCheckReleaseAssignment() && e.releaseTagged() && !e.inRelease();
                if (!runByTest.isEmpty() && e.testIds() != null) {
                    boolean anyFail = false, anyAtt = false, anyPass = false, anyKnown = false;
                    for (String id : e.testIds()) {
                        RunInfo ri = runByTest.get(id);
                        if (ri == null) continue;
                        switch (ri.state()) {
                            case "FAILED" -> { anyFail = true; anyKnown = true; }
                            case "NEEDS_ATTENTION" -> { anyAtt = true; anyKnown = true; }
                            case "PASSED" -> { anyPass = true; anyKnown = true; }
                            default -> {}
                        }
                    }
                    if (anyKnown) envState = anyFail ? "FAILED" : (anyAtt ? "NEEDS_ATTENTION" : (anyPass ? "PASSED" : coverageState));
                }
                String mark;
                if (wrongRelease) mark = tc + " \u26A0 wrong rel";
                else if (noRelease) mark = tc + " \u26A0 no release";
                else mark = switch (envState) {
                    case "FAILED" -> tc + " \u2717";
                    case "NEEDS_ATTENTION" -> tc + " \u26A0";
                    case "PASSED" -> tc + " \u2713";
                    case "NOT_RUN" -> tc + " \u2717 not run";
                    case "NO_RELEASE" -> tc + " \u2717 no rel";
                    default -> tc + " (no run)";
                };
                envSummary.put(env, mark);
            }

            // Overall "see all runs" link for this feature.
            String testsUrl = testTabUrl;

            String verdictWord = switch (coverageState) {
                case "FAILED" -> "failed"; case "NEEDS_ATTENTION" -> "needs attention";
                case "PASSED" -> "passed";
                case "NOT_RUN" -> "not run in this release";
                case "NO_RELEASE" -> "not tagged to this release";
                default -> "no run";
            };

            // Transparent detail. Line format the UI understands:
            //   "<text> ||<url>"  -> text with a trailing Octane link
            //   colour is derived from keywords (passed/failed/needs attention).
            java.util.List<String> detail = new ArrayList<>();
            // 1) Overall feature result + link to see ALL runs.
            detail.add("Overall Octane result: " + verdictWord
                    + (testsUrl != null ? " ||" + testsUrl : ""));
            // 2) If a mixed case flipped to green because the latest run passed, say so.
            if (flipNote != null) detail.add(flipNote);
            // 3) Per-env, per-test lines with the test's own status + link.
            for (String env : java.util.List.of("DEV", "IST", "UAT", "BCM")) {
                EnvEval e = eval.get(env);
                if (e == null) continue;
                java.util.List<String> names = e.testNames();
                java.util.List<String> ids = e.testIds();
                for (int i = 0; i < names.size(); i++) {
                    String id = (ids != null && i < ids.size()) ? ids.get(i) : "";
                    RunInfo ri = runByTest.get(id);
                    String statusTxt;
                    String linkUrl;
                    if (ri != null && !"UNKNOWN".equals(ri.state())) {
                        statusTxt = ri.state().toLowerCase().replace("_", " ");
                        linkUrl = ri.runId() != null ? runUrl(ri.runId()) : testUrl(id); // link to the run itself
                    } else {
                        // Not a mixed/queried test — reflect the overall coverage state.
                        statusTxt = verdictWord;
                        linkUrl = testUrl(id);
                    }
                    detail.add(env + ": " + names.get(i) + " — " + statusTxt
                            + (linkUrl != null ? " ||" + linkUrl : ""));
                }
            }

            int totalRuns = executed, passedRuns = passed, failedRuns = liveFailed;

            boolean hasHardProblem = missingEnvs.stream().anyMatch(m ->
                    !m.toLowerCase().contains("needs attention"));
            boolean ok = hasTests && !hasHardProblem;
            log.info("Octane {} rel={} -> total={} executed={} covPassed={} covFailed={} covNeedsAtt={} state={} mixed={} envs={} problems={} -> {}",
                    issueKey, releaseName, total, executed, passed, covFailed, covNeedsAtt, coverageState, mixed, envSummary, missingEnvs, ok ? "PASS" : "MISSING");
            return new OctaneResult(ok, testTabUrl, missingEnvs, totalRuns, passedRuns, failedRuns, envSummary, detail);
        } catch (Exception e) {
            log.warn("Octane coverage check failed ({}): {}", issueKey, e.getMessage());
            return new OctaneResult(false, null, requiredEnvs);
        }
    }

    /**
     * Extracts release names from an Octane run_in_releases field, which may be:
     * a plain string ("STS-2026-X5"), an object ({name:...}), an array of such
     * objects, or a reference object with a data array. Returns a comma-joined
     * string of all release names found.
     */
    /**
     * Fallback resolver for a single test's run_in_releases, used when the combined
     * list query omitted the field. Fetches GET /tests/{id}?fields=run_in_releases.
     * Cached so repeated scans don't re-fetch.
     */
    private final java.util.concurrent.ConcurrentHashMap<String, String> runInReleasesCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    private String fetchRunInReleases(String testId) {
        String cached = runInReleasesCache.get(testId);
        if (cached != null) return cached;
        try {
            var o = props.getOctane();
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests/" + testId + "?fields=run_in_releases,id";
            HttpResponse<String> r = octaneGet(url);
            if (r == null || r.statusCode() >= 400) { runInReleasesCache.put(testId, ""); return ""; }
            JsonNode body = mapper.readTree(r.body());
            // single-entity endpoints return the object directly (may also wrap in data[0]).
            JsonNode node = body.has("run_in_releases") ? body.path("run_in_releases")
                    : body.path("data").path(0).path("run_in_releases");
            String val = extractReleases(node);
            log.info("  fallback run_in_releases for test {}: '{}'", testId, val);
            runInReleasesCache.put(testId, val == null ? "" : val);
            return val == null ? "" : val;
        } catch (Exception e) {
            log.warn("  fallback run_in_releases fetch failed for {}: {}", testId, e.getMessage());
            runInReleasesCache.put(testId, "");
            return "";
        }
    }

    /** Collects a field-name iterator into a list (for diagnostics). */
    private java.util.List<String> iteratorToList(java.util.Iterator<String> it) {
        java.util.List<String> out = new ArrayList<>();
        while (it != null && it.hasNext()) out.add(it.next());
        return out;
    }

    private String extractReleases(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return "";
        if (node.isTextual()) return node.asText("");
        java.util.List<String> names = new ArrayList<>();
        JsonNode arr = node.isArray() ? node
                : (node.has("data") ? node.path("data") : null);
        if (arr != null && arr.isArray()) {
            for (JsonNode n : arr) {
                if (n.isTextual()) names.add(n.asText(""));
                else if (n.has("name")) names.add(n.path("name").asText(""));
            }
        } else if (node.has("name")) {
            names.add(node.path("name").asText(""));
        } else {
            // Last resort: stringify.
            String s = node.asText("");
            if (!s.isBlank()) names.add(s);
        }
        names.removeIf(String::isBlank);
        return String.join(", ", names);
    }

    /**
     * True only if a run_in_releases value is JUST the "Not Yet Defined"
     * placeholder (with nothing else). Must be checked per-token: a value like
     * "STS - Not Yet Defined, STS-2026-X7" is NOT "not yet defined" — it has a real
     * release (X7) alongside the placeholder.
     */
    private boolean isNotYetDefined(String runInReleases) {
        return !hasRealReleaseTag(runInReleases);
    }

    /** True if run_in_releases contains at least one real release token (i.e. a
     *  non-blank token that isn't the "Not Yet Defined" placeholder). */
    private boolean hasRealReleaseTag(String runInReleases) {
        if (runInReleases == null || runInReleases.isBlank()) return false;
        for (String tok : runInReleases.split("[,;|/]")) {
            String t = tok.trim().toLowerCase();
            if (t.isEmpty()) continue;
            if (t.contains("not yet defined") || t.contains("notyetdefined")) continue;
            return true;   // a genuine release is present
        }
        return false;
    }

    /**
     * EXACT release match. run_in_releases may hold one or several releases
     * (comma/semicolon/pipe separated, e.g. "STS-2026-R6, STS-2026-X8"). A test
     * counts for the target release only when one of those tokens equals it
     * exactly (case-insensitive) — so "STS-2026-X7" never matches "STS-2026-X8",
     * "STS-2026-X70", "STS - Not Yet Defined", or a blank value.
     */
    private boolean releaseMatchesExactly(String runInReleases, String targetRelease) {
        if (runInReleases == null || runInReleases.isBlank()) return false;
        if (targetRelease == null || targetRelease.isBlank()) return false;
        String target = targetRelease.trim();
        for (String tok : runInReleases.split("[,;|/]")) {
            if (tok.trim().equalsIgnoreCase(target)) return true;
        }
        return false;
    }

    /**
     * BATCHED latest-run lookup: fetches the newest run per test for a whole set of
     * tests in ONE /runs query (instead of one call per test), which is the main
     * lever for a fast scan. Runs come back ordered newest-first; we keep the first
     * run seen per test id. Tests with no run in the result are returned as NO_RUN.
     * Any test not resolvable here (e.g. the covered_manual_test edge case) can be
     * back-filled by the per-test latestRun.
     */
    private java.util.Map<String, RunInfo> latestRunsBatch(java.util.Collection<String> testIds, String matchRelease) {
        java.util.Map<String, RunInfo> out = new java.util.LinkedHashMap<>();
        if (testIds == null || testIds.isEmpty()) return out;
        // Serve from cache where possible; only query the misses.
        java.util.List<String> misses = new ArrayList<>();
        for (String id : testIds) {
            RunInfo c = latestRunInfoCache.get(id);
            if (c != null) out.put(id, c); else misses.add(id);
        }
        if (misses.isEmpty()) return out;
        try {
            var o = props.getOctane();
            StringBuilder testClause = new StringBuilder();
            for (String id : misses) {
                if (testClause.length() > 0) testClause.append("||");
                testClause.append("(test={id=").append(id).append("})");
            }
            String base = "((subtype IN 'run_manual','run_automated');(" + testClause + "))";
            String rel = (matchRelease != null && !matchRelease.isBlank())
                    ? "(" + base + ";(release={name='" + matchRelease + "'}))" : base;
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/runs?fields=native_status,id,test&limit=500&offset=0"
                    + "&order_by=-creation_time,id&query=" + enc("\"" + rel + "\"");
            HttpResponse<String> r = octaneGet(url);
            if (r == null || r.statusCode() >= 400) {
                // Batch failed → let the caller fall back to per-test for the misses.
                log.info("  latestRunsBatch HTTP {} for {} tests — will fall back per-test",
                        r == null ? "null" : r.statusCode(), misses.size());
                return out;
            }
            JsonNode data = mapper.readTree(r.body()).path("data");
            if (data.isArray()) {
                for (JsonNode run : data) {
                    String tid = run.path("test").path("id").asText("");
                    if (tid.isEmpty() || out.containsKey(tid)) continue; // first = newest
                    RunInfo ri = new RunInfo(runState(statusText(run)), run.path("id").asText(""));
                    out.put(tid, ri);
                    latestRunInfoCache.put(tid, ri);
                }
            }
            // Any miss with still no run in this release = NO_RUN.
            for (String id : misses) {
                if (!out.containsKey(id)) {
                    RunInfo none = new RunInfo("NO_RUN", null);
                    out.put(id, none);
                    latestRunInfoCache.put(id, none);
                }
            }
            log.info("  latestRunsBatch resolved {} tests in one call (release '{}')", misses.size(), matchRelease);
            return out;
        } catch (Exception e) {
            log.info("latestRunsBatch failed: {} — falling back per-test", e.getMessage());
            return out; // partial; caller fills the rest per-test
        }
    }

    /** Latest-run outcome for a test: PASSED/FAILED/NEEDS_ATTENTION/UNKNOWN + run id. */
    private record RunInfo(String state, String runId) {}
    private final java.util.concurrent.ConcurrentHashMap<String, RunInfo> latestRunInfoCache
            = new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * Queries the runs of a test, ordered newest-first, and returns the LATEST
     * run's state + id (optionally release-scoped). This is the custom rule: out
     * of N runs, the most recent run's outcome is what counts — so a re-run that
     * passed after an earlier failure is treated as passed.
     *
     * Matches the Octane runs API shape: status lives in native_status (a
     * list_node with a logical_name like run_native_status.passed/failed), runs
     * are ordered by -creation_time, and the query covers both the test and its
     * covered_manual_test.
     */
    private RunInfo latestRun(String testId, String matchRelease) {
        if (testId == null || testId.isBlank()) return new RunInfo("UNKNOWN", null);
        RunInfo cached = latestRunInfoCache.get(testId);
        if (cached != null) return cached;
        var o = props.getOctane();
        RunInfo out = new RunInfo("UNKNOWN", null);
        try {
            // Base query — EXACTLY the shape proven to work in your Octane:
            //   ((subtype IN 'run_manual','run_automated');
            //    ((test={(covered_manual_test={id=<id>})})||(test={id=<id>})))
            String base = "((subtype IN 'run_manual','run_automated');"
                    + "((test={(covered_manual_test={id=" + testId + "})})"
                    + "||(test={id=" + testId + "})))";
            // EXACT release only. We do NOT fall back to "newest run in any
            // release" — borrowing a run from R6/X8 was making a subject show
            // "passed" for a release that was never actually run. If there is no
            // run in the target release, the test is NO_RUN for this release.
            String rel = (matchRelease != null && !matchRelease.isBlank())
                    ? "(" + base + ";(release={name='" + matchRelease + "'}))" : base;
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/runs?fields=native_status,id,name&limit=1&offset=0"
                    + "&order_by=-creation_time,id&query=" + enc("\"" + rel + "\"");
            HttpResponse<String> r = octaneGet(url);
            JsonNode data = (r != null && r.statusCode() < 400)
                    ? mapper.readTree(r.body()).path("data") : mapper.createArrayNode();
            if (!data.isArray() || data.size() == 0) {
                // No run in THIS release -> NO_RUN (not "borrow another release").
                log.info("    latestRun test {} -> 0 runs in release '{}' => NO_RUN", testId, matchRelease);
                RunInfo none = new RunInfo("NO_RUN", null);
                latestRunInfoCache.put(testId, none);
                return none;
            }
            JsonNode chosen = data.get(0);
            String st = statusText(chosen);
            String runId = chosen.path("id").asText("");
            out = new RunInfo(runState(st), runId);
            log.info("    latest run for test {} -> state={} runId={} raw_status='{}'", testId, out.state(), runId, st);
            latestRunInfoCache.put(testId, out);
            return out;
        } catch (Exception e) {
            log.info("latestRun({}) failed: {}", testId, e.getMessage());
            latestRunInfoCache.put(testId, out);
            return out;
        }
    }

    /** Builds a UI link to a specific Octane run. */
    private String runUrl(String runId) {
        if (runId == null || runId.isBlank()) return null;
        var o = props.getOctane();
        return o.getBaseUrl() + "/ui/entity-navigation?p=" + o.getSharedSpaceId() + "/" + o.getWorkspaceId()
                + "&entityType=run&id=" + runId;
    }

    /** Builds a UI link to a specific Octane test. */
    private String testUrl(String testId) {
        if (testId == null || testId.isBlank()) return null;
        var o = props.getOctane();
        return o.getBaseUrl() + "/ui/entity-navigation?p=" + o.getSharedSpaceId() + "/" + o.getWorkspaceId()
                + "&entityType=test&id=" + testId;
    }

    private String statusText(JsonNode run) {
        // Prefer native_status (list_node): use its logical_name (stable) then name.
        JsonNode ns = run.path("native_status");
        if (ns.isObject()) {
            String ln = ns.path("logical_name").asText("");
            if (!ln.isBlank()) return ln;          // e.g. list_node.run_native_status.passed
            String nm = ns.path("name").asText("");
            if (!nm.isBlank()) return nm;           // e.g. Passed / Failed / Requires Attention
        } else {
            String nsTxt = ns.asText("");
            if (!nsTxt.isBlank()) return nsTxt;
        }
        JsonNode s = run.path("status");
        if (s.isObject()) return s.path("name").asText(s.path("id").asText(""));
        return s.asText("");
    }

    /** Normalises a run status string to PASSED/FAILED/NEEDS_ATTENTION/UNKNOWN. */
    private String runState(String st) {
        if (st == null) return "UNKNOWN";
        String s = st.toLowerCase().replace("_", " ").replace("-", " ");
        // Requires/Needs Attention — check BEFORE passed/failed because some
        // logical names combine words (e.g. "requires attention").
        if (s.contains("attention") || s.contains("requires") || s.contains("needs")
                || s.contains("warning") || s.contains("unstable")) return "NEEDS_ATTENTION";
        if (s.contains("passed") || s.contains("success")) return "PASSED";
        if (s.contains("failed") || s.contains("failure") || s.contains("error")) return "FAILED";
        return "UNKNOWN";
    }

    /** test_type.name -> our environment bucket (config-driven with defaults). */
    private String envForTestType(String testTypeName) {
        if (testTypeName == null) return null;
        String raw = testTypeName.trim();
        var map = props.getOctane().getTestTypeEnvMap();
        // Config map first (case-insensitive lookup).
        if (map != null && !map.isEmpty()) {
            for (var e : map.entrySet()) {
                if (e.getKey() != null && e.getKey().equalsIgnoreCase(raw))
                    return e.getValue() == null ? null : e.getValue().trim().toUpperCase();
            }
        }
        // Built-in defaults: IST=IST, Unit Test=DEV, Acceptance=UAT, End to End=BCM.
        return switch (raw.toLowerCase()) {
            case "unit test" -> "DEV";
            case "acceptance" -> "UAT";
            case "end to end" -> "BCM";
            case "ist" -> "IST";
            default -> null;
        };
    }

    /**
     * Per-env evaluation. releaseTagged distinguishes "tagged to a different
     * release" (wrong release) from "not tagged at all" (run_in_releases empty),
     * which is common — the release lives on the run, not always on the test.
     */
    /**
     * Per-env test presence. The pass/fail/needs-attention verdict comes from the
     * (release-scoped, authoritative) coverage API totals — NOT from parsing each
     * test's unreliable test_status. This keeps the scan to one tests call per
     * subject and no per-run calls.
     */
    private record EnvEval(boolean hasTest, boolean inRelease, boolean releaseTagged,
                           int testCount, java.util.List<String> testNames,
                           java.util.List<String> testIds,
                           java.util.List<String> inReleaseTestIds) {}

    /**
     * Queries Octane tests covering a feature path and evaluates, per env bucket,
     * whether there is a test, whether it is assigned to the queried release, and
     * whether the last run passed / ran at all. Uses the Octane SaaS API. Fails
     * soft (empty map) so a query failure never fabricates gaps.
     */
    private Map<String, EnvEval> octaneEnvEval(String featurePath, String releaseName) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl()) || isBlank(o.getSharedSpaceId()) || isBlank(o.getWorkspaceId()))
            return Map.of();
        Map<String, EnvEval> cached = octaneBucketCache.get(featurePath);
        if (cached != null) return cached;

        Map<String, EnvEval> result = new java.util.HashMap<>();
        boolean acquired = false;
        try {
            acquired = octaneGate.tryAcquire(30, java.util.concurrent.TimeUnit.SECONDS);
            if (!acquired) { log.warn("Octane gate timeout for path {}", featurePath); return result; }

            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return result;
            // Robust match: try exact path first; Octane's path query is sensitive
            // to trailing separators, so match both the exact path and its subtree.
            String query = "\"((covered_content={(path='" + featurePath + "*')}))\"";
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests?fields=test_type,name,run_in_releases,id&limit=500&query=" + enc(query);
            log.info("Octane tests URL: {}", url);
            HttpResponse<String> r = octaneGet(url);   // retry/backoff + 401 re-auth handled inside
            if (r == null || r.statusCode() >= 400) {
                log.info("Octane tests query HTTP {} (path={})", r == null ? "null" : r.statusCode(), featurePath);
                return result;
            }
            var oc = props.getOctane();
            String matchRelease = (oc.getReleaseName() != null && !oc.getReleaseName().isBlank())
                    ? oc.getReleaseName() : releaseName;

            JsonNode root = mapper.readTree(r.body());
            JsonNode data = root.path("data");
            int count = data.isArray() ? data.size() : 0;
            log.info("Octane feature path='{}' rel(match)='{}' -> {} test(s)", featurePath, matchRelease, count);
            // DEFINITIVE DIAGNOSTIC: log the full first test object exactly as Octane
            // returned it, so we can see which fields are actually present. This tells
            // us whether run_in_releases is being dropped (server-side) or mis-parsed.
            if (count > 0 && log.isInfoEnabled()) {
                log.info("  Octane FIRST test object (raw): {}", data.get(0).toString());
                log.info("  Octane response field keys on first test: {}",
                        iteratorToList(data.get(0).fieldNames()));
            }
            if (data.isArray()) for (JsonNode t : data) {
                String testId = t.path("id").asText("");
                String testName = t.path("name").asText("");
                String runInReleases = extractReleases(t.path("run_in_releases"));
                // Fallback: if run_in_releases wasn't returned in the combined query
                // (some tenants omit it there), fetch it for this single test. This
                // guarantees correct release tagging regardless of the list-query
                // behaviour. Only triggers when the field is actually absent.
                if ((runInReleases == null || runInReleases.isBlank())
                        && t.path("run_in_releases").isMissingNode()
                        && !testId.isBlank()) {
                    runInReleases = fetchRunInReleases(testId);
                }
                boolean releaseTagged = hasRealReleaseTag(runInReleases);
                boolean inRelease;
                if (!oc.isCheckReleaseAssignment()) {
                    inRelease = true;
                } else {
                    // EXACT release only: a test counts for THIS release solely when
                    // run_in_releases contains the selected release as an exact token.
                    // Untagged tests, "Not Yet Defined", and other releases (R6, X8…)
                    // do NOT count toward this release's status.
                    inRelease = releaseMatchesExactly(runInReleases, matchRelease);
                }

                // Bucket this test into every env its test_type maps to.
                List<String> testEnvs = new ArrayList<>();
                for (JsonNode tt : t.path("test_type").path("data")) {
                    String typeName = tt.path("name").asText("");
                    String env = envForTestType(typeName);
                    if (env == null) continue;
                    testEnvs.add(env);
                    EnvEval prev = result.get(env);
                    boolean ir = inRelease || (prev != null && prev.inRelease());
                    boolean rt = releaseTagged || (prev != null && prev.releaseTagged());
                    int tc = 1 + (prev != null ? prev.testCount() : 0);
                    java.util.List<String> names = new ArrayList<>(prev != null ? prev.testNames() : java.util.List.of());
                    names.add(testName);
                    java.util.List<String> ids = new ArrayList<>(prev != null ? prev.testIds() : java.util.List.of());
                    if (!testId.isBlank()) ids.add(testId);
                    java.util.List<String> inRelIds = new ArrayList<>(prev != null ? prev.inReleaseTestIds() : java.util.List.of());
                    if (inRelease && !testId.isBlank()) inRelIds.add(testId);
                    result.put(env, new EnvEval(true, ir, rt, tc, names, ids, inRelIds));
                }
                log.info("  Octane test id={} '{}' types={} runIn='{}' releaseTagged={} inRelease={}",
                        testId, testName, testEnvs, runInReleases, releaseTagged, inRelease);
            }
            log.info("Octane env eval path='{}' -> {}", featurePath,
                    result.keySet());
            octaneBucketCache.put(featurePath, result);
            return result;
        } catch (Exception e) {
            log.warn("Octane tests query failed ({}): {}", featurePath, e.getMessage());
            return result;
        } finally {
            if (acquired) octaneGate.release();
        }
    }

    /** Clears per-scan Octane caches so a manual refresh re-queries Octane. */
    public void clearOctaneCache() { octaneBucketCache.clear(); latestRunInfoCache.clear(); }

    private synchronized void octaneSignIn() {
        // Guard: if another thread already refreshed the cookie while we waited on
        // the lock, don't sign in again.
        if (octaneCookie != null) return;
        var o = props.getOctane();
        String payload = "{\"client_id\":\"" + o.getClientId()
                + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
        // Retry sign-in a few times with backoff: on a release switch several
        // threads may race to re-auth and the SaaS endpoint can transiently 429/503.
        int attempts = 3;
        for (int i = 1; i <= attempts && octaneCookie == null; i++) {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                        .header("Content-Type", "application/json")
                        .timeout(Duration.ofSeconds(15))
                        .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
                HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() < 400) {
                    String cookie = r.headers().allValues("set-cookie").stream()
                            .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                            .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                    octaneCookie = cookie;
                    log.info("Octane sign-in {} (attempt {})", cookie != null ? "OK" : "returned no cookie", i);
                    if (cookie != null) return;
                } else {
                    log.warn("Octane sign-in HTTP {} (attempt {}/{})", r.statusCode(), i, attempts);
                }
            } catch (Exception e) {
                log.warn("Octane sign-in attempt {}/{} failed: {}", i, attempts, e.getMessage());
            }
            if (octaneCookie == null && i < attempts) {
                try { Thread.sleep(400L * i + (long) (Math.random() * 200)); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); return; }
            }
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            var octaneCfg = props.getOctane();
            String clientType = octaneCfg.getClientType() == null || octaneCfg.getClientType().isBlank()
                    ? "HPE_MQM_UI" : octaneCfg.getClientType();
            java.util.function.Function<String, HttpRequest> build = cookie -> HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", cookie == null ? "" : cookie)
                    .header("Accept", "application/json")
                    // Octane's REST API runs in a restricted mode without a client-type
                    // header and SILENTLY OMITS aggregate/reference fields such as
                    // run_in_releases — even when they're listed in fields=. The browser
                    // sends this implicitly; we must send it explicitly so the field
                    // comes back. (This is the fix for "run_in_releases present in the
                    // browser but missing from the API JSON".)
                    .header("HPECLIENTTYPE", clientType)
                    .timeout(Duration.ofSeconds(20)).GET().build();
            HttpRequest req = build.apply(octaneCookie);
            // On 401, re-sign-in and rebuild the request with the fresh cookie.
            // Thread-safe: capture the cookie we used; only invalidate+resign if it
            // hasn't already been refreshed by another thread.
            java.util.function.Supplier<HttpRequest> reAuth = () -> {
                synchronized (this) {
                    String usedCookie = req.headers().firstValue("Cookie").orElse(null);
                    if (octaneCookie != null && !octaneCookie.equals(usedCookie)) {
                        // Another thread already refreshed — just use the new cookie.
                        return build.apply(octaneCookie);
                    }
                    octaneCookie = null;
                    octaneSignIn();
                    return octaneCookie != null ? build.apply(octaneCookie) : null;
                }
            };
            return sendWithRetry(saas, req, "Octane GET", reAuth);
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** Pick the project key (config first token, else derive from the issue key prefix). */
    private String firstProjectKey(String projectKeys, String issueKey) {
        if (projectKeys != null && !projectKeys.isBlank()) return projectKeys.split(",")[0].trim();
        int dash = issueKey.lastIndexOf('-');
        return dash > 0 ? issueKey.substring(0, dash) : issueKey;
    }

    // ---- SharePoint ----
    // Per-epic cache of the subfolders that contain at least one file, so the
    // listing happens once per epic (not once per artifact). Cleared each scan
    // via the cache TTL on the service layer; here it lives for the connector.

    /**
     * Checks one SharePoint artifact for an epic using its artifacts.json spec.
     *
     * Folder resolution: spec.folder with {YEAR} -> current year and {EPIC} ->
     * epic key, prefixed by the configured root path, under the library. If
     * spec.folder is empty, the epic's own folder under the root is used.
     *
     * Files are listed (recursing into subfolders when goInside=true) and a file
     * matches when its name contains ALL of match.all (after {EPIC} substitution)
     * AND at least one of match.any AND, if extensions is non-empty, ends with one
     * of them. The check passes when at least minFiles files match.
     */
    private boolean checkSharePointArtifact(String epicKey, ArtifactSpec spec, int year) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return false;
        boolean mandatory = spec.mandatory == null || spec.mandatory; // default mandatory
        try {
            String y = String.valueOf(year);
            String root = (sp.getRootPath() == null ? "" : sp.getRootPath()).replace("{YEAR}", y);
            String sub = (spec.folder == null ? "" : spec.folder).replace("{YEAR}", y).replace("{EPIC}", epicKey);

            String subjectId = subjectIdOf(epicKey);
            List<String> anyTokens = (spec.match != null && spec.match.any != null) ? spec.match.any : List.of();
            List<String> exts = (spec.match != null && spec.match.extensions != null) ? spec.match.extensions : List.of();

            List<String> matchingFiles = new ArrayList<>();
            String checkedFolder;

            // The artifact's base folder (full path from site+library).
            String baseRel = (siteAndLibrary(sp) + "/" + root + sub).replaceAll("/{2,}", "/");

            int totalFiles = 0;
            List<String> sampleFiles = new ArrayList<>();
            if (spec.goInside) {
                // CASE A — goInside (PR, ESTIMATION, UNIT_TEST):
                List<FolderRef> subjectFolders = findSubjectFolders(baseRel, subjectId, epicKey);
                checkedFolder = subjectFolders.isEmpty() ? baseRel + "/<no folder matching " + subjectId + ">"
                        : subjectFolders.get(0).serverRel;
                for (FolderRef fr : subjectFolders) {
                    for (String name : listFiles(fr.serverRel, true, 0)) {
                        totalFiles++;
                        if (sampleFiles.size() < 8) sampleFiles.add(name);
                        if (keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                    }
                }
            } else {
                // CASE B — shared folder (PR_EXCEL, TEST CASE, TEST EXEC):
                // The FILE NAME must contain the subject id (or epic key) and the
                // right extension; keywords are a secondary filter (only applied if
                // none of the id-matching files would otherwise qualify).
                checkedFolder = baseRel;
                List<String> idExtMatches = new ArrayList<>();
                List<String> filesInFolder = fileListCache.computeIfAbsent(baseRel, k -> listFiles(k, false, 0));
                for (String name : filesInFolder) {
                    totalFiles++;
                    if (sampleFiles.size() < 8) sampleFiles.add(name);
                    String lower = name.toLowerCase();
                    boolean hasId = lower.contains(subjectId.toLowerCase())
                            || lower.contains(epicKey.toLowerCase());
                    if (!hasId) continue;
                    boolean extOk = exts.isEmpty() || exts.stream().anyMatch(e -> lower.endsWith(e.toLowerCase()));
                    if (!extOk) continue;
                    idExtMatches.add(name);
                    if (keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                }
                // If id+extension matched files but keywords didn't, accept the
                // id+extension matches — the subject id in a Quality folder file is
                // a strong enough signal (filenames vary in keyword wording).
                if (matchingFiles.isEmpty() && !idExtMatches.isEmpty()) {
                    matchingFiles.addAll(idExtMatches);
                }
            }

            boolean ok = matchingFiles.size() >= Math.max(1, spec.minFiles);
            log.info("SharePoint {} [{}] mandatory={} folder='{}' totalFiles={} matched={} {} -> {}",
                    epicKey, spec.key, mandatory, checkedFolder, totalFiles, matchingFiles.size(),
                    matchingFiles.isEmpty() ? ("(files seen: " + sampleFiles + ")") : matchingFiles,
                    ok ? "PASS" : (mandatory ? "MISSING" : "MISSING(optional)"));
            return ok || !mandatory; // non-mandatory never produces a gap
        } catch (Exception e) {
            log.warn("SharePoint check failed ({} {}): {}", epicKey, spec.key, e.getMessage());
            return !mandatory;
        }
    }

    private record FolderRef(String name, String serverRel) {}

    /**
     * Lists subfolders under baseRel and returns those whose name contains the
     * subject id (or the full epic key). These are the per-subject folders.
     */
    private List<FolderRef> findSubjectFolders(String baseRel, String subjectId, String epicKey) {
        // Fetch (and cache) the base folder's subfolder list ONCE per scan, then
        // match the subject id against the cached list — avoids re-listing the
        // same hundreds of change-request folders for every subject.
        List<FolderRef> all = folderListCache.computeIfAbsent(baseRel, this::listSubfolders);
        List<FolderRef> out = new ArrayList<>();
        String keyl = epicKey.toLowerCase();
        java.util.regex.Pattern idPat = java.util.regex.Pattern.compile(
                "(?<![0-9])" + java.util.regex.Pattern.quote(subjectId) + "(?![0-9])");
        for (FolderRef f : all) {
            String nl = f.name().toLowerCase();
            if (nl.contains(keyl) || idPat.matcher(f.name()).find()) out.add(f);
        }
        return out;
    }

    /** Lists all immediate subfolders of a base folder (network call, cached by caller). */
    private List<FolderRef> listSubfolders(String baseRel) {
        List<FolderRef> out = new ArrayList<>();
        var sp = props.getSharepoint();
        try {
            String sub = "Folders?$select=Name,ServerRelativeUrl";
            String url = spFolderApi(sp.getBaseUrl(), baseRel, sub, false);
            HttpResponse<String> r = spGet(url);
            // 404 on the legacy method → retry with the modern GetFolderByServerRelativePath.
            if (r != null && r.statusCode() == 404) {
                log.info("SharePoint Folders 404 (legacy) for '{}' — retrying modern path API", baseRel);
                r = spGet(spFolderApi(sp.getBaseUrl(), baseRel, sub, true));
            }
            if (r == null || r.statusCode() >= 400) {
                if (r != null) {
                    if (r.statusCode() == 401 || r.statusCode() == 403) spAuthFailed.set(true);
                    log.info("SharePoint Folders HTTP {} for '{}' (url={})", r.statusCode(), baseRel, url);
                }
                return out;
            }
            JsonNode root = mapper.readTree(r.body());
            JsonNode folders = root.has("value") ? root.path("value") : root.path("d").path("results");
            if (folders.isArray()) for (JsonNode f : folders) {
                String name = f.path("Name").asText("");
                if ("Forms".equalsIgnoreCase(name)) continue;
                String srv = f.path("ServerRelativeUrl").asText("");
                if (srv.isBlank()) srv = baseRel + "/" + name;
                out.add(new FolderRef(name, srv));
            }
            log.info("Listed {} subfolders under '{}'", out.size(), baseRel);
        } catch (Exception e) {
            log.info("listSubfolders failed ({}): {}", baseRel, e.getMessage());
        }
        return out;
    }

    /** Keyword match: contains one of `any` (if given) and ends with one of `exts` (if given). */
    private boolean keywordMatches(String name, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        if (any != null && !any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** site path + library, e.g. /sites/ITTAADM/Project Documents */
    private String siteAndLibrary(CockpitProperties.SharePoint sp) {
        String sitePath = sp.getBaseUrl().replaceFirst("^https?://[^/]+", "");
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        return (sitePath + "/" + lib).replaceAll("/{2,}", "/");
    }

    /** Lists file names directly in a folder, optionally recursing into subfolders. */
    private List<String> listFiles(String serverRel, boolean recurse, int depth) {
        List<String> names = new ArrayList<>();
        if (depth > 5) return names; // safety bound
        var sp = props.getSharepoint();
        try {
            String url = spFolderApi(sp.getBaseUrl(), serverRel, "Files?$select=Name", false);
            HttpResponse<String> r = spGet(url);
            if (r != null && r.statusCode() == 404) {
                log.info("SharePoint Files 404 (legacy) for '{}' — retrying modern path API", serverRel);
                r = spGet(spFolderApi(sp.getBaseUrl(), serverRel, "Files?$select=Name", true));
            }
            if (r != null && r.statusCode() < 400) {
                JsonNode root = mapper.readTree(r.body());
                JsonNode files = root.has("value") ? root.path("value")
                        : root.path("d").path("results");
                if (files.isArray()) for (JsonNode f : files) names.add(f.path("Name").asText(""));
            } else if (r != null) {
                // Log at INFO so auth/path problems are visible (not hidden at debug).
                boolean authGone = r.statusCode() == 401 || r.statusCode() == 403;
                if (authGone) spAuthFailed.set(true);
                log.info("SharePoint Files HTTP {} for folder '{}' (url={}){}", r.statusCode(), serverRel, url,
                        authGone ? " — cookies likely expired" : "");
            }
            if (recurse) {
                String fsub = "Folders?$select=Name,ServerRelativeUrl";
                HttpResponse<String> fr = spGet(spFolderApi(sp.getBaseUrl(), serverRel, fsub, false));
                if (fr != null && fr.statusCode() == 404) {
                    fr = spGet(spFolderApi(sp.getBaseUrl(), serverRel, fsub, true));
                }
                if (fr != null && fr.statusCode() < 400) {
                    JsonNode froot = mapper.readTree(fr.body());
                    JsonNode folders = froot.has("value") ? froot.path("value")
                            : froot.path("d").path("results");
                    if (folders.isArray()) for (JsonNode sf : folders) {
                        String name = sf.path("Name").asText("");
                        if ("Forms".equalsIgnoreCase(name)) continue; // skip system folder
                        String srv = sf.path("ServerRelativeUrl").asText("");
                        if (srv.isBlank()) srv = serverRel + "/" + name;
                        names.addAll(listFiles(srv, true, depth + 1));
                    }
                } else if (fr != null) {
                    log.info("SharePoint Folders HTTP {} for folder '{}'", fr.statusCode(), serverRel);
                }
            }
        } catch (Exception e) {
            log.info("listFiles error ({}): {}", serverRel, e.getMessage());
        }
        return names;
    }

    /**
     * Builds the SharePoint REST URL to access a folder's sub-resource.
     * `useModernPath=false` uses the legacy GetFolderByServerRelativeUrl('...'),
     * `true` uses the modern GetFolderByServerRelativePath(decodedurl='...') which
     * SharePoint Online prefers (the legacy one can 404 on special characters).
     */
    private String spFolderApi(String baseUrl, String serverRel, String subResource, boolean useModernPath) {
        if (useModernPath) {
            // decodedurl takes the RAW (unencoded) path; quotes doubled per OData.
            String raw = serverRel.replace("'", "''");
            return baseUrl + "/_api/web/GetFolderByServerRelativePath(decodedurl='"
                    + encodeQuoteValue(raw) + "')/" + subResource;
        }
        return baseUrl + "/_api/web/GetFolderByServerRelativeUrl('"
                + encodePath(serverRel) + "')/" + subResource;
    }

    /** Minimal encoding for a decodedurl='...' value (space + a few reserved chars). */
    private String encodeQuoteValue(String s) {
        return s.replace("%", "%25").replace(" ", "%20").replace("#", "%23").replace("&", "%26");
    }

    private HttpResponse<String> spGet(String url) {
        try {
            var sp = props.getSharepoint();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(20)).GET().build();
            return sendWithRetry(saas, req, "SharePoint GET");
        } catch (Exception e) {
            log.debug("SharePoint GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** A file matches when its name contains the Jira id (full key or its number) and (if given) an extension. */
    private boolean fileMatchesId(String name, String epicKey, String idNum, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        boolean hasId = lower.contains(epicKey.toLowerCase()) || lower.contains(idNum.toLowerCase());
        if (!hasId) return false;
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** A file matches if it contains all `all` tokens, one `any` token, and (if given) an extension. */
    private boolean fileMatches(String name, List<String> all, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        for (String a : all) if (!lower.contains(a.toLowerCase())) return false;
        if (!any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (!exts.isEmpty()) {
            boolean ext = false;
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) { ext = true; break; }
            if (!ext) return false;
        }
        return true;
    }

    /** Encode a server-relative path for GetFolderByServerRelativeUrl('...'). */
    private String encodePath(String path) {
        // SharePoint's GetFolderByServerRelativeUrl('...') needs the path
        // percent-encoded for special characters (brackets, parens, #, &, %, etc.)
        // while keeping the slashes. Single quotes are doubled per OData rules.
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '/') { sb.append('/'); continue; }
            if (c == '\'') { sb.append("''"); continue; }
            if (c == ' ') { sb.append("%20"); continue; }
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
                    || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
                sb.append(c);
            } else {
                byte[] bytes = String.valueOf(c).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                for (byte b : bytes) sb.append('%').append(String.format("%02X", b & 0xff));
            }
        }
        return sb.toString();
    }
    /**
     * Sends an HTTP request with retry + exponential backoff on transient
     * failures (429 Too Many Requests, 502/503/504, and IOExceptions). Honors the
     * server's Retry-After header when present. Returns the final response (which
     * may still be an error) or null if all attempts throw.
     *
     * This is the single robust path used by Jira, Octane and SharePoint so all
     * three survive rate-limiting the same way.
     */
    private HttpResponse<String> sendWithRetry(HttpClient client, HttpRequest req, String tag) {
        return sendWithRetry(client, req, tag, null);
    }

    /**
     * Sends with retry + exponential backoff on transient failures (429/502/503/504
     * and IOExceptions). Honors Retry-After.
     *
     * If a reAuth hook is supplied, a 401 triggers a ONE-TIME re-authentication and
     * a rebuild of the request (via reAuth) before retrying — this is what recovers
     * an expired Octane/SharePoint session mid-scan without a backend restart.
     *
     * The JDK HttpClient throws IOException "WWW-Authenticate header missing for
     * response code 401" when a server returns 401 without that header (Octane does
     * this). We detect that message and treat it as a 401 so re-auth kicks in
     * instead of blindly retrying an expired cookie.
     */
    private HttpResponse<String> sendWithRetry(HttpClient client, HttpRequest req, String tag,
                                               java.util.function.Supplier<HttpRequest> reAuth) {
        int maxAttempts = 4;
        long baseMs = 400;
        long maxWaitMs = 2500;   // never sleep longer than this on backoff
        HttpResponse<String> last = null;
        boolean reAuthed = false;
        HttpRequest current = req;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                last = client.send(current, HttpResponse.BodyHandlers.ofString());
                int sc = last.statusCode();
                // 401 -> re-authenticate ONCE, then retry with a fresh request.
                if (sc == 401 && reAuth != null && !reAuthed) {
                    log.info("{} -> 401, re-authenticating session…", tag);
                    HttpRequest rebuilt = reAuth.get();
                    if (rebuilt != null) { current = rebuilt; reAuthed = true; continue; }
                }
                boolean transient_ = sc == 429 || sc == 502 || sc == 503 || sc == 504;
                if (!transient_) return last;
                if (attempt == maxAttempts) { log.warn("{} -> HTTP {} after {} attempts (giving up)", tag, sc, attempt); return last; }
                long waitMs = Math.min(maxWaitMs, retryAfterMs(last).orElse((long) (baseMs * Math.pow(2, attempt - 1)) + (long) (Math.random() * 250)));
                log.info("{} -> HTTP {} (attempt {}/{}), backing off {}ms", tag, sc, attempt, maxAttempts, waitMs);
                Thread.sleep(waitMs);
            } catch (java.io.IOException ioe) {
                String msg = ioe.getMessage() == null ? "" : ioe.getMessage();
                boolean looks401 = msg.contains("401") || msg.toLowerCase().contains("www-authenticate");
                // JDK surfaces some 401s as IOException — recover via re-auth once.
                if (looks401 && reAuth != null && !reAuthed) {
                    log.info("{} -> 401 (as IOException), re-authenticating session…", tag);
                    HttpRequest rebuilt = reAuth.get();
                    if (rebuilt != null) { current = rebuilt; reAuthed = true; continue; }
                }
                // A 401 with no re-auth hook (or re-auth already tried) is NOT worth
                // 5 retries — bail fast so the scan continues.
                if (looks401) { log.warn("{} -> persistent 401: {}", tag, msg); return last; }
                if (attempt == maxAttempts) { log.warn("{} IO failure after {} attempts: {}", tag, attempt, msg); return last; }
                long waitMs = Math.min(maxWaitMs, (long) (baseMs * Math.pow(2, attempt - 1)) + (long) (Math.random() * 250));
                log.info("{} IO error (attempt {}/{}): {} — retrying in {}ms", tag, attempt, maxAttempts, msg, waitMs);
                try { Thread.sleep(waitMs); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); return last; }
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt(); return last;
            }
        }
        return last;
    }

    private java.util.Optional<Long> retryAfterMs(HttpResponse<String> r) {
        return r.headers().firstValue("retry-after").map(v -> {
            try { return Long.parseLong(v.trim()) * 1000; }   // seconds
            catch (NumberFormatException e) { return 2000L; } // HTTP-date -> default 2s
        });
    }

    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(30)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = sendWithRetry(http, b.build(), "Jira " + path);
            if (r == null || r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r == null ? "null" : r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    /**
     * Encodes a URL PATH segment. URLEncoder produces form-encoding where a space
     * becomes '+', which is wrong inside a path and 404s on SharePoint. Paths need
     * '%20' for spaces (and '+' left as a literal), so we fix those up here.
     */
    private String encPath(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8)
                .replace("+", "%20")   // space -> %20 (not +)
                .replace("%2B", "+");  // keep a literal '+' as '+'
    }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
