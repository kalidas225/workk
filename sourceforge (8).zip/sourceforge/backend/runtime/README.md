# Runtime toolchain (company JDK + Artifactory settings)

Drop your company-provided files here. Nothing in this folder is committed with
real secrets — mount it at runtime (Docker volume) so credentials never live in
the source zip. The build runner reads these via configuration.

## 1. Company JDK  ->  runtime/jdk/
Extract your company JDK so that this path exists:
    runtime/jdk/bin/java
    runtime/jdk/bin/javac
    runtime/jdk/lib/security/cacerts   <- already trusts your Artifactory TLS

Then set (or rely on the default if you keep this exact path):
    SOURCEFORGE_JAVA_HOME=/app/runtime/jdk          (in Docker)
    sourceforge.build.java-home=/abs/path/runtime/jdk   (running locally)

Because the build runs with this JDK as JAVA_HOME, Maven/Java use its cacerts,
so the Artifactory HTTPS handshake is trusted automatically — no keytool import.

## 2. settings.xml  ->  runtime/settings.xml
Your company Maven settings with the Artifactory mirror + server credentials, e.g.:

    <settings>
      <mirrors>
        <mirror>
          <id>artifactory</id>
          <mirrorOf>*</mirrorOf>
          <url>https://artifactory.company.com/artifactory/maven-virtual</url>
        </mirror>
      </mirrors>
      <servers>
        <server>
          <id>artifactory</id>
          <username>${env.ARTIFACTORY_USER}</username>
          <password>${env.ARTIFACTORY_TOKEN}</password>
        </server>
      </servers>
    </settings>

Then set:
    SOURCEFORGE_MAVEN_SETTINGS=/app/runtime/settings.xml
    sourceforge.build.maven-settings=/abs/path/runtime/settings.xml

## 3. Maven (optional)  ->  runtime/maven/
Only if you don't want to use the mvn already on PATH. Provide so that
runtime/maven/bin/mvn exists, then:
    SOURCEFORGE_MAVEN_HOME=/app/runtime/maven

## Quick local run (no Docker)
    export SOURCEFORGE_JAVA_HOME=$PWD/runtime/jdk
    export SOURCEFORGE_MAVEN_SETTINGS=$PWD/runtime/settings.xml
    export ARTIFACTORY_USER=... ARTIFACTORY_TOKEN=...
    ./mvnw spring-boot:run     # or: mvn spring-boot:run

The first "MVN INSTALL" build will resolve dependencies from your Artifactory and
stream the full log to the UI until BUILD SUCCESS.
