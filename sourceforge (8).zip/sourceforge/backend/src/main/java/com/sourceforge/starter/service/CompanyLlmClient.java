package com.sourceforge.starter.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;

/**
 * Thin client for the company LLM. Provider-agnostic: supports an
 * OpenAI-compatible (/v1/chat/completions) or Anthropic-compatible (/v1/messages)
 * endpoint, selected via configuration. Disabled by default; when no endpoint or
 * key is configured, {@link #isEnabled()} returns false and callers fall back to
 * the static compatibility map.
 *
 * Configuration (application.properties or env):
 *   sourceforge.llm.enabled=true
 *   sourceforge.llm.provider=openai|anthropic
 *   sourceforge.llm.base-url=https://llm.intra.company/v1
 *   sourceforge.llm.api-key=...           (or env SOURCEFORGE_LLM_API_KEY)
 *   sourceforge.llm.model=company-default
 */
@Service
public class CompanyLlmClient {

    private static final Logger log = LoggerFactory.getLogger(CompanyLlmClient.class);

    private final boolean enabled;
    private final String provider;   // "openai" | "anthropic"
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    private final Duration requestTimeout;
    private final HttpClient http;
    private final ObjectMapper mapper = new ObjectMapper();
    private volatile String lastError;   // reason for the most recent failure, or null

    public CompanyLlmClient(
            @Value("${sourceforge.llm.enabled:false}") boolean enabled,
            @Value("${sourceforge.llm.provider:openai}") String provider,
            @Value("${sourceforge.llm.base-url:}") String baseUrl,
            @Value("${sourceforge.llm.api-key:}") String apiKey,
            @Value("${sourceforge.llm.model:default}") String model,
            @Value("${sourceforge.llm.connect-timeout-seconds:10}") long connectTimeoutSeconds,
            @Value("${sourceforge.llm.request-timeout-seconds:60}") long requestTimeoutSeconds) {
        this.enabled = enabled;
        this.provider = provider == null ? "openai" : provider.toLowerCase();
        this.baseUrl = baseUrl == null ? "" : baseUrl.replaceAll("/+$", "");
        this.apiKey = apiKey == null ? "" : apiKey;
        this.model = model;
        this.requestTimeout = Duration.ofSeconds(requestTimeoutSeconds <= 0 ? 60 : requestTimeoutSeconds);
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(connectTimeoutSeconds <= 0 ? 10 : connectTimeoutSeconds))
                .build();
        if (this.enabled) {
            log.info("CompanyLlmClient enabled  provider={}  baseUrl={}  model={}  connectTimeout={}s  requestTimeout={}s",
                    this.provider, this.baseUrl, this.model, connectTimeoutSeconds, requestTimeoutSeconds);
        } else {
            log.info("CompanyLlmClient disabled (no LLM configured); using static compatibility map only");
        }
    }

    /** Last failure reason, for surfacing to the UI (null when the last call succeeded). */
    public String lastError() { return lastError; }

    public boolean isEnabled() {
        return enabled && !baseUrl.isBlank();
    }

    /**
     * Sends a single user prompt and returns the assistant's text, or empty on any error.
     * Errors never propagate — callers degrade gracefully to the static map — but the
     * reason is recorded in {@link #lastError()} so the UI can explain the fallback.
     */
    public Optional<String> complete(String systemPrompt, String userPrompt) {
        if (!isEnabled()) return Optional.empty();
        lastError = null;
        try {
            String url;
            String body;
            HttpRequest.Builder rb = HttpRequest.newBuilder().timeout(requestTimeout);

            if ("anthropic".equals(provider)) {
                url = baseUrl + "/messages";
                body = mapper.writeValueAsString(Map.of(
                        "model", model,
                        "max_tokens", 1024,
                        "system", systemPrompt,
                        "messages", new Object[]{Map.of("role", "user", "content", userPrompt)}
                ));
                rb.header("x-api-key", apiKey).header("anthropic-version", "2023-06-01");
            } else { // openai-compatible
                url = baseUrl + "/chat/completions";
                body = mapper.writeValueAsString(Map.of(
                        "model", model,
                        "messages", new Object[]{
                                Map.of("role", "system", "content", systemPrompt),
                                Map.of("role", "user", "content", userPrompt)
                        }
                ));
                rb.header("Authorization", "Bearer " + apiKey);
            }

            HttpRequest req = rb.uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() / 100 != 2) {
                lastError = "LLM returned HTTP " + resp.statusCode();
                log.warn("LLM call non-2xx: status={}", resp.statusCode());
                return Optional.empty();
            }
            return Optional.ofNullable(extractText(resp.body()));
        } catch (java.net.http.HttpConnectTimeoutException e) {
            lastError = "Connection to the LLM timed out (could not connect). Check base-url/network.";
            log.warn("LLM connect timeout: {}", e.getMessage());
            return Optional.empty();
        } catch (java.net.http.HttpTimeoutException e) {
            lastError = "The LLM did not respond in time (request timeout). It may be slow or overloaded.";
            log.warn("LLM request timeout: {}", e.getMessage());
            return Optional.empty();
        } catch (java.net.ConnectException e) {
            lastError = "Could not reach the LLM endpoint (connection refused). Check base-url and that the gateway is up.";
            log.warn("LLM connect refused: {}", e.getMessage());
            return Optional.empty();
        } catch (Exception e) {
            lastError = "LLM call failed: " + e.getClass().getSimpleName()
                    + (e.getMessage() != null ? " — " + e.getMessage() : "");
            log.warn("LLM call failed: {}", e.getMessage());
            return Optional.empty();
        }
    }

    private String extractText(String responseBody) throws Exception {
        JsonNode root = mapper.readTree(responseBody);
        if ("anthropic".equals(provider)) {
            JsonNode content = root.path("content");
            if (content.isArray() && content.size() > 0) {
                return content.get(0).path("text").asText(null);
            }
            return null;
        }
        JsonNode choices = root.path("choices");
        if (choices.isArray() && choices.size() > 0) {
            return choices.get(0).path("message").path("content").asText(null);
        }
        return null;
    }
}
