package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.ArtifactSpec;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts;
    private final com.bnpparibas.releasecockpit.service.SubjectConfigService subjectConfig;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane session cookie (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    // Cache of Octane env buckets per feature path (stable during a scan) and a
    // semaphore that caps concurrent Octane SaaS calls to avoid rate-limiting.
    private final java.util.concurrent.ConcurrentHashMap<String, java.util.Set<String>> octaneBucketCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.Semaphore octaneGate = new java.util.concurrent.Semaphore(2);

    public LiveConnector(CockpitProperties props, HttpClientFactory clients,
                         com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts,
                         com.bnpparibas.releasecockpit.service.SubjectConfigService subjectConfig) {
        this.props = props;
        this.clients = clients;
        this.artifacts = artifacts;
        this.subjectConfig = subjectConfig;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira base-url not configured; returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();

        // 1) Explicit release names take priority (no project lookup needed).
        if (!isBlank(j.getReleaseNames())) {
            for (String name : j.getReleaseNames().split(",")) {
                name = name.trim();
                if (!name.isEmpty()) out.add(new Release(name, name, null, false, ""));
            }
            log.info("Using {} explicit release name(s) from config.", out.size());
            return out;
        }

        // 2) Otherwise scan project fixVersions.
        if (isBlank(j.getProjectKeys())) {
            log.warn("Neither release-names nor project-keys set; no releases. "
                    + "Set cockpit.jira.release-names (e.g. 25.07,25.08) or project-keys.");
            return List.of();
        }
        for (String project : j.getProjectKeys().split(",")) {
            project = project.trim();
            if (project.isEmpty()) continue;
            // Jira DC: project key is case-sensitive; numeric ids also work.
            String body = getJira("/rest/api/2/project/" + enc(project) + "/versions");
            if (body == null) {
                log.warn("Jira versions for project '{}' returned no body (check the key — "
                        + "it must be the PROJECT KEY, e.g. TCAAS1484, not the name).", project);
                continue;
            }
            try {
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        if (name.isEmpty()) continue;
                        LocalDate date = safeDate(v.path("releaseDate").asText(null));
                        boolean released = v.path("released").asBoolean(false);
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                } else {
                    // Jira returned an error object (e.g. 400) rather than an array.
                    log.warn("Jira versions for '{}' not an array — response: {}", project,
                            body.length() > 300 ? body.substring(0, 300) : body);
                }
            } catch (Exception e) {
                log.warn("Parsing Jira versions for '{}' failed: {}", project, e.getMessage());
            }
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String fields = "summary,status,assignee,reporter,created";
            if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank())
                fields += "," + j.getOctaneLinkField();
            if (j.getOctaneFeatureField() != null && !j.getOctaneFeatureField().isBlank())
                fields += "," + j.getOctaneFeatureField();
            String url = "/rest/api/2/search?jql=" + enc(jql) + "&maxResults=200&fields=" + fields;
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");

            // Parse all issues first (cheap, no network).
            record Raw(String key, String issueId, String summary, String status, String dev, String devEmail,
                       String rep, String repEmail, LocalDate created, List<String> octaneIds) {}
            List<Raw> raws = new ArrayList<>();
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                String issueId = it.path("id").asText("");   // Jira numeric id, e.g. 4048900
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank()) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                raws.add(new Raw(key, issueId, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        f.path("assignee").path("displayName").asText(""),
                        f.path("assignee").path("emailAddress").asText(""),
                        f.path("reporter").path("displayName").asText(""),
                        f.path("reporter").path("emailAddress").asText(""),
                        safeDate(f.path("created").asText("").replaceAll("T.*", "")),
                        octaneIds));
            }

            ExecutorService pool = Executors.newFixedThreadPool(
                    Math.min(4, Math.max(2, raws.size())));
            try {
                final int relYear = releaseYearFor(releaseName);
                List<Future<Subject>> futures = new ArrayList<>();
                for (Raw rw : raws) {
                    futures.add(pool.submit(() -> {
                        List<String> requiredEnvs = requiredOctaneEnvs(releaseName, rw.key());
                        OctaneResult octane = checkOctane(rw.key(), rw.issueId(), requiredEnvs);
                        Readiness r = buildReadiness(rw.key(), octane, relYear);
                        return new Subject(rw.key(), rw.summary(), rw.status(),
                                rw.dev(), rw.devEmail(), rw.rep(), rw.repEmail(),
                                rw.created(), rw.octaneIds(), r);
                    }));
                }
                for (Future<Subject> fut : futures) {
                    try { out.add(fut.get()); }
                    catch (Exception e) { log.warn("Subject check failed: {}", e.getMessage()); }
                }
            } finally {
                pool.shutdown();
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject from artifacts.json. For each enabled
     * SharePoint artifact, resolves its folder, finds files (per goInside rules)
     * and requires minFiles. Per-subject skips are handled in subject-checks.json,
     * not here. The numeric subject id is the trailing number of the epic key.
     */
    private Readiness buildReadiness(String epicKey, OctaneResult octane, int year) {
        boolean octaneOk = octane.ok();
        java.util.Map<String, Boolean> results = new java.util.HashMap<>();
        for (ArtifactSpec spec : artifacts.sharePointArtifacts()) {
            results.put(spec.key, checkSharePointArtifact(epicKey, spec, year));
        }
        // Artifacts not enabled are absent from the map and default to satisfied
        // (so a disabled artifact never shows as a gap).
        boolean pr = results.getOrDefault("PR", true);
        boolean prExcel = results.getOrDefault("PR_EXCEL", true);
        boolean est = results.getOrDefault("ESTIMATION_SHEET", true);
        boolean rev = results.getOrDefault("OCTANE_REVIEW_DOC", true);
        boolean exec = results.getOrDefault("OCTANE_EXECUTION_DOC", true);
        boolean unit = results.getOrDefault("UNIT_TEST", true); // disabled by default

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");
        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing,
                octane.url(), octane.missingEnvs());
    }

    /**
     * Required Octane environments for a subject, from its release-scoped check
     * config: the configured octaneEnvironments (default IST/DEV/UAT), plus BCM
     * when bcmEndToEnd is enabled.
     */
    private List<String> requiredOctaneEnvs(String releaseName, String subjectKey) {
        var cfg = subjectConfig.forSubject(releaseName, subjectKey);
        List<String> envs = new ArrayList<>();
        if (cfg != null && cfg.octaneEnvironments() != null) {
            for (String e : cfg.octaneEnvironments()) if (e != null && !e.isBlank()) envs.add(e.trim().toUpperCase());
        }
        if (cfg != null && cfg.bcmEndToEnd() && !envs.contains("BCM")) envs.add("BCM");
        return envs;
    }

    /** Numeric subject id = trailing digits of the epic key (TCAAS1484-4971 -> 4971). */
    private String subjectIdOf(String epicKey) {
        var m = java.util.regex.Pattern.compile("(\\d+)$").matcher(epicKey);
        return m.find() ? m.group(1) : epicKey;
    }

    /** Year used for {YEAR} substitution — from the release's date, else current year. */
    private int releaseYearFor(String releaseName) {
        try {
            for (Release r : listReleases()) {
                if (r.name().equals(releaseName) && r.releaseDate() != null) {
                    return r.releaseDate().getYear();
                }
            }
        } catch (Exception ignore) { }
        return java.time.Year.now().getValue();
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    /**
     * Octane coverage for a Jira subject, via the Jira octane-coverage REST API:
     *   /rest/octane-coverage/1.0/coverage?project-key=..&issue-key=..&issue-id=..
     *       &workspace-config-id=..&workspace-id=..
     * The response gives totalTestsCount, totalExecutedTestsCount and coverage
     * groups (e.g. Passed count). This runs on the internal Jira client, so no
     * Octane sign-in is needed. Passes when there are tests and (if
     * require-runs-passed) all executed tests passed.
     */
    /** Rich Octane result: overall pass, the test-tab URL, and missing env buckets. */
    private record OctaneResult(boolean ok, String url, List<String> missingEnvs) {}

    /**
     * Octane coverage for a Jira subject.
     * Step 1 — Jira octane-coverage REST API gives total/executed/passed counts,
     *   plus the Octane feature entity (its path + testTabUrl).
     * Step 2 — Octane tests query (by feature path) buckets tests by test_type
     *   (Unit Test->Dev, Acceptance->UAT, IST->IST, End to End->BCM) so we can
     *   report which REQUIRED environment has no tests.
     * requiredEnvs comes from the subject's check config (default IST/DEV/UAT,
     * plus BCM when bcmEndToEnd is on).
     */
    private OctaneResult checkOctane(String issueKey, String issueId, List<String> requiredEnvs) {
        var o = props.getOctane();
        var j = props.getJira();
        if (isBlank(j.getBaseUrl()) || isBlank(issueId)) {
            log.info("Octane: no Jira base/issue-id for {} — skipping", issueKey);
            return new OctaneResult(false, null, requiredEnvs);
        }
        try {
            String projectKey = firstProjectKey(j.getProjectKeys(), issueKey);
            String path = "/rest/octane-coverage/1.0/coverage"
                    + "?project-key=" + enc(projectKey)
                    + "&issue-key=" + enc(issueKey)
                    + "&issue-id=" + enc(issueId)
                    + (isBlank(o.getWorkspaceConfigId()) ? "" : "&workspace-config-id=" + enc(o.getWorkspaceConfigId()))
                    + (isBlank(o.getWorkspaceId()) ? "" : "&workspace-id=" + enc(o.getWorkspaceId()));
            String body = getJira(path);
            if (body == null) { log.info("Octane coverage {} -> no response", issueKey); return new OctaneResult(false, null, requiredEnvs); }
            JsonNode root = mapper.readTree(body);
            String status = root.path("status").asText("");
            int total = root.path("totalTestsCount").asInt(0);
            int executed = root.path("totalExecutedTestsCount").asInt(0);
            int passed = 0;
            for (JsonNode grp : root.path("coverageGroups")) {
                JsonNode fields = grp.path("fields");
                if ("run_status_passed".equals(fields.path("id").asText(""))
                        || "Passed".equalsIgnoreCase(fields.path("name").asText(""))) {
                    passed += fields.path("count").asInt(0);
                }
            }
            // Octane feature entity: testTabUrl (link the user clicks) + path (to query tests).
            JsonNode entity = root.path("octaneEntity").path("fields");
            String testTabUrl = entity.path("testTabUrl").asText(entity.path("url").asText(null));
            String featurePath = entity.path("path").asText("");

            boolean hasTests = total > 0 && !"noData".equalsIgnoreCase(status);
            boolean allPassed = !o.isRequireRunsPassed() || (executed > 0 && passed >= executed);

            // Step 2: which required env buckets have NO tests?
            List<String> missingEnvs = new ArrayList<>();
            if (requiredEnvs != null && !requiredEnvs.isEmpty() && !featurePath.isBlank()) {
                java.util.Set<String> present = octaneEnvBuckets(featurePath);
                for (String env : requiredEnvs) {
                    if (!present.contains(env.toUpperCase())) missingEnvs.add(env.toUpperCase());
                }
            }

            boolean ok = hasTests && allPassed && missingEnvs.isEmpty();
            log.info("Octane {} -> total={} executed={} passed={} status={} missingEnvs={} -> {}",
                    issueKey, total, executed, passed, status, missingEnvs, ok ? "PASS" : "MISSING");
            return new OctaneResult(ok, testTabUrl, missingEnvs);
        } catch (Exception e) {
            log.warn("Octane coverage check failed ({}): {}", issueKey, e.getMessage());
            return new OctaneResult(false, null, requiredEnvs);
        }
    }

    /** test_type.name -> our environment bucket. */
    private String envForTestType(String testTypeName) {
        if (testTypeName == null) return null;
        String t = testTypeName.trim().toLowerCase();
        return switch (t) {
            case "unit test" -> "DEV";
            case "acceptance" -> "UAT";
            case "end to end" -> "BCM";
            case "ist" -> "IST";
            default -> null; // Regression and others don't map to a required bucket
        };
    }

    /**
     * Queries Octane tests covering a feature path and returns the set of env
     * buckets that have at least one test. Uses the Octane SaaS API (client
     * sign-in). Fails soft: returns an empty set on any error, so a query
     * failure never fabricates "missing" gaps beyond what's required.
     */
    private java.util.Set<String> octaneEnvBuckets(String featurePath) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl()) || isBlank(o.getSharedSpaceId()) || isBlank(o.getWorkspaceId()))
            return new java.util.HashSet<>();
        // Cache per feature path — the same feature is queried once per scan even
        // if several subjects map to it, and repeat scans reuse until cleared.
        java.util.Set<String> cached = octaneBucketCache.get(featurePath);
        if (cached != null) return cached;

        java.util.Set<String> buckets = new java.util.HashSet<>();
        boolean acquired = false;
        try {
            // Rate-limit: cap concurrent Octane SaaS calls, with a small spacing
            // delay so we don't trip Octane's request throttling.
            acquired = octaneGate.tryAcquire(20, java.util.concurrent.TimeUnit.SECONDS);
            if (!acquired) { log.warn("Octane gate timeout for path {}", featurePath); return buckets; }
            Thread.sleep(150); // gentle spacing between Octane calls

            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return buckets;
            String query = "\"((covered_content={(path='" + featurePath + "*')}))\"";
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests?fields=test_type,name&limit=200&query=" + enc(query);
            HttpResponse<String> r = octaneGet(url);
            if (r != null && (r.statusCode() == 401 || r.statusCode() == 429)) {
                if (r.statusCode() == 429) Thread.sleep(1500); // backoff on rate-limit
                octaneSignIn(); r = octaneGet(url);
            }
            if (r == null || r.statusCode() >= 400) {
                log.info("Octane tests query HTTP {} (path={})", r == null ? "null" : r.statusCode(), featurePath);
                return buckets;
            }
            JsonNode data = mapper.readTree(r.body()).path("data");
            if (data.isArray()) for (JsonNode t : data) {
                for (JsonNode tt : t.path("test_type").path("data")) {
                    String env = envForTestType(tt.path("name").asText(""));
                    if (env != null) buckets.add(env);
                }
            }
            log.info("Octane env buckets for path {} -> {}", featurePath, buckets);
            octaneBucketCache.put(featurePath, buckets); // cache success only
            return buckets;
        } catch (Exception e) {
            log.warn("Octane tests query failed ({}): {}", featurePath, e.getMessage());
            return buckets;
        } finally {
            if (acquired) octaneGate.release();
        }
    }

    /** Clears per-scan Octane caches so a manual refresh re-queries Octane. */
    public void clearOctaneCache() { octaneBucketCache.clear(); }

    private void octaneSignIn() {
        var o = props.getOctane();
        try {
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() < 400) {
                String cookie = r.headers().allValues("set-cookie").stream()
                        .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                        .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                octaneCookie = cookie;
                log.info("Octane sign-in {}", cookie != null ? "OK" : "returned no cookie");
            } else {
                log.warn("Octane sign-in HTTP {}", r.statusCode());
            }
        } catch (Exception e) {
            log.warn("Octane sign-in failed gracefully: {}", e.getMessage());
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", octaneCookie)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** Pick the project key (config first token, else derive from the issue key prefix). */
    private String firstProjectKey(String projectKeys, String issueKey) {
        if (projectKeys != null && !projectKeys.isBlank()) return projectKeys.split(",")[0].trim();
        int dash = issueKey.lastIndexOf('-');
        return dash > 0 ? issueKey.substring(0, dash) : issueKey;
    }

    // ---- SharePoint ----
    // Per-epic cache of the subfolders that contain at least one file, so the
    // listing happens once per epic (not once per artifact). Cleared each scan
    // via the cache TTL on the service layer; here it lives for the connector.

    /**
     * Checks one SharePoint artifact for an epic using its artifacts.json spec.
     *
     * Folder resolution: spec.folder with {YEAR} -> current year and {EPIC} ->
     * epic key, prefixed by the configured root path, under the library. If
     * spec.folder is empty, the epic's own folder under the root is used.
     *
     * Files are listed (recursing into subfolders when goInside=true) and a file
     * matches when its name contains ALL of match.all (after {EPIC} substitution)
     * AND at least one of match.any AND, if extensions is non-empty, ends with one
     * of them. The check passes when at least minFiles files match.
     */
    private boolean checkSharePointArtifact(String epicKey, ArtifactSpec spec, int year) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return false;
        boolean mandatory = spec.mandatory == null || spec.mandatory; // default mandatory
        try {
            String y = String.valueOf(year);
            String root = (sp.getRootPath() == null ? "" : sp.getRootPath()).replace("{YEAR}", y);
            String sub = (spec.folder == null ? "" : spec.folder).replace("{YEAR}", y).replace("{EPIC}", epicKey);

            String subjectId = subjectIdOf(epicKey);
            List<String> anyTokens = (spec.match != null && spec.match.any != null) ? spec.match.any : List.of();
            List<String> exts = (spec.match != null && spec.match.extensions != null) ? spec.match.extensions : List.of();

            List<String> matchingFiles = new ArrayList<>();
            String checkedFolder;

            // The artifact's base folder (full path from site+library).
            String baseRel = (siteAndLibrary(sp) + "/" + root + sub).replaceAll("/{2,}", "/");

            int totalFiles = 0;
            List<String> sampleFiles = new ArrayList<>();
            if (spec.goInside) {
                // CASE A — goInside (PR, ESTIMATION, UNIT_TEST):
                List<FolderRef> subjectFolders = findSubjectFolders(baseRel, subjectId, epicKey);
                checkedFolder = subjectFolders.isEmpty() ? baseRel + "/<no folder matching " + subjectId + ">"
                        : subjectFolders.get(0).serverRel;
                for (FolderRef fr : subjectFolders) {
                    for (String name : listFiles(fr.serverRel, true, 0)) {
                        totalFiles++;
                        if (sampleFiles.size() < 8) sampleFiles.add(name);
                        if (keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                    }
                }
            } else {
                // CASE B — shared folder (PR_EXCEL, TEST CASE, TEST EXEC):
                // The FILE NAME must contain the subject id (or epic key) and the
                // right extension; keywords are a secondary filter (only applied if
                // none of the id-matching files would otherwise qualify).
                checkedFolder = baseRel;
                List<String> idExtMatches = new ArrayList<>();
                for (String name : listFiles(baseRel, false, 0)) {
                    totalFiles++;
                    if (sampleFiles.size() < 8) sampleFiles.add(name);
                    String lower = name.toLowerCase();
                    boolean hasId = lower.contains(subjectId.toLowerCase())
                            || lower.contains(epicKey.toLowerCase());
                    if (!hasId) continue;
                    boolean extOk = exts.isEmpty() || exts.stream().anyMatch(e -> lower.endsWith(e.toLowerCase()));
                    if (!extOk) continue;
                    idExtMatches.add(name);
                    if (keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                }
                // If id+extension matched files but keywords didn't, accept the
                // id+extension matches — the subject id in a Quality folder file is
                // a strong enough signal (filenames vary in keyword wording).
                if (matchingFiles.isEmpty() && !idExtMatches.isEmpty()) {
                    matchingFiles.addAll(idExtMatches);
                }
            }

            boolean ok = matchingFiles.size() >= Math.max(1, spec.minFiles);
            log.info("SharePoint {} [{}] mandatory={} folder='{}' totalFiles={} matched={} {} -> {}",
                    epicKey, spec.key, mandatory, checkedFolder, totalFiles, matchingFiles.size(),
                    matchingFiles.isEmpty() ? ("(files seen: " + sampleFiles + ")") : matchingFiles,
                    ok ? "PASS" : (mandatory ? "MISSING" : "MISSING(optional)"));
            return ok || !mandatory; // non-mandatory never produces a gap
        } catch (Exception e) {
            log.warn("SharePoint check failed ({} {}): {}", epicKey, spec.key, e.getMessage());
            return !mandatory;
        }
    }

    private record FolderRef(String name, String serverRel) {}

    /**
     * Lists subfolders under baseRel and returns those whose name contains the
     * subject id (or the full epic key). These are the per-subject folders.
     */
    private List<FolderRef> findSubjectFolders(String baseRel, String subjectId, String epicKey) {
        List<FolderRef> out = new ArrayList<>();
        var sp = props.getSharepoint();
        try {
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + encodePath(baseRel) + "')/Folders?$select=Name,ServerRelativeUrl";
            HttpResponse<String> r = spGet(url);
            if (r == null || r.statusCode() >= 400) {
                if (r != null) log.info("SharePoint Folders HTTP {} for '{}'", r.statusCode(), baseRel);
                return out;
            }
            JsonNode root = mapper.readTree(r.body());
            JsonNode folders = root.has("value") ? root.path("value") : root.path("d").path("results");
            String keyl = epicKey.toLowerCase();
            // Match the subject id as a whole token (not a substring of a bigger
            // number), e.g. "2328" matches "TCAAS1484-2328 - desc" but not "12328".
            java.util.regex.Pattern idPat = java.util.regex.Pattern.compile(
                    "(?<![0-9])" + java.util.regex.Pattern.quote(subjectId) + "(?![0-9])");
            if (folders.isArray()) for (JsonNode f : folders) {
                String name = f.path("Name").asText("");
                if ("Forms".equalsIgnoreCase(name)) continue;
                String nl = name.toLowerCase();
                boolean hit = nl.contains(keyl) || idPat.matcher(name).find();
                if (hit) {
                    String srv = f.path("ServerRelativeUrl").asText("");
                    if (srv.isBlank()) srv = baseRel + "/" + name;
                    out.add(new FolderRef(name, srv));
                }
            }
        } catch (Exception e) {
            log.info("findSubjectFolders failed ({}): {}", baseRel, e.getMessage());
        }
        return out;
    }

    /** Keyword match: contains one of `any` (if given) and ends with one of `exts` (if given). */
    private boolean keywordMatches(String name, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        if (any != null && !any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** site path + library, e.g. /sites/ITTAADM/Project Documents */
    private String siteAndLibrary(CockpitProperties.SharePoint sp) {
        String sitePath = sp.getBaseUrl().replaceFirst("^https?://[^/]+", "");
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        return (sitePath + "/" + lib).replaceAll("/{2,}", "/");
    }

    /** Lists file names directly in a folder, optionally recursing into subfolders. */
    private List<String> listFiles(String serverRel, boolean recurse, int depth) {
        List<String> names = new ArrayList<>();
        if (depth > 5) return names; // safety bound
        var sp = props.getSharepoint();
        try {
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + encodePath(serverRel) + "')/Files?$select=Name";
            HttpResponse<String> r = spGet(url);
            if (r != null && r.statusCode() < 400) {
                JsonNode root = mapper.readTree(r.body());
                JsonNode files = root.has("value") ? root.path("value")
                        : root.path("d").path("results");
                if (files.isArray()) for (JsonNode f : files) names.add(f.path("Name").asText(""));
            } else if (r != null) {
                // Log at INFO so auth/path problems are visible (not hidden at debug).
                log.info("SharePoint Files HTTP {} for folder '{}'{}", r.statusCode(), serverRel,
                        (r.statusCode() == 401 || r.statusCode() == 403) ? " — cookies likely expired" : "");
            }
            if (recurse) {
                String furl = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                        + encodePath(serverRel) + "')/Folders?$select=Name,ServerRelativeUrl";
                HttpResponse<String> fr = spGet(furl);
                if (fr != null && fr.statusCode() < 400) {
                    JsonNode froot = mapper.readTree(fr.body());
                    JsonNode folders = froot.has("value") ? froot.path("value")
                            : froot.path("d").path("results");
                    if (folders.isArray()) for (JsonNode sf : folders) {
                        String name = sf.path("Name").asText("");
                        if ("Forms".equalsIgnoreCase(name)) continue; // skip system folder
                        String srv = sf.path("ServerRelativeUrl").asText("");
                        if (srv.isBlank()) srv = serverRel + "/" + name;
                        names.addAll(listFiles(srv, true, depth + 1));
                    }
                } else if (fr != null) {
                    log.info("SharePoint Folders HTTP {} for folder '{}'", fr.statusCode(), serverRel);
                }
            }
        } catch (Exception e) {
            log.info("listFiles error ({}): {}", serverRel, e.getMessage());
        }
        return names;
    }

    private HttpResponse<String> spGet(String url) {
        try {
            var sp = props.getSharepoint();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(20)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.debug("SharePoint GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** A file matches when its name contains the Jira id (full key or its number) and (if given) an extension. */
    private boolean fileMatchesId(String name, String epicKey, String idNum, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        boolean hasId = lower.contains(epicKey.toLowerCase()) || lower.contains(idNum.toLowerCase());
        if (!hasId) return false;
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** A file matches if it contains all `all` tokens, one `any` token, and (if given) an extension. */
    private boolean fileMatches(String name, List<String> all, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        for (String a : all) if (!lower.contains(a.toLowerCase())) return false;
        if (!any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (!exts.isEmpty()) {
            boolean ext = false;
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) { ext = true; break; }
            if (!ext) return false;
        }
        return true;
    }

    /** Encode a server-relative path for GetFolderByServerRelativeUrl('...'). */
    private String encodePath(String path) {
        // SharePoint's GetFolderByServerRelativeUrl('...') needs the path
        // percent-encoded for special characters (brackets, parens, #, &, %, etc.)
        // while keeping the slashes. Single quotes are doubled per OData rules.
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c == '/') { sb.append('/'); continue; }
            if (c == '\'') { sb.append("''"); continue; }
            if (c == ' ') { sb.append("%20"); continue; }
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
                    || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
                sb.append(c);
            } else {
                byte[] bytes = String.valueOf(c).getBytes(java.nio.charset.StandardCharsets.UTF_8);
                for (byte b : bytes) sb.append('%').append(String.format("%02X", b & 0xff));
            }
        }
        return sb.toString();
    }
    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(30)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
