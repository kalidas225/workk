# Release Cockpit — BNP Paribas

A release-readiness dashboard. Pick a release configured in Jira, see its
subjects, developer distribution, and Octane/SharePoint readiness as charts,
and email developers about gaps — with intelligent date checkpoints derived
from the Jira release date.

- **Frontend:** Angular 19 (standalone components, Chart.js). Runs standalone
  with built-in mock data, or against the live API.
- **Backend:** Java 21 + Spring Boot 3. New REST API layer; the connector logic
  is ported from the Release Guardian tool. Runs in **mock mode** by default so
  it starts with zero credentials.

![Dashboard](screenshots/cockpit-top.png)

---

## What it does

- **Release dropdown** — all releases (Jira fixVersions) configured for the year.
- **Systems status panel** — Jira, SharePoint, Octane, and **ServiceNow** shown
  in one place, each with a live connection state (Connected / Down / Mock /
  Coming soon) and the auth method. The single-stop view: no jumping between
  tools to see if a system is reachable.
- **Release health meter** — a composite 0-100 score with a letter grade
  (Excellent / Good / At risk / Critical), four sub-score bars (readiness,
  Octane, SharePoint, timeline), and concrete risk notes.
- **Checkpoint rail** — the signature element. From the Jira **release date** it
  derives:
  - **PPD starts** = release date − **2 weeks**
  - **End-UAT done** = release date − **3 weeks**
  Each shows a live status (Upcoming / Active / Due soon / Overdue / Done).
- **Pie / charts** — developer distribution (doughnut) and Octane + SharePoint
  readiness (stacked bars).
- **Release timeline** — the signature element. From the Jira **release date**
  it auto-computes six milestones:
  - **PPD-1** = release date − **2 weeks**
  - **PPD-1 rollback** = same day as PPD-1
  - **PPD-2** = the **Monday** of the week after PPD-1
  - **LCAB** = the **Tuesday** of the release week
  - **End-UAT done** = release date − **3 weeks**
  - **Release** = the release date
  Each shows a live status. Dates are auto-computed but can be overridden per
  release in `checkpoint-overrides.json` when they shift.
- **Grid filters** — a search box (key, summary, developer, reporter, email)
  plus status / readiness / developer column filters on the subjects table.
- **Per-system refresh** — each system (Jira / SharePoint / Octane / ServiceNow)
  has its own refresh button with a loader, so you refresh one without
  reloading everything. Skeleton loaders show while data is in flight.
- **Auto-check scheduler** — a configurable cron (default every 3 hours,
  `cockpit.scheduler.auto-check-cron`) refreshes data and, when
  `cockpit.scheduler.auto-mail=true`, emails developers about gaps and sends a
  manager summary automatically.
- **Two themes** — Light and Dark, both with an iOS-style frosted-glass finish.
- **Data-dense terminal UI** — a live systems + metrics ticker strip, three tabs
  (Dashboard / ServiceNow / Check config), monospace numerics, modern charts,
  and a custom dropdown (no white-in-dark-mode native select).
- **ServiceNow tab** — release-linked change tickets (number, state, priority,
  owner) in their own tab, fetched from the ServiceNow Table API when connected.
- **Check config tab** — per-subject check overrides you can view and edit:
  which Octane environments apply (e.g. UAT only, skip IST/DEV), whether BCM
  end-to-end testing is required, and which SharePoint folders to skip. The JSON
  file is the source of truth; UI edits save back to it.
- **Subjects table** — paginated (20 per page), showing developer **and
  reporter**, per-subject Octane and SharePoint status, the specific missing
  items, and a **Send mail** button.
- **Mail all gaps** — one click emails every developer who has a not-ready
  subject. **To** = developer + reporter; **CC** = managers.
- **Email summary** — sends a polished overall release-status email to managers.
- **Rich HTML emails** — both the per-subject gap email and the release-status
  summary use Outlook-safe HTML templates.
- **Intelligent late-add alert** — a scheduled check detects subjects added at
  the last minute when end-UAT is close, and immediately emails the developer
  that end-UAT is approaching.
- **Hybrid data** — the backend caches connector data; the **Refresh** button
  forces a re-fetch from source.

## ServiceNow (single-stop, ready to connect)

The dashboard is designed as a **single stop** — you shouldn't leave it to check
another tool. ServiceNow is wired in but disabled by default; it appears in the
systems panel as "Coming soon" until you connect it. To enable:

1. Set `cockpit.servicenow.enabled=true` and fill in `base-url`, `username`,
   `password`, `table` (e.g. `change_request`), and `release-field`.
2. Implement the ticket fetch in a `ServiceNowConnector` (the model
   `Domain.ServiceNowTicket` and the status probe already exist). It calls the
   standard Table API: `GET /api/now/table/{table}?sysparm_query=...`.

Once enabled, release-linked ServiceNow tickets surface alongside the Jira
subjects, so change requests and incidents for a release are visible in the same
view.

---

## Repository layout

```
release-cockpit/
├── backend/                  # Java 21 + Spring Boot REST API
│   ├── pom.xml
│   └── src/main/java/com/bnpparibas/releasecockpit/
│       ├── ReleaseCockpitApplication.java
│       ├── config/           # properties, cache, CORS
│       ├── connector/        # data-source contract + Mock + (Live = port from Node)
│       ├── controller/       # the dashboard REST API
│       ├── model/            # domain records
│       ├── scheduler/        # intelligent late-add detection
│       └── service/          # checkpoints, aggregation, mail
│   └── src/main/resources/application.yml
├── frontend/                 # Angular 19 dashboard
│   └── src/app/
│       ├── app.component.*   # the dashboard (TS / HTML / SCSS)
│       ├── api.service.ts    # mock + live data service
│       └── models.ts
├── screenshots/              # rendered UI previews
└── README.md  +  CONNECTORS.md
```

---

## Quick start

### Frontend (runs standalone, no backend needed)

```bash
cd frontend
npm install
npm start            # ng serve -> http://localhost:4200
```
It starts in **mock mode** (`USE_MOCK = true` in `src/app/api.service.ts`) with
realistic demo data. To point it at the live backend, set `USE_MOCK = false`.

### Backend (Java 21 + Spring Boot)

```bash
cd backend
# Build with your BNP Artifactory mirror in ~/.m2/settings.xml (as usual)
mvn clean package
java -jar target/release-cockpit.jar    # -> http://localhost:8080
```
It starts in **mock mode** (`cockpit.mock-mode=true`) so it runs with no
credentials. Set `COCKPIT_MOCK_MODE=false` and fill in the connector env vars
(see `application.yml`) to go live.

---

## The intelligent checkpoints

From the single Jira release date, the backend (`CheckpointService`) computes:

| Checkpoint | Rule | Statuses |
|---|---|---|
| **PPD start** | release − 14 days | Upcoming → Active → Done |
| **End-UAT done** | release − 21 days | Upcoming → Due soon (≤4 days) → Overdue |

The scheduler (`IntelligentCheckScheduler`) runs hourly: for any unreleased
release whose end-UAT deadline is within the due-soon window, it finds subjects
created in the last 5 days (a "late add") and emails the developer once that
end-UAT is approaching. Dedupe is in-memory by default; persist it for
production (see CONNECTORS.md).

---

## Going live

The backend ships with a **MockConnector** so everything runs immediately. The
**LiveConnector** (calling Jira, Octane, SharePoint) is a direct port of the
Release Guardian connectors you already have. See **CONNECTORS.md** for the
porting guide and the exact REST calls.

---

## API reference

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/releases` | Dropdown options |
| GET | `/api/releases/{name}/checkpoints` | PPD / end-UAT dates + status |
| GET | `/api/releases/{name}/summary` | Pie-chart aggregates |
| GET | `/api/releases/{name}/health` | Release health score + grade + risks |
| GET | `/api/releases/{name}/subjects?page&size` | Paginated subjects |
| GET | `/api/status` | Live status of Jira / SharePoint / Octane / ServiceNow |
| GET | `/api/releases/{name}/servicenow` | Release-linked ServiceNow tickets |
| GET | `/api/checks` | Per-subject check config (default + overrides) |
| PUT | `/api/checks/{key}` | Update a subject's check override |
| DELETE | `/api/checks/{key}` | Revert a subject to the default checks |
| POST | `/api/releases/{name}/refresh` | Clear cache (manual refresh) |
| POST | `/api/releases/{name}/subjects/{key}/mail` | Email one developer + reporter (managers CC) |
| POST | `/api/releases/{name}/mail-all` | Email all not-ready developers |
| POST | `/api/releases/{name}/mail-summary` | Email the release-status summary to managers |

---

## Screenshots

See the `screenshots/` folder:
- `cockpit-top.png` — checkpoint rail + charts
- `cockpit-full.png` — full dashboard
- `cockpit-pagination.png` — paginated subjects
- `cockpit-toast.png` — mail action + page 2
```
