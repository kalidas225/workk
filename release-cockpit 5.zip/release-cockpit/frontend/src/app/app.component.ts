import { Component, OnInit, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, registerables } from 'chart.js';
import { ApiService } from './api.service';
import { DropdownComponent, DropdownOption } from './dropdown.component';
import {
  Release, Checkpoints, Subject, ReleaseSummary, Page, ARTIFACT_LABELS,
  ReleaseHealth, ConnectionStatus, ServiceNowTicket, SubjectCheckConfig, ChecksConfig, Milestone,
} from './models';

Chart.register(...registerables);

type Tab = 'dashboard' | 'servicenow' | 'config';
const ENVS = ['IST', 'DEV', 'UAT'];
const SP_ITEMS = ['PR', 'PR_EXCEL', 'ESTIMATION_SHEET', 'OCTANE_REVIEW_DOC', 'OCTANE_EXECUTION_DOC', 'UNIT_TEST'];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, DropdownComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, AfterViewChecked {
  releases: Release[] = [];
  selected = '';
  checkpoints?: Checkpoints;
  summary?: ReleaseSummary;
  health?: ReleaseHealth;
  systems: ConnectionStatus[] = [];
  subjectsPage?: Page<Subject>;
  tickets: ServiceNowTicket[] = [];
  checks?: ChecksConfig;

  page = 0; size = 20;
  loading = false; toast = ''; sendingKey = ''; mailingAll = false;
  tab: Tab = 'dashboard';
  theme: 'light' | 'dark' = 'light';
  artifactLabels = ARTIFACT_LABELS;
  envs = ENVS; spItems = SP_ITEMS;

  // per-system refresh state
  sysLoading: Record<string, boolean> = {};
  // dropdown open state

  // filters
  filterText = '';
  filterStatus = '';
  filterReadiness = ''; // '', 'ready', 'gaps'
  filterDev = '';

  @ViewChild('devChart') devChartRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('readyChart') readyChartRef?: ElementRef<HTMLCanvasElement>;
  private devChart?: Chart; private readyChart?: Chart;
  private chartsDirty = false;

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    const saved = (typeof localStorage !== 'undefined' && localStorage.getItem('rc-theme')) as any;
    this.setTheme(saved === 'dark' ? 'dark' : 'light');
    this.api.getStatus().subscribe(s => this.systems = s);
    this.api.getChecks().subscribe(c => this.checks = c);
    this.api.getReleases().subscribe(r => {
      this.releases = r;
      const up = r.find(x => !x.released) ?? r[0];
      if (up) { this.selected = up.name; this.load(); }
    });
  }

  ngAfterViewChecked(): void {
    if (this.chartsDirty && this.summary && this.tab === 'dashboard'
        && this.devChartRef && this.readyChartRef) {
      this.renderCharts();
      this.chartsDirty = false;
    }
  }

  setTheme(t: 'light' | 'dark'): void {
    this.theme = t;
    if (typeof document !== 'undefined') document.documentElement.setAttribute('data-theme', t);
    if (typeof localStorage !== 'undefined') localStorage.setItem('rc-theme', t);
    this.chartsDirty = true;
  }

  setTab(t: Tab): void {
    this.tab = t;
    if (t === 'servicenow') this.api.getServiceNow(this.selected).subscribe(x => this.tickets = x);
    if (t === 'dashboard') this.chartsDirty = true;
  }

  onRelease(): void { this.page = 0; this.load(); if (this.tab === 'servicenow') this.setTab('servicenow'); }

  load(): void {
    if (!this.selected) return;
    this.loading = true;
    this.api.getCheckpoints(this.selected).subscribe(c => this.checkpoints = c);
    this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.chartsDirty = true; });
    this.api.getHealth(this.selected).subscribe(h => this.health = h);
    this.loadSubjects();
  }
  loadSubjects(): void {
    this.api.getSubjects(this.selected, this.page, this.size).subscribe(p => { this.subjectsPage = p; this.loading = false; });
  }
  refresh(): void { this.flash('Refreshing from source'); this.load(); }

  // Per-system refresh: re-probe one system + (for data systems) reload data.
  refreshSystem(sys: string): void {
    this.sysLoading[sys] = true;
    this.api.getStatus().subscribe(all => {
      const one = all.find(s => s.system === sys);
      if (one) { const idx = this.systems.findIndex(x => x.system === sys); if (idx >= 0) this.systems[idx] = one; }
      // data systems also refresh the relevant slice
      if (sys === 'JIRA') { this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.chartsDirty = true; }); this.loadSubjects(); }
      if (sys === 'SERVICENOW') this.api.getServiceNow(this.selected).subscribe(t => this.tickets = t);
      setTimeout(() => { this.sysLoading[sys] = false; this.flash(sys + ' refreshed'); }, 350);
    });
  }

  // ---- dropdown ----
  pick(name: string): void { if (name !== this.selected) { this.selected = name; this.onRelease(); } }

  // ---- filtering ----
  get devOptions(): string[] {
    const all = this.subjectsPage?.content ?? [];
    return Array.from(new Set(all.map(s => s.developerName))).sort();
  }
  get statusOptions(): string[] {
    const all = this.subjectsPage?.content ?? [];
    return Array.from(new Set(all.map(s => s.status))).sort();
  }
  get filteredSubjects(): Subject[] {
    let list = this.subjectsPage?.content ?? [];
    const q = this.filterText.trim().toLowerCase();
    if (q) list = list.filter(s =>
      s.key.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) ||
      s.developerName.toLowerCase().includes(q) || s.reporterName.toLowerCase().includes(q) ||
      s.developerEmail.toLowerCase().includes(q));
    if (this.filterStatus) list = list.filter(s => s.status === this.filterStatus);
    if (this.filterDev) list = list.filter(s => s.developerName === this.filterDev);
    if (this.filterReadiness === 'ready') list = list.filter(s => s.readiness.missingCount === 0);
    if (this.filterReadiness === 'gaps') list = list.filter(s => s.readiness.missingCount > 0);
    return list;
  }
  clearFilters(): void { this.filterText = ''; this.filterStatus = ''; this.filterReadiness = ''; this.filterDev = ''; }
  get hasFilters(): boolean { return !!(this.filterText || this.filterStatus || this.filterReadiness || this.filterDev); }

  // dropdown option lists
  get releaseOptions(): DropdownOption[] {
    return this.releases.map(r => ({
      value: r.name, label: r.name,
      tag: r.released ? 'shipped' : 'active', tagLive: !r.released,
    }));
  }
  get statusFilterOptions(): DropdownOption[] {
    return [{ value: '', label: 'All status' }, ...this.statusOptions.map(s => ({ value: s, label: s }))];
  }
  get readinessFilterOptions(): DropdownOption[] {
    return [
      { value: '', label: 'All readiness' },
      { value: 'ready', label: 'Ready' },
      { value: 'gaps', label: 'Has gaps' },
    ];
  }
  get devFilterOptions(): DropdownOption[] {
    return [{ value: '', label: 'All developers' }, ...this.devOptions.map(d => ({ value: d, label: d }))];
  }

  nextPage(): void { if (this.subjectsPage && this.page + 1 < this.totalPages) { this.page++; this.loadSubjects(); } }
  prevPage(): void { if (this.page > 0) { this.page--; this.loadSubjects(); } }
  goPage(p: number): void { this.page = p; this.loadSubjects(); }
  get totalPages(): number { return this.subjectsPage ? Math.ceil(this.subjectsPage.totalElements / this.size) : 0; }
  get pageNumbers(): number[] { return Array.from({ length: this.totalPages }, (_, i) => i); }
  get selRelease(): Release | undefined { return this.releases.find(r => r.name === this.selected); }

  sendMail(s: Subject): void {
    this.sendingKey = s.key;
    this.api.sendMail(this.selected, s.key).subscribe(r => { this.sendingKey = ''; this.flash('Email queued for ' + s.developerName + ' + reporter'); });
  }
  mailAll(): void { this.mailingAll = true; this.api.mailAll(this.selected).subscribe(r => { this.mailingAll = false; this.flash('Queued ' + r.sent + ' email(s) to developers with gaps'); }); }
  mailSummary(): void { this.api.mailSummary(this.selected).subscribe(r => this.flash(r.status)); }

  missingLabels(s: Subject): string[] { return s.readiness.missing.map(m => this.artifactLabels[m] ?? m); }
  statusClass(st: string): string {
    return st === 'ACTIVE' ? 's-active' : st === 'DUE_SOON' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : 's-active';
  }
  gradeClass(g?: string): string { return g === 'EXCELLENT' ? 'g-ex' : g === 'GOOD' ? 'g-gd' : g === 'AT_RISK' ? 'g-rk' : g === 'CRITICAL' ? 'g-cr' : 'g-gd'; }
  msClass(st: string): string { return st === 'ACTIVE' ? 's-active' : st === 'DUE_SOON' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : 's-up'; }
  msTag(st: string): string { return st === 'ACTIVE' ? 'today' : st === 'DUE_SOON' ? 'soon' : st === 'OVERDUE' ? 'overdue' : st === 'DONE' ? 'done' : 'upcoming'; }
  gradeLabel(g?: string): string { return g === 'EXCELLENT' ? 'Excellent' : g === 'GOOD' ? 'Good' : g === 'AT_RISK' ? 'At risk' : g === 'CRITICAL' ? 'Critical' : '—'; }

  sysDot(st: string): string { return st === 'UP' ? 'dot-ok' : st === 'DOWN' ? 'dot-bad' : st === 'DEGRADED' ? 'dot-warn' : st === 'NOT_CONFIGURED' ? 'dot-mock' : 'dot-info'; }
  sysLabel(st: string): string { return st === 'UP' ? 'Live' : st === 'DOWN' ? 'Down' : st === 'DEGRADED' ? 'Degraded' : st === 'NOT_CONFIGURED' ? 'Off' : 'Mock'; }
  sysBadgeStyle(st: string): any {
    const map: any = { UP: ['var(--ok-dim)', 'var(--ok)'], DOWN: ['var(--bad-dim)', 'var(--bad)'], DEGRADED: ['var(--warn-dim)', 'var(--warn)'], MOCK: ['var(--info-dim)', 'var(--info)'], NOT_CONFIGURED: ['var(--chip)', 'var(--muted)'] };
    const c = map[st] || map['MOCK']; return { background: c[0], color: c[1] };
  }

  readyPct(): number { return this.summary && this.summary.totalSubjects ? Math.round(this.summary.ready / this.summary.totalSubjects * 100) : 0; }

  // ---- config editing ----
  cfgFor(key: string): SubjectCheckConfig {
    return this.checks?.overrides[key] ?? this.checks?.default ?? { octaneEnvironments: ENVS, bcmEndToEnd: false, skipSharePoint: [], note: '' };
  }
  get cfgKeys(): string[] { return this.checks ? Object.keys(this.checks.overrides) : []; }

  toggleEnv(key: string, env: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.octaneEnvironments = cfg.octaneEnvironments.includes(env) ? cfg.octaneEnvironments.filter(e => e !== env) : [...cfg.octaneEnvironments, env];
    this.saveCfg(key, cfg);
  }
  toggleBcm(key: string): void { const cfg = { ...this.cfgFor(key) }; cfg.bcmEndToEnd = !cfg.bcmEndToEnd; this.saveCfg(key, cfg); }
  toggleSkip(key: string, item: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.skipSharePoint = cfg.skipSharePoint.includes(item) ? cfg.skipSharePoint.filter(s => s !== item) : [...cfg.skipSharePoint, item];
    this.saveCfg(key, cfg);
  }
  private saveCfg(key: string, cfg: SubjectCheckConfig): void {
    if (this.checks) this.checks.overrides[key] = cfg;
    this.api.putCheck(key, cfg).subscribe(() => this.flash('Saved check config for ' + key));
  }

  private flash(m: string): void { this.toast = m; setTimeout(() => { if (this.toast === m) this.toast = ''; }, 3000); }

  private renderCharts(): void {
    if (!this.summary) return;
    const text = this.theme === 'dark' ? '#8A93A4' : '#6A7488';
    const grid = this.theme === 'dark' ? 'rgba(255,255,255,.06)' : 'rgba(17,24,39,.06)';
    const pal = ['#00A36F', '#3E63DD', '#D98E04', '#6E56CF', '#E5484D', '#12A594', '#E93D82', '#5B6472'];
    if (this.devChartRef) {
      this.devChart?.destroy();
      const d = this.summary.developerDistribution;
      this.devChart = new Chart(this.devChartRef.nativeElement, {
        type: 'doughnut',
        data: { labels: d.map(x => x.developer), datasets: [{ data: d.map(x => x.subjectCount), backgroundColor: pal, borderWidth: 0, hoverOffset: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '68%',
          plugins: { legend: { position: 'right', labels: { boxWidth: 9, boxHeight: 9, font: { size: 11 }, color: text, usePointStyle: true, pointStyle: 'circle' } } } },
      });
    }
    if (this.readyChartRef) {
      this.readyChart?.destroy();
      const b = this.summary.readinessBreakdown;
      this.readyChart = new Chart(this.readyChartRef.nativeElement, {
        type: 'bar',
        data: { labels: ['Octane', 'SharePoint'], datasets: [
          { label: 'Ready', data: [b.octaneOk, b.sharepointOk], backgroundColor: '#00A36F', borderRadius: 5, barPercentage: 0.55 },
          { label: 'Missing', data: [b.octaneMissing, b.sharepointMissing], backgroundColor: '#E5484D', borderRadius: 5, barPercentage: 0.55 } ] },
        options: { responsive: true, maintainAspectRatio: false,
          scales: { x: { stacked: true, grid: { display: false }, ticks: { color: text, font: { size: 11 } } },
                    y: { stacked: true, beginAtZero: true, grid: { color: grid }, ticks: { color: text, font: { size: 10 } } } },
          plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, boxHeight: 9, font: { size: 11 }, color: text, usePointStyle: true, pointStyle: 'circle' } } } },
      });
    }
  }
}
