import { Component, EventEmitter, HostListener, Input, Output, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

export interface DropdownOption {
  value: string;
  label: string;
  tag?: string;        // optional small tag on the right (e.g. "shipped")
  tagLive?: boolean;   // green "active" style tag
}

/**
 * One modern dropdown used everywhere (release picker + all filters) so every
 * dropdown looks identical. Features:
 *  - solid menu above content (no transparency bleed), high z-index
 *  - auto-fits the full option text (menu width follows the widest option)
 *  - built-in search box (shown when there are more than `searchThreshold`
 *    options, or when `searchable` is forced)
 */
@Component({
  selector: 'app-dropdown',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="dd" [class.open]="open" [class.dd-block]="block">
      <button type="button" class="dd-btn" (click)="toggle($event)" [style.min-width.px]="minWidth">
        <span class="dd-lab" *ngIf="label">{{ label }}</span>
        <span class="dd-val" [class.mono]="mono" [title]="selectedLabel">{{ selectedLabel }}</span>
        <svg class="dd-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="dd-menu" *ngIf="open">
        <div class="dd-search" *ngIf="showSearch">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-3.5-3.5"/></svg>
          <input #searchBox type="text" [(ngModel)]="query" (click)="$event.stopPropagation()"
                 placeholder="Search…" />
        </div>
        <div class="dd-list">
          <button type="button" class="dd-item" *ngFor="let o of visibleOptions"
                  [class.sel]="o.value === value" (click)="choose(o)" [title]="o.label">
            <span class="dd-item-label" [class.mono]="mono">{{ o.label }}</span>
            <span class="dd-item-tag" *ngIf="o.tag" [class.live]="o.tagLive">{{ o.tag }}</span>
            <svg class="dd-check" *ngIf="o.value === value" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
          </button>
          <div class="dd-empty" *ngIf="visibleOptions.length === 0">No matches</div>
        </div>
      </div>
    </div>
  `,
})
export class DropdownComponent implements AfterViewChecked {
  @Input() options: DropdownOption[] = [];
  @Input() value = '';
  @Input() label = '';
  @Input() placeholder = 'Select';
  @Input() mono = false;
  @Input() block = false;        // full-width trigger (filters)
  @Input() minWidth = 0;
  @Input() searchable: boolean | null = null;  // null = auto
  @Input() searchThreshold = 6;
  @Output() valueChange = new EventEmitter<string>();

  @ViewChild('searchBox') searchBox?: ElementRef<HTMLInputElement>;

  open = false;
  query = '';
  private focusPending = false;

  constructor(private host: ElementRef) {}

  get selectedLabel(): string {
    const found = this.options.find(o => o.value === this.value);
    return found ? found.label : this.placeholder;
  }

  get showSearch(): boolean {
    if (this.searchable !== null) return this.searchable;
    return this.options.length > this.searchThreshold;
  }

  get visibleOptions(): DropdownOption[] {
    const q = this.query.trim().toLowerCase();
    if (!q) return this.options;
    return this.options.filter(o => o.label.toLowerCase().includes(q));
  }

  toggle(e: MouseEvent): void {
    e.stopPropagation();
    this.open = !this.open;
    if (this.open) { this.query = ''; this.focusPending = true; }
  }
  choose(o: DropdownOption): void {
    this.open = false;
    if (o.value !== this.value) this.valueChange.emit(o.value);
  }

  ngAfterViewChecked(): void {
    if (this.focusPending && this.searchBox) {
      this.searchBox.nativeElement.focus();
      this.focusPending = false;
    }
  }

  @HostListener('document:click', ['$event'])
  onDoc(e: MouseEvent): void {
    if (this.open && !this.host.nativeElement.contains(e.target)) this.open = false;
  }
}
