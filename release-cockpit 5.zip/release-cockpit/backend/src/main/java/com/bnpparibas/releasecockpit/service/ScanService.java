package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.connector.ReleaseDataConnector;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Background scan + cache for the (slow) per-release readiness scan
 * (Jira subjects + Octane + SharePoint).
 *
 * Goals:
 *  - The dashboard NEVER blocks on a live scan. API reads return whatever is in
 *    cache instantly (possibly empty on first hit), and a background scan fills
 *    it in. Subsequent reads are instant.
 *  - Switching tabs/releases re-uses the cache; it does NOT re-scan.
 *  - The UI can show "last checked" and "next check" per release.
 *  - A single release scan runs at most once at a time (no stampede).
 */
@Slf4j
@Service
public class ScanService {

    public record ScanState(List<Subject> subjects, Instant lastChecked,
                            Instant nextCheck, boolean scanning) {}

    private final ReleaseDataConnector connector;
    private final Map<String, ScanState> cache = new ConcurrentHashMap<>();
    private final Map<String, Boolean> inFlight = new ConcurrentHashMap<>();
    private final ExecutorService pool = Executors.newFixedThreadPool(3);

    /** How long a cached scan is considered fresh (ms). Default 10 min. */
    private final long ttlMs = 10 * 60 * 1000L;

    public ScanService(ReleaseDataConnector connector) {
        this.connector = connector;
    }

    /**
     * Returns cached subjects immediately. If nothing is cached yet, kicks off a
     * background scan and returns an empty list (UI shows a loader). If the cache
     * is stale, returns stale data AND refreshes in the background.
     */
    public List<Subject> getSubjects(String releaseName) {
        ScanState st = cache.get(releaseName);
        if (st == null) {
            triggerScan(releaseName);
            return List.of();
        }
        if (isStale(st)) triggerScan(releaseName);
        return st.subjects();
    }

    /** Cached state for the UI (last/next check, scanning flag). */
    public ScanState state(String releaseName) {
        ScanState st = cache.get(releaseName);
        if (st == null) {
            return new ScanState(List.of(), null, null, Boolean.TRUE.equals(inFlight.get(releaseName)));
        }
        return st;
    }

    /** Force a background refresh (e.g. the Refresh button). */
    public void refresh(String releaseName) {
        cache.remove(releaseName);
        triggerScan(releaseName);
    }

    /** Re-scan a single subject only (used by Check config when one changes). */
    public void rescanSubject(String releaseName, String subjectKey) {
        // The connector scans per release; re-scan the release in the background
        // but only if not already running. (A true single-subject API would need
        // connector support; this keeps it cheap by reusing the in-flight guard.)
        triggerScan(releaseName);
    }

    private boolean isStale(ScanState st) {
        return st.lastChecked() == null
                || st.lastChecked().plusMillis(ttlMs).isBefore(Instant.now());
    }

    private void triggerScan(String releaseName) {
        if (inFlight.putIfAbsent(releaseName, Boolean.TRUE) != null) {
            return; // a scan for this release is already running
        }
        // mark scanning in the visible state
        ScanState prev = cache.get(releaseName);
        cache.put(releaseName, new ScanState(
                prev == null ? List.of() : prev.subjects(),
                prev == null ? null : prev.lastChecked(),
                prev == null ? null : prev.nextCheck(), true));
        pool.submit(() -> {
            long t0 = System.currentTimeMillis();
            try {
                List<Subject> subjects = connector.listSubjects(releaseName);
                Instant now = Instant.now();
                cache.put(releaseName, new ScanState(subjects, now, now.plusMillis(ttlMs), false));
                log.info("Scan {} complete: {} subjects in {} ms",
                        releaseName, subjects.size(), System.currentTimeMillis() - t0);
            } catch (Exception e) {
                log.warn("Scan {} failed: {}", releaseName, e.getMessage());
                ScanState p = cache.get(releaseName);
                cache.put(releaseName, new ScanState(
                        p == null ? List.of() : p.subjects(),
                        p == null ? null : p.lastChecked(),
                        p == null ? null : p.nextCheck(), false));
            } finally {
                inFlight.remove(releaseName);
            }
        });
    }
}
