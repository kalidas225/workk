package com.bnpparibas.releasecockpit.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Loads per-release checkpoint date overrides (checkpoint-overrides.json).
 * Dates are auto-computed from the release date; this lets PPD dates be
 * corrected without code changes when they shift.
 */
@Slf4j
@Service
public class CheckpointOverrideService {

    private static final String RESOURCE = "checkpoint-overrides.json";
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, Map<String, LocalDate>> byRelease = new HashMap<>();

    public CheckpointOverrideService() {
        load();
    }

    private void load() {
        try {
            JsonNode root;
            File external = new File("config/" + RESOURCE);
            if (external.exists()) {
                root = mapper.readTree(external);
            } else {
                try (InputStream is = new ClassPathResource(RESOURCE).getInputStream()) {
                    root = mapper.readTree(is);
                }
            }
            JsonNode releases = root.path("releases");
            releases.fieldNames().forEachRemaining(rel -> {
                Map<String, LocalDate> dates = new HashMap<>();
                JsonNode node = releases.path(rel);
                node.fieldNames().forEachRemaining(k -> {
                    try { dates.put(k, LocalDate.parse(node.path(k).asText())); }
                    catch (Exception ignore) {}
                });
                byRelease.put(rel, dates);
            });
            log.info("Loaded checkpoint overrides for {} release(s)", byRelease.size());
        } catch (Exception e) {
            log.warn("No checkpoint overrides loaded: {}", e.getMessage());
        }
    }

    public Map<String, LocalDate> forRelease(String releaseName) {
        return byRelease.getOrDefault(releaseName, Map.of());
    }
}
