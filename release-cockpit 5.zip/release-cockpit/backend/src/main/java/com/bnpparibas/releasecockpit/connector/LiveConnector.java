package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8))
            .version(HttpClient.Version.HTTP_1_1)
            .build();

    public LiveConnector(CockpitProperties props) {
        this.props = props;
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl()) || isBlank(j.getProjectKeys())) {
            log.warn("Jira not configured (base-url/project-keys); returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();
        try {
            for (String project : j.getProjectKeys().split(",")) {
                project = project.trim();
                if (project.isEmpty()) continue;
                String body = getJira("/rest/api/2/project/" + project + "/versions");
                if (body == null) continue;
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        String rd = v.path("releaseDate").asText(null);
                        boolean released = v.path("released").asBoolean(false);
                        LocalDate date = rd != null ? safeDate(rd) : null;
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                }
            }
        } catch (Exception e) {
            log.warn("listReleases failed gracefully: {}", e.getMessage());
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String url = "/rest/api/2/search?jql=" + enc(jql)
                    + "&maxResults=200&fields=summary,status,assignee,reporter,created,"
                    + (j.getOctaneLinkField() == null ? "" : j.getOctaneLinkField());
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                String dev = f.path("assignee").path("displayName").asText("");
                String devEmail = f.path("assignee").path("emailAddress").asText("");
                String rep = f.path("reporter").path("displayName").asText("");
                String repEmail = f.path("reporter").path("emailAddress").asText("");
                LocalDate created = safeDate(f.path("created").asText("").replaceAll("T.*", ""));
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                // Readiness checks (Octane/SharePoint) are the pending Release
                // Guardian port. Until ported, report unverified (false) so gaps
                // are visible — never crash.
                Readiness r = unverifiedReadiness(octaneIds);
                out.add(new Subject(key, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        dev, devEmail, rep, repEmail, created, octaneIds, r));
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- helpers ----
    private Readiness unverifiedReadiness(List<String> octaneIds) {
        List<String> missing = new ArrayList<>(List.of(
                "OCTANE_TESTS_LINKED", "PR", "UNIT_TEST", "ESTIMATION_SHEET",
                "PR_EXCEL", "OCTANE_REVIEW_DOC", "OCTANE_EXECUTION_DOC"));
        return new Readiness(false, false, false, false, false, false, false,
                missing.size(), missing);
    }

    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(12)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
