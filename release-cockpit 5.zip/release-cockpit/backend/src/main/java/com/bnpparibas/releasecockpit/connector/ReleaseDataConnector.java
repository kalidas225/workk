package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;

import java.util.List;

/**
 * The data-source contract. Two implementations:
 *   - MockConnector (default; in-memory demo data so the app runs with no creds)
 *   - LiveConnector (calls Jira/Octane/SharePoint; ported from Release Guardian)
 *
 * Selected by the cockpit.mock-mode flag.
 */
public interface ReleaseDataConnector {

    /** All releases (Jira fixVersions) configured for the year. */
    List<Release> listReleases();

    /** Subjects (epics) tagged for a given release, with readiness resolved. */
    List<Subject> listSubjects(String releaseName);
}
