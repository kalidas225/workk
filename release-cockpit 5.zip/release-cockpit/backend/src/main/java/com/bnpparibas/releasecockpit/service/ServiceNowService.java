package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ServiceNowTicket;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;

/**
 * Fetches ServiceNow tickets linked to a release.
 *
 *   - Mock mode (or not enabled): returns deterministic demo tickets.
 *   - Live: queries the ServiceNow Table API filtered by the release field.
 *       GET /api/now/table/{table}?sysparm_query={releaseField}={release}
 *
 * Uses the JDK HttpClient (no Spring WebFlux dependency).
 */
@Slf4j
@Service
public class ServiceNowService {

    private final CockpitProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;

    public ServiceNowService(CockpitProperties props,
                             com.bnpparibas.releasecockpit.connector.HttpClientFactory clients) {
        this.props = props;
        // ServiceNow is typically reached via the corporate proxy (SaaS/instance).
        this.http = clients.proxied();
    }

    public boolean isEnabled() {
        return props.getServicenow().isEnabled();
    }

    public List<ServiceNowTicket> ticketsForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockTickets(releaseName);
        }
        try {
            String basic = Base64.getEncoder()
                    .encodeToString((nz(sn.getUsername()) + ":" + nz(sn.getPassword())).getBytes());
            String query = URLEncoder.encode(sn.getReleaseField() + "=" + releaseName, StandardCharsets.UTF_8);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(sn.getBaseUrl() + "/api/now/table/" + sn.getTable()
                            + "?sysparm_query=" + query + "&sysparm_limit=50"))
                    .header("Authorization", "Basic " + basic)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(12)).GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow returned HTTP {}", resp.statusCode());
                return List.of();
            }
            return parse(resp.body(), sn.getBaseUrl(), sn.getTable());
        } catch (Exception e) {
            log.error("ServiceNow fetch failed: {}", e.getMessage());
            return List.of();
        }
    }

    private List<ServiceNowTicket> parse(String json, String baseUrl, String table) {
        List<ServiceNowTicket> out = new ArrayList<>();
        try {
            JsonNode result = mapper.readTree(json).path("result");
            for (JsonNode r : result) {
                String sysId = r.path("sys_id").asText("");
                out.add(new ServiceNowTicket(
                        r.path("number").asText(""),
                        r.path("short_description").asText(""),
                        r.path("state").asText(""),
                        r.path("priority").asText(""),
                        r.path("assigned_to").path("display_value").asText(
                                r.path("assigned_to").asText("")),
                        table,
                        baseUrl + "/nav_to.do?uri=" + table + ".do?sys_id=" + sysId));
            }
        } catch (Exception e) {
            log.error("ServiceNow parse failed: {}", e.getMessage());
        }
        return out;
    }

    // Deterministic demo tickets per release.
    private List<ServiceNowTicket> mockTickets(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x5A17);
        String[] states = {"New", "Assess", "Authorize", "Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"1 - Critical", "2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Srinivasan Nagarajan", "Selvakumar C",
                "Kameshwaran Pandi", "Akhila Gowrishankar"};
        String[] descs = {
                "Production deployment for release " + releaseName,
                "Database schema migration", "Firewall rule change for new endpoints",
                "Config rollout to UAT", "Certificate renewal", "Load balancer update",
                "Batch job schedule change", "Rollback plan validation"
        };
        int n = 3 + rng.nextInt(5);
        List<ServiceNowTicket> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(new ServiceNowTicket(
                    String.format("CHG%07d", 30000 + rng.nextInt(9999)),
                    descs[rng.nextInt(descs.length)],
                    states[rng.nextInt(states.length)],
                    prios[rng.nextInt(prios.length)],
                    devs[rng.nextInt(devs.length)],
                    "change_request",
                    "#"));
        }
        return out;
    }

    private String nz(String s) { return s == null ? "" : s; }
}
