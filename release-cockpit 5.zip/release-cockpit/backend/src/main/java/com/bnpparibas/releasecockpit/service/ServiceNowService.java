package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ServiceNowTicket;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ServiceNow integration for BNP's API gateway.
 *
 * Ported from the working standalone service: OAuth2 client-credentials
 * (consumer key/secret -> bearer token) against a token endpoint, then calls
 * the gateway's /changes and /changes/{number} endpoints. Separate credentials
 * for the changes and attachments APIs, each token cached until expiry.
 *
 *   - Mock mode (or not enabled): returns deterministic demo tickets.
 *   - Live: OAuth2 token -> GET {baseUrl}/changes?sysparm_query=...
 *
 * Uses the JDK HttpClient via HttpClientFactory.proxied() so the corporate
 * proxy (with Basic proxy auth) is applied automatically.
 */
@Slf4j
@Service
public class ServiceNowService {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final CockpitProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;

    /** Cached OAuth2 tokens keyed by "changes" / "attachments". */
    private final ConcurrentHashMap<String, TokenWithExpiry> tokenCache = new ConcurrentHashMap<>();

    public ServiceNowService(CockpitProperties props,
                             com.bnpparibas.releasecockpit.connector.HttpClientFactory clients) {
        this.props = props;
        this.http = clients.proxied();
    }

    public boolean isEnabled() {
        return props.getServicenow().isEnabled();
    }

    // ---- token handling -----------------------------------------------------

    private record TokenWithExpiry(String token, long expiresAt) {
        boolean isExpired() { return System.currentTimeMillis() >= expiresAt; }
    }

    /** OAuth2 client-credentials token for the given API ("changes" or "attachments"). */
    private synchronized String getAccessToken(String api) {
        var sn = props.getServicenow();
        var oauth = "attachments".equals(api) ? sn.getAttachments() : sn.getChanges();
        String cacheKey = api;

        TokenWithExpiry cached = tokenCache.get(cacheKey);
        if (cached != null && !cached.isExpired()) return cached.token();

        try {
            String creds = oauth.getConsumerKey() + ":" + oauth.getConsumerSecret();
            String encoded = Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8));
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(sn.getTokenUrl()))
                    .header("Authorization", "Basic " + encoded)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString("grant_type=client_credentials"))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow token endpoint HTTP {} for {} — body: {}",
                        resp.statusCode(), api, resp.body());
                throw new RuntimeException("Token request failed: HTTP " + resp.statusCode());
            }
            JsonNode body = mapper.readTree(resp.body());
            String token = body.path("access_token").asText("");
            if (token.isBlank()) throw new RuntimeException("No access_token in token response");
            long expiresIn = body.path("expires_in").asLong(300);
            long expiresAt = System.currentTimeMillis() + (expiresIn - 60) * 1000; // 60s buffer
            tokenCache.put(cacheKey, new TokenWithExpiry(token, expiresAt));
            log.info("ServiceNow {} token obtained (expires in {}s)", api, expiresIn);
            return token;
        } catch (Exception e) {
            log.error("ServiceNow {} token error: {}", api, e.getMessage());
            throw new RuntimeException("ServiceNow token error: " + e.getMessage(), e);
        }
    }

    public void clearTokenCache() { tokenCache.clear(); }

    // ---- HTTP with 401 self-heal -------------------------------------------

    private HttpResponse<String> getWithAuth(String api, String url) throws Exception {
        String token = getAccessToken(api);
        HttpResponse<String> resp = doGet(url, token);
        if (resp.statusCode() == 401) {
            log.info("ServiceNow 401 on {} — refreshing token and retrying", api);
            tokenCache.remove(api);
            token = getAccessToken(api);
            resp = doGet(url, token);
        }
        return resp;
    }

    private HttpResponse<String> doGet(String url, String token) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .timeout(Duration.ofSeconds(20)).GET().build();
        return http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    // ---- release ticket listing (used by the dashboard) --------------------

    public List<ServiceNowTicket> ticketsForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockTickets(releaseName);
        }
        try {
            // Filter changes by the release field when configured; otherwise return
            // recent changes for the environment. The gateway expects an UNencoded
            // encoded-query in sysparm_query (URL-encoded once).
            String query = (sn.getReleaseField() != null && !sn.getReleaseField().isBlank())
                    ? sn.getReleaseField() + "=" + releaseName
                    : "u_environment=" + sn.getEnvironment();
            String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                    + "start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=50";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow /changes HTTP {}", resp.statusCode());
                return List.of();
            }
            return parse(resp.body(), sn.getBaseUrl());
        } catch (Exception e) {
            log.error("ServiceNow fetch failed: {}", e.getMessage());
            return List.of();
        }
    }

    /** Fetch a single change by its number (e.g. CHG0045821). */
    public String getChangeDetails(String changeNumber) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) return "{}";
        try {
            String query = "number=" + changeNumber;
            String fields = "sys_id,number,short_description,description,state,priority,risk,impact,"
                    + "assignment_group,assigned_to,start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=1";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow change-details HTTP {}", resp.statusCode());
                return "{}";
            }
            JsonNode root = mapper.readTree(resp.body()).path("result");
            if (root.isArray() && root.size() > 0) return mapper.writeValueAsString(root.get(0));
            return "{}";
        } catch (Exception e) {
            log.error("ServiceNow change-details failed: {}", e.getMessage());
            return "{}";
        }
    }

    // ---- release changes grouped by env + linked incidents/problems ---------

    /**
     * All ServiceNow records for a release. Changes are matched by the release key
     * appearing in short_description (this instance's naming convention), then
     * bucketed into PPD-1 / PPD-2 / Prod. Incidents and problems linked to those
     * changes (caused-by) are also returned, for display after the Prod release.
     */
    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges changesForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockReleaseChanges(releaseName);
        }
        try {
            String query = "short_descriptionLIKE" + releaseName;
            String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                    + "start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=200";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow /changes HTTP {} for release {}", resp.statusCode(), releaseName);
                return empty(true);
            }
            List<ServiceNowTicket> all = parse(resp.body(), sn.getBaseUrl());

            List<ServiceNowTicket> ppd1 = new ArrayList<>();
            List<ServiceNowTicket> ppd2 = new ArrayList<>();
            List<ServiceNowTicket> prod = new ArrayList<>();
            List<String> changeNumbers = new ArrayList<>();
            for (ServiceNowTicket t : all) {
                changeNumbers.add(t.number());
                switch (t.env()) {
                    case "PPD1" -> ppd1.add(t);
                    case "PPD2" -> ppd2.add(t);
                    default -> prod.add(t); // PROD or unknown -> Prod bucket
                }
            }

            List<ServiceNowTicket> incidents = linkedRecords("incidents", changeNumbers, sn);
            List<ServiceNowTicket> problems = linkedRecords("problems", changeNumbers, sn);

            log.info("ServiceNow release {} -> {} changes (PPD1={} PPD2={} PROD={}), {} incidents, {} problems",
                    releaseName, all.size(), ppd1.size(), ppd2.size(), prod.size(), incidents.size(), problems.size());
            return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                    ppd1, ppd2, prod, incidents, problems, true);
        } catch (Exception e) {
            log.error("ServiceNow changesForRelease failed: {}", e.getMessage());
            return empty(true);
        }
    }

    /** Incidents/problems linked to the release's changes via caused-by. */
    private List<ServiceNowTicket> linkedRecords(String api, List<String> changeNumbers,
                                                 CockpitProperties.ServiceNow sn) {
        if (changeNumbers.isEmpty()) return List.of();
        try {
            String type = "incidents".equals(api) ? "incident" : "problem";
            String query = "caused_byIN" + String.join(",", changeNumbers);
            String fields = "sys_id,number,short_description,state,priority,assigned_to,caused_by,rfc";
            String url = sn.getBaseUrl() + "/" + api
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=100";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.warn("ServiceNow /{} HTTP {}", api, resp.statusCode());
                return List.of();
            }
            List<ServiceNowTicket> out = new ArrayList<>();
            JsonNode result = mapper.readTree(resp.body()).path("result");
            for (JsonNode r : result) {
                out.add(new ServiceNowTicket(
                        dv(r, "number"), dv(r, "short_description"), dv(r, "state"),
                        dv(r, "priority"), dv(r, "assigned_to"), type,
                        sn.getBaseUrl() + "/" + api + "/" + dv(r, "number"), ""));
            }
            return out;
        } catch (Exception e) {
            log.warn("ServiceNow linked {} fetch failed: {}", api, e.getMessage());
            return List.of();
        }
    }

    /** Derives the environment bucket from a change's env field / description. */
    private String deriveEnv(String environment, String shortDesc) {
        String s = ((environment == null ? "" : environment) + " " + (shortDesc == null ? "" : shortDesc)).toLowerCase();
        if (s.contains("ppd-1") || s.contains("ppd1") || s.contains("ppd 1")) return "PPD1";
        if (s.contains("ppd-2") || s.contains("ppd2") || s.contains("ppd 2")) return "PPD2";
        if (s.contains("prod") || s.contains("production")) return "PROD";
        return "";
    }

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges empty(boolean enabled) {
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                List.of(), List.of(), List.of(), List.of(), List.of(), enabled);
    }

    private List<ServiceNowTicket> parse(String json, String baseUrl) {
        List<ServiceNowTicket> out = new ArrayList<>();
        try {
            JsonNode result = mapper.readTree(json).path("result");
            for (JsonNode r : result) {
                String shortDesc = dv(r, "short_description");
                String env = deriveEnv(dv(r, "u_environment"), shortDesc);
                out.add(new ServiceNowTicket(
                        dv(r, "number"),
                        shortDesc,
                        dv(r, "state"),
                        dv(r, "priority"),
                        dv(r, "assigned_to"),
                        "change_request",
                        baseUrl + "/changes/" + dv(r, "number"),
                        env));
            }
        } catch (Exception e) {
            log.error("ServiceNow parse failed: {}", e.getMessage());
        }
        return out;
    }

    /**
     * Reads a field that may be a plain string OR a display-value object
     * {"display_value": "...", "value": "..."} (sysparm_display_value=all).
     */
    private String dv(JsonNode node, String field) {
        JsonNode f = node.path(field);
        if (f.isObject()) return f.path("display_value").asText(f.path("value").asText(""));
        return f.asText("");
    }

    // ---- demo data ----------------------------------------------------------

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges mockReleaseChanges(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x33CE);
        String[] states = {"Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Selvakumar C", "Kameshwaran Pandi"};
        java.util.function.BiFunction<String, String, ServiceNowTicket> mk = (env, desc) ->
                new ServiceNowTicket(
                        String.format("CHG%07d", 40000 + rng.nextInt(9999)),
                        desc + " " + releaseName,
                        states[rng.nextInt(states.length)],
                        prios[rng.nextInt(prios.length)],
                        devs[rng.nextInt(devs.length)],
                        "change_request", "#", env);
        List<ServiceNowTicket> ppd1 = List.of(mk.apply("PPD1", "PPD-1 deployment for"));
        List<ServiceNowTicket> ppd2 = List.of(mk.apply("PPD2", "PPD-2 deployment for"));
        List<ServiceNowTicket> prod = List.of(mk.apply("PROD", "Production rollout for"));
        List<ServiceNowTicket> incidents = List.of(new ServiceNowTicket(
                String.format("INC%07d", 20000 + rng.nextInt(9999)),
                "Post-release latency spike after " + releaseName,
                "In Progress", "2 - High", devs[0], "incident", "#", ""));
        List<ServiceNowTicket> problems = List.of(new ServiceNowTicket(
                String.format("PRB%07d", 10000 + rng.nextInt(9999)),
                "Root cause analysis for " + releaseName + " regression",
                "Assess", "3 - Moderate", devs[1], "problem", "#", ""));
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                ppd1, ppd2, prod, incidents, problems, true);
    }

    private List<ServiceNowTicket> mockTickets(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x5A17);
        String[] states = {"New", "Assess", "Authorize", "Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"1 - Critical", "2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Srinivasan Nagarajan", "Selvakumar C",
                "Kameshwaran Pandi", "Akhila Gowrishankar"};
        String[] descs = {
                "Production deployment for release " + releaseName,
                "Database schema migration", "Firewall rule change for new endpoints",
                "Config rollout to UAT", "Certificate renewal", "Load balancer update",
                "Batch job schedule change", "Rollback plan validation"
        };
        int n = 3 + rng.nextInt(5);
        List<ServiceNowTicket> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(new ServiceNowTicket(
                    String.format("CHG%07d", 30000 + rng.nextInt(9999)),
                    descs[rng.nextInt(descs.length)],
                    states[rng.nextInt(states.length)],
                    prios[rng.nextInt(prios.length)],
                    devs[rng.nextInt(devs.length)],
                    "change_request",
                    "#"));
        }
        return out;
    }
}
