package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.ProxySelector;
import java.net.http.HttpClient;
import java.security.cert.X509Certificate;
import java.time.Duration;

/**
 * Builds HttpClients for the connectors.
 *
 *  - direct():  no proxy (internal systems like Jira on the corporate network).
 *  - proxied(): routes through the corporate proxy with Basic proxy auth
 *               (for SaaS targets — Octane, SharePoint Online).
 *
 * TLS: when cockpit.proxy.trust-all-ssl=true (mirrors NODE_TLS_REJECT_UNAUTHORIZED=0)
 * an all-trusting SSLContext is installed so internal/self-signed certs and the
 * proxy's TLS interception don't cause PKIX path-building failures. For a
 * hardened setup, import the BNP CA into a truststore instead (see notes below).
 *
 * Proxy Basic auth over HTTPS CONNECT tunnels requires clearing the JDK's
 * disabled auth schemes, done once here.
 */
@Slf4j
@Component
public class HttpClientFactory {

    static {
        // Must be set before ANY java.net.http.HttpClient is created, because the
        // JDK reads this property once at class-init. Allows our explicit
        // Authorization header through when a proxy Authenticator is present.
        // (Belt-and-braces: also pass -Djdk.httpclient.allowRestrictedHeaders=Authorization
        // as a JVM arg if a client is somehow built earlier in the app.)
        String allowed = System.getProperty("jdk.httpclient.allowRestrictedHeaders", "");
        if (!allowed.toLowerCase().contains("authorization")) {
            System.setProperty("jdk.httpclient.allowRestrictedHeaders",
                    allowed.isBlank() ? "Authorization" : allowed + ",Authorization");
        }
    }

    private final CockpitProperties props;
    private final HttpClient direct;
    private final HttpClient proxied;

    public HttpClientFactory(CockpitProperties props) {
        this.props = props;
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        System.setProperty("jdk.http.auth.proxying.disabledSchemes", "");

        SSLContext ssl = props.getProxy().isTrustAllSsl() ? trustAllContext() : null;

        this.direct = base(ssl).build();

        var p = props.getProxy();
        if (p.isEnabled() && p.getHost() != null && !p.getHost().isBlank()) {
            HttpClient.Builder b = base(ssl)
                    .proxy(ProxySelector.of(new InetSocketAddress(p.getHost(), p.getPort())));
            if (p.getUser() != null && !p.getUser().isBlank()) {
                b.authenticator(new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        // Answer ONLY for the proxy, never for the target site
                        // (target auth is handled per-request via headers/cookies).
                        if (getRequestorType() == RequestorType.PROXY) {
                            return new PasswordAuthentication(p.getUser(),
                                    (p.getPass() == null ? "" : p.getPass()).toCharArray());
                        }
                        return null;
                    }
                });
            }
            this.proxied = b.build();
            log.info("HTTP: proxied client via {}:{} (trustAllSsl={})",
                    p.getHost(), p.getPort(), p.isTrustAllSsl());
        } else {
            this.proxied = this.direct;
            log.info("HTTP: no proxy configured; using direct client (trustAllSsl={})",
                    p.isTrustAllSsl());
        }
    }

    private HttpClient.Builder base(SSLContext ssl) {
        HttpClient.Builder b = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .version(HttpClient.Version.HTTP_1_1)
                // Do NOT follow redirects automatically — SharePoint/SSO 302s to
                // a login page otherwise look like success and mask 401s.
                .followRedirects(HttpClient.Redirect.NEVER);
        if (ssl != null) b.sslContext(ssl);
        return b;
    }

    /** All-trusting SSLContext. Use only on a trusted corporate network. */
    private SSLContext trustAllContext() {
        try {
            TrustManager[] tm = { new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }};
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, tm, new java.security.SecureRandom());
            // Also relax hostname verification for the default engine.
            javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier((h, s) -> true);
            log.warn("TLS: trust-all-ssl ENABLED — all server certificates accepted. "
                    + "For production, import the BNP CA into a truststore instead.");
            return ctx;
        } catch (Exception e) {
            log.error("Failed to build trust-all SSLContext: {}", e.getMessage());
            return null;
        }
    }

    public HttpClient direct() { return direct; }
    public HttpClient proxied() { return proxied; }
}
