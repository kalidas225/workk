package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.connector.HttpClientFactory;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sends HTML readiness emails.
 *
 * Two delivery paths:
 *   - EMA SMTP (default / production): JavaMailSender via EmailMessageFactory.
 *     Recipients = developer + reporter, managers CC'd.
 *   - SecuredMail REST API (local dev only): used when
 *     cockpit.mail.secured-mail-url is set. Recipients = the configured
 *     fallback address only, no CC (manual forwarding).
 *
 * The SecuredMail URL being present is what selects the local-dev path, so the
 * production EMA configuration stays untouched.
 */
@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final EmailMessageFactory factory;     // null if no JavaMailSender
    private final HttpClient http;                  // for SecuredMail REST
    private final ObjectMapper mapper = new ObjectMapper();
    private final String jiraBaseUrl;

    public MailService(CockpitProperties props,
                       ObjectProvider<JavaMailSender> mailSenderProvider,
                       HttpClientFactory clients) {
        this.props = props;
        JavaMailSender sender = mailSenderProvider.getIfAvailable();
        this.factory = (sender != null) ? new EmailMessageFactory(sender) : null;
        this.http = clients.proxied();
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
        if (useSecuredMail()) {
            log.info("Mail: using SecuredMail REST API (local-dev path) at {}",
                    props.getMail().getSecuredMailUrl());
        } else if (factory == null) {
            log.warn("Mail: no JavaMailSender and no SecuredMail URL — emails will be logged, not sent.");
        } else {
            log.info("Mail: using EMA SMTP relay (JavaMailSender).");
        }
    }

    private boolean useSecuredMail() {
        String url = props.getMail().getSecuredMailUrl();
        return url != null && !url.isBlank();
    }

    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        List<String> to = recipientsFor(subject);
        List<String> cc = ccList();
        String subjectLine = "[Release " + releaseName + "] Action needed on " + subject.key()
                + " - " + subject.readiness().missingCount() + " item(s) missing";
        String html = EmailTemplate.gapEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null && cp.ppdStart() != null ? cp.ppdStart().toString() : "",
                cp != null && cp.endUatDone() != null ? cp.endUatDone().toString() : "",
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key());
        return send(to, cc, subjectLine, html, "gap:" + subject.key());
    }

    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0) { sendSubjectAlert(releaseName, s, cp); sent++; }
        }
        return sent;
    }

    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = summaryRecipients();
        List<Subject> atRisk = subjects.stream()
                .filter(s -> s.readiness().missingCount() > 0)
                .sorted((a, b) -> b.readiness().missingCount() - a.readiness().missingCount())
                .toList();
        String subjectLine = "[Release " + releaseName + "] Status - " + health.grade()
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, atRisk);
        return send(to, List.of(), subjectLine, html, "summary:" + releaseName);
    }

    // ── recipients ─────────────────────────────────────────────────────────
    private List<String> recipientsFor(Subject s) {
        // Local-dev SecuredMail path: send only to the configured address.
        if (useSecuredMail()) return fallbackList();
        List<String> to = new ArrayList<>();
        if (s.developerEmail() != null && !s.developerEmail().isBlank()) to.add(s.developerEmail());
        if (s.reporterEmail() != null && !s.reporterEmail().isBlank()
                && !s.reporterEmail().equalsIgnoreCase(s.developerEmail())) to.add(s.reporterEmail());
        if (to.isEmpty()) to.addAll(fallbackList());
        return to;
    }

    private List<String> summaryRecipients() {
        if (useSecuredMail()) return fallbackList();
        List<String> to = new ArrayList<>();
        for (String m : props.getMail().getSummaryTo()) if (m != null && !m.isBlank()) to.add(m.trim());
        for (String m : props.getMail().getManagersCc()) if (m != null && !m.isBlank()) to.add(m.trim());
        if (to.isEmpty()) to.addAll(fallbackList());
        return to;
    }

    private List<String> ccList() {
        // No CC on the SecuredMail local-dev path.
        if (useSecuredMail()) return List.of();
        List<String> cc = new ArrayList<>();
        for (String m : props.getMail().getManagersCc()) if (m != null && !m.isBlank()) cc.add(m.trim());
        return cc;
    }

    private List<String> fallbackList() {
        List<String> to = new ArrayList<>();
        String fb = props.getMail().getFallbackTo();
        if (fb != null && !fb.isBlank()) for (String a : fb.split(",")) if (!a.isBlank()) to.add(a.trim());
        return to;
    }

    // ── delivery ───────────────────────────────────────────────────────────
    private String send(List<String> to, List<String> cc, String subjectLine, String html, String tag) {
        if (props.isMockMode()) {
            log.info("MOCK MAIL [{}] to={} cc={} subject='{}' ({} chars)", tag, to, cc, subjectLine, html.length());
            return "Simulated send to " + String.join(", ", to);
        }
        return useSecuredMail()
                ? sendViaSecuredMail(to, subjectLine, html, tag)
                : sendViaSmtp(to, cc, subjectLine, html, tag);
    }

    private String sendViaSmtp(List<String> to, List<String> cc, String subjectLine, String html, String tag) {
        if (factory == null) {
            log.warn("UNSENT MAIL [{}] (no JavaMailSender) to={} subject='{}'", tag, to, subjectLine);
            return "Mail not configured";
        }
        try {
            String from = props.getMail().getFromAddress();
            MimeMessage msg = factory.createMessage(from, props.getMail().getReplyTo(), to, cc, subjectLine, html);
            factory.send(msg);
            log.info("EMA sent [{}] from {} to {} (cc {})", tag, from, to, cc);
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("EMA send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String sendViaSecuredMail(List<String> to, String subjectLine, String html, String tag) {
        var mail = props.getMail();
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("FromEmail", mail.getFromAddress());
            payload.put("ToEmail", to);
            payload.put("CcEmail", List.of());
            payload.put("BccEmail", List.of());
            payload.put("Subject", subjectLine);
            payload.put("emailMessage", html);
            payload.put("Body", html);
            payload.put("ClientName", "Release Cockpit");
            payload.put("IsBodyHtml", true);
            String body = mapper.writeValueAsString(payload);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(mail.getSecuredMailUrl()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.error("SecuredMail [{}] HTTP {} body={}", tag, r.statusCode(), r.body());
                return "Send failed: HTTP " + r.statusCode();
            }
            log.info("SecuredMail sent [{}] to {} (HTTP {})", tag, to, r.statusCode());
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("SecuredMail send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String companyName() { return "BNP Paribas"; }
}
