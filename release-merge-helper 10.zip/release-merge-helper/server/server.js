// Release Merge Helper server — plain Node, zero dependencies.
// Load .env first so GITLAB_CA_FILE / GITLAB_INSECURE etc. are available everywhere.
require('./lib/loadEnv').loadEnv();
// GitLab config (URL, group, per-developer PAT) comes from request headers:
//   X-GitLab-Url, X-GitLab-Group, X-GitLab-Token
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const gs = require('./lib/gitService');
const disc = require('./lib/repoDiscovery');
const gl = require('./lib/gitlab');
const glApi = require('./lib/gitlabApi');
const { fixSqlFile } = require('./lib/sqlLint');

const PORT = process.env.PORT || 5173;
// Bind to 0.0.0.0 inside containers so the pod is reachable; override with HOST if needed.
const HOST = process.env.HOST || '0.0.0.0';
const DIST = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function send(res, code, body, type = 'application/json') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,X-GitLab-Url,X-GitLab-Group,X-GitLab-Token',
  });
  res.end(data);
}
function readBody(req) { return new Promise((resolve) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } }); }); }

// per-request GitLab context from headers
function ctxOf(req) {
  return {
    baseUrl: req.headers['x-gitlab-url'] || '',
    group: req.headers['x-gitlab-group'] || '',
    token: req.headers['x-gitlab-token'] || '',
  };
}

async function wt(ctx, repoKey, forWrite = false, target = null) {
  const lp = await disc.resolveWorkingTree(ctx, repoKey, forWrite, null, target);
  if (!lp) throw new gs.GitError(`Could not resolve a working copy for: ${repoKey}`);
  return lp;
}

// Group a flat commit list (from the GitLab compare API) by subject key, matching the shape
// the local-git commits() endpoint returns so the frontend is agnostic to the source.
function groupCommits(commits, source, target) {
  const withKeys = commits.map((c) => ({ ...c, subjectKey: gs.deriveSubjectKey(c.subject) }));
  const map = new Map();
  for (const c of withKeys) { if (!map.has(c.subjectKey)) map.set(c.subjectKey, []); map.get(c.subjectKey).push(c); }
  const groups = [...map.entries()].map(([key, cs]) => ({ key, count: cs.length, commits: cs }));
  return { source, target, total: commits.length, returned: commits.length, offset: 0, limit: 0, groups, via: 'api' };
}

// Convert a GitLab API diff (array of { diff, old_path, new_path, new_file, deleted_file,
// renamed_file }) into the { file, patch, additions, deletions, rows } shape the UI renders,
// reusing the same side-by-side row builder as the local-git path.
function normalizeApiDiff(apiFiles) {
  const files = [];
  for (const f of apiFiles || []) {
    const file = f.new_path || f.old_path;
    const patch = f.diff || '';
    let additions = 0, deletions = 0;
    for (const line of patch.split('\n')) {
      if (line.startsWith('+') && !line.startsWith('+++')) additions++;
      else if (line.startsWith('-') && !line.startsWith('---')) deletions++;
    }
    files.push({
      file, patch, additions, deletions,
      rows: gs.toSideBySide(patch),
      binary: /Binary files/.test(patch) || (!patch && !f.new_file && !f.deleted_file),
      newFile: !!f.new_file, deletedFile: !!f.deleted_file, renamedFile: !!f.renamed_file,
      oldPath: f.old_path, newPath: f.new_path,
    });
  }
  return files;
}

const routes = {
  'POST /api/gitlab/check': async (ctx) => gl.checkToken(ctx),
  'GET /api/repos': async (ctx) => { const d = await disc.discover(ctx); return { groups: d.groups, gitlab: gl.gitlabEnabled(ctx), gitlabError: d.gitlabError }; },

  'POST /api/connect': async (ctx, q, body) => {
    const lp = await wt(ctx, body.repoKey);
    return { ok: true, root: await gs.root(lp), currentBranch: await gs.currentBranch(lp), repoKey: body.repoKey, workingCopy: lp };
  },
  'POST /api/warm': async (ctx, q, body) => { await wt(ctx, body.repoKey); return { ok: true, warmed: true }; },
  'GET /api/branches': async (ctx, q) => {
    // Fast path: GitLab API (no clone needed). Fall back to local git if API unavailable.
    const projectId = await disc.gitlabIdFor(ctx, q.repoKey);
    if (projectId) {
      try { return { branches: await glApi.branches(ctx, projectId), via: 'api' }; }
      catch (e) { /* fall through to local */ }
    }
    return { branches: await gs.branches(await wt(ctx, q.repoKey)), via: 'git' };
  },
  'POST /api/fetch': async (ctx, q, body) => ({ ok: true, output: await gs.fetchAll(await wt(ctx, body.repoKey)) }),
  'GET /api/protected': async (ctx, q) => ({ branch: q.branch, isProtected: await gs.isProtected(await wt(ctx, q.repoKey), q.branch) }),
  'GET /api/commits': async (ctx, q) => {
    // Fast path: GitLab compare API returns the commits between target and source server-side,
    // with NO clone/fetch of repo objects. This is the main win for the "browse" experience —
    // the user sees subjects in ~1s instead of waiting for a clone.
    const projectId = await disc.gitlabIdFor(ctx, q.repoKey);
    const source = q.source || 'develop';
    const target = q.target || '';
    if (projectId && target) {
      try {
        const commits = await glApi.compareCommits(ctx, projectId, source, target);
        return groupCommits(commits, source, target);
      } catch (e) { /* fall through to local git */ }
    }
    return gs.commits(await wt(ctx, q.repoKey), source, target, { limit: parseInt(q.limit || '0', 10) || 0, offset: parseInt(q.offset || '0', 10) || 0 });
  },
  'POST /api/dry-run': async (ctx, q, body) => gs.dryRun(await wt(ctx, body.repoKey), body),
  'POST /api/cherry-pick/start': async (ctx, q, body) => {
    // FULLY REMOTE: the cherry-pick happens entirely on GitLab via the API. No local clone, no
    // proxy object transfer. The work branch is created isolated from the release target; nothing
    // is merged into release until the developer reviews the diff and raises the MR.
    const projectId = await disc.gitlabIdFor(ctx, body.repoKey);
    const shas = body.commits || [];
    if (!projectId) throw new gs.GitError('This repository is not a GitLab project — remote cherry-pick is unavailable.');
    if (!shas.length) throw new gs.GitError('Select at least one commit.');
    if (!body.target) throw new gs.GitError('Target branch is required.');
    if (!body.newBranch) throw new gs.GitError('A new branch name is required.');

    const workBranch = body.newBranch.trim();
    const ordered = [...shas].reverse(); // GitLab applies oldest→newest; UI sends newest-first

    const res = await glApi.tryCherryPickAll(ctx, projectId, {
      target: body.target, shas: ordered, workBranch, createWorkBranch: true,
    });

    if (res.ok) {
      let reviewFiles = [];
      try {
        const cmp = await glApi.compareDiff(ctx, projectId, body.target, workBranch);
        reviewFiles = normalizeApiDiff(cmp.files);
      } catch { /* diff is best-effort */ }
      return {
        status: 'done', via: 'api', workBranch,
        applied: res.applied, skipped: shas.length - res.applied,
        remaining: 0, autoResolved: [], log: [],
        needsReview: true, reviewFiles, published: true,
      };
    }
    if (res.reason === 'branch-exists') {
      throw new gs.GitError(`Branch '${workBranch}' already exists on GitLab. Choose a different name.`);
    }
    if (res.reason === 'conflict') {
      // GitLab could not apply a commit cleanly. We cannot resolve conflicts remotely (there's no
      // working tree on the API), so we report it clearly instead of showing an empty editor. The
      // partial branch has already been rolled back by tryCherryPickAll.
      const which = res.conflictSha ? ` (commit ${String(res.conflictSha).slice(0, 8)})` : '';
      throw new gs.GitError(
        `Cherry-pick conflicts with '${body.target}'${which}. GitLab can't auto-merge this remotely. ` +
        `Resolve it by creating the branch in GitLab and cherry-picking there, or pick the commits onto an intermediate branch first.`
      );
    }
    throw new gs.GitError(res.detail || 'Cherry-pick failed on GitLab.');
  },
  'POST /api/cherry-pick/resolve': async (ctx, q, body) => {
    // Remote path has no local resolution flow. Kept for API compatibility.
    throw new gs.GitError('Conflict resolution is handled in GitLab for remote cherry-picks.');
  },
  'POST /api/cherry-pick/abort': async (ctx, q, body) => {
    // Fully remote: abort = delete the work branch on GitLab (fast, one API call). Never touches
    // a local clone.
    const projectId = await disc.gitlabIdFor(ctx, body.repoKey);
    if (!projectId || !body.workBranch) return { ok: true, aborted: true, note: 'nothing to abort' };
    const deleted = await glApi.deleteBranch(ctx, projectId, body.workBranch);
    return { ok: true, aborted: true, via: 'api', deleted };
  },
  'POST /api/push': async (ctx, q, body) => gs.push(await wt(ctx, body.repoKey), body.branch, !!body.setUpstream),
  'GET /api/commit-diff': async (ctx, q) => {
    // Fast path: GitLab API returns the per-commit diff as JSON, no blob fetch over the proxy.
    const projectId = await disc.gitlabIdFor(ctx, q.repoKey);
    if (projectId) {
      try {
        const raw = await glApi.commitDiff(ctx, projectId, q.sha);
        return { sha: q.sha, files: normalizeApiDiff(raw.files), via: 'api' };
      } catch (e) { /* fall through */ }
    }
    return gs.commitDiff(await wt(ctx, q.repoKey), q.sha);
  },
  'GET /api/branch-diff': async (ctx, q) => {
    // Fast path: GitLab compare API returns the diff between base and head server-side.
    const projectId = await disc.gitlabIdFor(ctx, q.repoKey);
    if (projectId) {
      try {
        const raw = await glApi.compareDiff(ctx, projectId, q.base, q.head);
        return { base: q.base, head: q.head, files: normalizeApiDiff(raw.files), via: 'api' };
      } catch (e) { /* fall through to local */ }
    }
    return gs.branchDiff(await wt(ctx, q.repoKey), q.base, q.head);
  },
  'POST /api/merge-request': async (ctx, q, body) => {
    const projectId = await disc.gitlabIdFor(ctx, body.repoKey);
    if (!projectId) throw new gs.GitError('No GitLab project id for this repo — can\'t raise an MR.');
    return gl.createMergeRequest(ctx, projectId, body);
  },
  'POST /api/branch/delete': async (ctx, q, body) => {
    const projectId = await disc.gitlabIdFor(ctx, body.repoKey);
    if (!projectId) throw new gs.GitError('Deleting branches requires a GitLab project.');
    const name = (body.branch || '').trim();
    if (!name) throw new gs.GitError('Branch name is required.');
    // Safety net: never delete a protected branch, even if the UI somehow allows it.
    try {
      const list = await glApi.branches(ctx, projectId);
      const match = list.find((b) => b.name === name);
      if (match && match.protectedBranch) throw new gs.GitError(`'${name}' is protected and cannot be deleted.`);
    } catch (e) { if (/protected/.test(String(e.message))) throw e; /* else proceed */ }
    const deleted = await glApi.deleteBranch(ctx, projectId, name);
    if (!deleted) throw new gs.GitError(`Could not delete '${name}'. It may be protected or already gone.`);
    return { ok: true, deleted: name };
  },
  'POST /api/fix-sql': async (ctx, q, body) => ({ ok: true, file: body.file, fixed: fixSqlFile(await wt(ctx, body.repoKey), body.file) }),
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');
  const u = new URL(req.url, `http://localhost:${PORT}`);

  // Kubernetes liveness/readiness probes. Kept dependency-free and fast (no git/network calls)
  // so a slow GitLab can never make the pod look unhealthy and get killed.
  if (req.method === 'GET' && (u.pathname === '/healthz' || u.pathname === '/api/health')) {
    return send(res, 200, JSON.stringify({ status: 'ok', uptime: Math.round(process.uptime()), ts: new Date().toISOString() }));
  }
  if (req.method === 'GET' && u.pathname === '/readyz') {
    // Ready as soon as the HTTP server is accepting connections; we don't gate readiness on
    // GitLab reachability (that's per-request and per-user-token).
    return send(res, shuttingDown ? 503 : 200, JSON.stringify({ ready: !shuttingDown }));
  }

  // SSE: stream clone progress while connecting to a repo.
  // EventSource can't set headers, so GitLab config comes via query params here.
  if (req.method === 'GET' && u.pathname === '/api/connect-stream') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
      'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    });
    const ctx = {
      baseUrl: u.searchParams.get('gitlabUrl') || '',
      group: u.searchParams.get('gitlabGroup') || '',
      token: u.searchParams.get('gitlabToken') || '',
    };
    const repoKey = u.searchParams.get('repoKey') || '';

    let closed = false;
    req.on('close', () => { closed = true; });
    const sse = (event, data) => {
      if (closed || res.writableEnded) return false;
      try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); return true; }
      catch { closed = true; return false; }
    };
    // Disable the browser's automatic SSE reconnect (default would re-fire the clone).
    try { res.write('retry: 86400000\n\n'); } catch { /* */ }

    let lastPct = -1;
    try {
      const lp = await disc.resolveWorkingTree(ctx, repoKey, false, (p) => {
        if (p.overallPct !== lastPct) { lastPct = p.overallPct; sse('progress', p); }
      });
      if (!lp) throw new gs.GitError(`Could not resolve a working copy for: ${repoKey}`);
      const result = { ok: true, root: await gs.root(lp), currentBranch: await gs.currentBranch(lp), repoKey, workingCopy: lp };
      sse('done', result);
    } catch (e) {
      sse('error', { error: e.message || 'Connect failed' });
    }
    if (!res.writableEnded) res.end();
    return;
  }

  const key = `${req.method} ${u.pathname}`;
  if (routes[key]) {
    try {
      const ctx = ctxOf(req);
      const q = Object.fromEntries(u.searchParams.entries());
      const body = req.method === 'POST' ? await readBody(req) : {};
      return send(res, 200, await routes[key](ctx, q, body));
    } catch (e) {
      return send(res, e instanceof gs.GitError ? 400 : 500, { error: e.message || 'Unexpected error' });
    }
  }
  if (req.method === 'GET' && !u.pathname.startsWith('/api/')) {
    let fp = path.join(DIST, u.pathname === '/' ? 'index.html' : u.pathname.slice(1));
    if (!fs.existsSync(fp) || !fs.statSync(fp).isFile()) fp = path.join(DIST, 'index.html');
    if (fs.existsSync(fp)) return send(res, 200, fs.readFileSync(fp), MIME[path.extname(fp)] || 'application/octet-stream');
    return send(res, 404, 'UI not built.', 'text/plain');
  }
  send(res, 404, { error: 'Not found' });
});
let shuttingDown = false;

server.listen(PORT, HOST, () => {
  console.log(`Release Merge Helper listening on http://${HOST}:${PORT}`);
  if (String(process.env.GITLAB_INSECURE || '').toLowerCase() === 'true') {
    console.warn('⚠  GITLAB_INSECURE=true — TLS certificate verification is OFF. Use GITLAB_CA_FILE for production.');
  } else if (process.env.GITLAB_CA_FILE) {
    console.log(`✓ Trusting GitLab CA bundle: ${process.env.GITLAB_CA_FILE}`);
  }
  if (process.env.PROXY_HOST) {
    console.log(`✓ Using proxy ${process.env.PROXY_HOST}:${process.env.PROXY_PORT || 8080}${process.env.PROXY_USER ? ' (authenticated)' : ''}`);
  }
});

// Graceful shutdown for Kubernetes: stop accepting new connections, let in-flight requests
// finish, then exit. Without this, a rolling deploy can drop active cherry-picks mid-flight.
function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`${signal} received — draining connections, shutting down gracefully…`);
  server.close(() => { console.log('All connections drained. Bye.'); process.exit(0); });
  // Hard cap so a stuck connection can't block the pod from terminating.
  setTimeout(() => { console.warn('Forced shutdown after timeout.'); process.exit(0); }, 25000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
// Never crash the pod on an unhandled async error from a single request.
process.on('unhandledRejection', (err) => console.error('unhandledRejection:', err));
process.on('uncaughtException', (err) => console.error('uncaughtException:', err));
