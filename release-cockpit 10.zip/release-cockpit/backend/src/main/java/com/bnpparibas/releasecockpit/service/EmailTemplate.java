package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;

import java.util.List;
import java.util.Map;

/**
 * Builds polished, Outlook-safe HTML email bodies (inline styles + tables).
 *
 *   gapEmail()     -> per-subject email: exactly what's missing + the action
 *                     each owner must take.
 *   summaryEmail() -> overall release status for the whole team.
 *
 * Kept dependency-free (pure String building) so it ports cleanly and renders
 * consistently in corporate mail clients that strip <style>/flrexbox.
 */
public final class EmailTemplate {

    private EmailTemplate() {}

    // Human-readable label + the concrete action for each artifact key.
    private static final Map<String, String[]> ITEM = Map.ofEntries(
            Map.entry("OCTANE_TESTS_LINKED", new String[]{
                    "Octane test cases linked & passed",
                    "Link the UAT test cases to this Jira id in Octane and ensure all runs are passed (IST/DEV/UAT)."}),
            Map.entry("BCM_TESTING", new String[]{
                    "BCM end-to-end testing",
                    "Execute the BCM end-to-end test in Octane for UAT and mark it passed."}),
            Map.entry("PR", new String[]{
                    "Peer Review document",
                    "Upload the Peer Review (PR Code) document for this epic to the SharePoint epic folder."}),
            Map.entry("PR_EXCEL", new String[]{
                    "Peer Review Excel",
                    "Place the Peer Review Excel (.xlsx) in 03 - Quality / 06 - Peer Reviews / DEV - Code."}),
            Map.entry("ESTIMATION_SHEET", new String[]{
                    "Estimation sheet",
                    "Add the HLE / estimation sheet for this epic to the SharePoint folder."}),
            Map.entry("OCTANE_REVIEW_DOC", new String[]{
                    "UAT test-case Review document",
                    "Upload the UAT test-case review evidence to Test Case (UAT)."}),
            Map.entry("OCTANE_EXECUTION_DOC", new String[]{
                    "UAT test-case Execution document",
                    "Upload the UAT test-case execution evidence to Test Exec (UAT)."}),
            Map.entry("UNIT_TEST", new String[]{
                    "Unit test evidence",
                    "Attach the unit-test report/coverage for this epic."})
    );

    private static String label(String key) {
        String[] v = ITEM.get(key);
        return v != null ? v[0] : key;
    }
    private static String action(String key) {
        String[] v = ITEM.get(key);
        return v != null ? v[1] : "Provide the missing artifact for this item.";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;");
    }

    // Palette
    private static final String BRAND = "#00915A";
    private static final String INK = "#0F1729";
    private static final String MUTED = "#667085";
    private static final String LINE = "#E4E7EC";
    private static final String DANGER = "#D92D20";
    private static final String DANGER_SOFT = "#FCEBEA";
    private static final String OK = "#067647";
    private static final String AMBER = "#B54708";

    // ──────────────────────────────────────────────────────────────────────
    //  PER-SUBJECT GAP EMAIL
    // ──────────────────────────────────────────────────────────────────────
    public static String gapEmail(String company, String releaseName, String releaseDate,
                                  String ppdStart, String endUatDone, long daysToRelease,
                                  Subject s, String jiraUrl) {
        List<String> missing = s.readiness().missing();

        StringBuilder rows = new StringBuilder();
        for (String key : missing) {
            rows.append("""
                <tr>
                  <td style="padding:12px 14px;border-bottom:1px solid %LINE%;vertical-align:top;width:26px;">
                    <span style="display:inline-block;width:18px;height:18px;border-radius:50%;background:%DANGER%;color:#fff;text-align:center;font-size:12px;line-height:18px;">&#10005;</span>
                  </td>
                  <td style="padding:12px 14px;border-bottom:1px solid %LINE%;">
                    <div style="font-size:14px;font-weight:700;color:%INK%;">%LABEL%</div>
                    <div style="font-size:12.5px;color:%MUTED%;margin-top:3px;line-height:1.5;">%ACTION%</div>
                  </td>
                </tr>
                """
                    .replace("%LABEL%", esc(label(key)))
                    .replace("%ACTION%", esc(action(key)))
                    .replace("%LINE%", LINE).replace("%DANGER%", DANGER)
                    .replace("%INK%", INK).replace("%MUTED%", MUTED));
        }

        String deadlineNote = daysToRelease >= 0
                ? "Release is in <strong>" + daysToRelease + " day(s)</strong>. End-UAT must be done by <strong>" + esc(endUatDone) + "</strong>."
                : "This release has shipped.";

        return ("""
            <!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;padding:0;background:#F3F4F6;">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F3F4F6;padding:24px 0;">
            <tr><td align="center">
            <table role="presentation" width="620" cellpadding="0" cellspacing="0" style="width:620px;max-width:94%;background:#fff;border-radius:14px;overflow:hidden;border:1px solid %LINE%;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
              <tr><td style="background:%INK%;padding:18px 24px;">
                <span style="font-size:18px;font-weight:800;color:#fff;">%COMPANY% · Release Cockpit</span>
              </td></tr>
              <tr><td style="padding:24px 24px 6px;">
                <div style="font-size:11px;letter-spacing:.07em;text-transform:uppercase;color:%MUTED%;font-weight:700;">Action required · Release %RELEASE%</div>
                <div style="font-size:21px;font-weight:800;color:%INK%;margin-top:6px;">%KEY% — %COUNT% item(s) to complete</div>
                <p style="font-size:14px;color:%INK%;line-height:1.6;margin:14px 0 0;">
                  Hi %DEV%,<br>
                  Your epic <a href="%URL%" style="color:%BRAND%;font-weight:700;text-decoration:none;">%KEY%</a>
                  (%SUMMARY%) is tagged for release <strong>%RELEASE%</strong> but is not yet release-ready.
                  %DEADLINE%
                </p>
              </td></tr>
              <tr><td style="padding:18px 24px 0;">
                <div style="font-size:13px;font-weight:700;color:%DANGER%;margin-bottom:8px;">What is missing &amp; what to do</div>
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid %LINE%;border-radius:10px;overflow:hidden;">
                  %ROWS%
                </table>
              </td></tr>
              <tr><td style="padding:18px 24px 0;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#FAFBFC;border:1px solid %LINE%;border-radius:10px;">
                  <tr>
                    <td style="padding:12px 14px;font-size:12.5px;color:%MUTED%;">
                      <strong style="color:%INK%;">Developer:</strong> %DEV% &nbsp;·&nbsp;
                      <strong style="color:%INK%;">Reporter:</strong> %REPORTER% &nbsp;·&nbsp;
                      <strong style="color:%INK%;">Status:</strong> %STATUS%
                    </td>
                  </tr>
                </table>
              </td></tr>
              <tr><td style="padding:18px 24px 24px;">
                <a href="%URL%" style="display:inline-block;background:%BRAND%;color:#fff;text-decoration:none;font-size:14px;font-weight:700;padding:11px 22px;border-radius:8px;">Open %KEY% in Jira</a>
              </td></tr>
              <tr><td style="padding:14px 24px;background:#FAFAFA;border-top:1px solid %LINE%;">
                <p style="margin:0;font-size:11px;color:%MUTED%;line-height:1.5;">
                  Automated from %COMPANY% Release Cockpit. Developer &amp; reporter are on To; release managers are on CC.
                </p>
              </td></tr>
            </table></td></tr></table></body></html>
            """)
                .replace("%ROWS%", rows.toString())
                .replace("%COMPANY%", esc(company))
                .replace("%RELEASE%", esc(releaseName))
                .replace("%KEY%", esc(s.key()))
                .replace("%COUNT%", String.valueOf(missing.size()))
                .replace("%DEV%", esc(s.developerName()))
                .replace("%REPORTER%", esc(s.reporterName()))
                .replace("%SUMMARY%", esc(s.summary()))
                .replace("%STATUS%", esc(s.status()))
                .replace("%URL%", esc(jiraUrl))
                .replace("%DEADLINE%", deadlineNote)
                .replace("%BRAND%", BRAND).replace("%INK%", INK)
                .replace("%MUTED%", MUTED).replace("%LINE%", LINE).replace("%DANGER%", DANGER);
    }

    // ──────────────────────────────────────────────────────────────────────
    //  OVERALL RELEASE-STATUS SUMMARY EMAIL
    // ──────────────────────────────────────────────────────────────────────
    public static String summaryEmail(String company, String releaseName, String releaseDate,
                                      long daysToRelease, ReleaseSummary sum, ReleaseHealth health,
                                      List<Subject> atRisk) {
        String gradeColor = switch (health.grade()) {
            case "EXCELLENT" -> OK;
            case "GOOD" -> "#1570EF";
            case "AT_RISK" -> AMBER;
            default -> DANGER;
        };

        StringBuilder riskRows = new StringBuilder();
        for (String r : health.risks()) {
            riskRows.append("<li style=\"margin:0 0 6px;color:#475467;font-size:13px;line-height:1.5;\">")
                    .append(esc(r)).append("</li>");
        }

        // Top at-risk subjects (max 8) so managers see the headline items.
        StringBuilder subjRows = new StringBuilder();
        int shown = 0;
        for (Subject s : atRisk) {
            if (shown++ >= 8) break;
            subjRows.append("""
                <tr>
                  <td style="padding:9px 12px;border-bottom:1px solid %LINE%;font-size:13px;font-weight:700;color:%INK%;">%KEY%</td>
                  <td style="padding:9px 12px;border-bottom:1px solid %LINE%;font-size:12.5px;color:#475467;">%DEV%</td>
                  <td style="padding:9px 12px;border-bottom:1px solid %LINE%;font-size:12px;color:%DANGER%;">%MISS% missing</td>
                </tr>
                """
                    .replace("%KEY%", esc(s.key()))
                    .replace("%DEV%", esc(s.developerName()))
                    .replace("%MISS%", String.valueOf(s.readiness().missingCount()))
                    .replace("%LINE%", LINE).replace("%INK%", INK).replace("%DANGER%", DANGER));
        }
        if (subjRows.length() == 0) {
            subjRows.append("<tr><td colspan=\"3\" style=\"padding:12px;color:")
                    .append(OK).append(";font-size:13px;font-weight:600;\">All subjects are release-ready.</td></tr>");
        }

        String deadline = daysToRelease >= 0
                ? "Release in <strong>" + daysToRelease + " day(s)</strong> (" + esc(releaseDate) + ")"
                : "Shipped (" + esc(releaseDate) + ")";

        return ("""
            <!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
            <body style="margin:0;padding:0;background:#F3F4F6;">
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F3F4F6;padding:24px 0;">
            <tr><td align="center">
            <table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:640px;max-width:94%;background:#fff;border-radius:14px;overflow:hidden;border:1px solid %LINE%;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
              <tr><td style="background:%INK%;padding:18px 24px;">
                <span style="font-size:18px;font-weight:800;color:#fff;">%COMPANY% · Release Status</span>
              </td></tr>
              <tr><td style="padding:24px 24px 4px;">
                <div style="font-size:11px;letter-spacing:.07em;text-transform:uppercase;color:%MUTED%;font-weight:700;">Release %RELEASE% · %DEADLINE%</div>
              </td></tr>
              <tr><td style="padding:14px 24px 0;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                    <td style="width:130px;vertical-align:top;">
                      <table role="presentation" cellpadding="0" cellspacing="0" style="border:2px solid %GRADE%;border-radius:12px;">
                        <tr><td style="padding:14px 18px;text-align:center;">
                          <div style="font-size:34px;font-weight:800;color:%INK%;line-height:1;">%SCORE%</div>
                          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:%GRADE%;margin-top:4px;">%GRADELABEL%</div>
                        </td></tr>
                      </table>
                    </td>
                    <td style="vertical-align:top;padding-left:18px;">
                      <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                        %BARS%
                      </table>
                    </td>
                  </tr>
                </table>
              </td></tr>
              <tr><td style="padding:18px 24px 0;">
                <div style="font-size:13px;font-weight:700;color:%INK%;margin-bottom:6px;">Where we stand</div>
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#FAFBFC;border:1px solid %LINE%;border-radius:10px;">
                  <tr><td style="padding:12px 14px;font-size:13px;color:#475467;line-height:1.6;">
                    <strong style="color:%INK%;">%READY%</strong> of <strong style="color:%INK%;">%TOTAL%</strong> subjects are release-ready
                    (%NOTREADY% still need work). Octane coverage <strong>%OCT%%</strong>, SharePoint artifacts <strong>%SP%%</strong>.
                  </td></tr>
                </table>
              </td></tr>
              <tr><td style="padding:18px 24px 0;">
                <div style="font-size:13px;font-weight:700;color:%INK%;margin-bottom:6px;">Risks &amp; attention</div>
                <ul style="margin:0;padding-left:18px;">%RISKS%</ul>
              </td></tr>
              <tr><td style="padding:18px 24px 0;">
                <div style="font-size:13px;font-weight:700;color:%INK%;margin-bottom:6px;">Top subjects needing action</div>
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid %LINE%;border-radius:10px;overflow:hidden;">
                  %SUBJ%
                </table>
              </td></tr>
              <tr><td style="padding:18px 24px;background:#FAFAFA;border-top:1px solid %LINE%;margin-top:18px;">
                <p style="margin:0;font-size:11px;color:%MUTED%;line-height:1.5;">
                  Automated release-status summary from %COMPANY% Release Cockpit.
                </p>
              </td></tr>
            </table></td></tr></table></body></html>
            """)
                .replace("%BARS%", bar("Readiness", health.readinessScore(), gradeColor)
                        + bar("Octane", health.octaneScore(), gradeColor)
                        + bar("SharePoint", health.sharepointScore(), gradeColor)
                        + bar("Timeline", health.timelineScore(), gradeColor))
                .replace("%RISKS%", riskRows.toString())
                .replace("%SUBJ%", subjRows.toString())
                .replace("%COMPANY%", esc(company))
                .replace("%RELEASE%", esc(releaseName))
                .replace("%DEADLINE%", deadline)
                .replace("%SCORE%", String.valueOf(health.score()))
                .replace("%GRADELABEL%", esc(gradeLabel(health.grade())))
                .replace("%GRADE%", gradeColor)
                .replace("%READY%", String.valueOf(sum.ready()))
                .replace("%TOTAL%", String.valueOf(sum.totalSubjects()))
                .replace("%NOTREADY%", String.valueOf(sum.notReady()))
                .replace("%OCT%", String.valueOf(health.octaneScore()))
                .replace("%SP%", String.valueOf(health.sharepointScore()))
                .replace("%INK%", INK).replace("%MUTED%", MUTED)
                .replace("%LINE%", LINE).replace("%DANGER%", DANGER);
    }

    private static String bar(String label, int pct, String color) {
        return ("""
            <tr>
              <td style="padding:3px 0;font-size:12px;color:#475467;width:80px;">%L%</td>
              <td style="padding:3px 8px;">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EAECF0;border-radius:20px;">
                  <tr><td style="background:%C%;height:8px;border-radius:20px;width:%P%%;font-size:0;">&nbsp;</td></tr>
                </table>
              </td>
              <td style="padding:3px 0;font-size:12px;font-weight:700;color:#1D2939;width:38px;text-align:right;">%P%%</td>
            </tr>
            """).replace("%L%", label).replace("%C%", color).replace("%P%", String.valueOf(pct));
    }

    private static String gradeLabel(String g) {
        return switch (g) {
            case "EXCELLENT" -> "Excellent";
            case "GOOD" -> "Good";
            case "AT_RISK" -> "At risk";
            case "CRITICAL" -> "Critical";
            default -> g;
        };
    }
}
