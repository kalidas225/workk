package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.model.Domain.SubjectCheckConfig;
import com.bnpparibas.releasecockpit.service.SubjectConfigService;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Per-subject check configuration API. The JSON file is the source of truth;
 * these endpoints let the dashboard view and edit it.
 *
 *   GET    /api/checks               -> { default, overrides:{key:cfg} }
 *   GET    /api/checks/{key}         -> effective config for one subject
 *   PUT    /api/checks/{key}         -> set a subject's override (body: cfg)
 *   DELETE /api/checks/{key}         -> revert subject to default
 */
@RestController
@RequestMapping("/api/checks")
public class SubjectConfigController {

    private final SubjectConfigService service;

    public SubjectConfigController(SubjectConfigService service) {
        this.service = service;
    }

    @GetMapping
    public Map<String, Object> all() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("default", service.getDefault());
        out.put("overrides", service.getOverrides());
        return out;
    }

    @GetMapping("/{key}")
    public SubjectCheckConfig one(@PathVariable String key) {
        return service.forSubject(key);
    }

    @PutMapping("/{key}")
    public SubjectCheckConfig update(@PathVariable String key, @RequestBody SubjectCheckConfig cfg) {
        return service.update(key, cfg);
    }

    @DeleteMapping("/{key}")
    public Map<String, Object> remove(@PathVariable String key) {
        service.remove(key);
        return Map.of("removed", key);
    }
}
