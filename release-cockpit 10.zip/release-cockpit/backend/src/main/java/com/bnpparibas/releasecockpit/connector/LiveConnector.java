package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.ArtifactSpec;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane bearer token (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    public LiveConnector(CockpitProperties props, HttpClientFactory clients,
                         com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts) {
        this.props = props;
        this.clients = clients;
        this.artifacts = artifacts;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira base-url not configured; returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();

        // 1) Explicit release names take priority (no project lookup needed).
        if (!isBlank(j.getReleaseNames())) {
            for (String name : j.getReleaseNames().split(",")) {
                name = name.trim();
                if (!name.isEmpty()) out.add(new Release(name, name, null, false, ""));
            }
            log.info("Using {} explicit release name(s) from config.", out.size());
            return out;
        }

        // 2) Otherwise scan project fixVersions.
        if (isBlank(j.getProjectKeys())) {
            log.warn("Neither release-names nor project-keys set; no releases. "
                    + "Set cockpit.jira.release-names (e.g. 25.07,25.08) or project-keys.");
            return List.of();
        }
        for (String project : j.getProjectKeys().split(",")) {
            project = project.trim();
            if (project.isEmpty()) continue;
            // Jira DC: project key is case-sensitive; numeric ids also work.
            String body = getJira("/rest/api/2/project/" + enc(project) + "/versions");
            if (body == null) {
                log.warn("Jira versions for project '{}' returned no body (check the key — "
                        + "it must be the PROJECT KEY, e.g. TCAAS1484, not the name).", project);
                continue;
            }
            try {
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        if (name.isEmpty()) continue;
                        LocalDate date = safeDate(v.path("releaseDate").asText(null));
                        boolean released = v.path("released").asBoolean(false);
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                } else {
                    // Jira returned an error object (e.g. 400) rather than an array.
                    log.warn("Jira versions for '{}' not an array — response: {}", project,
                            body.length() > 300 ? body.substring(0, 300) : body);
                }
            } catch (Exception e) {
                log.warn("Parsing Jira versions for '{}' failed: {}", project, e.getMessage());
            }
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String url = "/rest/api/2/search?jql=" + enc(jql)
                    + "&maxResults=200&fields=summary,status,assignee,reporter,created,"
                    + (j.getOctaneLinkField() == null ? "" : j.getOctaneLinkField());
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");

            // Parse all issues first (cheap, no network).
            record Raw(String key, String summary, String status, String dev, String devEmail,
                       String rep, String repEmail, LocalDate created, List<String> octaneIds) {}
            List<Raw> raws = new ArrayList<>();
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                raws.add(new Raw(key, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        f.path("assignee").path("displayName").asText(""),
                        f.path("assignee").path("emailAddress").asText(""),
                        f.path("reporter").path("displayName").asText(""),
                        f.path("reporter").path("emailAddress").asText(""),
                        safeDate(f.path("created").asText("").replaceAll("T.*", "")),
                        octaneIds));
            }

            // Run the readiness checks for all subjects in PARALLEL — each
            // subject does 1 Octane query + 1 SharePoint folder listing (not 6),
            // so a 36-subject release goes from hundreds of sequential calls to
            // a few dozen concurrent ones. Bounded pool keeps the proxy happy.
            ExecutorService pool = Executors.newFixedThreadPool(
                    Math.min(12, Math.max(2, raws.size())));
            try {
                final int relYear = releaseYearFor(releaseName);
                List<Future<Subject>> futures = new ArrayList<>();
                for (Raw rw : raws) {
                    futures.add(pool.submit(() -> {
                        boolean octaneOk = checkOctane(rw.octaneIds());
                        Readiness r = buildReadiness(rw.key(), octaneOk, relYear);
                        return new Subject(rw.key(), rw.summary(), rw.status(),
                                rw.dev(), rw.devEmail(), rw.rep(), rw.repEmail(),
                                rw.created(), rw.octaneIds(), r);
                    }));
                }
                for (Future<Subject> fut : futures) {
                    try { out.add(fut.get()); }
                    catch (Exception e) { log.warn("Subject check failed: {}", e.getMessage()); }
                }
            } finally {
                pool.shutdown();
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject from artifacts.json. For each enabled
     * SharePoint artifact, resolves its folder ({YEAR}/{EPIC} substituted),
     * lists files (recursing if goInside), and matches filenames by
     * all+any+extensions, requiring minFiles. skipSubjects bypasses a check.
     * The numeric subject id is the trailing number of the epic key.
     */
    private Readiness buildReadiness(String epicKey, boolean octaneOk, int year) {
        String subjectId = subjectIdOf(epicKey);
        java.util.Map<String, Boolean> results = new java.util.HashMap<>();
        for (ArtifactSpec spec : artifacts.sharePointArtifacts()) {
            if (spec.skipSubjects != null && spec.skipSubjects.contains(subjectId)) {
                results.put(spec.key, true); // explicitly skipped = satisfied
                continue;
            }
            results.put(spec.key, checkSharePointArtifact(epicKey, spec, year));
        }
        // Enabled-but-absent artifacts default to "not present"; artifacts not in
        // the enabled set default to satisfied (so disabled ones don't show gaps).
        boolean pr = results.getOrDefault("PR", true);
        boolean prExcel = results.getOrDefault("PR_EXCEL", true);
        boolean est = results.getOrDefault("ESTIMATION_SHEET", true);
        boolean rev = results.getOrDefault("OCTANE_REVIEW_DOC", true);
        boolean exec = results.getOrDefault("OCTANE_EXECUTION_DOC", true);
        boolean unit = true; // UNIT_TEST removed by default

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");
        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing);
    }

    /** Numeric subject id = trailing digits of the epic key (TCAAS1484-4971 -> 4971). */
    private String subjectIdOf(String epicKey) {
        var m = java.util.regex.Pattern.compile("(\\d+)$").matcher(epicKey);
        return m.find() ? m.group(1) : epicKey;
    }

    /** Year used for {YEAR} substitution — from the release's date, else current year. */
    private int releaseYearFor(String releaseName) {
        try {
            for (Release r : listReleases()) {
                if (r.name().equals(releaseName) && r.releaseDate() != null) {
                    return r.releaseDate().getYear();
                }
            }
        } catch (Exception ignore) { }
        return java.time.Year.now().getValue();
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    private boolean checkOctane(List<String> octaneIds) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl())) { return false; }
        if (octaneIds == null || octaneIds.isEmpty()) {
            log.info("Octane: no test ids on subject (Jira field '{}' empty?) — skipping Octane check",
                    props.getJira().getOctaneLinkField());
            return false;
        }
        try {
            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return false;
            String ids = String.join(" || ", octaneIds.stream().map(i -> "id=" + i).toList());
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests?fields=id,name,last_runs&query=\"" + enc("(" + ids + ")") + "\"";
            HttpResponse<String> r = octaneGet(url);
            if (r != null && r.statusCode() == 401) { octaneSignIn(); r = octaneGet(url); }
            if (r == null || r.statusCode() >= 400) {
                log.info("Octane query HTTP {} for ids {}", r == null ? "null" : r.statusCode(), octaneIds);
                return false;
            }
            int total = mapper.readTree(r.body()).path("total_count").asInt(0);
            log.info("Octane ids {} -> {} test(s) found", octaneIds, total);
            return total > 0;
        } catch (Exception e) {
            log.warn("Octane check failed gracefully: {}", e.getMessage());
            return false;
        }
    }

    private void octaneSignIn() {
        var o = props.getOctane();
        try {
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() < 400) {
                // capture the LWSSO_COOKIE_KEY from Set-Cookie
                String cookie = r.headers().allValues("set-cookie").stream()
                        .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                        .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                octaneCookie = cookie;
                log.info("Octane sign-in {}", cookie != null ? "OK" : "returned no cookie");
            } else {
                log.warn("Octane sign-in HTTP {}", r.statusCode());
            }
        } catch (Exception e) {
            log.warn("Octane sign-in failed gracefully: {}", e.getMessage());
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", octaneCookie)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    // ---- SharePoint ----
    // Per-epic cache of the subfolders that contain at least one file, so the
    // listing happens once per epic (not once per artifact). Cleared each scan
    // via the cache TTL on the service layer; here it lives for the connector.

    /**
     * Checks one SharePoint artifact for an epic using its artifacts.json spec.
     *
     * Folder resolution: spec.folder with {YEAR} -> current year and {EPIC} ->
     * epic key, prefixed by the configured root path, under the library. If
     * spec.folder is empty, the epic's own folder under the root is used.
     *
     * Files are listed (recursing into subfolders when goInside=true) and a file
     * matches when its name contains ALL of match.all (after {EPIC} substitution)
     * AND at least one of match.any AND, if extensions is non-empty, ends with one
     * of them. The check passes when at least minFiles files match.
     */
    private boolean checkSharePointArtifact(String epicKey, ArtifactSpec spec, int year) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return false;
        try {
            String y = String.valueOf(year);
            // {YEAR} is substituted in BOTH the root path and the artifact folder,
            // so a 2025 release looks under ".../2025 Change request/.../2025/...".
            String root = (sp.getRootPath() == null ? "" : sp.getRootPath()).replace("{YEAR}", y);
            String sub = (spec.folder == null ? "" : spec.folder)
                    .replace("{YEAR}", y).replace("{EPIC}", epicKey);
            // If the artifact folder is empty, look in the epic's own folder under
            // the root; otherwise the configured (shared) folder under the root.
            String relWithinLib = root + (sub.isBlank() ? "/" + epicKey : sub);
            String serverRel = (siteAndLibrary(sp) + "/" + relWithinLib).replaceAll("/{2,}", "/");

            List<String> fileNames = listFiles(serverRel, spec.goInside, 0);

            // Matching: by default a file just needs to contain the Jira id. If the
            // spec provides match.any keywords / extensions, those refine it; but
            // the Jira id (epicKey or its trailing number) is always required.
            String idNum = subjectIdOf(epicKey);
            List<String> anyTokens = (spec.match != null && spec.match.any != null) ? spec.match.any : List.of();
            List<String> exts = (spec.match != null && spec.match.extensions != null) ? spec.match.extensions : List.of();

            int matched = 0;
            for (String name : fileNames) {
                if (fileMatchesId(name, epicKey, idNum, exts)) matched++;
            }
            boolean ok = matched >= Math.max(1, spec.minFiles);
            log.info("SharePoint {} [{}] folder='{}' files={} matched={} -> {}",
                    epicKey, spec.key, serverRel, fileNames.size(), matched, ok ? "PASS" : "MISSING");
            return ok;
        } catch (Exception e) {
            log.warn("SharePoint check failed ({} {}): {}", epicKey, spec.key, e.getMessage());
            return false;
        }
    }

    /** site path + library, e.g. /sites/ITTAADM/Project Documents */
    private String siteAndLibrary(CockpitProperties.SharePoint sp) {
        String sitePath = sp.getBaseUrl().replaceFirst("^https?://[^/]+", "");
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        return (sitePath + "/" + lib).replaceAll("/{2,}", "/");
    }

    /** Lists file names directly in a folder, optionally recursing into subfolders. */
    private List<String> listFiles(String serverRel, boolean recurse, int depth) {
        List<String> names = new ArrayList<>();
        if (depth > 5) return names; // safety bound
        var sp = props.getSharepoint();
        try {
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + encodePath(serverRel) + "')/Files?$select=Name";
            HttpResponse<String> r = spGet(url);
            if (r != null && r.statusCode() < 400) {
                JsonNode root = mapper.readTree(r.body());
                JsonNode files = root.has("value") ? root.path("value")
                        : root.path("d").path("results");
                if (files.isArray()) for (JsonNode f : files) names.add(f.path("Name").asText(""));
            } else if (r != null) {
                // Log at INFO so auth/path problems are visible (not hidden at debug).
                log.info("SharePoint Files HTTP {} for folder '{}'{}", r.statusCode(), serverRel,
                        (r.statusCode() == 401 || r.statusCode() == 403) ? " — cookies likely expired" : "");
            }
            if (recurse) {
                String furl = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                        + encodePath(serverRel) + "')/Folders?$select=Name,ServerRelativeUrl";
                HttpResponse<String> fr = spGet(furl);
                if (fr != null && fr.statusCode() < 400) {
                    JsonNode froot = mapper.readTree(fr.body());
                    JsonNode folders = froot.has("value") ? froot.path("value")
                            : froot.path("d").path("results");
                    if (folders.isArray()) for (JsonNode sf : folders) {
                        String name = sf.path("Name").asText("");
                        if ("Forms".equalsIgnoreCase(name)) continue; // skip system folder
                        String srv = sf.path("ServerRelativeUrl").asText("");
                        if (srv.isBlank()) srv = serverRel + "/" + name;
                        names.addAll(listFiles(srv, true, depth + 1));
                    }
                } else if (fr != null) {
                    log.info("SharePoint Folders HTTP {} for folder '{}'", fr.statusCode(), serverRel);
                }
            }
        } catch (Exception e) {
            log.info("listFiles error ({}): {}", serverRel, e.getMessage());
        }
        return names;
    }

    private HttpResponse<String> spGet(String url) {
        try {
            var sp = props.getSharepoint();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(20)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.debug("SharePoint GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** A file matches when its name contains the Jira id (full key or its number) and (if given) an extension. */
    private boolean fileMatchesId(String name, String epicKey, String idNum, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        boolean hasId = lower.contains(epicKey.toLowerCase()) || lower.contains(idNum.toLowerCase());
        if (!hasId) return false;
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** A file matches if it contains all `all` tokens, one `any` token, and (if given) an extension. */
    private boolean fileMatches(String name, List<String> all, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        for (String a : all) if (!lower.contains(a.toLowerCase())) return false;
        if (!any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (!exts.isEmpty()) {
            boolean ext = false;
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) { ext = true; break; }
            if (!ext) return false;
        }
        return true;
    }

    /** Encode a server-relative path for GetFolderByServerRelativeUrl('...'). */
    private String encodePath(String path) {
        return path.replace("'", "''").replace(" ", "%20");
    }
    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(30)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
