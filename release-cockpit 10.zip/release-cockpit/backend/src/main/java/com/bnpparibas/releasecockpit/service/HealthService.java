package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Computes a composite "release health" meter (0-100) from the readiness
 * summary and the checkpoint statuses.
 *
 * Weighting (tunable):
 *   - 40%  readiness   (share of subjects fully ready)
 *   - 25%  octane      (share with Octane tests linked)
 *   - 20%  sharepoint  (share SharePoint-complete)
 *   - 15%  timeline    (penalised when end-UAT is due-soon/overdue)
 */
@Service
public class HealthService {

    public ReleaseHealth compute(ReleaseSummary summary, Checkpoints checkpoints) {
        int total = Math.max(1, summary.totalSubjects());

        int readiness = pct(summary.ready(), total);
        int octane = pct(summary.readinessBreakdown().octaneOk(), total);
        int sharepoint = pct(summary.readinessBreakdown().sharepointOk(), total);
        int timeline = timelineScore(checkpoints);

        int score = (int) Math.round(
                readiness * 0.40 + octane * 0.25 + sharepoint * 0.20 + timeline * 0.15);

        List<String> risks = new ArrayList<>();
        if (readiness < 60) risks.add(summary.notReady() + " of " + summary.totalSubjects() + " subjects still have gaps");
        if (octane < 70) risks.add("Octane coverage is low (" + octane + "%)");
        if (sharepoint < 70) risks.add("SharePoint artifacts incomplete (" + sharepoint + "%)");
        if (checkpoints != null && "OVERDUE".equals(checkpoints.endUatStatus()))
            risks.add("End-UAT deadline has passed");
        else if (checkpoints != null && "DUE_SOON".equals(checkpoints.endUatStatus()))
            risks.add("End-UAT deadline is approaching");
        if (risks.isEmpty()) risks.add("On track — no major risks detected");

        return new ReleaseHealth(score, grade(score), readiness, octane, sharepoint, timeline, risks);
    }

    private int timelineScore(Checkpoints c) {
        if (c == null) return 100;
        // End-UAT status dominates; PPD modulates.
        int s = switch (c.endUatStatus()) {
            case "OVERDUE" -> 25;
            case "DUE_SOON" -> 60;
            case "DONE" -> 100;
            default -> 90; // UPCOMING
        };
        if ("OVERDUE".equals(c.ppdStatus())) s = Math.min(s, 50);
        return s;
    }

    private int pct(int part, int total) {
        return (int) Math.round((part * 100.0) / total);
    }

    private String grade(int score) {
        if (score >= 85) return "EXCELLENT";
        if (score >= 70) return "GOOD";
        if (score >= 50) return "AT_RISK";
        return "CRITICAL";
    }
}
