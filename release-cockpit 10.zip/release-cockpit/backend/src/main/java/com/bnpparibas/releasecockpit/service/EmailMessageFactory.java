package com.bnpparibas.releasecockpit.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.List;

/**
 * Builds MIME messages for the EMA SMTP relay, following the same pattern as the
 * STS dispatcher EmailMessageFactory:
 *   helper(message, multipart=true, UTF-8); setFrom + setReplyTo; setTo/Cc;
 *   setSubject; setText(body, html=true).
 *
 * Not a Spring @Component on its own — it's constructed by MailService with the
 * (optional) JavaMailSender, so the app still starts when mail isn't wired.
 */
@Slf4j
public class EmailMessageFactory {

    private final JavaMailSender javaMailSender;

    public EmailMessageFactory(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public MimeMessage createMessage(String from, String replyTo, List<String> to, List<String> cc,
                                     String subject, String htmlBody) throws MessagingException {
        final MimeMessage message = javaMailSender.createMimeMessage();
        final MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(new InternetAddress(from));
        helper.setReplyTo(new InternetAddress(
                (replyTo == null || replyTo.isBlank()) ? from : firstAddress(replyTo)));
        helper.setTo(to.toArray(new String[0]));
        if (cc != null && !cc.isEmpty()) {
            helper.setCc(cc.toArray(new String[0]));
        }
        helper.setSubject(subject);
        helper.setText(htmlBody, true);
        return message;
    }

    public void send(MimeMessage message) {
        javaMailSender.send(message);
    }

    /** Reply-To must be a single address; take the first if a list is configured. */
    private String firstAddress(String csv) {
        String first = csv.split(",")[0].trim();
        return first.isEmpty() ? csv : first;
    }
}
