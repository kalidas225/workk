package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Sends HTML readiness emails through the EMA SMTP relay using JavaMailSender,
 * via the EmailMessageFactory pattern.
 *
 * Recipients:  To = developer + reporter,  CC = managers (cockpit.mail.managers-cc).
 * From: cockpit.mail.from-address (e.g. Kalidas.Singamsetty@asia.bnpparibas.com).
 *
 * Resilience: JavaMailSender is injected via ObjectProvider, so if the mail
 * starter/SMTP is not wired the application STILL STARTS and mail simply falls
 * back to logging. In mock mode it always just logs.
 */
@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final EmailMessageFactory factory; // null if no JavaMailSender
    private final String jiraBaseUrl;

    public MailService(CockpitProperties props, ObjectProvider<JavaMailSender> mailSenderProvider) {
        this.props = props;
        JavaMailSender sender = mailSenderProvider.getIfAvailable();
        this.factory = (sender != null) ? new EmailMessageFactory(sender) : null;
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
        if (factory == null) {
            log.warn("No JavaMailSender available — emails will be logged, not sent. "
                    + "Configure spring.mail.* (EMA SMTP) to enable sending.");
        }
    }

    /** Email one developer + reporter (managers CC) about a subject's gaps. */
    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        List<String> to = recipientsFor(subject);
        List<String> cc = ccList();
        String subjectLine = "[Release " + releaseName + "] Action needed on " + subject.key()
                + " — " + subject.readiness().missingCount() + " item(s) missing";
        String html = EmailTemplate.gapEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null && cp.ppdStart() != null ? cp.ppdStart().toString() : "",
                cp != null && cp.endUatDone() != null ? cp.endUatDone().toString() : "",
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key());
        return send(to, cc, subjectLine, html, "gap:" + subject.key());
    }

    /** Email all developers who have a not-ready subject. */
    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0) { sendSubjectAlert(releaseName, s, cp); sent++; }
        }
        return sent;
    }

    /** Email the overall release-status summary to managers / summary list. */
    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = new ArrayList<>();
        for (String m : props.getMail().getSummaryTo()) if (!m.isBlank()) to.add(m.trim());
        for (String m : props.getMail().getManagersCc()) if (!m.isBlank()) to.add(m.trim());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());

        List<Subject> atRisk = subjects.stream()
                .filter(s -> s.readiness().missingCount() > 0)
                .sorted((a, b) -> b.readiness().missingCount() - a.readiness().missingCount())
                .toList();
        String subjectLine = "[Release " + releaseName + "] Status — " + health.grade()
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, atRisk);
        return send(to, List.of(), subjectLine, html, "summary:" + releaseName);
    }

    // ── helpers ──────────────────────────────────────────────────────────────
    private List<String> recipientsFor(Subject s) {
        List<String> to = new ArrayList<>();
        if (s.developerEmail() != null && !s.developerEmail().isBlank()) to.add(s.developerEmail());
        if (s.reporterEmail() != null && !s.reporterEmail().isBlank()
                && !s.reporterEmail().equalsIgnoreCase(s.developerEmail())) to.add(s.reporterEmail());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());
        return to;
    }

    private List<String> ccList() {
        List<String> cc = new ArrayList<>();
        for (String m : props.getMail().getManagersCc()) if (m != null && !m.isBlank()) cc.add(m.trim());
        return cc;
    }

    private String send(List<String> to, List<String> cc, String subjectLine, String html, String tag) {
        if (props.isMockMode() || factory == null) {
            log.info("MOCK/UNSENT MAIL [{}] from={} to={} cc={} subject='{}' (html {} chars)",
                    tag, props.getMail().getFromAddress(), to, cc, subjectLine, html.length());
            return "Simulated send to " + String.join(", ", to)
                    + (cc.isEmpty() ? "" : " (cc " + String.join(", ", cc) + ")")
                    + (factory == null ? " — mail not configured" : " — mock mode");
        }
        try {
            String from = props.getMail().getFromAddress();
            MimeMessage msg = factory.createMessage(from, props.getMail().getReplyTo(), to, cc, subjectLine, html);
            factory.send(msg);
            log.info("Sent [{}] from {} to {} (cc {})", tag, from, to, cc);
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("Mail send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String companyName() { return "BNP Paribas"; }
}
