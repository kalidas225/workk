package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.SubjectCheckConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads and persists per-subject check overrides (subject-checks.json).
 *
 * Source of truth is the JSON file; the dashboard reads the resolved config and
 * the UI can update it via the controller. On update we write the file back so
 * the config survives restarts (in a container, mount this path on a volume).
 *
 * Resolution: a subject's effective config = its specific entry if present,
 * otherwise the "default" block.
 */
@Slf4j
@Service
public class SubjectConfigService {

    private static final String RESOURCE = "subject-checks.json";
    private final ObjectMapper mapper = new ObjectMapper();

    // In-memory model: default + per-subject map. Mutable so the UI can edit.
    private SubjectCheckConfig defaults;
    private final Map<String, SubjectCheckConfig> overrides = new LinkedHashMap<>();
    // Where to persist edits (falls back to a temp copy if classpath is read-only).
    private File persistFile;

    public SubjectConfigService() {
        load();
    }

    private synchronized void load() {
        try {
            JsonNode root;
            // Prefer a writable external file if it already exists next to the app.
            File external = new File("config/" + RESOURCE);
            if (external.exists()) {
                root = mapper.readTree(external);
                persistFile = external;
            } else {
                try (InputStream is = new ClassPathResource(RESOURCE).getInputStream()) {
                    root = mapper.readTree(is);
                }
                persistFile = external; // we'll create it on first save
            }
            defaults = parse(root.path("default"));
            overrides.clear();
            JsonNode subs = root.path("subjects");
            subs.fieldNames().forEachRemaining(key ->
                    overrides.put(key, parse(subs.path(key))));
            log.info("Loaded subject checks: {} override(s)", overrides.size());
        } catch (Exception e) {
            log.warn("Could not load {} ({}); using built-in defaults", RESOURCE, e.getMessage());
            defaults = new SubjectCheckConfig(List.of("IST", "DEV", "UAT"), false, List.of(), null);
        }
    }

    private SubjectCheckConfig parse(JsonNode n) {
        List<String> envs = strList(n.path("octaneEnvironments"));
        if (envs.isEmpty()) envs = List.of("IST", "DEV", "UAT");
        boolean bcm = n.path("bcmEndToEnd").asBoolean(false);
        List<String> skip = strList(n.path("skipSharePoint"));
        String note = n.path("note").asText(null);
        return new SubjectCheckConfig(envs, bcm, skip, note);
    }

    private List<String> strList(JsonNode n) {
        List<String> out = new ArrayList<>();
        if (n != null && n.isArray()) n.forEach(e -> out.add(e.asText()));
        return out;
    }

    /** Effective config for a subject (its override, else the default). */
    public SubjectCheckConfig forSubject(String key) {
        return overrides.getOrDefault(key, defaults);
    }

    public SubjectCheckConfig getDefault() { return defaults; }
    public Map<String, SubjectCheckConfig> getOverrides() { return overrides; }

    /** Update one subject's override and persist. */
    public synchronized SubjectCheckConfig update(String key, SubjectCheckConfig cfg) {
        overrides.put(key, cfg);
        persist();
        return cfg;
    }

    /** Remove an override (subject reverts to default) and persist. */
    public synchronized void remove(String key) {
        overrides.remove(key);
        persist();
    }

    private void persist() {
        try {
            ObjectNode root = mapper.createObjectNode();
            root.set("default", toNode(defaults));
            ObjectNode subs = mapper.createObjectNode();
            overrides.forEach((k, v) -> subs.set(k, toNode(v)));
            root.set("subjects", subs);
            File target = persistFile != null ? persistFile : new File("config/" + RESOURCE);
            if (target.getParentFile() != null) target.getParentFile().mkdirs();
            mapper.writerWithDefaultPrettyPrinter().writeValue(target, root);
            persistFile = target;
            log.info("Persisted subject checks to {}", target.getPath());
        } catch (IOException e) {
            log.error("Failed to persist subject checks: {}", e.getMessage());
        }
    }

    private ObjectNode toNode(SubjectCheckConfig c) {
        ObjectNode n = mapper.createObjectNode();
        ArrayNode envs = n.putArray("octaneEnvironments");
        c.octaneEnvironments().forEach(envs::add);
        n.put("bcmEndToEnd", c.bcmEndToEnd());
        ArrayNode skip = n.putArray("skipSharePoint");
        c.skipSharePoint().forEach(skip::add);
        if (c.note() != null) n.put("note", c.note());
        return n;
    }
}
