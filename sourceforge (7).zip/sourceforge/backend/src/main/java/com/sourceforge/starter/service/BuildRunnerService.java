package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Runs a REAL build of the generated project so the user can confirm the whole
 * package compiles — all dependencies resolved, not just a syntax check.
 *
 *  - Java   : writes the generated project to a temp dir and runs
 *             `mvn -B clean install` (or `-DskipTests` per config), streaming
 *             every output line until BUILD SUCCESS / BUILD FAILURE.
 *  - Python : `poetry install` (+ build) for Poetry projects, or
 *             `pip install . && python -m py_compile` for pip projects.
 *
 * Output is streamed line-by-line via the supplied consumer so the controller
 * can forward it to the browser over SSE. The terminal exit code determines
 * success.
 *
 * Honest note: a real Maven build downloads dependencies from Maven Central or a
 * configured mirror/Artifactory. On a host without that access the build will
 * fail at dependency resolution; the streaming + log capture still work, and the
 * build succeeds wherever the repository is reachable. The mirror can be set with
 * sourceforge.build.maven-mirror (a settings.xml mirror URL) or left blank.
 */
@Service
public class BuildRunnerService {

    private static final Logger log = LoggerFactory.getLogger(BuildRunnerService.class);

    private final ProjectGeneratorService generator;
    private final boolean skipTests;
    private final long timeoutSeconds;
    private final String javaHome;       // company JDK (its cacerts already trusts Artifactory)
    private final String mavenHome;      // optional company Maven; else mvn on PATH
    private final String mavenSettings;  // path to company settings.xml (Artifactory mirror + creds)

    public BuildRunnerService(
            ProjectGeneratorService generator,
            @Value("${sourceforge.build.skip-tests:true}") boolean skipTests,
            @Value("${sourceforge.build.timeout-seconds:600}") long timeoutSeconds,
            @Value("${sourceforge.build.java-home:}") String javaHome,
            @Value("${sourceforge.build.maven-home:}") String mavenHome,
            @Value("${sourceforge.build.maven-settings:}") String mavenSettings) {
        this.generator = generator;
        this.skipTests = skipTests;
        this.timeoutSeconds = timeoutSeconds;
        this.javaHome = javaHome == null ? "" : javaHome.trim();
        this.mavenHome = mavenHome == null ? "" : mavenHome.trim();
        this.mavenSettings = mavenSettings == null ? "" : mavenSettings.trim();
    }

    public record BuildOutcome(boolean success, int exitCode, String summary) {}

    /**
     * Writes the generated project to disk and runs its real build, streaming
     * each log line to {@code onLine}. Returns the final outcome.
     */
    public BuildOutcome runBuild(ProjectRequest request, Consumer<String> onLine) {
        Path workDir = null;
        try {
            workDir = Files.createTempDirectory("sf-build-");
            Map<String, String> files = generator.buildFiles(request);
            // The generated files are prefixed with "<artifactId>/"; strip that so the
            // project root (with pom.xml / pyproject.toml) sits at workDir root.
            String prefix = request.artifactId() + "/";
            for (var e : files.entrySet()) {
                String rel = e.getKey().startsWith(prefix) ? e.getKey().substring(prefix.length()) : e.getKey();
                Path p = workDir.resolve(rel);
                Files.createDirectories(p.getParent());
                Files.writeString(p, e.getValue());
            }
            onLine.accept("[sourceforge] wrote " + files.size() + " files to build workspace");
            onLine.accept("[sourceforge] language=" + request.language()
                    + " build=" + request.type() + "  starting build…");
            onLine.accept("");

            List<String> command = request.isPython()
                    ? pythonCommand(request, workDir, onLine)
                    : mavenCommand(workDir, onLine);
            if (command == null || command.isEmpty()) {
                onLine.accept("[sourceforge] no build tool available on the server runtime.");
                return new BuildOutcome(false, -1, "Build tool not available.");
            }

            onLine.accept("$ " + String.join(" ", command));
            onLine.accept("");
            int exit = runProcess(command, workDir, onLine);

            boolean success = exit == 0;
            String summary = success
                    ? "BUILD SUCCESS — the project compiled and packaged cleanly."
                    : "BUILD FAILED (exit " + exit + ") — see the log above for the first error.";
            onLine.accept("");
            onLine.accept("[sourceforge] " + summary);
            log.info("real build  artifact={}  lang={}  exit={}  success={}",
                    request.artifactId(), request.language(), exit, success);
            return new BuildOutcome(success, exit, summary);

        } catch (Exception ex) {
            log.warn("build runner failed: {}", ex.getMessage());
            onLine.accept("[sourceforge] build could not start: " + ex.getMessage());
            return new BuildOutcome(false, -1, "Build could not start: " + ex.getMessage());
        } finally {
            if (workDir != null) deleteRecursive(workDir);
        }
    }

    private List<String> mavenCommand(Path workDir, Consumer<String> onLine) {
        String mvn = resolveMaven();
        if (mvn == null) {
            onLine.accept("[sourceforge] Maven (mvn) not found. Set sourceforge.build.maven-home or put mvn on PATH.");
            return null;
        }
        List<String> cmd = new ArrayList<>(List.of(mvn, "-B", "clean", "install"));
        if (skipTests) cmd.add("-DskipTests");
        if (!mavenSettings.isBlank()) {
            // Company settings.xml: Artifactory mirror + server credentials.
            cmd.add("-s");
            cmd.add(mavenSettings);
            onLine.accept("[sourceforge] using Maven settings: " + mavenSettings);
        } else {
            onLine.accept("[sourceforge] no settings.xml configured (sourceforge.build.maven-settings);"
                    + " using Maven defaults — set this to reach your Artifactory.");
        }
        return cmd;
    }

    /** Resolve mvn from the configured Maven home, else from PATH. */
    private String resolveMaven() {
        if (!mavenHome.isBlank()) {
            Path candidate = Path.of(mavenHome, "bin", isWindows() ? "mvn.cmd" : "mvn");
            if (Files.isExecutable(candidate)) return candidate.toString();
        }
        return resolve("mvn");
    }

    private List<String> pythonCommand(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        String python = resolve("python3", "python");
        if (python == null) {
            onLine.accept("[sourceforge] Python is not on PATH.");
            return null;
        }
        // Poetry project
        if ("poetry".equals(request.type())) {
            String poetry = resolve("poetry");
            if (poetry != null) {
                return List.of(poetry, "install", "--no-interaction");
            }
            onLine.accept("[sourceforge] poetry not installed; falling back to a syntax check.");
        } else {
            // pip project: install then byte-compile the package
            // (kept as a single shell so install + compile run in sequence)
            String pip = resolve("pip3", "pip");
            if (pip != null) {
                return List.of("sh", "-c",
                        pip + " install . && " + python + " -m compileall -q src");
            }
            onLine.accept("[sourceforge] pip not installed; falling back to a syntax check.");
        }
        // Fallback: byte-compile all sources for a syntax check
        return List.of(python, "-m", "compileall", "-q", ".");
    }

    private int runProcess(List<String> command, Path workDir, Consumer<String> onLine)
            throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(workDir.toFile());
        pb.redirectErrorStream(true);
        var env = pb.environment();
        // Keep Maven from emitting colour codes that would clutter the browser log.
        env.put("MAVEN_OPTS", "-Djansi.force=false");
        // Run the build with the company JDK: its cacerts already trusts the
        // Artifactory TLS chain, so no separate certificate import is needed.
        if (!javaHome.isBlank()) {
            env.put("JAVA_HOME", javaHome);
            String binDir = Path.of(javaHome, "bin").toString();
            String sep = isWindows() ? ";" : ":";
            env.put("PATH", binDir + sep + env.getOrDefault("PATH", ""));
            onLine.accept("[sourceforge] JAVA_HOME=" + javaHome + " (company JDK; its cacerts trusts Artifactory)");
        } else {
            onLine.accept("[sourceforge] no company JDK configured (sourceforge.build.java-home);"
                    + " using the JDK on PATH.");
        }
        Process proc = pb.start();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                onLine.accept(stripAnsi(line));
            }
        }
        boolean finished = proc.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        if (!finished) {
            proc.destroyForcibly();
            onLine.accept("[sourceforge] build timed out after " + timeoutSeconds + "s; aborted.");
            return 124;
        }
        return proc.exitValue();
    }

    private static String stripAnsi(String s) {
        return s.replaceAll("\u001B\\[[;\\d]*m", "");
    }

    private String resolve(String... candidates) {
        for (String c : candidates) {
            try {
                Process p = new ProcessBuilder(isWindows() ? "where" : "which", c)
                        .redirectErrorStream(true).start();
                if (p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0) return c;
            } catch (Exception ignore) { /* next */ }
        }
        return null;
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private void deleteRecursive(Path root) {
        try {
            Files.walk(root).sorted(Comparator.reverseOrder())
                    .forEach(p -> { try { Files.deleteIfExists(p); } catch (Exception ignore) {} });
        } catch (Exception ignore) { /* best effort */ }
    }
}
