# Sourceforge — End-to-End Setup (company JDK + Artifactory + Qwen LLM)

Everything is configurable; nothing company-specific is baked into the image.

## What you provide
1. Company JDK  -> backend/runtime/jdk/   (its cacerts already trusts Artifactory)
2. settings.xml -> backend/runtime/settings.xml   (Artifactory mirror + servers)
3. Qwen LLM endpoint (OpenAI-compatible) + API key   (the one you use via Roocode)

See backend/runtime/README.md for exact file layout.

## Run with Docker (recommended)
    cp .env.example .env          # fill in Artifactory creds + Qwen endpoint/key
    # place company JDK under backend/runtime/jdk/ and settings.xml at backend/runtime/settings.xml
    docker compose up --build
    # open http://localhost:8080

## Run locally (no Docker)
    cd backend
    export SOURCEFORGE_JAVA_HOME=$PWD/runtime/jdk
    export SOURCEFORGE_MAVEN_SETTINGS=$PWD/runtime/settings.xml
    export ARTIFACTORY_USER=...  ARTIFACTORY_TOKEN=...
    export SOURCEFORGE_LLM_ENABLED=true
    export SOURCEFORGE_LLM_PROVIDER=openai
    export SOURCEFORGE_LLM_BASE_URL=https://your-qwen-endpoint/v1
    export SOURCEFORGE_LLM_API_KEY=sk-...
    export SOURCEFORGE_LLM_MODEL=qwen2.5-coder
    mvn spring-boot:run
    # frontend: cd ../frontend && npm install && npm start  (proxies /api to :8080)

## How the pieces connect
- Full build ("MVN INSTALL" button / before generate): runs `mvn -B clean install
  -s <settings.xml>` with JAVA_HOME = company JDK. Because that JDK's cacerts
  trusts your Artifactory TLS, dependency downloads succeed with no cert import.
  The complete log streams live to the UI over SSE until BUILD SUCCESS.
- Python build: `poetry install` or `pip install . && python -m compileall`,
  matching the chosen build type; log streams the same way.
- Compatible-version dropdowns: backend calls your Qwen endpoint
  (OpenAI-compatible /v1/chat/completions, Bearer auth). Key stays server-side.
  If the LLM is unreachable/disabled, the static version catalog is used.

## LLM = Qwen via OpenAI-compatible API (as used in Roocode)
provider=openai means the client posts to {base-url}/chat/completions with
Authorization: Bearer {api-key} and {"model": "...", "messages": [...]} — the
same shape Roocode uses. Set base-url/api-key/model to your Qwen gateway.
