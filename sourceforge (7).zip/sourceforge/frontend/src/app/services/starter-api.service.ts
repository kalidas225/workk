import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MetadataResponse, ProjectRequest } from '../models/metadata.model';

@Injectable({ providedIn: 'root' })
export class StarterApiService {
  private readonly baseUrl = '/api';

  constructor(private http: HttpClient) {}

  getMetadata(): Observable<MetadataResponse> {
    return this.http.get<MetadataResponse>(`${this.baseUrl}/metadata`);
  }

  /** Returns { path: content } for the Explore preview. */
  previewProject(request: ProjectRequest): Observable<Record<string, string>> {
    return this.http.post<Record<string, string>>(`${this.baseUrl}/preview`, request);
  }

  generateProject(request: ProjectRequest): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/generate`, request, {
      responseType: 'blob'
    });
  }

  /** Compatible version dropdown options per dependency for the selected Boot/Java. */
  compatibleVersions(body: {
    dependencies: string[]; language: string; bootVersion: string; javaVersion: string;
  }): Observable<Record<string, string[]>> {
    return this.http.post<Record<string, string[]>>(`${this.baseUrl}/compatible-versions`, body);
  }

  /** Sandbox-compile the generated Java; returns structured diagnostics. */
  compileProject(request: ProjectRequest): Observable<CompileResult> {
    return this.http.post<CompileResult>(`${this.baseUrl}/compile`, request);
  }

  /**
   * Runs the REAL build (mvn clean install / poetry|pip) and streams the full log.
   * Uses fetch + ReadableStream to parse Server-Sent Events from a POST request
   * (EventSource only supports GET). Calls onLog for each log line and onDone
   * with the final outcome. Returns an AbortController so the caller can cancel.
   */
  streamBuild(
    request: ProjectRequest,
    onLog: (line: string) => void,
    onDone: (outcome: { success: boolean; exitCode: number; summary: string }) => void,
    onError: (message: string) => void
  ): AbortController {
    const controller = new AbortController();
    fetch(`${this.baseUrl}/build-stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream' },
      body: JSON.stringify(request),
      signal: controller.signal
    })
      .then(async (resp) => {
        if (!resp.ok || !resp.body) { onError(`Build request failed (HTTP ${resp.status})`); return; }
        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        // SSE frames are separated by a blank line; each frame has event:/data: lines.
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let sep: number;
          while ((sep = buffer.indexOf('\n\n')) >= 0) {
            const frame = buffer.slice(0, sep);
            buffer = buffer.slice(sep + 2);
            let event = 'message';
            const dataLines: string[] = [];
            for (const raw of frame.split('\n')) {
              if (raw.startsWith('event:')) event = raw.slice(6).trim();
              else if (raw.startsWith('data:')) dataLines.push(raw.slice(5).replace(/^ /, ''));
            }
            const data = dataLines.join('\n');
            if (event === 'log') {
              onLog(data);
            } else if (event === 'done') {
              try { onDone(JSON.parse(data)); }
              catch { onDone({ success: false, exitCode: -1, summary: data }); }
            }
          }
        }
      })
      .catch((err) => {
        if (err?.name !== 'AbortError') onError(err?.message || 'Build stream error');
      });
    return controller;
  }
}

export interface CompileDiagnostic {
  kind: string;
  path: string;
  line: number;
  column: number;
  message: string;
}

export interface CompileResult {
  ok: boolean;
  compilerAvailable: boolean;
  errorCount: number;
  warningCount: number;
  diagnostics: CompileDiagnostic[];
  summary: string;
}
