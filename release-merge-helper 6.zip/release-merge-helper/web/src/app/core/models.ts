export interface RepoRef {
  gitlabId: number | null; name: string; path: string; webUrl: string | null;
  localPath: string | null; defaultBranch: string; source: 'gitlab' | 'local' | 'both'; cached?: boolean; operable?: boolean;
}
export interface ProjectGroup { group: string; repos: RepoRef[]; }
export interface ReposResponse { groups: ProjectGroup[]; gitlab: boolean; gitlabError?: string | null; }
export interface ConnectResponse { ok: boolean; root: string; currentBranch: string; repoKey: string; }
export interface Branch { name: string; sha: string; date: string; remote: boolean; protectedBranch: boolean; }
export interface Commit {
  hash: string; shortHash: string; author: string; email: string;
  date: string; subject: string; body: string; subjectKey: string;
}
export interface SubjectGroup { key: string; count: number; commits: Commit[]; }
export interface CommitsResponse { source: string; target: string; total: number; returned?: number; offset?: number; limit?: number; groups: SubjectGroup[]; }

export interface DryItem { sha: string; ok: boolean; conflicts: string[]; }
export interface DryResponse { dryRun: true; results: DryItem[]; }

export type SegType = 'context' | 'conflict';
export interface Segment {
  type: SegType;
  lines?: string[];                 // context
  ours?: string[]; theirs?: string[]; oursLabel?: string; theirsLabel?: string; // conflict
}
export interface ConflictFile { file: string; segments: Segment[]; conflictCount: number; }

export interface AutoResolved { sha: string; files: string[]; }
export interface MrResponse { ok: boolean; iid: number | null; webUrl: string | null; state: string | null; title?: string; }
export interface SqlWarning { file: string; ok: boolean; reason: string; lastLine: string; }

export interface CherryPickState {
  status: 'conflict' | 'done';
  // conflict:
  sha?: string; fullSha?: string; workBranch: string; remaining?: number; applied: number;
  files?: ConflictFile[]; log: string[];
  // done:
  ok?: boolean; createdNewBranch?: boolean; head?: string; pushHint?: string | null;
  sqlWarnings?: SqlWarning[];
  autoResolved?: AutoResolved[];
  skipped?: number; skippedShas?: string[];
}
export interface PushResponse { ok: boolean; branch: string | null; output: string; }

// per-conflict choice in the editor
export type Side = 'ours' | 'theirs' | 'both';
