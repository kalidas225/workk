import { Component, EventEmitter, Input, Output, computed, signal } from '@angular/core';
import { ConflictFile, Segment, Side } from '../core/models';

interface Choice { side: Side; }

@Component({
  selector: 'app-conflict-editor',
  standalone: true,
  template: `
  <div class="ce">
    <div class="ce-head">
      <div class="ce-head-main">
        <div class="ce-title-row">
          <span class="ce-icon">⚠</span>
          <div>
            <strong>Resolve conflicts</strong>
            <small>commit <code>{{ sha }}</code> · {{ files.length }} file(s) need a decision · order files were already auto-merged</small>
          </div>
        </div>
      </div>
      <div class="ce-head-actions">
        <span class="ce-progress" [class.complete]="allResolved()">{{ resolvedCount() }} / {{ totalConflicts() }} resolved</span>
        <button class="ce-btn primary" [disabled]="!allResolved()" (click)="emitResolved()">
          @if (allResolved()) { Apply &amp; continue → } @else { {{ totalConflicts() - resolvedCount() }} left }
        </button>
        <button class="ce-x" (click)="cancelled.emit()" title="Cancel cherry-pick" aria-label="Cancel cherry-pick">×</button>
      </div>
    </div>

    <div class="ce-body">
    @for (f of files; track f.file; let fi = $index) {
      <div class="ce-file" [class.collapsed]="isCollapsed(fi)">
        <div class="ce-file-head" (click)="toggleFile(fi)">
          <span class="caret">{{ isCollapsed(fi) ? '▸' : '▾' }}</span>
          <span class="fname mono">{{ f.file }}</span>
          <span class="fbadge" [class.done]="fileResolved(f, fi)">{{ resolvedInFile(f, fi) }} / {{ conflictsIn(f).length }} resolved</span>
          <span class="file-quick" (click)="$event.stopPropagation()">
            <button class="quick-btn" (click)="resolveFile(fi, f, 'ours')" title="Keep all release for this file">all ours</button>
            <button class="quick-btn" (click)="resolveFile(fi, f, 'theirs')" title="Keep all incoming for this file">all theirs</button>
          </span>
        </div>

        @if (!isCollapsed(fi)) {
          <div class="ce-file-body">
          @for (seg of f.segments; track $index; let si = $index) {
            @if (seg.type === 'context') {
              @if (nonEmpty(seg.lines)) {
                <pre class="ctx mono">{{ joinLines(seg.lines) }}</pre>
              }
            } @else {
              <div class="hunk" [attr.data-side]="choiceFor(fi, si)?.side ?? 'none'">
                <div class="hunk-bar">
                  <span class="hunk-n">conflict #{{ conflictOrdinal(f, si) }} @if (choiceFor(fi, si)) { <span class="hunk-done">✓</span> }</span>
                  <div class="hunk-actions">
                    <button class="side-btn ours" [class.on]="choiceFor(fi, si)?.side === 'ours'" (click)="pick(fi, si, 'ours')">
                      ◀ Keep {{ seg.oursLabel || 'release' }}
                    </button>
                    <button class="side-btn theirs" [class.on]="choiceFor(fi, si)?.side === 'theirs'" (click)="pick(fi, si, 'theirs')">
                      Keep {{ seg.theirsLabel || 'incoming' }} ▶
                    </button>
                    <button class="side-btn both" [class.on]="choiceFor(fi, si)?.side === 'both'" (click)="pick(fi, si, 'both')">
                      Both
                    </button>
                  </div>
                </div>
                <div class="hunk-cols">
                  <div class="col ours" [class.dim]="choiceFor(fi, si)?.side === 'theirs'" [class.chosen]="choiceFor(fi, si)?.side === 'ours' || choiceFor(fi, si)?.side === 'both'">
                    <div class="col-tag">ours · release</div>
                    <pre class="mono">{{ joinLines(seg.ours) || '(empty)' }}</pre>
                  </div>
                  <div class="col theirs" [class.dim]="choiceFor(fi, si)?.side === 'ours'" [class.chosen]="choiceFor(fi, si)?.side === 'theirs' || choiceFor(fi, si)?.side === 'both'">
                    <div class="col-tag">theirs · incoming</div>
                    <pre class="mono">{{ joinLines(seg.theirs) || '(empty)' }}</pre>
                  </div>
                </div>
              </div>
            }
          }
          </div>
        }
      </div>
    }

    </div>

    <div class="ce-foot">
      <button class="ce-btn ghost" (click)="cancelled.emit()">Cancel cherry-pick</button>
      <button class="ce-btn primary" [disabled]="!allResolved()" (click)="emitResolved()">
        @if (allResolved()) { Apply &amp; continue → } @else { {{ totalConflicts() - resolvedCount() }} conflict(s) left }
      </button>
    </div>
  </div>
  `,
  styleUrl: './conflict-editor.component.css',
})
export class ConflictEditorComponent {
  @Input({ required: true }) files: ConflictFile[] = [];
  @Input() sha = '';
  @Output() resolved = new EventEmitter<{ file: string; content: string }[]>();
  @Output() cancelled = new EventEmitter<void>();

  // choices keyed "fileIndex:segIndex"
  private choices = signal<Map<string, Choice>>(new Map());
  private collapsed = signal<Set<number>>(new Set());

  private k(fi: number, si: number) { return `${fi}:${si}`; }
  choiceFor(fi: number, si: number) { return this.choices().get(this.k(fi, si)); }
  pick(fi: number, si: number, side: Side) {
    const m = new Map(this.choices()); m.set(this.k(fi, si), { side }); this.choices.set(m);
    // auto-collapse a file once all its conflicts are resolved, to guide the eye to what's left
    const f = this.files[fi];
    if (f && this.conflictsIn(f).every((_, idx) => this.choiceFor(fi, f.segments.indexOf(this.conflictsIn(f)[idx])))) {
      // no-op; collapsing handled by user. (kept simple + predictable)
    }
  }
  resolveFile(fi: number, f: ConflictFile, side: Side) {
    const m = new Map(this.choices());
    f.segments.forEach((seg, si) => { if (seg.type === 'conflict') m.set(this.k(fi, si), { side }); });
    this.choices.set(m);
  }

  isCollapsed(fi: number) { return this.collapsed().has(fi); }
  toggleFile(fi: number) { const s = new Set(this.collapsed()); s.has(fi) ? s.delete(fi) : s.add(fi); this.collapsed.set(s); }

  conflictsIn(f: ConflictFile) { return f.segments.filter((s) => s.type === 'conflict'); }
  resolvedInFile(f: ConflictFile, fi: number) {
    let n = 0; f.segments.forEach((seg, si) => { if (seg.type === 'conflict' && this.choiceFor(fi, si)) n++; }); return n;
  }
  fileResolved(f: ConflictFile, fi: number) { return this.resolvedInFile(f, fi) === this.conflictsIn(f).length && this.conflictsIn(f).length > 0; }
  nonEmpty(lines?: string[]) { return !!lines && lines.some((l) => l.trim() !== ''); }
  joinLines(lines?: string[]) { return (lines || []).join('\n'); }
  conflictOrdinal(f: ConflictFile, si: number) {
    let n = 0; for (let i = 0; i <= si; i++) if (f.segments[i].type === 'conflict') n++; return n;
  }

  totalConflicts = computed(() =>
    this.files.reduce((a, f) => a + f.segments.filter((s) => s.type === 'conflict').length, 0));
  resolvedCount = computed(() => this.choices().size);
  allResolved = computed(() => this.resolvedCount() === this.totalConflicts() && this.totalConflicts() > 0);

  emitResolved() {
    const out: { file: string; content: string }[] = [];
    this.files.forEach((f, fi) => {
      const lines: string[] = [];
      f.segments.forEach((seg, si) => {
        if (seg.type === 'context') lines.push(...(seg.lines || []));
        else {
          const c = this.choiceFor(fi, si)?.side ?? 'ours';
          if (c === 'ours') lines.push(...(seg.ours || []));
          else if (c === 'theirs') lines.push(...(seg.theirs || []));
          else lines.push(...(seg.ours || []), ...(seg.theirs || []));
        }
      });
      out.push({ file: f.file, content: lines.join('\n') });
    });
    this.resolved.emit(out);
  }
}
