import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StarterApiService, CompileResult } from './services/starter-api.service';
import {
  DATABASE_OPTIONS,
  DDL_AUTO_OPTIONS,
  ArchitectureOption,
  Dependency,
  DependencyCategory,
  LanguageMetadata,
  MetadataResponse,
  ProjectRequest,
  buildTypeLabel,
  packagingLabel
} from './models/metadata.model';

interface TreeNode {
  name: string;
  isDir: boolean;
  children: TreeNode[];
}

interface FlatNode {
  name: string;
  isDir: boolean;
  depth: number;
  ancestorsLast: boolean[];
}

interface PreviewTreeNode {
  name: string;
  fullPath: string;
  isDir: boolean;
  children: Map<string, PreviewTreeNode>;
}

interface PreviewNode {
  name: string;
  fullPath: string;
  isDir: boolean;
  depth: number;
}

interface FormState {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
  architecture: string;
  dbType: string;
  dbUrl: string;
  dbUsername: string;
  dbPassword: string;
  dbDdlAuto: string;
  // Env section
  envEnabled: boolean;
  envSelected: string[];                 // subset of [dev,ist,uat,ppd,prod]
  envConfigServerUrl: string;
  envConfigServerProfile: string;
  // DMZR section
  dmzrEnabled: boolean;
  dmzrVaultPolicies: boolean;
  dmzrHelmChart: boolean;
  dmzrVaultRole: string;
  dmzrVaultSecretPath: string;
  dmzrK8sNamespace: string;
  dmzrDockerImage: string;
  dmzrEnvironments: string[];
  // BNP/BP2S deployment
  applicationCode: string;        // ap-code, e.g. ap25701
  cosEnabled: boolean;
  cosInstanceIds: string;         // comma-separated instance ids
  cosEndpoint: string;
  cosBucket: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  metadata = signal<MetadataResponse | null>(null);
  loading = signal(false);
  generating = signal(false);
  errorMessage = signal<string | null>(null);
  successMessage = signal<string | null>(null);

  readonly DATABASE_OPTIONS = DATABASE_OPTIONS;
  readonly DDL_AUTO_OPTIONS = DDL_AUTO_OPTIONS;
  readonly buildTypeLabel = buildTypeLabel;
  readonly packagingLabel = packagingLabel;

  // OS-aware shortcut modifier label: "⌘" on Mac, "Ctrl" elsewhere.
  readonly modKeyLabel = signal<string>(this.detectModKey());

  // Theme: "light" | "dark"
  theme = signal<'light' | 'dark'>('light');

  form = signal<FormState>({
    type: 'maven',
    language: 'java',
    bootVersion: '3.3.5',
    groupId: 'com.bnpparibas.cib2s',
    artifactId: 'demo',
    name: 'demo',
    description: 'Demo project for Spring Boot',
    packageName: 'com.bnpparibas.cib2s.demo',
    packaging: 'jar',
    javaVersion: '21',
    architecture: 'standard',
    dbType: 'h2',
    dbUrl: 'jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1;MODE=PostgreSQL',
    dbUsername: 'sa',
    dbPassword: '',
    dbDdlAuto: 'update',
    envEnabled: false,
    envSelected: ['dev'],
    envConfigServerUrl: '',
    envConfigServerProfile: 'dev',
    dmzrEnabled: false,
    dmzrVaultPolicies: true,
    dmzrHelmChart: true,
    dmzrVaultRole: '',
    dmzrVaultSecretPath: '',
    dmzrK8sNamespace: 'default',
    dmzrDockerImage: '',
    dmzrEnvironments: ['dev', 'prod'],
    applicationCode: '',
    cosEnabled: false,
    cosInstanceIds: '',
    cosEndpoint: 's3.eu-de.cloud-object-storage.appdomain.cloud:4208',
    cosBucket: ''
  });

  selectedIds = signal<Set<string>>(new Set());

  // Per-dependency version overrides (depId -> version string; blank = managed)
  depVersions = signal<Record<string, string>>({});

  // Per-environment deployment settings: profile id -> {ecosystem, kubernetesPath, namespace, cosInstanceIds, cosBuckets}
  envSettings = signal<Record<string, { ecosystem: string; kubernetesPath: string; namespace: string; cosInstanceIds: string; cosBuckets: string }>>({});

  envSettingValue(env: string, field: 'ecosystem' | 'kubernetesPath' | 'namespace' | 'cosInstanceIds' | 'cosBuckets'): string {
    return this.envSettings()[env]?.[field] ?? '';
  }
  setEnvSetting(env: string, field: 'ecosystem' | 'kubernetesPath' | 'namespace' | 'cosInstanceIds' | 'cosBuckets', value: string): void {
    this.envSettings.update(s => {
      const cur = s[env] ?? { ecosystem: '', kubernetesPath: '', namespace: '', cosInstanceIds: '', cosBuckets: '' };
      return { ...s, [env]: { ...cur, [field]: value } };
    });
  }

  modalOpen = signal(false);
  summaryOpen = signal(false);
  searchQuery = signal('');
  highlightedIndex = signal(0);

  // ===== Explore / file preview state =====
  previewLoading = signal(false);
  previewError = signal<string | null>(null);
  previewFiles = signal<Record<string, string>>({});   // path -> content (live, editable)
  editedPaths = signal<Set<string>>(new Set());          // which paths the user changed
  activePreviewPath = signal<string | null>(null);       // currently open file in editor

  private packageNameTouched = false;
  private nameTouched = false;
  private dbUrlTouched = false;
  private dbUsernameTouched = false;

  constructor(private api: StarterApiService) {}

  // ===== language-aware metadata accessors =====
  activeLanguage = computed<LanguageMetadata | null>(() => {
    const meta = this.metadata();
    if (!meta) return null;
    return meta.languageMetadata.find(l => l.id === this.form().language) ?? meta.languageMetadata[0];
  });

  buildTypes = computed<string[]>(() => this.activeLanguage()?.buildTypes ?? []);
  runtimeVersions = computed<string[]>(() => this.activeLanguage()?.runtimeVersions ?? []);
  packagings = computed<string[]>(() => this.activeLanguage()?.packagings ?? []);
  frameworkVersions = computed<string[]>(() => this.activeLanguage()?.frameworkVersions ?? []);
  dependencyCatalog = computed<DependencyCategory[]>(() => this.activeLanguage()?.dependencies ?? []);

  isJava = computed<boolean>(() => this.form().language === 'java');
  isPython = computed<boolean>(() => this.form().language === 'python');

  selectedDeps = computed<Dependency[]>(() => {
    const ids = this.selectedIds();
    const cats = this.dependencyCatalog();
    const flat: Dependency[] = [];
    for (const c of cats) for (const d of c.dependencies) if (ids.has(d.id)) flat.push(d);
    return flat;
  });

  architectures = computed<ArchitectureOption[]>(() => this.metadata()?.architectures ?? []);

  architectureLabel(id: string): string {
    return this.architectures().find(a => a.id === id)?.label ?? id;
  }

  // ===== File-tree preview (mirrors what the backend will generate) =====
  fileTree = computed<TreeNode>(() => this.buildFileTree());

  private buildFileTree(): TreeNode {
    const f = this.form();
    const art = f.artifactId || 'demo';
    const paths: string[] = [];

    if (this.isPython()) {
      const pkgDir = (f.packageName || 'com.bnpparibas.cib2s.demo').replace(/\./g, '_');
      if (f.type === 'poetry') {
        paths.push('pyproject.toml');
      } else {
        paths.push('requirements.txt');
        if (this.hasDevDeps()) paths.push('requirements-dev.txt');
        paths.push('setup.py');
      }
      paths.push(`src/${pkgDir}/__init__.py`);
      if (f.architecture !== 'standard') {
        paths.push(`src/${pkgDir}/models.py`);
        paths.push(`src/${pkgDir}/repository.py`);
        paths.push(`src/${pkgDir}/service.py`);
        paths.push(`src/${pkgDir}/router.py`);
        if (f.architecture === 'microservice') {
          paths.push(`src/${pkgDir}/settings.py`);
          paths.push(`src/${pkgDir}/client.py`);
        }
      }
      paths.push(`src/${pkgDir}/main.py`);
      paths.push('tests/__init__.py');
      paths.push('tests/test_smoke.py');
      paths.push('.gitignore');
      paths.push('README.md');
    } else {
      const pkgPath = (f.packageName || 'com.bnpparibas.cib2s.demo').replace(/\./g, '/');
      const cls = this.toClassName(art) + 'Application';
      if (f.type === 'maven') {
        paths.push('pom.xml');
        paths.push('.mvn/wrapper/README.md');
      } else if (f.type === 'gradle-kotlin') {
        paths.push('build.gradle.kts');
        paths.push('settings.gradle.kts');
        paths.push('gradle/wrapper/README.md');
      } else {
        paths.push('build.gradle');
        paths.push('settings.gradle');
        paths.push('gradle/wrapper/README.md');
      }
      paths.push(`src/main/java/${pkgPath}/${cls}.java`);
      if (f.architecture !== 'standard') {
        paths.push(`src/main/java/${pkgPath}/model/Greeting.java`);
        paths.push(`src/main/java/${pkgPath}/dto/GreetingRequest.java`);
        paths.push(`src/main/java/${pkgPath}/repository/GreetingRepository.java`);
        paths.push(`src/main/java/${pkgPath}/service/GreetingService.java`);
        paths.push(`src/main/java/${pkgPath}/controller/GreetingController.java`);
        if (f.architecture === 'microservice') {
          paths.push(`src/main/java/${pkgPath}/config/AppProperties.java`);
          paths.push(`src/main/java/${pkgPath}/config/RestClientConfig.java`);
          paths.push(`src/main/java/${pkgPath}/client/DownstreamClient.java`);
          paths.push(`src/main/java/${pkgPath}/controller/StatusController.java`);
          paths.push(`src/main/java/${pkgPath}/web/GlobalExceptionHandler.java`);
        }
      }
      paths.push(`src/test/java/${pkgPath}/${cls}Tests.java`);
      paths.push('src/main/resources/application.properties');
      if (f.envEnabled && f.envSelected.length) {
        paths.push('src/main/resources/bootstrap.yaml');
        for (const e of f.envSelected) paths.push(`src/main/resources/bootstrap-${e}.yaml`);
      }
      paths.push('.gitignore');
      paths.push('README.md');
    }

    // DMZR assets (both languages)
    if (f.dmzrEnabled) {
      const envs = f.dmzrEnvironments.length ? f.dmzrEnvironments : ['dev', 'ist', 'uat', 'ppd', 'prod'];
      if (f.dmzrVaultPolicies) {
        paths.push('dmzr/vault/kubernetes-auth.md');
        for (const e of envs) {
          paths.push(`dmzr/vault/policies/${art}-${e}.hcl`);
          paths.push(`dmzr/vault/secrets/${e}.yaml`);
        }
      }
      if (f.dmzrHelmChart) {
        paths.push('dmzr/helm/chart/Chart.yaml');
        paths.push('dmzr/helm/chart/values.yaml');
        paths.push('dmzr/helm/chart/templates/deployment.yaml');
        paths.push('dmzr/helm/chart/templates/service.yaml');
        paths.push('dmzr/helm/chart/templates/serviceaccount.yaml');
        for (const e of envs) paths.push(`dmzr/helm/values-${e}.yaml`);
      }
      paths.push('dmzr/README.md');
    }
    paths.push('HELP.md');

    // Build a tree from the flat path list
    const rootNode: TreeNode = { name: art + '/', isDir: true, children: [] };
    for (const p of paths) {
      const segs = p.split('/');
      let cursor = rootNode;
      segs.forEach((seg, idx) => {
        const isLast = idx === segs.length - 1;
        const isDir = !isLast;
        let child = cursor.children.find(c => c.name === (isDir ? seg + '/' : seg) && c.isDir === isDir);
        if (!child) {
          child = { name: isDir ? seg + '/' : seg, isDir, children: [] };
          cursor.children.push(child);
        }
        cursor = child;
      });
    }
    this.sortTree(rootNode);
    return rootNode;
  }

  private sortTree(node: TreeNode): void {
    node.children.sort((a, b) => {
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    for (const c of node.children) this.sortTree(c);
  }

  // Flattened tree (depth + name + isDir + isLast path markers) for template rendering.
  flatTree = computed<FlatNode[]>(() => {
    const out: FlatNode[] = [];
    const root = this.fileTree();
    const walk = (node: TreeNode, depth: number, ancestorsLast: boolean[]) => {
      const children = node.children;
      children.forEach((child, idx) => {
        const isLast = idx === children.length - 1;
        out.push({
          name: child.name,
          isDir: child.isDir,
          depth,
          ancestorsLast: [...ancestorsLast]
        });
        if (child.isDir) {
          walk(child, depth + 1, [...ancestorsLast, isLast]);
        }
      });
    };
    // Root node itself shown as the top line
    out.push({ name: root.name, isDir: true, depth: 0, ancestorsLast: [] });
    walk(root, 1, []);
    return out;
  });

  treeIndent(node: FlatNode): string {
    // Build the indentation guide for a row at the given depth.
    if (node.depth <= 1) return '';
    let s = '';
    for (let i = 1; i < node.depth; i++) {
      s += node.ancestorsLast[i - 1] ? '    ' : '│   ';
    }
    return s;
  }

  private hasDevDeps(): boolean {
    return this.selectedDeps().some(d => d.scope === 'dev');
  }

  private toClassName(artifactId: string): string {
    let out = '';
    let upper = true;
    for (const c of artifactId) {
      if (c === '-' || c === '_' || c === '.') { upper = true; continue; }
      out += upper ? c.toUpperCase() : c;
      upper = false;
    }
    return out || 'Application';
  }

  ngOnInit(): void {
    this.initTheme();
    this.loadMetadata();
  }

  // ===== Theme =====
  private initTheme(): void {
    let initial: 'light' | 'dark' = 'light';
    try {
      const stored = localStorage.getItem('sf-theme');
      if (stored === 'dark' || stored === 'light') {
        initial = stored;
      } else if (typeof window !== 'undefined' && window.matchMedia
                 && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        initial = 'dark';
      }
    } catch {
      // localStorage unavailable — fall back to light
    }
    this.applyTheme(initial);
  }

  toggleTheme(): void {
    this.applyTheme(this.theme() === 'dark' ? 'light' : 'dark');
  }

  private applyTheme(theme: 'light' | 'dark'): void {
    this.theme.set(theme);
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', theme);
    }
    try { localStorage.setItem('sf-theme', theme); } catch { /* ignore */ }
  }

  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent) {
    const isMod = e.ctrlKey || e.metaKey;
    // Ctrl/Cmd + Enter → generate
    if (isMod && e.key === 'Enter') { e.preventDefault(); this.generate(); return; }
    // Ctrl/Cmd + Space → explore (preview)
    if (isMod && (e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar')) {
      e.preventDefault(); this.showSummary(); return;
    }
    if (isMod && e.key.toLowerCase() === 'b') { e.preventDefault(); this.openDependencyModal(); return; }
    if (this.modalOpen()) {
      if (e.key === 'Escape') { this.closeDependencyModal(); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); this.moveHighlight(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); this.moveHighlight(-1); }
      else if (e.key === 'Enter') {
        e.preventDefault();
        const flat = this.filteredDepsFlat();
        const i = this.highlightedIndex();
        if (flat[i]) this.toggleDependency(flat[i].id);
      }
    }
    if (this.summaryOpen() && e.key === 'Escape') this.summaryOpen.set(false);
  }

  // ===== OS detection =====
  private detectModKey(): string {
    if (typeof navigator === 'undefined') return 'Ctrl';
    const ua = (navigator.userAgent || '').toLowerCase();
    const platform = ((navigator as any).platform || '').toLowerCase();
    const isMac = /mac|iphone|ipad|ipod/.test(platform) || /mac os x|macintosh/.test(ua);
    return isMac ? '⌘' : 'Ctrl';
  }

  loadMetadata(): void {
    this.loading.set(true);
    this.errorMessage.set(null);
    this.api.getMetadata().subscribe({
      next: (meta) => {
        this.metadata.set(meta);
        // Pick default language and seed form from its defaults
        const defLang = meta.languageMetadata.find(l => l.id === meta.defaultLanguage) ?? meta.languageMetadata[0];
        this.applyLanguageDefaults(defLang);
        this.loading.set(false);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMessage.set('Could not reach the backend. Is the server running on http://localhost:8080 ?');
        console.error(err);
      }
    });
  }

  private applyLanguageDefaults(lang: LanguageMetadata) {
    const d = lang.defaults;
    this.form.update(f => ({
      ...f,
      language: lang.id,
      type: d.type,
      bootVersion: d.bootVersion,
      groupId: d.groupId,
      artifactId: d.artifactId,
      name: d.name,
      description: d.description,
      packageName: d.packageName,
      packaging: d.packaging,
      javaVersion: d.javaVersion
    }));
    this.selectedIds.set(new Set());
  }

  reset(): void {
    const meta = this.metadata();
    if (!meta) return;
    const lang = meta.languageMetadata.find(l => l.id === meta.defaultLanguage) ?? meta.languageMetadata[0];
    this.applyLanguageDefaults(lang);
    this.form.update(f => ({
      ...f,
      architecture: 'standard',
      dbType: 'h2', dbUrl: 'jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1;MODE=PostgreSQL', dbUsername: 'sa', dbPassword: '', dbDdlAuto: 'update',
      envEnabled: false, envSelected: ['dev'], envConfigServerUrl: '', envConfigServerProfile: 'dev',
      dmzrEnabled: false, dmzrVaultPolicies: true, dmzrHelmChart: true,
      dmzrVaultRole: '', dmzrVaultSecretPath: '', dmzrK8sNamespace: 'default',
      dmzrDockerImage: '', dmzrEnvironments: ['dev', 'prod'],
      applicationCode: '', cosEnabled: false, cosInstanceIds: '',
      cosEndpoint: 's3.eu-de.cloud-object-storage.appdomain.cloud:4208', cosBucket: ''
    }));
    this.packageNameTouched = false;
    this.nameTouched = false;
    this.dbUrlTouched = false;
    this.dbUsernameTouched = false;
    this.depVersions.set({});
    this.envSettings.set({});
    this.errorMessage.set(null);
    this.successMessage.set(null);
  }

  changeLanguage(newLang: string): void {
    const meta = this.metadata();
    if (!meta) return;
    const lang = meta.languageMetadata.find(l => l.id === newLang);
    if (!lang) return;
    // Reset env config when switching to python (not supported there)
    if (newLang !== 'java') {
      this.form.update(f => ({ ...f, envEnabled: false }));
    }
    this.applyLanguageDefaults(lang);
  }

  updateForm<K extends keyof FormState>(field: K, value: FormState[K]) {
    this.form.update((f) => ({ ...f, [field]: value }));
    const f = this.form();
    if (field === 'groupId' || field === 'artifactId') {
      if (!this.packageNameTouched) {
        this.form.update((cur) => ({ ...cur, packageName: this.derivePackageName(f.groupId, f.artifactId) }));
      }
    }
    if (field === 'artifactId') {
      if (!this.nameTouched) {
        this.form.update((cur) => ({ ...cur, name: f.artifactId }));
      }
    }
    // Boot/Java/language changes alter dependency compatibility -> refresh dropdowns
    if (field === 'bootVersion' || field === 'javaVersion' || field === 'language') {
      this.refreshCompatibleVersions();
    }
  }

  onPackageNameInput(v: string) { this.packageNameTouched = true; this.updateForm('packageName', v); }
  onNameInput(v: string) { this.nameTouched = true; this.updateForm('name', v); }
  onDbUrlInput(v: string) { this.dbUrlTouched = true; this.updateForm('dbUrl', v); }
  onDbUsernameInput(v: string) { this.dbUsernameTouched = true; this.updateForm('dbUsername', v); }

  changeDatabaseType(newType: string): void {
    const opt = DATABASE_OPTIONS.find(o => o.id === newType);
    this.form.update(f => {
      const next = { ...f, dbType: newType };
      if (newType === 'none') {
        next.dbUrl = ''; next.dbUsername = ''; next.dbPassword = '';
        this.dbUrlTouched = false; this.dbUsernameTouched = false;
      } else if (opt) {
        if (!this.dbUrlTouched) {
          next.dbUrl = opt.defaultUrl.replace(/\/demo(\?|;|$)/, `/${f.artifactId}$1`);
        }
        if (!this.dbUsernameTouched) {
          next.dbUsername = opt.defaultUsername;
        }
      }
      return next;
    });
  }

  toggleEnvSelected(env: string): void {
    const cur = new Set(this.form().envSelected);
    if (cur.has(env)) cur.delete(env); else cur.add(env);
    this.form.update(f => ({ ...f, envSelected: Array.from(cur) }));
  }

  toggleDmzrEnv(env: string): void {
    const cur = new Set(this.form().dmzrEnvironments);
    if (cur.has(env)) cur.delete(env); else cur.add(env);
    this.form.update(f => ({ ...f, dmzrEnvironments: Array.from(cur) }));
  }

  isEnvSelected(env: string): boolean { return this.form().envSelected.includes(env); }

  /** Build the per-environment settings map, only for selected profiles. */
  private buildEnvSettings(selected: string[]): Record<string, { ecosystem: string; kubernetesPath: string; namespace: string; cosInstanceIds: string[]; cosBuckets: string[] }> {
    const all = this.envSettings();
    const out: Record<string, { ecosystem: string; kubernetesPath: string; namespace: string; cosInstanceIds: string[]; cosBuckets: string[] }> = {};
    const split = (v: string) => (v || '').split(',').map(x => x.trim()).filter(x => x.length > 0);
    for (const env of selected) {
      const s = all[env];
      if (s && (s.ecosystem || s.kubernetesPath || s.namespace || s.cosInstanceIds || s.cosBuckets)) {
        out[env] = {
          ecosystem: s.ecosystem || '',
          kubernetesPath: s.kubernetesPath || '',
          namespace: s.namespace || '',
          cosInstanceIds: split(s.cosInstanceIds),
          cosBuckets: split(s.cosBuckets)
        };
      }
    }
    return out;
  }
  isDmzrEnvSelected(env: string): boolean { return this.form().dmzrEnvironments.includes(env); }

  private derivePackageName(groupId: string, artifactId: string): string {
    const g = (groupId || '').toLowerCase().trim();
    const a = (artifactId || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!g) return a;
    if (!a) return g;
    return `${g}.${a}`;
  }

  openDependencyModal(): void {
    this.modalOpen.set(true);
    this.searchQuery.set('');
    this.highlightedIndex.set(0);
    setTimeout(() => {
      const el = document.getElementById('dependency-search') as HTMLInputElement | null;
      el?.focus();
    }, 30);
  }
  closeDependencyModal(): void { this.modalOpen.set(false); }

  // ===== Explore (file preview) =====
  showSummary(): void {
    this.summaryOpen.set(true);
    this.loadPreview();
  }

  loadPreview(): void {
    const errors = this.validate();
    if (errors.length) {
      this.previewError.set(errors.join('. '));
      return;
    }
    this.previewLoading.set(true);
    this.previewError.set(null);
    // Preview reflects current config; start from a clean (non-edited) request
    this.api.previewProject(this.buildRequest(false)).subscribe({
      next: (files) => {
        this.previewFiles.set(files);
        this.editedPaths.set(new Set());
        // Open a sensible default file (the main source, else the first)
        const keys = Object.keys(files);
        const preferred = keys.find(k => /Application\.java$|main\.py$/.test(k))
          ?? keys.find(k => /\.(java|py)$/.test(k))
          ?? keys[0] ?? null;
        this.activePreviewPath.set(preferred);
        this.previewLoading.set(false);
      },
      error: (err) => {
        this.previewLoading.set(false);
        this.previewError.set(err?.error?.message || 'Could not load preview');
      }
    });
  }

  selectPreviewFile(path: string): void {
    this.activePreviewPath.set(path);
  }

  /** Jump from a compile diagnostic to the offending file in the Explore editor. */
  openDiagnostic(d: { path: string; line: number }): void {
    if (!d.path) return;
    // diagnostic paths are relative to the source root; match the preview key by tail.
    const fileName = d.path.split('/').pop() || d.path;
    const paths = this.previewPaths();
    const match = paths.find(p => p.endsWith(d.path))
      || paths.find(p => p.endsWith('/' + fileName))
      || paths.find(p => p.endsWith(fileName));
    if (match) {
      if (!this.summaryOpen()) this.summaryOpen.set(true);
      this.activePreviewPath.set(match);
    }
  }

  /** Called when the editor textarea changes. */
  onPreviewEdit(content: string): void {
    const path = this.activePreviewPath();
    if (!path) return;
    this.previewFiles.update(files => ({ ...files, [path]: content }));
    this.editedPaths.update(s => { const n = new Set(s); n.add(path); return n; });
  }

  isPathEdited(path: string): boolean { return this.editedPaths().has(path); }
  editedCount(): number { return this.editedPaths().size; }

  activePreviewContent(): string {
    const p = this.activePreviewPath();
    if (!p) return '';
    return this.previewFiles()[p] ?? '';
  }

  /** Sorted file paths for the Explore tree/list. */
  previewPaths = computed<string[]>(() => Object.keys(this.previewFiles()).sort());

  // Collapsed folder paths in the Explore tree
  collapsedDirs = signal<Set<string>>(new Set());

  toggleDir(dirPath: string): void {
    const next = new Set(this.collapsedDirs());
    if (next.has(dirPath)) next.delete(dirPath); else next.add(dirPath);
    this.collapsedDirs.set(next);
  }
  isDirCollapsed(dirPath: string): boolean {
    return this.collapsedDirs().has(dirPath);
  }

  /**
   * Flattened tree of the preview files, with depth + full-path so folders can
   * be collapsed and files selected. Rows under a collapsed folder are hidden.
   */
  previewFlatTree = computed<PreviewNode[]>(() => {
    const paths = this.previewPaths();
    // Build a nested structure
    const root: PreviewTreeNode = { name: '', fullPath: '', isDir: true, children: new Map() };
    for (const p of paths) {
      const segs = p.split('/');
      let cursor = root;
      let acc = '';
      segs.forEach((seg, idx) => {
        const isLast = idx === segs.length - 1;
        acc = acc ? acc + '/' + seg : seg;
        let child = cursor.children.get(seg);
        if (!child) {
          child = { name: seg, fullPath: acc, isDir: !isLast, children: new Map() };
          cursor.children.set(seg, child);
        }
        cursor = child;
      });
    }
    // DFS flatten, sorting dirs first then files
    const out: PreviewNode[] = [];
    const collapsed = this.collapsedDirs();
    const walk = (node: PreviewTreeNode, depth: number, hidden: boolean) => {
      const kids = [...node.children.values()].sort((a, b) => {
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        return a.name.localeCompare(b.name);
      });
      for (const k of kids) {
        if (!hidden) {
          out.push({ name: k.name, fullPath: k.fullPath, isDir: k.isDir, depth });
        }
        if (k.isDir) {
          const childHidden = hidden || collapsed.has(k.fullPath);
          walk(k, depth + 1, childHidden);
        }
      }
    };
    walk(root, 0, false);
    return out;
  });

  fileLabel(path: string): string {
    const parts = path.split('/');
    return parts[parts.length - 1] || path;
  }

  // Reset preview state when closing Explore
  closeExplore(): void {
    this.summaryOpen.set(false);
  }

  toggleDependency(id: string): void {
    const next = new Set(this.selectedIds());
    if (next.has(id)) next.delete(id); else next.add(id);
    this.selectedIds.set(next);
    this.refreshCompatibleVersions();
  }
  /** Add a dep by id, idempotent. Used by the Recommendations panel's quick-add button. */
  addDependencyById(id: string): void {
    if (this.selectedIds().has(id)) return;
    const next = new Set(this.selectedIds());
    next.add(id);
    this.selectedIds.set(next);
    this.refreshCompatibleVersions();
  }
  /**
   * Architecture-aware recommendations. Shows the user, BEFORE clicking build,
   * which dependencies they almost certainly need given their architecture and
   * what they haven't already selected. Mirrors the post-failure hint logic so
   * the user can fix things proactively.
   */
  dependencyAdvice = computed<{ id: string; name: string; reason: string }[]>(() => {
    if (!this.isJava()) return [];
    const selected = this.selectedIds();
    const arch = this.form().architecture;
    const tips: { id: string; name: string; reason: string }[] = [];
    // Any architecture: needs a runtime starter so @SpringBootApplication compiles.
    const runtimeStarters = ['web', 'data-jpa', 'data-rest', 'security', 'actuator', 'webflux'];
    const hasAnyRuntime = runtimeStarters.some(id => selected.has(id));
    if (!hasAnyRuntime) {
      tips.push({
        id: 'web',
        name: 'Spring Web',
        reason: 'every Spring Boot app needs a runtime starter; pick this for REST/MVC apps',
      });
    }
    // MVC / Microservice generate a Controller — they will use @WebMvcTest in tests.
    if ((arch === 'mvc' || arch === 'microservice' || arch === 'standard') && !selected.has('web')) {
      tips.push({
        id: 'web',
        name: 'Spring Web',
        reason: 'the generated GreetingController + @WebMvcTest tests require it',
      });
    }
    // Data JPA hint: many projects benefit, but we only suggest if no DB starter at all.
    const dbStarters = ['data-jpa', 'data-rest', 'data-jdbc', 'data-mongodb'];
    if (!dbStarters.some(id => selected.has(id))) {
      // Only suggest JPA if user already has H2 or another JDBC driver in mind — skip otherwise.
      // We don't have signal on that here, so don't push JPA proactively.
    }
    // De-duplicate by id.
    const seen = new Set<string>();
    return tips.filter(t => !seen.has(t.id) && (seen.add(t.id) || true));
  });
  removeDependency(id: string): void {
    const next = new Set(this.selectedIds());
    next.delete(id);
    this.selectedIds.set(next);
    // also clear any version override
    this.depVersions.update(v => { const n = { ...v }; delete n[id]; return n; });
    this.refreshCompatibleVersions();
  }
  isSelected(id: string): boolean { return this.selectedIds().has(id); }

  // ===== Dependency versions (dropdown of compatible versions for the Boot/Java selection) =====
  // depId -> list of compatible version strings ("managed" means BOM-managed)
  compatibleVersions = signal<Record<string, string[]>>({});
  loadingVersions = signal(false);

  versionOptions(id: string): string[] {
    const opts = this.compatibleVersions()[id];
    return opts && opts.length ? opts : ['managed'];
  }
  versionOf(id: string): string {
    const cur = this.depVersions()[id];
    if (cur !== undefined && cur !== '') return cur;
    // default to first compatible option
    const opts = this.versionOptions(id);
    return opts[0] ?? 'managed';
  }
  setVersion(id: string, version: string): void {
    // store '' for managed so the backend omits an explicit <version>
    this.depVersions.update(v => ({ ...v, [id]: version === 'managed' ? '' : version }));
  }

  /** Fetch compatible version dropdowns for the currently selected deps + Boot/Java. */
  // Non-blocking LLM health banner (dropdowns always work via the static catalog)
  llmNotice = signal<string | null>(null);

  refreshCompatibleVersions(): void {
    const ids = Array.from(this.selectedIds());
    if (ids.length === 0) { this.compatibleVersions.set({}); return; }
    const f = this.form();
    this.loadingVersions.set(true);
    this.api.compatibleVersions({
      dependencies: ids,
      language: f.language,
      bootVersion: f.bootVersion,
      javaVersion: f.javaVersion
    }).subscribe({
      next: (map) => {
        this.compatibleVersions.set(map ?? {});
        this.loadingVersions.set(false);
        this.checkLlmStatus();
      },
      error: () => { this.loadingVersions.set(false); }  // keep prior options; dropdown falls back to 'managed'
    });
  }

  /** Refresh the LLM health note (shown only when the LLM is enabled but failing). */
  private checkLlmStatus(): void {
    this.api.llmStatus().subscribe({
      next: (s) => {
        if (s.enabled && s.lastError) {
          this.llmNotice.set('Version suggestions are using the built-in catalog — ' + s.lastError);
        } else {
          this.llmNotice.set(null);
        }
      },
      error: () => { /* status is best-effort; ignore */ }
    });
  }

  filteredCategories = computed<DependencyCategory[]>(() => {
    const cats = this.dependencyCatalog();
    const q = this.searchQuery().toLowerCase().trim();
    if (!q) return cats;
    const out: DependencyCategory[] = [];
    for (const cat of cats) {
      const deps = cat.dependencies.filter(d =>
        d.name.toLowerCase().includes(q) ||
        d.id.toLowerCase().includes(q) ||
        d.description.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q)
      );
      if (deps.length) out.push({ name: cat.name, dependencies: deps });
    }
    return out;
  });

  filteredDepsFlat(): Dependency[] {
    const flat: Dependency[] = [];
    for (const c of this.filteredCategories()) flat.push(...c.dependencies);
    return flat;
  }
  flatIndexOf(dep: Dependency): number {
    return this.filteredDepsFlat().findIndex(d => d.id === dep.id);
  }

  private moveHighlight(delta: number) {
    const flat = this.filteredDepsFlat();
    if (!flat.length) return;
    const i = this.highlightedIndex();
    const next = (i + delta + flat.length) % flat.length;
    this.highlightedIndex.set(next);
    setTimeout(() => {
      const el = document.querySelector(`[data-dep-index="${next}"]`);
      el?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, 0);
  }

  /** Build the request payload. When includeEdits is true, edited file contents are sent. */
  private buildRequest(includeEdits: boolean): ProjectRequest {
    const f = this.form();
    // Only send version overrides for currently-selected deps that differ from "managed"/blank
    const versions: Record<string, string> = {};
    const selected = this.selectedIds();
    const dv = this.depVersions();
    for (const id of selected) {
      const v = dv[id];
      if (v && v.trim() && v !== 'managed') versions[id] = v;
    }
    const edits: Record<string, string> = {};
    if (includeEdits) {
      const files = this.previewFiles();
      for (const p of this.editedPaths()) {
        if (files[p] !== undefined) edits[p] = files[p];
      }
    }
    return {
      type: f.type, language: f.language, bootVersion: f.bootVersion,
      groupId: f.groupId, artifactId: f.artifactId, name: f.name,
      description: f.description, packageName: f.packageName,
      packaging: f.packaging, javaVersion: f.javaVersion,
      architecture: f.architecture,
      dependencies: Array.from(selected),
      dependencyVersions: versions,
      editedFiles: edits,
      database: {
        type: f.dbType, url: f.dbUrl, username: f.dbUsername,
        password: f.dbPassword, ddlAuto: f.dbDdlAuto
      },
      environments: {
        enabled: f.envEnabled,
        environments: f.envSelected,
        configServerUrl: f.envConfigServerUrl,
        configServerProfile: f.envConfigServerProfile,
        settings: this.buildEnvSettings(f.envSelected)
      },
      dmzr: {
        enabled: f.dmzrEnabled,
        vaultPolicies: f.dmzrVaultPolicies,
        helmChart: f.dmzrHelmChart,
        vaultRole: f.dmzrVaultRole,
        vaultSecretPath: f.dmzrVaultSecretPath,
        kubernetesNamespace: f.dmzrK8sNamespace,
        dockerImage: f.dmzrDockerImage,
        environments: f.dmzrEnvironments
      },
      applicationCode: f.applicationCode,
      cos: {
        enabled: f.cosEnabled,
        instanceIds: [],
        endpoint: f.cosEndpoint,
        bucket: ''
      }
    };
  }

  /** Download a zip that includes any edits made in the Explore preview. */
  regenerateFromPreview(): void {
    if (this.generating()) return;
    this.summaryOpen.set(false);
    this.generate();
  }

  // ===== Sandbox compile (verify generated Java before download) =====
  compiling = signal(false);
  compileResult = signal<CompileResult | null>(null);
  compilePanelOpen = signal(false);

  runCompile(): void {
    if (this.compiling()) return;
    const errors = this.validate();
    if (errors.length) {
      this.errorMessage.set(errors.join('. '));
      return;
    }
    this.errorMessage.set(null);
    this.compileResult.set(null);
    this.compiling.set(true);
    this.compilePanelOpen.set(true);

    const request = this.buildRequest(true);
    this.api.compileProject(request).subscribe({
      next: (result) => {
        this.compileResult.set(result);
        this.compiling.set(false);
      },
      error: (err) => {
        this.compiling.set(false);
        this.compileResult.set({
          ok: false, compilerAvailable: false, errorCount: 0, warningCount: 0,
          diagnostics: [],
          summary: err?.error?.message || 'Compile request failed.'
        });
      }
    });
  }

  dismissCompilePanel(): void {
    this.compilePanelOpen.set(false);
    this.compileResult.set(null);
  }

  // ===== Live full build (real mvn clean install / python build, streamed) =====
  building = signal(false);
  buildLog = signal<string[]>([]);
  runAfterBuild = signal(false);
  buildOutcome = signal<{ success: boolean; exitCode: number; summary: string } | null>(null);
  buildConsoleOpen = signal(false);
  buildConsoleMinimized = signal(false);

  // ===== API Tester panel =====
  /** Info about the currently running verification app; null when nothing is running. */
  apiTesterApp = signal<{ language: string; artifactId: string; port: number; pid: number; baseUrl: string } | null>(null);
  /** Show/hide the API Tester panel (opens automatically once an app is running). */
  apiTesterOpen = signal(false);
  /** Minimized state — like the build console, keeps the panel out of the way. */
  apiTesterMinimized = signal(false);
  /** The current request being edited. */
  apiTesterMethod = signal<'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'>('GET');
  apiTesterPath = signal('/api/greetings');
  apiTesterBody = signal('');
  apiTesterHeaders = signal(''); // one "Header: value" per line
  /** Last response (or in-flight state). */
  apiTesterSending = signal(false);
  apiTesterResponse = signal<{
    status?: number; body?: string; headers?: Record<string, string[]>;
    error?: string; message?: string; elapsedMs?: number; targetUrl?: string;
  } | null>(null);

  /** Curl command preview, computed from the current form values. */
  apiTesterCurl = computed(() => {
    const app = this.apiTesterApp();
    if (!app) return '';
    const method = this.apiTesterMethod();
    const path = this.apiTesterPath().startsWith('/') ? this.apiTesterPath() : '/' + this.apiTesterPath();
    const url = `${app.baseUrl}${path}`;
    const parts = ['curl', '-i', '-X', method, `'${url}'`];
    const headers = this.parseHeaders(this.apiTesterHeaders());
    const body = this.apiTesterBody();
    if (body && !headers.some(([k]) => k.toLowerCase() === 'content-type')) {
      parts.push('-H', "'Content-Type: application/json'");
    }
    for (const [k, v] of headers) parts.push('-H', `'${k}: ${v}'`);
    if (body) {
      const escaped = body.replace(/'/g, "'\\''");
      parts.push('-d', `'${escaped}'`);
    }
    return parts.join(' ');
  });

  private parseHeaders(raw: string): Array<[string, string]> {
    const out: Array<[string, string]> = [];
    for (const line of raw.split(/\r?\n/)) {
      const t = line.trim();
      if (!t) continue;
      const idx = t.indexOf(':');
      if (idx <= 0) continue;
      out.push([t.slice(0, idx).trim(), t.slice(idx + 1).trim()]);
    }
    return out;
  }

  /** Fetch info about the running app. Called after a successful run-after-install. */
  refreshRunningApp(): void {
    this.api.getRunningApp().then(app => {
      this.apiTesterApp.set(app);
      if (app) {
        this.apiTesterOpen.set(true);
        // Sensible default path based on language.
        if (!this.apiTesterPath()) {
          this.apiTesterPath.set('/api/greetings');
        }
      }
    }).catch(() => {
      // No running app or endpoint missing — leave state untouched.
    });
  }

  /** Send the current request through the backend proxy to the running app. */
  sendApiRequest(): void {
    if (this.apiTesterSending()) return;
    const method = this.apiTesterMethod();
    const path = this.apiTesterPath().trim() || '/';
    const body = this.apiTesterBody();
    const headers: Record<string, string> = {};
    for (const [k, v] of this.parseHeaders(this.apiTesterHeaders())) headers[k] = v;
    this.apiTesterSending.set(true);
    this.apiTesterResponse.set(null);
    this.api.proxyRequest({ method, path, body: body || undefined, headers })
      .then(resp => { this.apiTesterResponse.set(resp); this.apiTesterSending.set(false); })
      .catch(err => {
        this.apiTesterResponse.set({ error: 'proxy-error', message: err?.message || String(err) });
        this.apiTesterSending.set(false);
      });
  }

  copyCurlCommand(): void {
    const cmd = this.apiTesterCurl();
    if (!cmd) return;
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(cmd).catch(() => {});
    }
  }

  /** Stop the running app (backend kills the process, clears the registry). */
  stopRunningApp(): void {
    this.api.stopRunningApp().finally(() => {
      this.apiTesterApp.set(null);
      this.apiTesterOpen.set(false);
      this.apiTesterResponse.set(null);
    });
  }

  toggleApiTesterMinimized(): void {
    this.apiTesterMinimized.update(v => !v);
  }

  toggleBuildConsoleMinimized(): void {
    this.buildConsoleMinimized.update(v => !v);
  }
  private buildAbort: AbortController | null = null;

  /** Stream a real full build (all dependencies) and show the complete log live. */
  runFullBuild(): void {
    if (this.building()) return;
    const errors = this.validate();
    if (errors.length) { this.errorMessage.set(errors.join('. ')); return; }
    this.errorMessage.set(null);
    this.buildLog.set([]);
    this.buildOutcome.set(null);
    this.buildConsoleOpen.set(true);
    this.building.set(true);

    const request = this.buildRequest(true);
    this.buildAbort = this.api.streamBuild(
      request,
      (line) => {
        this.buildLog.update(l => [...l, line]);
        queueMicrotask(() => {
          const el = document.querySelector('.build-console__log');
          if (el) el.scrollTop = el.scrollHeight;
        });
      },
      (outcome) => {
        this.buildOutcome.set(outcome);
        this.building.set(false);
        this.buildAbort = null;
        // If the app was launched (Run app after install) and started cleanly,
        // fetch the running-app info so the API Tester panel can hit it.
        if (outcome.success && this.runAfterBuild()) {
          this.refreshRunningApp();
        }
      },
      (msg) => {
        this.buildLog.update(l => [...l, '[error] ' + msg]);
        this.buildOutcome.set({ success: false, exitCode: -1, summary: msg });
        this.building.set(false);
        this.buildAbort = null;
      },
      this.runAfterBuild()
    );
  }

  cancelBuild(): void {
    if (this.buildAbort) { this.buildAbort.abort(); this.buildAbort = null; }
    this.building.set(false);
    this.buildLog.update(l => [...l, '[sourceforge] build cancelled by user']);
  }

  dismissBuildConsole(): void {
    this.cancelBuild();
    this.buildConsoleOpen.set(false);
    this.buildLog.set([]);
    this.buildOutcome.set(null);
  }

  /** Copy the full build log to the clipboard. */
  copyBuildLog(): void {
    const text = this.buildLog().join('\n');
    if (!text) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(() => this.fallbackCopy(text));
    } else {
      this.fallbackCopy(text);
    }
  }
  private fallbackCopy(text: string): void {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch { /* nothing else to do */ }
    document.body.removeChild(ta);
  }

  /** Download the full build log as a .log file. */
  downloadBuildLog(): void {
    const text = this.buildLog().join('\n');
    if (!text) return;
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mvn-build-${stamp}.log`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  /** Human-readable "path:line:col" for a diagnostic. */
  diagLocation(d: { path: string; line: number; column: number }): string {
    let loc = d.path || '';
    if (d.line > 0) {
      loc += ':' + d.line;
      if (d.column > 0) loc += ':' + d.column;
    }
    return loc;
  }

  generate(): void {
    if (this.generating()) return;
    const errors = this.validate();
    if (errors.length) {
      this.errorMessage.set(errors.join('. '));
      return;
    }
    this.errorMessage.set(null);
    this.successMessage.set(null);
    this.generating.set(true);

    const f = this.form();
    const request = this.buildRequest(true);

    this.api.generateProject(request).subscribe({
      next: (blob) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${f.artifactId}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        this.generating.set(false);
        this.successMessage.set(`Downloaded ${f.artifactId}.zip`);
        setTimeout(() => this.successMessage.set(null), 4000);
      },
      error: (err) => {
        this.generating.set(false);
        let msg = 'Generation failed';
        if (err?.error instanceof Blob) {
          err.error.text().then((t: string) => {
            try { this.errorMessage.set(JSON.parse(t).message || msg); }
            catch { this.errorMessage.set(t || msg); }
          });
        } else if (err?.error?.message) {
          this.errorMessage.set(err.error.message);
        } else {
          this.errorMessage.set(msg);
        }
      }
    });
  }

  validate(): string[] {
    const f = this.form();
    const errors: string[] = [];
    if (!f.groupId || !/^[a-zA-Z][a-zA-Z0-9_.\-]*$/.test(f.groupId)) errors.push('Group is invalid');
    if (!f.artifactId || !/^[a-zA-Z][a-zA-Z0-9_\-]*$/.test(f.artifactId)) errors.push('Artifact is invalid');
    if (!f.packageName || !/^[a-zA-Z][a-zA-Z0-9_.]*$/.test(f.packageName)) errors.push('Package name is invalid');
    if (!f.name) errors.push('Name is required');
    if (f.language === 'java' && !f.bootVersion) errors.push('Spring Boot version is required for Java');
    if (f.envEnabled && f.envSelected.length === 0) errors.push('Pick at least one environment');
    if (f.dmzrEnabled && !f.dmzrVaultPolicies && !f.dmzrHelmChart) errors.push('Enable Vault policies or Helm chart for DMZR');
    return errors;
  }

  languageLabel(l: string): string { return l.charAt(0).toUpperCase() + l.slice(1); }
  databaseLabel(id: string): string { return DATABASE_OPTIONS.find(o => o.id === id)?.label ?? id; }
  hasDatabase(): boolean { return this.form().dbType !== 'none'; }
  hasJpa(): boolean { return this.selectedIds().has('data-jpa'); }
  hasFastapi(): boolean { return this.selectedIds().has('fastapi'); }

  trackById = (_: number, item: { id: string }) => item.id;
  trackByName = (_: number, item: { name: string }) => item.name;
  trackByValue = (_: number, item: string) => item;
}
