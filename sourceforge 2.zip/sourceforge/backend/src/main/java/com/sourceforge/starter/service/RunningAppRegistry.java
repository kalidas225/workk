package com.sourceforge.starter.service;

import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Tracks the current verification-run application so the API Tester panel in
 * the UI can proxy requests to it. Only one app runs at a time — starting a new
 * verification run replaces the previous entry.
 */
@Service
public class RunningAppRegistry {

    /** Snapshot of the currently running verification app, or null if none. */
    public record RunningApp(
            String language,     // "java" | "python"
            String artifactId,   // e.g. "demo"
            int port,            // TCP port the app is bound to (localhost)
            long pid,            // OS process id (may be -1 if unavailable)
            long startedAt       // epoch ms when startup was confirmed
    ) {}

    private final AtomicReference<RunningApp> current = new AtomicReference<>();
    private final AtomicReference<Process> currentProc = new AtomicReference<>();

    public void set(RunningApp app, Process proc) {
        current.set(app);
        currentProc.set(proc);
    }

    public RunningApp get() { return current.get(); }

    /**
     * Best-effort stop of the currently running app. Returns true if a running
     * app was found and destroyed; false if nothing was running.
     */
    public boolean stop() {
        Process p = currentProc.getAndSet(null);
        current.set(null);
        if (p == null || !p.isAlive()) return false;
        p.destroy();
        try {
            if (!p.waitFor(8, java.util.concurrent.TimeUnit.SECONDS)) {
                p.destroyForcibly();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            p.destroyForcibly();
        }
        return true;
    }

    /** Called by the build runner when the launching thread exits normally. */
    public void clear() {
        current.set(null);
        currentProc.set(null);
    }
}
