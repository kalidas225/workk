package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Generates additional Java source files for layered (MVC) and microservice
 * architectures. Every emitted file is self-contained and compiles against the
 * spring-boot-starter-web dependency alone (which the generator guarantees is
 * present whenever a non-standard architecture is selected).
 *
 * The classes deliberately avoid JPA / database types so the project compiles
 * and runs regardless of whether a datasource was configured. Persistence is
 * represented by a simple in-memory repository.
 */
@Component
public class ArchitectureTemplateService {

    /** A single generated source file: relative path under the package dir + content. */
    public record SourceFile(String relativePath, String content) {}

    /**
     * Build the architecture-specific source files for a Java project.
     * Returns an empty list for "standard" (only the main class is emitted elsewhere).
     */
    public List<SourceFile> javaSources(ProjectRequest req) {
        if (req.isMvc()) return mvcSources(req);
        if (req.isMicroservice()) return microserviceSources(req);
        return standardSources(req);
    }

    /**
     * Standard architecture also gets a minimal Repository / Service / Controller
     * so the generated project ships with a working example regardless of which
     * pattern the user picked. This guarantees a runnable starter for every
     * architecture choice (Standard / MVC / Microservice).
     */
    private List<SourceFile> standardSources(ProjectRequest req) {
        return mvcSources(req);
    }

    // =========================================================
    //  MVC — layered: controller -> service -> repository -> model + DTO
    // =========================================================
    private List<SourceFile> mvcSources(ProjectRequest req) {
        String pkg = req.packageName();
        List<SourceFile> files = new ArrayList<>();

        // ----- model/Greeting.java -----
        files.add(new SourceFile("model/Greeting.java",
                "package " + pkg + ".model;\n\n" +
                "/** Domain model. */\n" +
                "public class Greeting {\n\n" +
                "    private Long id;\n" +
                "    private String message;\n\n" +
                "    public Greeting() {\n" +
                "    }\n\n" +
                "    public Greeting(Long id, String message) {\n" +
                "        this.id = id;\n" +
                "        this.message = message;\n" +
                "    }\n\n" +
                "    public Long getId() {\n" +
                "        return id;\n" +
                "    }\n\n" +
                "    public void setId(Long id) {\n" +
                "        this.id = id;\n" +
                "    }\n\n" +
                "    public String getMessage() {\n" +
                "        return message;\n" +
                "    }\n\n" +
                "    public void setMessage(String message) {\n" +
                "        this.message = message;\n" +
                "    }\n" +
                "}\n"));

        // ----- dto/GreetingRequest.java -----
        files.add(new SourceFile("dto/GreetingRequest.java",
                "package " + pkg + ".dto;\n\n" +
                "/** Inbound payload for creating a greeting. */\n" +
                "public class GreetingRequest {\n\n" +
                "    private String message;\n\n" +
                "    public String getMessage() {\n" +
                "        return message;\n" +
                "    }\n\n" +
                "    public void setMessage(String message) {\n" +
                "        this.message = message;\n" +
                "    }\n" +
                "}\n"));

        // ----- repository/GreetingRepository.java (in-memory, no JPA needed) -----
        files.add(new SourceFile("repository/GreetingRepository.java",
                "package " + pkg + ".repository;\n\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import org.springframework.stereotype.Repository;\n\n" +
                "import java.util.ArrayList;\n" +
                "import java.util.List;\n" +
                "import java.util.Optional;\n" +
                "import java.util.concurrent.ConcurrentHashMap;\n" +
                "import java.util.concurrent.atomic.AtomicLong;\n\n" +
                "/**\n" +
                " * Simple in-memory repository so the project compiles and runs without a\n" +
                " * database. Swap for a Spring Data JPA repository when persistence is added.\n" +
                " */\n" +
                "@Repository\n" +
                "public class GreetingRepository {\n\n" +
                "    private final ConcurrentHashMap<Long, Greeting> store = new ConcurrentHashMap<>();\n" +
                "    private final AtomicLong sequence = new AtomicLong(0);\n\n" +
                "    public List<Greeting> findAll() {\n" +
                "        return new ArrayList<>(store.values());\n" +
                "    }\n\n" +
                "    public Optional<Greeting> findById(Long id) {\n" +
                "        return Optional.ofNullable(store.get(id));\n" +
                "    }\n\n" +
                "    public Greeting save(Greeting greeting) {\n" +
                "        if (greeting.getId() == null) {\n" +
                "            greeting.setId(sequence.incrementAndGet());\n" +
                "        }\n" +
                "        store.put(greeting.getId(), greeting);\n" +
                "        return greeting;\n" +
                "    }\n" +
                "}\n"));

        // ----- service/GreetingService.java -----
        files.add(new SourceFile("service/GreetingService.java",
                "package " + pkg + ".service;\n\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import " + pkg + ".repository.GreetingRepository;\n" +
                "import org.springframework.stereotype.Service;\n\n" +
                "import java.util.List;\n" +
                "import java.util.Optional;\n\n" +
                "/** Business logic layer. */\n" +
                "@Service\n" +
                "public class GreetingService {\n\n" +
                "    private final GreetingRepository repository;\n\n" +
                "    public GreetingService(GreetingRepository repository) {\n" +
                "        this.repository = repository;\n" +
                "    }\n\n" +
                "    public List<Greeting> findAll() {\n" +
                "        return repository.findAll();\n" +
                "    }\n\n" +
                "    public Optional<Greeting> findById(Long id) {\n" +
                "        return repository.findById(id);\n" +
                "    }\n\n" +
                "    public Greeting create(String message) {\n" +
                "        Greeting greeting = new Greeting(null, message);\n" +
                "        return repository.save(greeting);\n" +
                "    }\n" +
                "}\n"));

        // ----- controller/GreetingController.java -----
        files.add(new SourceFile("controller/GreetingController.java",
                "package " + pkg + ".controller;\n\n" +
                "import " + pkg + ".dto.GreetingRequest;\n" +
                "import " + pkg + ".model.Greeting;\n" +
                "import " + pkg + ".service.GreetingService;\n" +
                "import org.springframework.http.ResponseEntity;\n" +
                "import org.springframework.web.bind.annotation.*;\n\n" +
                "import java.util.List;\n\n" +
                "/** REST controller — presentation layer. */\n" +
                "@RestController\n" +
                "@RequestMapping(\"/api/greetings\")\n" +
                "public class GreetingController {\n\n" +
                "    private final GreetingService service;\n\n" +
                "    public GreetingController(GreetingService service) {\n" +
                "        this.service = service;\n" +
                "    }\n\n" +
                "    @GetMapping\n" +
                "    public List<Greeting> all() {\n" +
                "        return service.findAll();\n" +
                "    }\n\n" +
                "    @GetMapping(\"/{id}\")\n" +
                "    public ResponseEntity<Greeting> byId(@PathVariable Long id) {\n" +
                "        return service.findById(id)\n" +
                "                .map(ResponseEntity::ok)\n" +
                "                .orElseGet(() -> ResponseEntity.notFound().build());\n" +
                "    }\n\n" +
                "    @PostMapping\n" +
                "    public ResponseEntity<Greeting> create(@RequestBody GreetingRequest request) {\n" +
                "        Greeting created = service.create(request.getMessage());\n" +
                "        return ResponseEntity.ok(created);\n" +
                "    }\n" +
                "}\n"));

        return files;
    }

    // =========================================================
    //  Microservice — adds REST client, health/info, config props, global error handling
    // =========================================================
    private List<SourceFile> microserviceSources(ProjectRequest req) {
        String pkg = req.packageName();
        // Reuse the layered classes as the core domain...
        List<SourceFile> files = new ArrayList<>(mvcSources(req));

        // ----- config/AppProperties.java -----
        files.add(new SourceFile("config/AppProperties.java",
                "package " + pkg + ".config;\n\n" +
                "import org.springframework.boot.context.properties.ConfigurationProperties;\n" +
                "import org.springframework.context.annotation.Configuration;\n\n" +
                "/**\n" +
                " * Externalised configuration, bound from properties prefixed with 'app'.\n" +
                " * Example: app.downstream-url=http://localhost:9090\n" +
                " */\n" +
                "@Configuration\n" +
                "@ConfigurationProperties(prefix = \"app\")\n" +
                "public class AppProperties {\n\n" +
                "    /** Base URL of a downstream service this microservice calls. */\n" +
                "    private String downstreamUrl = \"http://localhost:9090\";\n\n" +
                "    public String getDownstreamUrl() {\n" +
                "        return downstreamUrl;\n" +
                "    }\n\n" +
                "    public void setDownstreamUrl(String downstreamUrl) {\n" +
                "        this.downstreamUrl = downstreamUrl;\n" +
                "    }\n" +
                "}\n"));

        // ----- config/RestClientConfig.java (RestClient is part of spring-web 6.1+) -----
        files.add(new SourceFile("config/RestClientConfig.java",
                "package " + pkg + ".config;\n\n" +
                "import org.springframework.context.annotation.Bean;\n" +
                "import org.springframework.context.annotation.Configuration;\n" +
                "import org.springframework.web.client.RestClient;\n\n" +
                "/** Provides a configured RestClient for outbound calls. */\n" +
                "@Configuration\n" +
                "public class RestClientConfig {\n\n" +
                "    @Bean\n" +
                "    public RestClient restClient(AppProperties properties) {\n" +
                "        return RestClient.builder()\n" +
                "                .baseUrl(properties.getDownstreamUrl())\n" +
                "                .build();\n" +
                "    }\n" +
                "}\n"));

        // ----- client/DownstreamClient.java -----
        files.add(new SourceFile("client/DownstreamClient.java",
                "package " + pkg + ".client;\n\n" +
                "import org.springframework.stereotype.Component;\n" +
                "import org.springframework.web.client.RestClient;\n\n" +
                "/**\n" +
                " * Thin wrapper over RestClient representing a call to another microservice.\n" +
                " * Returns a String to keep the example dependency-free.\n" +
                " */\n" +
                "@Component\n" +
                "public class DownstreamClient {\n\n" +
                "    private final RestClient restClient;\n\n" +
                "    public DownstreamClient(RestClient restClient) {\n" +
                "        this.restClient = restClient;\n" +
                "    }\n\n" +
                "    public String fetchStatus() {\n" +
                "        try {\n" +
                "            return restClient.get()\n" +
                "                    .uri(\"/status\")\n" +
                "                    .retrieve()\n" +
                "                    .body(String.class);\n" +
                "        } catch (Exception ex) {\n" +
                "            // Downstream not reachable in local dev — degrade gracefully.\n" +
                "            return \"unknown\";\n" +
                "        }\n" +
                "    }\n" +
                "}\n"));

        // ----- web/GlobalExceptionHandler.java -----
        files.add(new SourceFile("web/GlobalExceptionHandler.java",
                "package " + pkg + ".web;\n\n" +
                "import org.springframework.http.HttpStatus;\n" +
                "import org.springframework.http.ResponseEntity;\n" +
                "import org.springframework.web.bind.annotation.ExceptionHandler;\n" +
                "import org.springframework.web.bind.annotation.RestControllerAdvice;\n\n" +
                "import java.time.Instant;\n" +
                "import java.util.Map;\n\n" +
                "/** Centralised error handling — returns a consistent JSON error body. */\n" +
                "@RestControllerAdvice\n" +
                "public class GlobalExceptionHandler {\n\n" +
                "    @ExceptionHandler(IllegalArgumentException.class)\n" +
                "    public ResponseEntity<Map<String, Object>> handleBadRequest(IllegalArgumentException ex) {\n" +
                "        Map<String, Object> body = Map.of(\n" +
                "                \"timestamp\", Instant.now().toString(),\n" +
                "                \"status\", HttpStatus.BAD_REQUEST.value(),\n" +
                "                \"error\", \"Bad Request\",\n" +
                "                \"message\", ex.getMessage() == null ? \"\" : ex.getMessage()\n" +
                "        );\n" +
                "        return ResponseEntity.badRequest().body(body);\n" +
                "    }\n\n" +
                "    @ExceptionHandler(Exception.class)\n" +
                "    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {\n" +
                "        Map<String, Object> body = Map.of(\n" +
                "                \"timestamp\", Instant.now().toString(),\n" +
                "                \"status\", HttpStatus.INTERNAL_SERVER_ERROR.value(),\n" +
                "                \"error\", \"Internal Server Error\",\n" +
                "                \"message\", ex.getMessage() == null ? \"\" : ex.getMessage()\n" +
                "        );\n" +
                "        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);\n" +
                "    }\n" +
                "}\n"));

        // ----- controller/StatusController.java (exercises the client + properties) -----
        files.add(new SourceFile("controller/StatusController.java",
                "package " + pkg + ".controller;\n\n" +
                "import " + pkg + ".client.DownstreamClient;\n" +
                "import org.springframework.web.bind.annotation.GetMapping;\n" +
                "import org.springframework.web.bind.annotation.RequestMapping;\n" +
                "import org.springframework.web.bind.annotation.RestController;\n\n" +
                "import java.util.Map;\n\n" +
                "/** Surfaces this service's status and the downstream service's status. */\n" +
                "@RestController\n" +
                "@RequestMapping(\"/api/status\")\n" +
                "public class StatusController {\n\n" +
                "    private final DownstreamClient downstreamClient;\n\n" +
                "    public StatusController(DownstreamClient downstreamClient) {\n" +
                "        this.downstreamClient = downstreamClient;\n" +
                "    }\n\n" +
                "    @GetMapping\n" +
                "    public Map<String, String> status() {\n" +
                "        return Map.of(\n" +
                "                \"service\", \"UP\",\n" +
                "                \"downstream\", downstreamClient.fetchStatus()\n" +
                "        );\n" +
                "    }\n" +
                "}\n"));

        // ----- config/OpenApiConfig.java (springdoc) -----
        files.add(new SourceFile("config/OpenApiConfig.java",
                "package " + pkg + ".config;\n\n" +
                "import io.swagger.v3.oas.models.OpenAPI;\n" +
                "import io.swagger.v3.oas.models.info.Info;\n" +
                "import io.swagger.v3.oas.models.info.License;\n" +
                "import org.springframework.context.annotation.Bean;\n" +
                "import org.springframework.context.annotation.Configuration;\n\n" +
                "/**\n" +
                " * OpenAPI 3 specification metadata. With springdoc on the classpath, the\n" +
                " * generated spec is served at /v3/api-docs and Swagger UI at /swagger-ui.html\n" +
                " */\n" +
                "@Configuration\n" +
                "public class OpenApiConfig {\n\n" +
                "    @Bean\n" +
                "    public OpenAPI apiInfo() {\n" +
                "        return new OpenAPI().info(new Info()\n" +
                "                .title(\"" + req.name() + " API\")\n" +
                "                .description(\"" + escapeJava(req.description()) + "\")\n" +
                "                .version(\"0.1.0\")\n" +
                "                .license(new License().name(\"Apache 2.0\")));\n" +
                "    }\n" +
                "}\n"));

        return files;
    }

    private String escapeJava(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    /**
     * Extra application.properties lines for the chosen architecture.
     * Returns "" when nothing extra is needed.
     */
    public String extraProperties(ProjectRequest req) {
        if (req.isMicroservice()) {
            return "\n# ===== Microservice =====\n" +
                    "app.downstream-url=http://localhost:9090\n" +
                    "\n# ===== OpenAPI / Swagger UI (springdoc) =====\n" +
                    "springdoc.api-docs.path=/v3/api-docs\n" +
                    "springdoc.swagger-ui.path=/swagger-ui.html\n";
        }
        return "";
    }

    /**
     * Returns a test source file for every production class generated by
     * {@link #javaSources(ProjectRequest)}. Tests are minimal and resilient:
     *   - Controllers   -> @WebMvcTest with a context-load assertion
     *   - Services      -> @SpringBootTest verifying the bean is wired
     *   - Repositories  -> @DataJpaTest only if Spring Data JPA is selected,
     *                       otherwise a plain JUnit smoke test (in-memory repos)
     *   - Everything else (model, dto, config, client, web) -> JUnit smoke test
     * This guarantees every generated production class has a matching test class
     * without inventing behaviour that the user didn't ask for.
     */
    public List<SourceFile> javaTests(ProjectRequest req) {
        List<SourceFile> tests = new ArrayList<>();
        if (!req.isJava()) return tests;
        String pkg = req.packageName();
        // Detect what the user actually selected — generated tests must only use
        // annotations whose supporting starters are present, or the test compile
        // will fail (e.g. @WebMvcTest needs spring-boot-starter-web on the main
        // classpath, not just spring-boot-starter-test).
        boolean hasJpa = hasDep(req, "data-jpa");
        boolean hasWeb = hasDep(req, "web");

        for (SourceFile prod : javaSources(req)) {
            String rel = prod.relativePath();
            if (!rel.endsWith(".java")) continue;
            int slash = rel.lastIndexOf('/');
            String subPackage = slash >= 0 ? rel.substring(0, slash) : "";
            String className = rel.substring(slash + 1, rel.length() - 5);
            String testClass = className + "Tests";
            String subPkgDot = subPackage.replace('/', '.');
            String fullSubPkg = subPkgDot.isEmpty() ? pkg : pkg + "." + subPkgDot;
            String testRel = (subPackage.isEmpty() ? "" : subPackage + "/") + testClass + ".java";
            tests.add(new SourceFile(testRel, testFor(fullSubPkg, subPkgDot, className, testClass, hasJpa, hasWeb, req.bootVersion())));
        }
        return tests;
    }

    private static boolean hasDep(ProjectRequest req, String idFragment) {
        return req.dependencies() != null
                && req.dependencies().stream().anyMatch(id -> id != null && id.contains(idFragment));
    }

    /** True for Spring Boot 4.x or newer — used to switch test imports to the
     *  new package paths introduced by the Boot 4 modularisation. */
    private static boolean isBoot4(String bootVersion) {
        if (bootVersion == null) return false;
        var m = java.util.regex.Pattern.compile("^(\\d+)\\.").matcher(bootVersion.trim());
        return m.find() && Integer.parseInt(m.group(1)) >= 4;
    }

    private String testFor(String fullPkg, String subPkg, String className, String testClass,
                           boolean hasJpa, boolean hasWeb, String bootVersion) {
        boolean boot4 = isBoot4(bootVersion);
        // Boot 4 moved the test auto-configure classes to new package paths.
        // WebMvcTest:   Boot 3 -> org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
        //               Boot 4 -> org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest
        // DataJpaTest:  Boot 3 -> org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest
        //               Boot 4 -> org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest
        String webMvcTestImport = boot4
                ? "org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest"
                : "org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest";
        String dataJpaTestImport = boot4
                ? "org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest"
                : "org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest";

        if ("controller".equals(subPkg)) {
            // @WebMvcTest / MockMvc require spring-boot-starter-web on the main
            // classpath. Fall back to a plain @SpringBootTest smoke test when web
            // isn't selected so the project always compiles.
            if (hasWeb) {
                return "package " + fullPkg + ";\n\n"
                        + "import org.junit.jupiter.api.Test;\n"
                        + "import org.springframework.beans.factory.annotation.Autowired;\n"
                        + "import " + webMvcTestImport + ";\n"
                        + "import org.springframework.test.web.servlet.MockMvc;\n\n"
                        + "import static org.junit.jupiter.api.Assertions.assertNotNull;\n\n"
                        + "@WebMvcTest(" + className + ".class)\n"
                        + "class " + testClass + " {\n\n"
                        + "    @Autowired\n"
                        + "    MockMvc mockMvc;\n\n"
                        + "    @Test\n"
                        + "    void contextLoads() {\n"
                        + "        assertNotNull(mockMvc);\n"
                        + "    }\n"
                        + "}\n";
            }
            return springBootSmokeTest(fullPkg, className, testClass);
        }
        if ("service".equals(subPkg)) {
            return "package " + fullPkg + ";\n\n"
                    + "import org.junit.jupiter.api.Test;\n"
                    + "import org.springframework.beans.factory.annotation.Autowired;\n"
                    + "import org.springframework.boot.test.context.SpringBootTest;\n\n"
                    + "import static org.junit.jupiter.api.Assertions.assertNotNull;\n\n"
                    + "@SpringBootTest\n"
                    + "class " + testClass + " {\n\n"
                    + "    @Autowired\n"
                    + "    " + className + " " + decap(className) + ";\n\n"
                    + "    @Test\n"
                    + "    void beanIsAvailable() {\n"
                    + "        assertNotNull(" + decap(className) + ");\n"
                    + "    }\n"
                    + "}\n";
        }
        if ("repository".equals(subPkg)) {
            if (hasJpa) {
                return "package " + fullPkg + ";\n\n"
                        + "import org.junit.jupiter.api.Test;\n"
                        + "import org.springframework.beans.factory.annotation.Autowired;\n"
                        + "import " + dataJpaTestImport + ";\n\n"
                        + "import static org.junit.jupiter.api.Assertions.assertNotNull;\n\n"
                        + "@DataJpaTest\n"
                        + "class " + testClass + " {\n\n"
                        + "    @Autowired\n"
                        + "    " + className + " " + decap(className) + ";\n\n"
                        + "    @Test\n"
                        + "    void repositoryWires() {\n"
                        + "        assertNotNull(" + decap(className) + ");\n"
                        + "    }\n"
                        + "}\n";
            }
            return "package " + fullPkg + ";\n\n"
                    + "import org.junit.jupiter.api.Test;\n"
                    + "import org.springframework.beans.factory.annotation.Autowired;\n"
                    + "import org.springframework.boot.test.context.SpringBootTest;\n\n"
                    + "import static org.junit.jupiter.api.Assertions.assertNotNull;\n\n"
                    + "@SpringBootTest\n"
                    + "class " + testClass + " {\n\n"
                    + "    @Autowired\n"
                    + "    " + className + " " + decap(className) + ";\n\n"
                    + "    @Test\n"
                    + "    void repositoryIsAvailable() {\n"
                    + "        assertNotNull(" + decap(className) + ");\n"
                    + "    }\n"
                    + "}\n";
        }
        return "package " + fullPkg + ";\n\n"
                + "import org.junit.jupiter.api.Test;\n\n"
                + "import static org.junit.jupiter.api.Assertions.assertNotNull;\n\n"
                + "class " + testClass + " {\n\n"
                + "    @Test\n"
                + "    void classExists() {\n"
                + "        assertNotNull(" + className + ".class);\n"
                + "    }\n"
                + "}\n";
    }

    private static String springBootSmokeTest(String fullPkg, String className, String testClass) {
        return "package " + fullPkg + ";\n\n"
                + "import org.junit.jupiter.api.Test;\n"
                + "import org.springframework.boot.test.context.SpringBootTest;\n\n"
                + "@SpringBootTest\n"
                + "class " + testClass + " {\n\n"
                + "    @Test\n"
                + "    void contextLoads() {\n"
                + "    }\n"
                + "}\n";
    }

    private static String decap(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }
}
