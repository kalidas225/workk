package com.sourceforge.starter.controller;

import com.sourceforge.starter.service.RunningAppRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Backs the API Tester UI panel: reports whether a verification-run application
 * is currently up, proxies HTTP requests to it (so the browser doesn't hit CORS
 * on cross-origin localhost calls), and stops it on demand.
 *
 * The proxy is intentionally minimal — it targets a locally-running process
 * that the user just launched via the "Run app after install" step; it does
 * NOT accept arbitrary URLs, only paths that get joined onto the registered
 * app's port.
 */
@RestController
@RequestMapping("/api")
public class ApiTesterController {

    private static final Logger log = LoggerFactory.getLogger(ApiTesterController.class);

    private final RunningAppRegistry registry;
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .build();

    public ApiTesterController(RunningAppRegistry registry) {
        this.registry = registry;
    }

    /** Returns the current running app info, or 204 if nothing is running. */
    @GetMapping("/running-app")
    public ResponseEntity<Map<String, Object>> current() {
        RunningAppRegistry.RunningApp app = registry.get();
        if (app == null) return ResponseEntity.noContent().build();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("language", app.language());
        body.put("artifactId", app.artifactId());
        body.put("port", app.port());
        body.put("pid", app.pid());
        body.put("startedAt", app.startedAt());
        body.put("baseUrl", "http://127.0.0.1:" + app.port());
        return ResponseEntity.ok(body);
    }

    /** Stops the currently-running verification app (if any). */
    @DeleteMapping("/running-app")
    public ResponseEntity<Map<String, Object>> stop() {
        boolean stopped = registry.stop();
        return ResponseEntity.ok(Map.of("stopped", stopped));
    }

    /**
     * Proxies an HTTP request to the currently-running app. The frontend sends:
     *   { method: "GET", path: "/api/greetings", body?: "...", headers?: {...} }
     * We forward the request to http://127.0.0.1:{port}{path} and stream the
     * response back with its status + headers + body inline. Timeouts are tight
     * (5 s) because this is meant for interactive smoke testing.
     */
    @PostMapping(value = "/proxy-request",
                 consumes = MediaType.APPLICATION_JSON_VALUE,
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> proxy(@RequestBody ProxyRequest req) {
        RunningAppRegistry.RunningApp app = registry.get();
        if (app == null) {
            return ResponseEntity.status(409).body(Map.of("error", "No running app to proxy to."));
        }
        if (req == null || req.method() == null || req.path() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Both 'method' and 'path' are required."));
        }
        String method = req.method().trim().toUpperCase();
        String path = req.path().startsWith("/") ? req.path() : "/" + req.path();
        URI uri;
        try {
            uri = URI.create("http://127.0.0.1:" + app.port() + path);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid path: " + e.getMessage()));
        }

        HttpRequest.Builder b = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(5));
        String body = req.body() == null ? "" : req.body();
        HttpRequest.BodyPublisher publisher = body.isEmpty()
                ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofString(body);
        switch (method) {
            case "GET"    -> b.GET();
            case "DELETE" -> b.DELETE();
            case "POST"   -> b.POST(publisher);
            case "PUT"    -> b.PUT(publisher);
            case "PATCH"  -> b.method("PATCH", publisher);
            case "HEAD"   -> b.method("HEAD", HttpRequest.BodyPublishers.noBody());
            case "OPTIONS"-> b.method("OPTIONS", publisher);
            default       -> { return ResponseEntity.badRequest().body(Map.of("error", "Unsupported method: " + method)); }
        }
        if (req.headers() != null) {
            for (var e : req.headers().entrySet()) {
                String h = e.getKey();
                // Skip restricted headers the JDK client won't allow.
                if (isRestrictedHeader(h)) continue;
                b.header(h, e.getValue());
            }
        }
        // Default content-type for methods that have a body but nothing set.
        if (!body.isEmpty() && (req.headers() == null || req.headers().keySet().stream()
                .noneMatch(k -> k.equalsIgnoreCase("content-type")))) {
            b.header("Content-Type", "application/json");
        }
        HttpResponse<String> resp;
        long t0 = System.currentTimeMillis();
        try {
            resp = client.send(b.build(), HttpResponse.BodyHandlers.ofString());
        } catch (java.net.http.HttpConnectTimeoutException e) {
            return ResponseEntity.ok(Map.of(
                    "error", "connect-timeout",
                    "message", "Could not connect to 127.0.0.1:" + app.port() + " within 3s. The app may still be starting or may have crashed."));
        } catch (java.net.http.HttpTimeoutException e) {
            return ResponseEntity.ok(Map.of(
                    "error", "request-timeout",
                    "message", "Request timed out after 5s."));
        } catch (Exception e) {
            log.warn("proxy request failed: {}", e.getMessage());
            return ResponseEntity.ok(Map.of("error", "proxy-error", "message", e.getMessage()));
        }
        long dt = System.currentTimeMillis() - t0;

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("status", resp.statusCode());
        Map<String, List<String>> headers = new LinkedHashMap<>();
        resp.headers().map().forEach(headers::put);
        out.put("headers", headers);
        out.put("body", resp.body());
        out.put("elapsedMs", dt);
        out.put("targetUrl", uri.toString());
        return ResponseEntity.ok(out);
    }

    /** JDK's HttpClient disallows setting certain hop-by-hop headers. */
    private static boolean isRestrictedHeader(String name) {
        String n = name == null ? "" : name.toLowerCase();
        return switch (n) {
            case "connection", "content-length", "expect", "host", "upgrade",
                 "transfer-encoding", "proxy-connection", "keep-alive" -> true;
            default -> false;
        };
    }

    public record ProxyRequest(String method, String path, String body, Map<String, String> headers) {}
}
