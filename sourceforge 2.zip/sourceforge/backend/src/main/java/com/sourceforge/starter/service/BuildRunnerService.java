package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Runs a REAL build of the generated project so the user can confirm the whole
 * package compiles — all dependencies resolved, not just a syntax check.
 *
 *  - Java   : writes the generated project to a temp dir and runs
 *             `mvn -B clean install` (or `-DskipTests` per config), streaming
 *             every output line until BUILD SUCCESS / BUILD FAILURE.
 *  - Python : `poetry install` (+ build) for Poetry projects, or
 *             `pip install . && python -m py_compile` for pip projects.
 *
 * Output is streamed line-by-line via the supplied consumer so the controller
 * can forward it to the browser over SSE. The terminal exit code determines
 * success.
 *
 * Honest note: a real Maven build downloads dependencies from Maven Central or a
 * configured mirror/Artifactory. On a host without that access the build will
 * fail at dependency resolution; the streaming + log capture still work, and the
 * build succeeds wherever the repository is reachable. The mirror can be set with
 * sourceforge.build.maven-mirror (a settings.xml mirror URL) or left blank.
 */
@Service
public class BuildRunnerService {

    private static final Logger log = LoggerFactory.getLogger(BuildRunnerService.class);

    private final ProjectGeneratorService generator;
    private final CompanyLlmClient llm;
    private final RunningAppRegistry runningApps;
    private final boolean skipTests;
    private final long timeoutSeconds;
    private final String jdkDir;         // base dir holding jdk-17, jdk-21, jdk-25, jdk-26
    private final String mavenDir;       // base dir holding e.g. apache-maven-3.9.9, 3.8.8
    private final String javaHome;       // explicit override (optional; wins over jdkDir)
    private final String mavenHome;      // explicit override (optional; wins over mavenDir)
    private final String mavenSettings;  // path to company settings.xml (Artifactory mirror + creds)

    public BuildRunnerService(
            ProjectGeneratorService generator,
            CompanyLlmClient llm,
            RunningAppRegistry runningApps,
            @Value("${sourceforge.build.skip-tests:true}") boolean skipTests,
            @Value("${sourceforge.build.timeout-seconds:600}") long timeoutSeconds,
            @Value("${sourceforge.build.jdk-dir:backend/runtime/jdk}") String jdkDir,
            @Value("${sourceforge.build.maven-dir:backend/runtime/maven}") String mavenDir,
            @Value("${sourceforge.build.java-home:}") String javaHome,
            @Value("${sourceforge.build.maven-home:}") String mavenHome,
            @Value("${sourceforge.build.maven-settings:}") String mavenSettings) {
        this.generator = generator;
        this.llm = llm;
        this.runningApps = runningApps;
        this.skipTests = skipTests;
        this.timeoutSeconds = timeoutSeconds;
        this.jdkDir = jdkDir == null ? "" : jdkDir.trim();
        this.mavenDir = mavenDir == null ? "" : mavenDir.trim();
        this.javaHome = javaHome == null ? "" : javaHome.trim();
        this.mavenHome = mavenHome == null ? "" : mavenHome.trim();
        this.mavenSettings = mavenSettings == null ? "" : mavenSettings.trim();
    }

    public record BuildOutcome(boolean success, int exitCode, String summary) {}

    /**
     * Asks the company LLM for a focused, project-specific diagnosis of a Maven
     * failure. Sends the project context (language/boot/java/deps) plus the tail
     * of the build log (the part containing the error) and constrains the answer
     * to a short, actionable list of fixes — telling the user exactly what to add
     * or change in the UI configuration / dependencies / settings.xml.
     */
    private String askLlmToDiagnose(ProjectRequest request, List<String> logLines) {
        // Extract the [ERROR] / [FATAL] lines verbatim — these are the only ground truth.
        // The rest of the log (mostly [INFO]) is noise that can mislead the model.
        StringBuilder errorBlock = new StringBuilder();
        int errCount = 0;
        for (String line : logLines) {
            if (line.contains("[ERROR]") || line.contains("[FATAL]")
                    || line.contains("package ") && line.contains("does not exist")
                    || line.contains("cannot find symbol")
                    || line.contains("BUILD FAILURE")) {
                errorBlock.append(line).append('\n');
                if (++errCount > 50) break;
            }
        }
        // Provide a small tail too for the surrounding context.
        StringBuilder tail = new StringBuilder();
        int start = Math.max(0, logLines.size() - 80);
        for (int i = start; i < logLines.size(); i++) {
            tail.append(logLines.get(i)).append('\n');
            if (tail.length() > 4000) break;
        }
        // Pre-compute the deterministic facts the model must rely on.
        boolean noSettings = mavenSettings.isBlank();
        String missingPackages = extractMissingPackages(logLines);
        boolean missingTestImports = missingPackages.contains("org.springframework.boot.test")
                || logLines.stream().anyMatch(l -> l.contains("WebMvcTest") && l.contains("cannot find symbol"))
                || logLines.stream().anyMatch(l -> l.contains("DataJpaTest") && l.contains("cannot find symbol"));
        boolean missingWebImports = missingPackages.contains("org.springframework.web")
                || missingPackages.contains("spring.web.servlet");

        String system = "You are a strict Spring Boot / Maven build diagnostician. "
                + "RULES (follow exactly):\n"
                + "1. Use ONLY the error lines and project facts given. Do NOT speculate about "
                + "topics not present in the error lines (no checksums, no proxy settings, no "
                + "TLS, no clock skew, no repository URLs — unless those words appear verbatim "
                + "in the errors).\n"
                + "2. Map error signatures directly:\n"
                + "   * 'package org.springframework.boot.test.autoconfigure.web.servlet does not "
                + "exist' OR 'cannot find symbol: class WebMvcTest' => the project needs "
                + "spring-boot-starter-web in main dependencies (in the UI: select 'Spring Web'). "
                + "Do NOT suggest changing settings.xml for this signature.\n"
                + "   * 'package org.springframework.boot.test.autoconfigure.orm.jpa does not "
                + "exist' OR 'cannot find symbol: class DataJpaTest' => the project needs "
                + "spring-boot-starter-data-jpa (in the UI: select 'Spring Data JPA').\n"
                + "   * 'package org.springframework.boot does not exist' AND main code uses "
                + "@SpringBootApplication => the project needs ANY Spring Boot runtime starter "
                + "(in the UI: select Spring Web, Spring Boot DevTools, Spring Data JPA, or "
                + "spring-boot-starter).\n"
                + "   * 'package org.springframework... does not exist' AND no settings.xml is "
                + "configured AND no dependency hint above matches => settings.xml is the cause; "
                + "configure the Artifactory mirror.\n"
                + "3. Output format: one short sentence with the root cause, then a numbered list "
                + "of at most 3 actions, each starting with 'In the UI:' or 'In pom.xml:' or 'In "
                + "settings.xml:'. No headers, no preamble, no markdown emphasis.";
        String userPrompt = "Project facts:\n"
                + "  language: " + request.language() + "\n"
                + "  spring-boot: " + request.bootVersion() + "\n"
                + "  java: " + request.javaVersion() + "\n"
                + "  architecture: " + request.architecture() + "\n"
                + "  selected dependencies: " + (request.dependencies() == null ? "none" : String.join(", ", request.dependencies())) + "\n"
                + "  settings.xml configured: " + (!noSettings) + "\n"
                + "  missing packages detected: " + (missingPackages.isEmpty() ? "none" : missingPackages) + "\n"
                + "  hint - missing test imports (WebMvcTest/DataJpaTest): " + missingTestImports + "\n"
                + "  hint - missing web imports: " + missingWebImports + "\n"
                + "\nError lines (verbatim):\n" + (errorBlock.length() == 0 ? "(no [ERROR] lines found)\n" : errorBlock)
                + "\nLog tail (for context):\n" + tail;
        try {
            return llm.complete(system, userPrompt).orElse(null);
        } catch (Exception e) {
            log.warn("LLM diagnosis call failed: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Inspects the failure log and emits a precise, signature-matched hint about
     * exactly what the user should do. Order matters: the most specific signature
     * (a particular missing import) is matched first, falling back to the generic
     * "no Spring Boot starter / no settings.xml" message only when no specific
     * cause is identifiable. This is deterministic (no network call) so the user
     * sees the most likely fix instantly, before any AI diagnosis follows.
     */
    private void emitDeterministicHint(ProjectRequest request, List<String> logLines, Consumer<String> onLine) {
        String packages = extractMissingPackages(logLines);
        boolean hasWebDep = request.dependencies() != null
                && request.dependencies().stream().anyMatch(id -> id != null && id.contains("web"));
        boolean hasJpaDep = request.dependencies() != null
                && request.dependencies().stream().anyMatch(id -> id != null && id.contains("data-jpa"));

        // Specific signature: @WebMvcTest / MockMvc used but Spring Web not selected.
        if ((packages.contains("org.springframework.boot.test.autoconfigure.web.servlet")
                || logLines.stream().anyMatch(l -> l.contains("cannot find symbol") && containsAnyLater(logLines, l, "WebMvcTest", "MockMvc")))
                && !hasWebDep) {
            onLine.accept("[sourceforge] HINT: the project's test classes use @WebMvcTest / MockMvc,");
            onLine.accept("[sourceforge]   which require Spring Web on the main classpath, but you didn't");
            onLine.accept("[sourceforge]   select it. In the UI: tick the 'Spring Web' dependency and re-run.");
            return;
        }

        // Specific signature: @WebMvcTest missing even though Spring Web IS selected.
        // For Boot 4.x, this means the project is missing spring-boot-starter-webmvc-test
        // (Boot 4 split spring-boot-starter-test into per-technology companions).
        // The generator now emits this automatically — if the user still hits this,
        // their pom is stale.
        if ((packages.contains("org.springframework.boot.test.autoconfigure.web.servlet")
                || packages.contains("org.springframework.boot.test.autoconfigure.orm.jpa")
                || logLines.stream().anyMatch(l -> l.contains("cannot find symbol") && containsAnyLater(logLines, l, "WebMvcTest", "DataJpaTest")))
                && hasWebDep) {
            boolean boot4 = request.bootVersion() != null && request.bootVersion().startsWith("4");
            if (boot4) {
                onLine.accept("[sourceforge] HINT: Spring Boot 4 SPLIT the test starter into per-technology");
                onLine.accept("[sourceforge]   companions: @WebMvcTest now lives in spring-boot-starter-webmvc-test,");
                onLine.accept("[sourceforge]   @DataJpaTest in spring-boot-starter-data-jpa-test, etc. The");
                onLine.accept("[sourceforge]   generator emits these automatically when the matching runtime");
                onLine.accept("[sourceforge]   starter is selected. Your pom is missing them — REGENERATE the");
                onLine.accept("[sourceforge]   project (click GENERATE again) so the fresh pom is used.");
            } else {
                onLine.accept("[sourceforge] HINT: spring-boot-starter-test IS in the pom but @WebMvcTest is");
                onLine.accept("[sourceforge]   missing. This is unusual for Boot 3.x — check that your Artifactory");
                onLine.accept("[sourceforge]   mirror is serving spring-boot-test-autoconfigure-" + (request.bootVersion() == null ? "X" : request.bootVersion()) + ".jar.");
            }
            return;
        }

        // Specific signature: @DataJpaTest used but Spring Data JPA not selected.
        if ((packages.contains("org.springframework.boot.test.autoconfigure.orm.jpa")
                || logLines.stream().anyMatch(l -> l.contains("cannot find symbol") && l.contains("DataJpaTest")))
                && !hasJpaDep) {
            onLine.accept("[sourceforge] HINT: the project's test classes use @DataJpaTest, which requires");
            onLine.accept("[sourceforge]   Spring Data JPA. In the UI: tick the 'Spring Data JPA' dependency.");
            return;
        }

        // Specific signature: @SpringBootApplication won't compile (no runtime starter).
        if (packages.equals("org.springframework.boot")
                || (packages.contains("org.springframework.boot") && packages.contains("org.springframework.boot.autoconfigure"))) {
            boolean hasAnyStarter = request.dependencies() != null
                    && request.dependencies().stream().anyMatch(id -> id != null
                        && (id.contains("web") || id.contains("data-jpa") || id.contains("data-rest")
                            || id.contains("security") || id.contains("actuator") || id.equals("starter")));
            if (!hasAnyStarter) {
                onLine.accept("[sourceforge] HINT: no Spring Boot runtime starter is selected, so the");
                onLine.accept("[sourceforge]   @SpringBootApplication class can't compile. In the UI, tick ONE of:");
                onLine.accept("[sourceforge]     • Spring Web        (REST/MVC apps)");
                onLine.accept("[sourceforge]     • Spring Boot DevTools");
                onLine.accept("[sourceforge]     • Spring Data JPA   (database apps)");
                return;
            }
        }

        // Fallback: generic "Spring missing" — likely the network/Artifactory problem.
        if (!packages.isEmpty() && packages.contains("org.springframework")) {
            onLine.accept("[sourceforge] HINT: 'package org.springframework... does not exist' here likely means");
            onLine.accept("[sourceforge]   Maven could not download dependencies from your Artifactory mirror.");
            if (mavenSettings.isBlank()) {
                onLine.accept("[sourceforge]   No settings.xml is configured — set SOURCEFORGE_MAVEN_SETTINGS to");
                onLine.accept("[sourceforge]   backend/runtime/settings.xml (a working Artifactory settings file).");
            } else {
                onLine.accept("[sourceforge]   settings.xml IS configured (" + mavenSettings + "), so verify the");
                onLine.accept("[sourceforge]   mirror URL is reachable and the artifact actually exists there.");
            }
        }
    }

    /** True if {@code anchor} is found, then any of the keywords appears within the next 6 lines. */
    private static boolean containsAnyLater(List<String> lines, String anchor, String... keywords) {
        int idx = lines.indexOf(anchor);
        if (idx < 0) return false;
        int end = Math.min(lines.size(), idx + 6);
        for (int i = idx + 1; i < end; i++) {
            for (String k : keywords) if (lines.get(i).contains(k)) return true;
        }
        return false;
    }

    /** Pulls all "package <x> does not exist" packages from the log into a comma-sep list. */
    private static String extractMissingPackages(List<String> logLines) {
        var pattern = java.util.regex.Pattern.compile("package ([\\w.]+) does not exist");
        java.util.Set<String> packages = new java.util.LinkedHashSet<>();
        for (String l : logLines) {
            var m = pattern.matcher(l);
            while (m.find()) packages.add(m.group(1));
        }
        return String.join(", ", packages);
    }

    /**
     * Selects the JDK home for the requested Java version from the jdk base dir.
     * Looks for jdk-&lt;ver&gt; (e.g. jdk-21), then any folder containing the version,
     * accepting either &lt;dir&gt;/bin/java or a macOS &lt;dir&gt;/Contents/Home/bin/java.
     * Returns null if none found.
     */
    String selectJdkHome(String javaVersion, Consumer<String> onLine) {
        if (jdkDir.isBlank() || javaVersion == null || javaVersion.isBlank()) return null;
        Path base = Path.of(jdkDir).toAbsolutePath();
        if (!Files.isDirectory(base)) {
            onLine.accept("[sourceforge] JDK dir not found: " + base
                    + " (set sourceforge.build.jdk-dir / SOURCEFORGE_JDK_DIR to an absolute path)");
            return null;
        }
        onLine.accept("[sourceforge] looking for a JDK for Java " + javaVersion + " under " + base);
        // 1. exact "jdk-<ver>" first
        Path exact = base.resolve("jdk-" + javaVersion);
        String hit = jdkHomeIfValid(exact);
        if (hit != null) return hit;
        // 2. one level deeper inside jdk-<ver> (e.g. jdk-21/jdk-21.0.1)
        hit = jdkHomeNested(exact);
        if (hit != null) return hit;
        // 3. any child whose name contains the version (and one level deeper inside it)
        try {
            for (Path child : Files.list(base).filter(Files::isDirectory).toList()) {
                String n = child.getFileName().toString();
                if (n.contains(javaVersion)) {
                    String h = jdkHomeIfValid(child);
                    if (h == null) h = jdkHomeNested(child);
                    if (h != null) return h;
                }
            }
        } catch (Exception ignore) { /* fall through */ }
        // Nothing valid — tell the user exactly what we saw.
        try {
            String contents = Files.list(base)
                    .map(p -> p.getFileName().toString())
                    .sorted()
                    .reduce((a, b) -> a + ", " + b).orElse("(empty)");
            onLine.accept("[sourceforge] no usable jdk-" + javaVersion + " here. Contents of " + base
                    + ": " + contents);
            onLine.accept("[sourceforge] expected " + (isWindows() ? "jdk-" + javaVersion + "\\bin\\java.exe"
                    : "jdk-" + javaVersion + "/bin/java"));
        } catch (Exception ignore) { /* best effort */ }
        return null;
    }

    /** A valid JDK home has bin/java(.exe), or Contents/Home/bin/java on macOS. */
    private String jdkHomeIfValid(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return null;
        if (hasJavaBin(dir)) return dir.toAbsolutePath().toString();
        Path macHome = dir.resolve(Path.of("Contents", "Home"));
        if (hasJavaBin(macHome)) return macHome.toAbsolutePath().toString();
        return null;
    }

    /** Look one directory level deeper (handles jdk-21/jdk-21.0.1/bin/java). */
    private String jdkHomeNested(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return null;
        try {
            for (Path sub : Files.list(dir).filter(Files::isDirectory).toList()) {
                String h = jdkHomeIfValid(sub);
                if (h != null) return h;
            }
        } catch (Exception ignore) { /* none */ }
        return null;
    }

    /** True if dir/bin/java(.exe) exists. Uses existence (not just the executable bit,
     *  which is unreliable for .exe on Windows over some filesystems). */
    private boolean hasJavaBin(Path dir) {
        if (dir == null) return false;
        Path java = dir.resolve(Path.of("bin", isWindows() ? "java.exe" : "java"));
        return Files.isRegularFile(java);
    }

    /**
     * Selects a Maven home from the maven base dir that is compatible with the
     * Boot + Java selection. Maven 3.9.x is required for Spring Boot 3.5+/4.x and
     * Java 17+; 3.8.x is the fallback. Prefers the newest compatible version found.
     */
    String selectMavenHome(String bootVersion, String javaVersion, Consumer<String> onLine) {
        if (mavenDir.isBlank()) return null;
        Path base = Path.of(mavenDir);
        if (!Files.isDirectory(base)) return null;
        String exe = isWindows() ? "mvn.cmd" : "mvn";
        try {
            // collect valid maven homes with a parsed version
            var candidates = Files.list(base)
                    .filter(Files::isDirectory)
                    .filter(p -> Files.isExecutable(p.resolve(Path.of("bin", exe))))
                    .sorted(Comparator.comparingInt((Path p) -> versionKey(parseMavenVersion(p.getFileName().toString())))
                            .reversed())
                    .toList();
            if (candidates.isEmpty()) return null;
            // Boot 3.5+/4.x needs Maven 3.9+. Pick newest >= 3.9 when required, else newest available.
            boolean needs39 = requiresMaven39(bootVersion, javaVersion);
            for (Path p : candidates) {
                int[] v = parseMavenVersion(p.getFileName().toString());
                boolean is39plus = v[0] > 3 || (v[0] == 3 && v[1] >= 9);
                if (!needs39 || is39plus) {
                    onLine.accept("[sourceforge] Maven " + v[0] + "." + v[1] + "." + v[2]
                            + " selected for Boot " + bootVersion + " / Java " + javaVersion);
                    return p.toAbsolutePath().toString();
                }
            }
            // none satisfied the 3.9 requirement; warn and use newest available
            onLine.accept("[sourceforge] WARNING: Boot " + bootVersion + " prefers Maven 3.9+, "
                    + "but none found in " + mavenDir + "; using newest available.");
            return candidates.get(0).toAbsolutePath().toString();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean requiresMaven39(String bootVersion, String javaVersion) {
        // Spring Boot 3.5+ and 4.x require Maven 3.9+. Java 25/26 also pair with 3.9+.
        if (bootVersion != null && !bootVersion.isBlank()) {
            int major = parseLeadingInt(bootVersion);
            if (major >= 4) return true;
            if (major == 3) {
                // 3.5+ -> needs 3.9
                String[] parts = bootVersion.split("\\.");
                if (parts.length >= 2 && parseLeadingInt(parts[1]) >= 5) return true;
            }
        }
        int jv = parseLeadingInt(javaVersion);
        return jv >= 25;
    }

    /** Parse "apache-maven-3.9.9" / "maven-3.8.8" / "3.9.9" -> [3,9,9]. */
    private int[] parseMavenVersion(String name) {
        var m = java.util.regex.Pattern.compile("(\\d+)\\.(\\d+)\\.(\\d+)").matcher(name);
        if (m.find()) {
            return new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3))};
        }
        return new int[]{0, 0, 0};
    }

    /** Comparable key for a [major,minor,patch] version, newest = largest. */
    private int versionKey(int[] v) {
        return v[0] * 1_000_000 + v[1] * 1_000 + v[2];
    }

    private int parseLeadingInt(String s) {
        if (s == null) return 0;
        var m = java.util.regex.Pattern.compile("(\\d+)").matcher(s);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    /**
     * Backward-compatible runBuild (no run-after step). Delegates to the
     * full method with runAfterBuild=false so existing callers and tests
     * keep working unchanged.
     */
    public BuildOutcome runBuild(ProjectRequest request, Consumer<String> onLine) {
        return runBuild(request, false, onLine);
    }

    /**
     * Writes the generated project to disk and runs its real build, streaming
     * each log line to {@code onLine}. When {@code runAfterBuild} is true AND
     * the install succeeded, launches the produced app (mvn spring-boot:run) for
     * a short configurable window to verify it starts cleanly, then terminates
     * it. Final outcome reflects both phases.
     */
    public BuildOutcome runBuild(ProjectRequest request, boolean runAfterBuild, Consumer<String> onLine) {
        Path workDir = null;
        try {
            workDir = Files.createTempDirectory("sf-build-");
            Map<String, String> files = generator.buildFiles(request);
            // The generated files are prefixed with "<artifactId>/"; strip that so the
            // project root (with pom.xml / pyproject.toml) sits at workDir root.
            String prefix = request.artifactId() + "/";
            for (var e : files.entrySet()) {
                String rel = e.getKey().startsWith(prefix) ? e.getKey().substring(prefix.length()) : e.getKey();
                Path p = workDir.resolve(rel);
                Files.createDirectories(p.getParent());
                Files.writeString(p, e.getValue());
            }
            onLine.accept("[sourceforge] wrote " + files.size() + " files to build workspace");
            onLine.accept("[sourceforge] language=" + request.language()
                    + " build=" + request.type() + "  starting build…");
            onLine.accept("");

            // Pre-flight: catch likely failures BEFORE invoking mvn so the user doesn't
            // wait for a download just to see a missing-starter error.
            if (request.isJava()) {
                preflightJavaProject(request, workDir, onLine);
            }

            List<String> command = request.isPython()
                    ? pythonCommand(request, workDir, onLine)
                    : mavenCommand(request, workDir, onLine);
            if (command == null || command.isEmpty()) {
                // The specific reason was already printed by mavenCommand/pythonCommand
                // (missing tool, no settings.xml, etc.); don't add a generic line on top.
                return new BuildOutcome(false, -1, "Build aborted before start — see log above.");
            }

            onLine.accept("$ " + String.join(" ", command));
            onLine.accept("");
            // Capture the full log so we can hand the tail to the LLM on failure,
            // and watch the stream for the classic dependency-resolution signature.
            boolean[] sawMissingSpring = {false};
            boolean[] sawMavenSuccess = {false};
            boolean[] sawMavenFailure = {false};
            List<String> logBuffer = new ArrayList<>();
            Consumer<String> watched = line -> {
                if (line.contains("package org.springframework") && line.contains("does not exist")) {
                    sawMissingSpring[0] = true;
                }
                // Track Maven's own verdict so we can override a noisy wrapper exit code.
                // (e.g. on Windows, mvn.cmd's batch wrapper sometimes exits non-zero with
                //  "'cmd' is not recognized" AFTER Maven itself printed BUILD SUCCESS.)
                if (line.contains("BUILD SUCCESS")) sawMavenSuccess[0] = true;
                if (line.contains("BUILD FAILURE")) sawMavenFailure[0] = true;
                logBuffer.add(line);
                onLine.accept(line);
            };
            int exit = runProcess(request, command, workDir, watched);

            // Maven's own verdict wins over the wrapper exit code when they disagree.
            // If Maven printed BUILD SUCCESS and never printed BUILD FAILURE, treat as
            // success regardless of the wrapper exit code (a known Windows mvn.cmd
            // quirk where a post-success shell line breaks the wrapper).
            boolean success;
            boolean wrapperNoise = false;
            if (sawMavenSuccess[0] && !sawMavenFailure[0]) {
                success = true;
                if (exit != 0) {
                    wrapperNoise = true;
                    onLine.accept("[sourceforge] note: Maven reported BUILD SUCCESS but the launcher "
                            + "exited " + exit + " (typically a Windows mvn.cmd / PATH quirk such as "
                            + "'cmd' not found). Trusting Maven's verdict.");
                }
            } else if (sawMavenFailure[0]) {
                success = false;
            } else {
                // No explicit verdict in the log — fall back to the exit code.
                success = exit == 0;
            }
            String summary = success
                    ? "BUILD SUCCESS — the project compiled and packaged cleanly."
                    : "BUILD FAILED (exit " + exit + ") — see the log above for the first error.";
            onLine.accept("");
            // Only diagnose actual failures — never run AI for a successful build.
            if (!success && !request.isPython()) {
                emitDeterministicHint(request, logBuffer, onLine);
                // Then, if the LLM is configured, ask it for a precise, project-specific
                // diagnosis. Streamed as clearly-labelled AI lines so the user knows the source.
                if (llm.isEnabled()) {
                    onLine.accept("");
                    onLine.accept("[ai] asking the company LLM for a project-specific diagnosis…");
                    String answer = askLlmToDiagnose(request, logBuffer);
                    if (answer != null && !answer.isBlank()) {
                        for (String l : answer.split("\\R")) onLine.accept("[ai] " + l);
                    } else {
                        String why = llm.lastError() == null ? "no response" : llm.lastError();
                        onLine.accept("[ai] (skipped — " + why + ")");
                    }
                }
            }
            onLine.accept("[sourceforge] " + summary);
            log.info("real build  artifact={}  lang={}  exit={}  success={}",
                    request.artifactId(), request.language(), exit, success);

            // Optional post-install: launch the app to confirm it actually boots.
            if (success && runAfterBuild) {
                if (request.isJava()) {
                    return runSpringBootApp(request, workDir, onLine);
                }
                if (request.isPython()) {
                    return runPythonApp(request, workDir, onLine);
                }
            }
            return new BuildOutcome(success, exit, summary);

        } catch (Exception ex) {
            log.warn("build runner failed: {}", ex.getMessage());
            onLine.accept("[sourceforge] build could not start: " + ex.getMessage());
            return new BuildOutcome(false, -1, "Build could not start: " + ex.getMessage());
        } finally {
            if (workDir != null) deleteRecursive(workDir);
        }
    }

    private List<String> mavenCommand(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        String mvn = resolveMaven(request, onLine);
        if (mvn == null) {
            onLine.accept("[sourceforge] ERROR: Maven was not found.");
            onLine.accept("[sourceforge] Looked in: backend/runtime/maven (sourceforge.build.maven-dir), "
                    + "sourceforge.build.maven-home, the MAVEN_HOME / M2_HOME environment variables, and PATH.");
            onLine.accept("[sourceforge] Fix: place a Maven distribution under backend/runtime/maven/ "
                    + "(e.g. apache-maven-3.9.9), or set MAVEN_HOME (e.g. " + exampleMavenHome()
                    + "), then restart this server.");
            return null;
        }
        // Always run a fresh build: -U forces re-check of dependencies (no offline
        // reliance), and a per-build local repo guarantees no cache is reused
        // between runs — every "MVN INSTALL" downloads/resolves from scratch.
        Path freshRepo = workDir.resolve(".m2-fresh");
        List<String> cmd = new ArrayList<>(List.of(
                mvn, "-B", "-U", "clean", "install",
                "-Dmaven.repo.local=" + freshRepo.toAbsolutePath()
        ));
        if (skipTests) cmd.add("-DskipTests");
        if (!mavenSettings.isBlank()) {
            // Company settings.xml: Artifactory mirror + server credentials.
            Path settingsPath = Path.of(mavenSettings);
            if (Files.isReadable(settingsPath)) {
                cmd.add("-s");
                cmd.add(mavenSettings);
                onLine.accept("[sourceforge] using Maven settings: " + mavenSettings);
                // Echo a quick summary so any odd token in the file is visible here.
                describeSettings(settingsPath, onLine);
            } else {
                onLine.accept("[sourceforge] WARNING: sourceforge.build.maven-settings is set to '"
                        + mavenSettings + "' but that file is not readable. Maven defaults will be used.");
            }
        } else {
            // No explicit settings.xml. Check whether the user's ~/.m2/settings.xml exists —
            // Maven will use it implicitly, and many corporate machines have it.
            Path userHomeSettings = Path.of(System.getProperty("user.home", "."), ".m2", "settings.xml");
            if (Files.isReadable(userHomeSettings)) {
                onLine.accept("[sourceforge] no explicit settings.xml configured; Maven will use "
                        + userHomeSettings + " (its mirrors/servers apply).");
                describeSettings(userHomeSettings, onLine);
            } else {
                // No project setting AND no user setting -> the build is almost certainly
                // going to fail on dependency resolution if the corporate network blocks
                // Maven Central. Refuse to start and tell the user exactly what to do.
                onLine.accept("");
                onLine.accept("[sourceforge] STOP: no Artifactory settings.xml is configured.");
                onLine.accept("[sourceforge]   Looked for sourceforge.build.maven-settings (env SOURCEFORGE_MAVEN_SETTINGS): not set.");
                onLine.accept("[sourceforge]   Looked for " + userHomeSettings + ": not present.");
                onLine.accept("[sourceforge]   Without a mirror, Maven will try Maven Central; if your corporate");
                onLine.accept("[sourceforge]   network blocks it, every Spring import will report 'package does not exist'.");
                onLine.accept("[sourceforge] Fix it once:");
                onLine.accept("[sourceforge]   1. Put your company settings.xml at backend/runtime/settings.xml");
                onLine.accept("[sourceforge]      (template: backend/runtime/settings.xml.example).");
                onLine.accept("[sourceforge]   2. Set SOURCEFORGE_MAVEN_SETTINGS to its absolute path, then restart the backend.");
                onLine.accept("[sourceforge] Aborting build to save you time. Re-run after the fix.");
                return null;
            }
        }
        return cmd;
    }

    /**
     * Sanity-checks the generated project on disk before mvn runs. Catches the
     * common cases where the build would fail for an obvious reason — e.g. source
     * uses @SpringBootApplication but pom has no runtime Spring starter (the cause
     * of "package org.springframework.boot does not exist" which you'd otherwise
     * only learn after a Maven download). Emits [WARN] lines (yellow in the UI)
     * with a precise fix.
     */
    private void preflightJavaProject(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        Path pom = workDir.resolve("pom.xml");
        if (!Files.isRegularFile(pom)) {
            onLine.accept("[WARN] pre-flight: pom.xml not found at workspace root; skipping checks.");
            return;
        }
        String pomXml;
        try { pomXml = Files.readString(pom); }
        catch (Exception e) {
            onLine.accept("[WARN] pre-flight: could not read pom.xml (" + e.getMessage() + ")");
            return;
        }
        boolean usesSpringBootApp = false;
        try {
            usesSpringBootApp = Files.walk(workDir)
                    .filter(p -> p.toString().endsWith(".java"))
                    .anyMatch(p -> {
                        try { return Files.readString(p).contains("@SpringBootApplication"); }
                        catch (Exception ex) { return false; }
                    });
        } catch (Exception ignore) { /* best effort */ }

        boolean hasRuntimeStarter = pomXml.contains("<artifactId>spring-boot-starter</artifactId>")
                || java.util.regex.Pattern.compile("<artifactId>spring-boot-starter-(?!test\\b)[^<]+</artifactId>")
                        .matcher(pomXml).find();

        if (usesSpringBootApp && !hasRuntimeStarter) {
            onLine.accept("[WARN] pre-flight: @SpringBootApplication is used but the pom has no runtime");
            onLine.accept("[WARN]              Spring Boot starter. Build will fail with");
            onLine.accept("[WARN]              'package org.springframework.boot does not exist'.");
            onLine.accept("[WARN] Fix in the UI: under Dependencies, add ONE of these starters:");
            onLine.accept("[WARN]   • Spring Web                 (for REST/MVC apps)");
            onLine.accept("[WARN]   • Spring Boot DevTools       (development convenience)");
            onLine.accept("[WARN]   • Spring Data JPA            (for database apps)");
            onLine.accept("[WARN]   • Spring Boot Starter (bare) (CLI/non-web apps)");
            onLine.accept("[WARN] Continuing the build — Maven will report the same failure.");
            onLine.accept("");
        } else if (usesSpringBootApp && hasRuntimeStarter) {
            onLine.accept("[INFO] pre-flight OK: a Spring Boot runtime starter is present.");
        }
    }

    /**
     * Returns the Maven version (e.g. "3.8.6") by invoking {@code mvn --version}.
     * Best-effort: returns null if anything goes wrong. Output is parsed from
     * the first line, which always starts with "Apache Maven X.Y.Z".
     */
    private String detectMavenCliVersion(String mvn, Consumer<String> onLine) {
        try {
            List<String> cmd;
            if (isWindows() && (mvn.toLowerCase().endsWith(".cmd") || mvn.toLowerCase().endsWith(".bat"))) {
                String sysRoot = System.getenv("SystemRoot");
                Path cmdExe = Path.of(sysRoot == null ? "C:\\Windows" : sysRoot, "System32", "cmd.exe");
                if (Files.isRegularFile(cmdExe)) {
                    cmd = List.of(cmdExe.toString(), "/d", "/c",
                            "\"" + mvn + "\" --version");
                } else {
                    cmd = List.of(mvn, "--version");
                }
            } else {
                cmd = List.of(mvn, "--version");
            }
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                String version = null;
                while ((line = br.readLine()) != null) {
                    if (version == null) {
                        var m = java.util.regex.Pattern.compile("Apache Maven (\\d+\\.\\d+(?:\\.\\d+)?)").matcher(line);
                        if (m.find()) version = m.group(1);
                    }
                }
                p.waitFor(10, TimeUnit.SECONDS);
                return version;
            }
        } catch (Exception e) {
            onLine.accept("[INFO] pre-flight: could not detect Maven CLI version (" + e.getClass().getSimpleName() + ")");
            return null;
        }
    }

    /** Returns the Maven version Boot needs, as {major, minor}; null if unknown. */
    private int[] bootRequiresMavenAtLeast(String bootVersion) {
        if (bootVersion == null || bootVersion.isBlank()) return null;
        int[] v = parseSemver(bootVersion);
        if (v == null) return null;
        // Boot 4.x -> Maven 3.9+ ; Boot 3.5+ -> Maven 3.9+ ; Boot 3.4 and below -> 3.8 OK
        if (v[0] >= 4) return new int[]{3, 9};
        if (v[0] == 3 && v[1] >= 5) return new int[]{3, 9};
        return new int[]{3, 6};
    }

    /** Parse "3.8.6" / "4.0.6" into [3,8,6] / [4,0,6]. Null on failure. */
    private static int[] parseSemver(String s) {
        if (s == null) return null;
        var m = java.util.regex.Pattern.compile("^(\\d+)\\.(\\d+)(?:\\.(\\d+))?").matcher(s.trim());
        if (!m.find()) return null;
        return new int[]{
                Integer.parseInt(m.group(1)),
                Integer.parseInt(m.group(2)),
                m.group(3) == null ? 0 : Integer.parseInt(m.group(3))
        };
    }

    private static int compareVersion(int[] a, int[] b) {
        int n = Math.max(a.length, b.length);
        for (int i = 0; i < n; i++) {
            int av = i < a.length ? a[i] : 0;
            int bv = i < b.length ? b[i] : 0;
            if (av != bv) return Integer.compare(av, bv);
        }
        return 0;
    }

    /**
     * Reads the configured settings.xml and prints a one-line-per-entry summary
     * of its mirror URLs, server ids, and active profile ids.
     */
    private void describeSettings(Path file, Consumer<String> onLine) {
        try {
            String xml = Files.readString(file);
            // Strip XML comments to keep regex hits meaningful.
            String stripped = xml.replaceAll("(?s)<!--.*?-->", "");
            var mirrors = java.util.regex.Pattern.compile("(?s)<mirror>(.*?)</mirror>").matcher(stripped);
            int n = 0;
            while (mirrors.find()) {
                String body = mirrors.group(1);
                String id = firstGroup(body, "<id>(.*?)</id>");
                String url = firstGroup(body, "<url>(.*?)</url>");
                String mirrorOf = firstGroup(body, "<mirrorOf>(.*?)</mirrorOf>");
                onLine.accept("[sourceforge]   mirror id=" + id + "  mirrorOf=" + mirrorOf + "  url=" + url);
                n++;
            }
            var servers = java.util.regex.Pattern.compile("(?s)<server>(.*?)</server>").matcher(stripped);
            while (servers.find()) {
                String id = firstGroup(servers.group(1), "<id>(.*?)</id>");
                onLine.accept("[sourceforge]   server id=" + id);
            }
            String active = firstGroup(stripped, "(?s)<activeProfile>(.*?)</activeProfile>");
            if (!"".equals(active)) {
                onLine.accept("[sourceforge]   activeProfile=" + active);
            }
            if (n == 0) {
                onLine.accept("[sourceforge]   (no <mirror> entries found — Maven will use the central repo)");
            }
        } catch (Exception e) {
            onLine.accept("[sourceforge] (could not parse settings.xml summary: " + e.getMessage() + ")");
        }
    }

    private String firstGroup(String haystack, String regex) {
        var m = java.util.regex.Pattern.compile(regex).matcher(haystack);
        return m.find() ? m.group(1).trim() : "";
    }

    /**
     * Resolve the mvn executable, in priority order:
     *   1. version-compatible Maven under backend/runtime/maven (Boot + Java aware)
     *   2. sourceforge.build.maven-home property
     *   3. MAVEN_HOME / M2_HOME environment variables (the user's local install)
     *   4. mvn / mvn.cmd on PATH
     * Works on macOS, Linux and Windows (mvn.cmd on Windows).
     */
    private String resolveMaven(ProjectRequest request, Consumer<String> onLine) {
        String exe = isWindows() ? "mvn.cmd" : "mvn";
        // 1. version-compatible Maven from runtime/maven
        String selected = selectMavenHome(request.bootVersion(), request.javaVersion(), onLine);
        String fromSelected = mavenFromHome(selected, exe);
        if (fromSelected != null) { onLine.accept("[sourceforge] Maven (runtime/maven): " + fromSelected); return fromSelected; }
        // 2. configured property
        String fromHome = mavenFromHome(mavenHome, exe);
        if (fromHome != null) { onLine.accept("[sourceforge] Maven (configured): " + fromHome); return fromHome; }
        // 3. environment variables
        for (String var : new String[]{"MAVEN_HOME", "M2_HOME"}) {
            String env = System.getenv(var);
            String fromEnv = mavenFromHome(env, exe);
            if (fromEnv != null) { onLine.accept("[sourceforge] Maven (from " + var + "): " + fromEnv); return fromEnv; }
        }
        // 4. PATH
        String onPath = resolve(isWindows() ? new String[]{"mvn.cmd", "mvn"} : new String[]{"mvn"});
        if (onPath != null) { onLine.accept("[sourceforge] Maven (from PATH): " + onPath); return onPath; }
        return null;
    }

    private String mavenFromHome(String home, String exe) {
        if (home == null || home.isBlank()) return null;
        Path candidate = Path.of(home.trim(), "bin", exe);
        return Files.isExecutable(candidate) ? candidate.toString() : null;
    }

    private String exampleMavenHome() {
        if (isWindows()) return "C:\\\\apache-maven-3.9.9";
        return System.getProperty("os.name", "").toLowerCase().contains("mac")
                ? "/opt/homebrew/Cellar/maven/3.9.9/libexec or /usr/local/Cellar/..."
                : "/opt/apache-maven-3.9.9";
    }

    private List<String> pythonCommand(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        String python = resolve(isWindows() ? new String[]{"python", "python3"} : new String[]{"python3", "python"});
        if (python == null) {
            onLine.accept("[sourceforge] ERROR: Python was not found on PATH.");
            onLine.accept("[sourceforge] Fix: install Python 3 and ensure 'python3' (or 'python' on Windows) is on PATH, then restart this server.");
            return null;
        }
        onLine.accept("[sourceforge] Python (from PATH): " + python);
        // Poetry project
        if ("poetry".equals(request.type())) {
            String poetry = resolve("poetry");
            if (poetry != null) {
                onLine.accept("[sourceforge] using Poetry: " + poetry);
                return List.of(poetry, "install", "--no-interaction");
            }
            onLine.accept("[sourceforge] poetry not installed; falling back to a syntax check (compileall).");
        } else {
            // pip project: install then byte-compile the package.
            String pip = resolve(isWindows() ? new String[]{"pip", "pip3"} : new String[]{"pip3", "pip"});
            if (pip != null) {
                onLine.accept("[sourceforge] using pip: " + pip);
                if (isWindows()) {
                    // cmd.exe chains with &&; run install then compile
                    return List.of("cmd.exe", "/c", pip + " install . && " + python + " -m compileall -q src");
                }
                return List.of("sh", "-c", pip + " install . && " + python + " -m compileall -q src");
            }
            onLine.accept("[sourceforge] pip not installed; falling back to a syntax check (compileall).");
        }
        // Fallback: byte-compile all sources for a syntax check
        return List.of(python, "-m", "compileall", "-q", ".");
    }

    private int runProcess(ProjectRequest request, List<String> command, Path workDir, Consumer<String> onLine)
            throws Exception {
        // Windows: when invoking a .cmd batch file via ProcessBuilder, the JVM relies
        // on the user's PATH having cmd.exe; if PATH is unusual or cmd.exe is shadowed,
        // the launcher prints "'cmd' is not recognized" AFTER the command finishes, and
        // returns a non-zero exit code even on success. Defend by wrapping the call via
        // the absolute path to cmd.exe so the launcher is always findable.
        List<String> effective = command;
        if (isWindows() && !command.isEmpty()) {
            String first = command.get(0);
            if (first.toLowerCase().endsWith(".cmd") || first.toLowerCase().endsWith(".bat")) {
                String sysRoot = System.getenv("SystemRoot");
                Path cmdExe = Path.of(sysRoot == null ? "C:\\Windows" : sysRoot,
                        "System32", "cmd.exe");
                if (Files.isRegularFile(cmdExe)) {
                    // Quote the batch file path so spaces are preserved.
                    StringBuilder line = new StringBuilder("\"").append(first).append("\"");
                    for (int i = 1; i < command.size(); i++) {
                        line.append(' ').append(quoteIfNeeded(command.get(i)));
                    }
                    effective = List.of(cmdExe.toString(), "/d", "/c", line.toString());
                    onLine.accept("[sourceforge] launching via " + cmdExe + " /c (Windows wrapper-safe mode)");
                }
            }
        }
        ProcessBuilder pb = new ProcessBuilder(effective);
        pb.directory(workDir.toFile());
        pb.redirectErrorStream(true);
        var env = pb.environment();
        // Keep Maven from emitting colour codes that would clutter the browser log.
        env.put("MAVEN_OPTS", "-Djansi.force=false");
        // Choose the JDK, in order:
        //   1. runtime/jdk/jdk-<version> matching the selected Java version
        //   2. sourceforge.build.java-home (explicit override)
        //   3. user's JAVA_HOME env var
        //   4. java on PATH
        // (The company JDK's cacerts already trusts Artifactory, so no cert import.)
        String selectedJdk = request.isJava() ? selectJdkHome(request.javaVersion(), onLine) : null;
        String jdkSource;
        String effectiveJavaHome;
        if (selectedJdk != null) {
            effectiveJavaHome = selectedJdk;
            jdkSource = "runtime/jdk for Java " + request.javaVersion();
        } else if (!javaHome.isBlank()) {
            effectiveJavaHome = javaHome;
            jdkSource = "configured java-home";
        } else if (System.getenv("JAVA_HOME") != null && !System.getenv("JAVA_HOME").isBlank()) {
            effectiveJavaHome = System.getenv("JAVA_HOME").trim();
            jdkSource = "JAVA_HOME env";
        } else {
            effectiveJavaHome = "";
            jdkSource = "";
        }
        if (request.isJava() && selectedJdk == null && jdkDir != null && !jdkDir.isBlank()) {
            onLine.accept("[sourceforge] note: no jdk-" + request.javaVersion()
                    + " found under " + jdkDir + "; falling back to java-home/JAVA_HOME/PATH.");
        }
        if (!effectiveJavaHome.isBlank()) {
            Path javaBin = Path.of(effectiveJavaHome, "bin", isWindows() ? "java.exe" : "java");
            if (Files.isExecutable(javaBin)) {
                env.put("JAVA_HOME", effectiveJavaHome);
                String binDir = Path.of(effectiveJavaHome, "bin").toString();
                String sep = isWindows() ? ";" : ":";
                env.put("PATH", binDir + sep + env.getOrDefault("PATH", ""));
                onLine.accept("[sourceforge] JDK (" + jdkSource + "): " + effectiveJavaHome);
            } else {
                onLine.accept("[sourceforge] WARNING: JDK home '" + effectiveJavaHome
                        + "' has no java executable; falling back to the java on PATH.");
            }
        } else if (request.isJava()) {
            onLine.accept("[sourceforge] no JDK found (runtime/jdk, java-home or JAVA_HOME);"
                    + " using the java on PATH if present.");
        }
        Process proc = pb.start();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                onLine.accept(stripAnsi(line));
            }
        }
        boolean finished = proc.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        if (!finished) {
            proc.destroyForcibly();
            onLine.accept("[sourceforge] build timed out after " + timeoutSeconds + "s; aborted.");
            return 124;
        }
        return proc.exitValue();
    }

    private static String stripAnsi(String s) {
        return s.replaceAll("\u001B\\[[;\\d]*m", "");
    }

    private String resolve(String... candidates) {
        for (String c : candidates) {
            try {
                Process p = new ProcessBuilder(isWindows() ? "where" : "which", c)
                        .redirectErrorStream(true).start();
                if (p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0) return c;
            } catch (Exception ignore) { /* next */ }
        }
        return null;
    }

    /**
     * Launches the just-built Spring Boot application via mvn spring-boot:run,
     * streams its log, and watches for either:
     *   - "Started ... in N.NNN seconds" (Spring Boot's confirmation), or
     *   - a startup exception / non-zero exit
     * After a configurable window (default 30 s) the process is terminated so
     * the build slot is released. Returns the run outcome.
     */
    private BuildOutcome runSpringBootApp(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        onLine.accept("");
        onLine.accept("[sourceforge] starting the application to verify it boots…");
        String mvn = resolveMaven(request, onLine);
        if (mvn == null) {
            return new BuildOutcome(false, -1, "Could not locate Maven for the run step.");
        }
        // Pick a free TCP port for the verification run so we never collide with
        // anything else listening on 8080 (or whatever the user's app defaults to).
        // The generated project's application.properties is left alone — only this
        // run gets the override, passed via spring-boot.run.arguments.
        int port = findFreePort();
        onLine.accept("[sourceforge] using free port " + port
                + " for the verification run (does not change the generated config).");

        List<String> command = new ArrayList<>(List.of(mvn, "-B", "spring-boot:run"));
        if (!mavenSettings.isBlank()) { command.add("-s"); command.add(mavenSettings); }
        // Don't fork — keep it in the same JVM so we can reliably kill it.
        command.add("-Dspring-boot.run.fork=false");
        // Override the server port for this run only. --server.port is a Spring
        // command-line property that wins over application.properties.
        command.add("-Dspring-boot.run.arguments=--server.port=" + port);

        // Apply the same Windows-safe wrapping used for the install step.
        List<String> effective = command;
        if (isWindows() && !command.isEmpty()) {
            String first = command.get(0);
            if (first.toLowerCase().endsWith(".cmd") || first.toLowerCase().endsWith(".bat")) {
                String sysRoot = System.getenv("SystemRoot");
                Path cmdExe = Path.of(sysRoot == null ? "C:\\Windows" : sysRoot, "System32", "cmd.exe");
                if (Files.isRegularFile(cmdExe)) {
                    StringBuilder line = new StringBuilder("\"").append(first).append("\"");
                    for (int i = 1; i < command.size(); i++) line.append(' ').append(quoteIfNeeded(command.get(i)));
                    effective = List.of(cmdExe.toString(), "/d", "/c", line.toString());
                }
            }
        }
        onLine.accept("$ " + String.join(" ", command));

        Process proc = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(effective)
                    .directory(workDir.toFile())
                    .redirectErrorStream(true);
            applyEnv(request, pb.environment(), onLine);
            proc = pb.start();

            boolean[] started = {false};
            boolean[] crashed = {false};
            Process finalProc = proc;
            Thread reader = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(finalProc.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String clean = stripAnsi(line);
                        onLine.accept(clean);
                        if (clean.contains("Started ") && clean.contains(" in ") && clean.contains(" seconds")) {
                            started[0] = true;
                        }
                        if (clean.contains("APPLICATION FAILED TO START") || clean.contains("Error starting ApplicationContext")) {
                            crashed[0] = true;
                        }
                    }
                } catch (Exception ignore) { /* stream closed */ }
            }, "sf-runapp-reader");
            reader.setDaemon(true);
            reader.start();

            // Wait up to runWindowSeconds for "Started ..." or a crash; otherwise stop after the window.
            long windowMs = Math.min(timeoutSeconds, 30) * 1000L;
            long deadline = System.currentTimeMillis() + windowMs;
            while (System.currentTimeMillis() < deadline) {
                if (started[0] || crashed[0]) break;
                if (!proc.isAlive()) break;
                Thread.sleep(200);
            }

            boolean runOk = started[0] && !crashed[0];
            String summary;
            if (runOk && proc.isAlive()) {
                // Startup confirmed. Register the app in the running-app registry so
                // the API Tester panel can proxy curl-style requests to it. The app
                // keeps running until the user clicks "Stop app" or the backend restarts.
                long pid;
                try { pid = proc.pid(); } catch (Exception ignore) { pid = -1; }
                runningApps.set(new RunningAppRegistry.RunningApp(
                        request.language(), request.artifactId(), port, pid, System.currentTimeMillis()), proc);
                summary = "BUILD SUCCESS — the application is running on port " + port + ".";
                onLine.accept("[sourceforge] " + summary);
                onLine.accept("[sourceforge] Open the API Tester panel in the UI to hit its endpoints.");
                // Return immediately, leaving proc alive. The registry owns cleanup.
                return new BuildOutcome(true, 0, summary);
            }
            // Not running cleanly: shut down anything left.
            if (proc.isAlive()) {
                onLine.accept("[sourceforge] stopping the application (startup did not confirm)…");
                proc.destroy();
                if (!proc.waitFor(8, TimeUnit.SECONDS)) proc.destroyForcibly();
            }
            if (crashed[0]) {
                summary = "BUILD SUCCESS but the application FAILED TO START — see the log above.";
            } else {
                summary = "BUILD SUCCESS but no startup confirmation within the window — "
                        + "the app may need longer or may not log 'Started …'. See log.";
            }
            onLine.accept("[sourceforge] " + summary);
            return new BuildOutcome(false, proc.exitValue() == 0 ? 0 : proc.exitValue(), summary);
        } catch (Exception ex) {
            if (proc != null && proc.isAlive()) proc.destroyForcibly();
            onLine.accept("[sourceforge] run step failed: " + ex.getMessage());
            return new BuildOutcome(false, -1, "Application run failed: " + ex.getMessage());
        }
    }

    /**
     * Returns an ephemeral TCP port that's free at this instant. Used for the
     * verification run so we don't collide with whatever's already bound to 8080
     * (or any other port the user's app might default to). Falls back to a random
     * port in the high range if the OS lookup fails for any reason.
     */
    private int findFreePort() {
        try (java.net.ServerSocket s = new java.net.ServerSocket(0)) {
            s.setReuseAddress(true);
            return s.getLocalPort();
        } catch (Exception e) {
            // Very unlikely. Fall back to a randomized high port.
            return 49152 + new java.util.Random().nextInt(16384);
        }
    }

    /**
     * Launches the just-built Python (FastAPI) application via uvicorn on a free
     * port, streams its log, watches for "Uvicorn running on" and either registers
     * it in the running-app registry (on success) or shuts it down (on failure).
     * Mirrors {@link #runSpringBootApp} for Java.
     */
    private BuildOutcome runPythonApp(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        onLine.accept("");
        onLine.accept("[sourceforge] starting the application to verify it boots…");
        int port = findFreePort();
        onLine.accept("[sourceforge] using free port " + port
                + " for the verification run (does not change the generated config).");

        // Best-effort: prefer `poetry run uvicorn <pkg>.main:app`, else `python -m uvicorn ...`.
        String pkg = (request.packageName() == null ? "app" : request.packageName().replace('.', '_'));
        String modulePath = pkg + ".main:app";
        String poetry = resolveOnPath("poetry");
        String python = resolveOnPath(isWindows() ? "python.exe" : "python3");
        if (python == null) python = resolveOnPath("python");
        List<String> command;
        if (poetry != null) {
            command = new ArrayList<>(List.of(poetry, "run", "uvicorn", modulePath,
                    "--host", "127.0.0.1", "--port", String.valueOf(port), "--log-level", "info"));
        } else if (python != null) {
            command = new ArrayList<>(List.of(python, "-m", "uvicorn", modulePath,
                    "--host", "127.0.0.1", "--port", String.valueOf(port), "--log-level", "info"));
        } else {
            onLine.accept("[sourceforge] neither poetry nor python found on PATH — cannot start the app.");
            return new BuildOutcome(false, -1, "Python runtime not available on the server.");
        }
        onLine.accept("$ " + String.join(" ", command));

        Process proc = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(command)
                    .directory(workDir.toFile())
                    .redirectErrorStream(true);
            proc = pb.start();
            boolean[] started = {false};
            boolean[] crashed = {false};
            Process finalProc = proc;
            Thread reader = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(finalProc.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String clean = stripAnsi(line);
                        onLine.accept(clean);
                        if (clean.contains("Uvicorn running on") || clean.contains("Application startup complete")) {
                            started[0] = true;
                        }
                        if (clean.contains("Traceback (most recent call last)")
                                || clean.contains("ERROR:") && clean.contains("Application startup failed")) {
                            crashed[0] = true;
                        }
                    }
                } catch (Exception ignore) { /* stream closed */ }
            }, "sf-runpy-reader");
            reader.setDaemon(true);
            reader.start();

            long windowMs = Math.min(timeoutSeconds, 30) * 1000L;
            long deadline = System.currentTimeMillis() + windowMs;
            while (System.currentTimeMillis() < deadline) {
                if (started[0] || crashed[0]) break;
                if (!proc.isAlive()) break;
                Thread.sleep(200);
            }

            boolean runOk = started[0] && !crashed[0];
            String summary;
            if (runOk && proc.isAlive()) {
                long pid;
                try { pid = proc.pid(); } catch (Exception ignore) { pid = -1; }
                runningApps.set(new RunningAppRegistry.RunningApp(
                        request.language(), request.artifactId(), port, pid, System.currentTimeMillis()), proc);
                summary = "BUILD SUCCESS — the application is running on port " + port + ".";
                onLine.accept("[sourceforge] " + summary);
                onLine.accept("[sourceforge] Open the API Tester panel in the UI to hit its endpoints.");
                return new BuildOutcome(true, 0, summary);
            }
            if (proc.isAlive()) {
                onLine.accept("[sourceforge] stopping the application (startup did not confirm)…");
                proc.destroy();
                if (!proc.waitFor(8, TimeUnit.SECONDS)) proc.destroyForcibly();
            }
            summary = crashed[0]
                    ? "BUILD SUCCESS but the application FAILED TO START — see the log above."
                    : "BUILD SUCCESS but no startup confirmation within the window — see log.";
            onLine.accept("[sourceforge] " + summary);
            return new BuildOutcome(false, proc.exitValue() == 0 ? 0 : proc.exitValue(), summary);
        } catch (Exception ex) {
            if (proc != null && proc.isAlive()) proc.destroyForcibly();
            onLine.accept("[sourceforge] run step failed: " + ex.getMessage());
            return new BuildOutcome(false, -1, "Application run failed: " + ex.getMessage());
        }
    }

    /** Resolves an executable on PATH, returning its absolute path (or null). */
    private String resolveOnPath(String exe) {
        try {
            Process p = new ProcessBuilder(isWindows() ? "where" : "which", exe)
                    .redirectErrorStream(true).start();
            if (p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0) {
                String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                for (String line : out.split("\\R")) {
                    String t = line.trim();
                    if (!t.isEmpty()) return t;
                }
            }
        } catch (Exception ignore) { /* miss */ }
        return null;
    }

    /** Apply JDK env vars (JAVA_HOME, PATH) for child processes — shared between install and run. */
    private void applyEnv(ProjectRequest request, Map<String, String> env, Consumer<String> onLine) {
        env.put("MAVEN_OPTS", "-Djansi.force=false");
        String selectedJdk = request.isJava() ? selectJdkHome(request.javaVersion(), s -> {}) : null;
        String effectiveJavaHome = selectedJdk != null ? selectedJdk
                : (!javaHome.isBlank() ? javaHome
                : (System.getenv("JAVA_HOME") != null ? System.getenv("JAVA_HOME").trim() : ""));
        if (!effectiveJavaHome.isBlank()) {
            Path javaBin = Path.of(effectiveJavaHome, "bin", isWindows() ? "java.exe" : "java");
            if (Files.isRegularFile(javaBin)) {
                env.put("JAVA_HOME", effectiveJavaHome);
                String binDir = Path.of(effectiveJavaHome, "bin").toString();
                String sep = isWindows() ? ";" : ":";
                env.put("PATH", binDir + sep + env.getOrDefault("PATH", ""));
            }
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    /** Quote an argument for Windows cmd.exe if it contains spaces or quotes. */
    private static String quoteIfNeeded(String s) {
        if (s == null) return "\"\"";
        if (s.isEmpty()) return "\"\"";
        if (s.indexOf(' ') < 0 && s.indexOf('"') < 0 && s.indexOf('\t') < 0) return s;
        return "\"" + s.replace("\"", "\\\"") + "\"";
    }

    private void deleteRecursive(Path root) {
        try {
            Files.walk(root).sorted(Comparator.reverseOrder())
                    .forEach(p -> { try { Files.deleteIfExists(p); } catch (Exception ignore) {} });
        } catch (Exception ignore) { /* best effort */ }
    }
}
