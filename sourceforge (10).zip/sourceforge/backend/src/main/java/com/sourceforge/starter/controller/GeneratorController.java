package com.sourceforge.starter.controller;

import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.BuildRunnerService;
import com.sourceforge.starter.service.ProjectGeneratorService;
import com.sourceforge.starter.service.SandboxCompileService;
import com.sourceforge.starter.service.VersionCompatibilityService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/api")
public class GeneratorController {

    private static final Logger log = LoggerFactory.getLogger(GeneratorController.class);

    private final ProjectGeneratorService generator;
    private final VersionCompatibilityService versionCompat;
    private final SandboxCompileService sandbox;
    private final BuildRunnerService buildRunner;
    private final com.sourceforge.starter.service.CompanyLlmClient llm;
    private final ExecutorService buildExecutor = Executors.newCachedThreadPool();

    public GeneratorController(ProjectGeneratorService generator,
                               VersionCompatibilityService versionCompat,
                               SandboxCompileService sandbox,
                               BuildRunnerService buildRunner,
                               com.sourceforge.starter.service.CompanyLlmClient llm) {
        this.generator = generator;
        this.versionCompat = versionCompat;
        this.sandbox = sandbox;
        this.buildRunner = buildRunner;
        this.llm = llm;
    }

    /** Returns the full set of generated files as { path: content } for the Explore preview. */
    @PostMapping(value = "/preview", produces = "application/json")
    public ResponseEntity<Map<String, String>> preview(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        Map<String, String> files = generator.previewFiles(request);
        log.info("POST /api/preview  artifact={}  files={}  took={}ms",
                request.artifactId(), files.size(), System.currentTimeMillis() - start);
        return ResponseEntity.ok(files);
    }

    /**
     * Returns the compatible version dropdown options for each requested dependency,
     * given the selected Spring Boot + Java version. Resolved from the static
     * compatibility map, refined by the company LLM when configured.
     */
    @PostMapping(value = "/compatible-versions", produces = "application/json")
    public ResponseEntity<Map<String, List<String>>> compatibleVersions(@RequestBody CompatibilityRequest req) {
        Map<String, List<String>> out = versionCompat.compatibleVersionsBatch(
                req.dependencies() == null ? List.of() : req.dependencies(),
                req.language(), req.bootVersion() == null ? "" : req.bootVersion(), req.javaVersion());
        return ResponseEntity.ok(out);
    }

    public record CompatibilityRequest(List<String> dependencies, String language,
                                       String bootVersion, String javaVersion) {}

    /**
     * Lightweight status for the version-dropdown LLM, so the UI can show a
     * non-blocking note when the company LLM is unreachable (dropdowns still work
     * from the built-in catalog). enabled=false means no LLM is configured.
     */
    @org.springframework.web.bind.annotation.GetMapping(value = "/llm-status", produces = "application/json")
    public ResponseEntity<Map<String, Object>> llmStatus() {
        Map<String, Object> status = new java.util.LinkedHashMap<>();
        status.put("enabled", llm.isEnabled());
        status.put("lastError", llm.lastError());   // null when healthy or never called
        return ResponseEntity.ok(status);
    }

    /**
     * Compiles the generated Java sources in a sandbox (javac via the Compiler API)
     * and returns structured diagnostics so the UI can show errors before download.
     */
    @PostMapping(value = "/compile", produces = "application/json")
    public ResponseEntity<SandboxCompileService.CompileResult> compile(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        var result = sandbox.compile(request);
        log.info("POST /api/compile  artifact={}  ok={}  errors={}  took={}ms",
                request.artifactId(), result.ok(), result.errorCount(), System.currentTimeMillis() - start);
        return ResponseEntity.ok(result);
    }

    /**
     * Runs a REAL full build of the generated project (Java: mvn clean install;
     * Python: poetry/pip install + compile) and streams the complete log to the
     * browser over Server-Sent Events. Each log line is one "log" event; a final
     * "done" event carries the success flag and summary.
     */
    @PostMapping(value = "/build-stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter buildStream(@Valid @RequestBody ProjectRequest request) {
        // Generous timeout; the build itself is also bounded server-side.
        SseEmitter emitter = new SseEmitter(15 * 60 * 1000L);
        buildExecutor.submit(() -> {
            try {
                var outcome = buildRunner.runBuild(request, line -> {
                    try {
                        emitter.send(SseEmitter.event().name("log").data(line));
                    } catch (IOException io) {
                        throw new RuntimeException(io);  // client disconnected
                    }
                });
                emitter.send(SseEmitter.event().name("done").data(
                        "{\"success\":" + outcome.success()
                        + ",\"exitCode\":" + outcome.exitCode()
                        + ",\"summary\":\"" + outcome.summary().replace("\"", "\\\"") + "\"}"));
                emitter.complete();
            } catch (Exception ex) {
                emitter.completeWithError(ex);
            }
        });
        return emitter;
    }

    @PostMapping(value = "/generate", produces = "application/zip")
    public ResponseEntity<byte[]> generate(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        log.info("POST /api/generate  artifact={}  language={}  build={}  runtime={}  deps={}  db={}  arch={}  envs={}  dmzr={}",
                request.artifactId(),
                request.language(),
                request.type(),
                request.javaVersion(),
                request.dependencies().size(),
                request.database() != null ? request.database().type() : "none",
                request.architecture(),
                request.environments() != null && request.environments().enabled()
                        ? request.environments().environments() : "off",
                request.dmzr() != null && request.dmzr().enabled() ? "on" : "off");

        byte[] zip = generator.generate(request);

        log.info("POST /api/generate  artifact={}  size={}KB  took={}ms",
                request.artifactId(), zip.length / 1024, System.currentTimeMillis() - start);

        ContentDisposition cd = ContentDisposition.attachment()
                .filename(request.artifactId() + ".zip")
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/zip"));
        headers.setContentDisposition(cd);
        headers.setContentLength(zip.length);
        return new ResponseEntity<>(zip, headers, HttpStatus.OK);
    }
}
