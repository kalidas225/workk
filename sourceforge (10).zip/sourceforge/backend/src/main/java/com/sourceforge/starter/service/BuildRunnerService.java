package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ProjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Runs a REAL build of the generated project so the user can confirm the whole
 * package compiles — all dependencies resolved, not just a syntax check.
 *
 *  - Java   : writes the generated project to a temp dir and runs
 *             `mvn -B clean install` (or `-DskipTests` per config), streaming
 *             every output line until BUILD SUCCESS / BUILD FAILURE.
 *  - Python : `poetry install` (+ build) for Poetry projects, or
 *             `pip install . && python -m py_compile` for pip projects.
 *
 * Output is streamed line-by-line via the supplied consumer so the controller
 * can forward it to the browser over SSE. The terminal exit code determines
 * success.
 *
 * Honest note: a real Maven build downloads dependencies from Maven Central or a
 * configured mirror/Artifactory. On a host without that access the build will
 * fail at dependency resolution; the streaming + log capture still work, and the
 * build succeeds wherever the repository is reachable. The mirror can be set with
 * sourceforge.build.maven-mirror (a settings.xml mirror URL) or left blank.
 */
@Service
public class BuildRunnerService {

    private static final Logger log = LoggerFactory.getLogger(BuildRunnerService.class);

    private final ProjectGeneratorService generator;
    private final boolean skipTests;
    private final long timeoutSeconds;
    private final String jdkDir;         // base dir holding jdk-17, jdk-21, jdk-25, jdk-26
    private final String mavenDir;       // base dir holding e.g. apache-maven-3.9.9, 3.8.8
    private final String javaHome;       // explicit override (optional; wins over jdkDir)
    private final String mavenHome;      // explicit override (optional; wins over mavenDir)
    private final String mavenSettings;  // path to company settings.xml (Artifactory mirror + creds)

    public BuildRunnerService(
            ProjectGeneratorService generator,
            @Value("${sourceforge.build.skip-tests:true}") boolean skipTests,
            @Value("${sourceforge.build.timeout-seconds:600}") long timeoutSeconds,
            @Value("${sourceforge.build.jdk-dir:backend/runtime/jdk}") String jdkDir,
            @Value("${sourceforge.build.maven-dir:backend/runtime/maven}") String mavenDir,
            @Value("${sourceforge.build.java-home:}") String javaHome,
            @Value("${sourceforge.build.maven-home:}") String mavenHome,
            @Value("${sourceforge.build.maven-settings:}") String mavenSettings) {
        this.generator = generator;
        this.skipTests = skipTests;
        this.timeoutSeconds = timeoutSeconds;
        this.jdkDir = jdkDir == null ? "" : jdkDir.trim();
        this.mavenDir = mavenDir == null ? "" : mavenDir.trim();
        this.javaHome = javaHome == null ? "" : javaHome.trim();
        this.mavenHome = mavenHome == null ? "" : mavenHome.trim();
        this.mavenSettings = mavenSettings == null ? "" : mavenSettings.trim();
    }

    public record BuildOutcome(boolean success, int exitCode, String summary) {}

    /**
     * Selects the JDK home for the requested Java version from the jdk base dir.
     * Looks for jdk-&lt;ver&gt; (e.g. jdk-21), then any folder containing the version,
     * accepting either &lt;dir&gt;/bin/java or a macOS &lt;dir&gt;/Contents/Home/bin/java.
     * Returns null if none found.
     */
    String selectJdkHome(String javaVersion, Consumer<String> onLine) {
        if (jdkDir.isBlank() || javaVersion == null || javaVersion.isBlank()) return null;
        Path base = Path.of(jdkDir).toAbsolutePath();
        if (!Files.isDirectory(base)) {
            onLine.accept("[sourceforge] JDK dir not found: " + base
                    + " (set sourceforge.build.jdk-dir / SOURCEFORGE_JDK_DIR to an absolute path)");
            return null;
        }
        onLine.accept("[sourceforge] looking for a JDK for Java " + javaVersion + " under " + base);
        // 1. exact "jdk-<ver>" first
        Path exact = base.resolve("jdk-" + javaVersion);
        String hit = jdkHomeIfValid(exact);
        if (hit != null) return hit;
        // 2. one level deeper inside jdk-<ver> (e.g. jdk-21/jdk-21.0.1)
        hit = jdkHomeNested(exact);
        if (hit != null) return hit;
        // 3. any child whose name contains the version (and one level deeper inside it)
        try {
            for (Path child : Files.list(base).filter(Files::isDirectory).toList()) {
                String n = child.getFileName().toString();
                if (n.contains(javaVersion)) {
                    String h = jdkHomeIfValid(child);
                    if (h == null) h = jdkHomeNested(child);
                    if (h != null) return h;
                }
            }
        } catch (Exception ignore) { /* fall through */ }
        // Nothing valid — tell the user exactly what we saw.
        try {
            String contents = Files.list(base)
                    .map(p -> p.getFileName().toString())
                    .sorted()
                    .reduce((a, b) -> a + ", " + b).orElse("(empty)");
            onLine.accept("[sourceforge] no usable jdk-" + javaVersion + " here. Contents of " + base
                    + ": " + contents);
            onLine.accept("[sourceforge] expected " + (isWindows() ? "jdk-" + javaVersion + "\\bin\\java.exe"
                    : "jdk-" + javaVersion + "/bin/java"));
        } catch (Exception ignore) { /* best effort */ }
        return null;
    }

    /** A valid JDK home has bin/java(.exe), or Contents/Home/bin/java on macOS. */
    private String jdkHomeIfValid(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return null;
        if (hasJavaBin(dir)) return dir.toAbsolutePath().toString();
        Path macHome = dir.resolve(Path.of("Contents", "Home"));
        if (hasJavaBin(macHome)) return macHome.toAbsolutePath().toString();
        return null;
    }

    /** Look one directory level deeper (handles jdk-21/jdk-21.0.1/bin/java). */
    private String jdkHomeNested(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return null;
        try {
            for (Path sub : Files.list(dir).filter(Files::isDirectory).toList()) {
                String h = jdkHomeIfValid(sub);
                if (h != null) return h;
            }
        } catch (Exception ignore) { /* none */ }
        return null;
    }

    /** True if dir/bin/java(.exe) exists. Uses existence (not just the executable bit,
     *  which is unreliable for .exe on Windows over some filesystems). */
    private boolean hasJavaBin(Path dir) {
        if (dir == null) return false;
        Path java = dir.resolve(Path.of("bin", isWindows() ? "java.exe" : "java"));
        return Files.isRegularFile(java);
    }

    /**
     * Selects a Maven home from the maven base dir that is compatible with the
     * Boot + Java selection. Maven 3.9.x is required for Spring Boot 3.5+/4.x and
     * Java 17+; 3.8.x is the fallback. Prefers the newest compatible version found.
     */
    String selectMavenHome(String bootVersion, String javaVersion, Consumer<String> onLine) {
        if (mavenDir.isBlank()) return null;
        Path base = Path.of(mavenDir);
        if (!Files.isDirectory(base)) return null;
        String exe = isWindows() ? "mvn.cmd" : "mvn";
        try {
            // collect valid maven homes with a parsed version
            var candidates = Files.list(base)
                    .filter(Files::isDirectory)
                    .filter(p -> Files.isExecutable(p.resolve(Path.of("bin", exe))))
                    .sorted(Comparator.comparingInt((Path p) -> versionKey(parseMavenVersion(p.getFileName().toString())))
                            .reversed())
                    .toList();
            if (candidates.isEmpty()) return null;
            // Boot 3.5+/4.x needs Maven 3.9+. Pick newest >= 3.9 when required, else newest available.
            boolean needs39 = requiresMaven39(bootVersion, javaVersion);
            for (Path p : candidates) {
                int[] v = parseMavenVersion(p.getFileName().toString());
                boolean is39plus = v[0] > 3 || (v[0] == 3 && v[1] >= 9);
                if (!needs39 || is39plus) {
                    onLine.accept("[sourceforge] Maven " + v[0] + "." + v[1] + "." + v[2]
                            + " selected for Boot " + bootVersion + " / Java " + javaVersion);
                    return p.toAbsolutePath().toString();
                }
            }
            // none satisfied the 3.9 requirement; warn and use newest available
            onLine.accept("[sourceforge] WARNING: Boot " + bootVersion + " prefers Maven 3.9+, "
                    + "but none found in " + mavenDir + "; using newest available.");
            return candidates.get(0).toAbsolutePath().toString();
        } catch (Exception e) {
            return null;
        }
    }

    private boolean requiresMaven39(String bootVersion, String javaVersion) {
        // Spring Boot 3.5+ and 4.x require Maven 3.9+. Java 25/26 also pair with 3.9+.
        if (bootVersion != null && !bootVersion.isBlank()) {
            int major = parseLeadingInt(bootVersion);
            if (major >= 4) return true;
            if (major == 3) {
                // 3.5+ -> needs 3.9
                String[] parts = bootVersion.split("\\.");
                if (parts.length >= 2 && parseLeadingInt(parts[1]) >= 5) return true;
            }
        }
        int jv = parseLeadingInt(javaVersion);
        return jv >= 25;
    }

    /** Parse "apache-maven-3.9.9" / "maven-3.8.8" / "3.9.9" -> [3,9,9]. */
    private int[] parseMavenVersion(String name) {
        var m = java.util.regex.Pattern.compile("(\\d+)\\.(\\d+)\\.(\\d+)").matcher(name);
        if (m.find()) {
            return new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3))};
        }
        return new int[]{0, 0, 0};
    }

    /** Comparable key for a [major,minor,patch] version, newest = largest. */
    private int versionKey(int[] v) {
        return v[0] * 1_000_000 + v[1] * 1_000 + v[2];
    }

    private int parseLeadingInt(String s) {
        if (s == null) return 0;
        var m = java.util.regex.Pattern.compile("(\\d+)").matcher(s);
        return m.find() ? Integer.parseInt(m.group(1)) : 0;
    }

    /**
     * Writes the generated project to disk and runs its real build, streaming
     * each log line to {@code onLine}. Returns the final outcome.
     */
    public BuildOutcome runBuild(ProjectRequest request, Consumer<String> onLine) {
        Path workDir = null;
        try {
            workDir = Files.createTempDirectory("sf-build-");
            Map<String, String> files = generator.buildFiles(request);
            // The generated files are prefixed with "<artifactId>/"; strip that so the
            // project root (with pom.xml / pyproject.toml) sits at workDir root.
            String prefix = request.artifactId() + "/";
            for (var e : files.entrySet()) {
                String rel = e.getKey().startsWith(prefix) ? e.getKey().substring(prefix.length()) : e.getKey();
                Path p = workDir.resolve(rel);
                Files.createDirectories(p.getParent());
                Files.writeString(p, e.getValue());
            }
            onLine.accept("[sourceforge] wrote " + files.size() + " files to build workspace");
            onLine.accept("[sourceforge] language=" + request.language()
                    + " build=" + request.type() + "  starting build…");
            onLine.accept("");

            List<String> command = request.isPython()
                    ? pythonCommand(request, workDir, onLine)
                    : mavenCommand(request, workDir, onLine);
            if (command == null || command.isEmpty()) {
                onLine.accept("[sourceforge] no build tool available on the server runtime.");
                return new BuildOutcome(false, -1, "Build tool not available.");
            }

            onLine.accept("$ " + String.join(" ", command));
            onLine.accept("");
            // Watch the stream for the classic "no dependencies resolved" signature so we
            // can give a precise hint if the build fails for that reason.
            boolean[] sawMissingSpring = {false};
            Consumer<String> watched = line -> {
                if (line.contains("package org.springframework") && line.contains("does not exist")) {
                    sawMissingSpring[0] = true;
                }
                onLine.accept(line);
            };
            int exit = runProcess(request, command, workDir, watched);

            boolean success = exit == 0;
            String summary = success
                    ? "BUILD SUCCESS — the project compiled and packaged cleanly."
                    : "BUILD FAILED (exit " + exit + ") — see the log above for the first error.";
            onLine.accept("");
            if (!success && sawMissingSpring[0] && !request.isPython()) {
                onLine.accept("[sourceforge] HINT: 'package org.springframework... does not exist' almost always");
                onLine.accept("[sourceforge]       means Maven could not download dependencies. Configure your");
                onLine.accept("[sourceforge]       Artifactory settings.xml: set SOURCEFORGE_MAVEN_SETTINGS (or");
                onLine.accept("[sourceforge]       sourceforge.build.maven-settings) to backend/runtime/settings.xml.");
                if (mavenSettings.isBlank()) {
                    onLine.accept("[sourceforge]       Currently NO settings.xml is configured — that is the likely cause.");
                }
            }
            onLine.accept("[sourceforge] " + summary);
            log.info("real build  artifact={}  lang={}  exit={}  success={}",
                    request.artifactId(), request.language(), exit, success);
            return new BuildOutcome(success, exit, summary);

        } catch (Exception ex) {
            log.warn("build runner failed: {}", ex.getMessage());
            onLine.accept("[sourceforge] build could not start: " + ex.getMessage());
            return new BuildOutcome(false, -1, "Build could not start: " + ex.getMessage());
        } finally {
            if (workDir != null) deleteRecursive(workDir);
        }
    }

    private List<String> mavenCommand(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        String mvn = resolveMaven(request, onLine);
        if (mvn == null) {
            onLine.accept("[sourceforge] ERROR: Maven was not found.");
            onLine.accept("[sourceforge] Looked in: backend/runtime/maven (sourceforge.build.maven-dir), "
                    + "sourceforge.build.maven-home, the MAVEN_HOME / M2_HOME environment variables, and PATH.");
            onLine.accept("[sourceforge] Fix: place a Maven distribution under backend/runtime/maven/ "
                    + "(e.g. apache-maven-3.9.9), or set MAVEN_HOME (e.g. " + exampleMavenHome()
                    + "), then restart this server.");
            return null;
        }
        List<String> cmd = new ArrayList<>(List.of(mvn, "-B", "clean", "install"));
        if (skipTests) cmd.add("-DskipTests");
        if (!mavenSettings.isBlank()) {
            // Company settings.xml: Artifactory mirror + server credentials.
            Path settingsPath = Path.of(mavenSettings);
            if (Files.isReadable(settingsPath)) {
                cmd.add("-s");
                cmd.add(mavenSettings);
                onLine.accept("[sourceforge] using Maven settings: " + mavenSettings);
                // Echo a quick summary so any odd token in the file is visible here.
                describeSettings(settingsPath, onLine);
            } else {
                onLine.accept("[sourceforge] WARNING: sourceforge.build.maven-settings is set to '"
                        + mavenSettings + "' but that file is not readable. Maven defaults will be used.");
            }
        } else {
            onLine.accept("[sourceforge] no settings.xml configured (sourceforge.build.maven-settings);"
                    + " using Maven defaults — set this to reach your Artifactory.");
        }
        return cmd;
    }

    /**
     * Reads the configured settings.xml and prints a one-line-per-entry summary
     * of its mirror URLs, server ids, and active profile ids. This makes any
     * unusual token (e.g. an Artifactory project key like "p-1334") visible in
     * the live build log without having to inspect the file separately.
     * Best-effort: regex-based so it works without a Maven dependency on disk.
     */
    private void describeSettings(Path file, Consumer<String> onLine) {
        try {
            String xml = Files.readString(file);
            // Strip XML comments to keep regex hits meaningful.
            String stripped = xml.replaceAll("(?s)<!--.*?-->", "");
            var mirrors = java.util.regex.Pattern.compile("(?s)<mirror>(.*?)</mirror>").matcher(stripped);
            int n = 0;
            while (mirrors.find()) {
                String body = mirrors.group(1);
                String id = firstGroup(body, "<id>(.*?)</id>");
                String url = firstGroup(body, "<url>(.*?)</url>");
                String mirrorOf = firstGroup(body, "<mirrorOf>(.*?)</mirrorOf>");
                onLine.accept("[sourceforge]   mirror id=" + id + "  mirrorOf=" + mirrorOf + "  url=" + url);
                n++;
            }
            var servers = java.util.regex.Pattern.compile("(?s)<server>(.*?)</server>").matcher(stripped);
            while (servers.find()) {
                String id = firstGroup(servers.group(1), "<id>(.*?)</id>");
                onLine.accept("[sourceforge]   server id=" + id);
            }
            String active = firstGroup(stripped, "(?s)<activeProfile>(.*?)</activeProfile>");
            if (!"".equals(active)) {
                onLine.accept("[sourceforge]   activeProfile=" + active);
            }
            if (n == 0) {
                onLine.accept("[sourceforge]   (no <mirror> entries found — Maven will use the central repo)");
            }
        } catch (Exception e) {
            onLine.accept("[sourceforge] (could not parse settings.xml summary: " + e.getMessage() + ")");
        }
    }

    private String firstGroup(String haystack, String regex) {
        var m = java.util.regex.Pattern.compile(regex).matcher(haystack);
        return m.find() ? m.group(1).trim() : "";
    }

    /**
     * Resolve the mvn executable, in priority order:
     *   1. version-compatible Maven under backend/runtime/maven (Boot + Java aware)
     *   2. sourceforge.build.maven-home property
     *   3. MAVEN_HOME / M2_HOME environment variables (the user's local install)
     *   4. mvn / mvn.cmd on PATH
     * Works on macOS, Linux and Windows (mvn.cmd on Windows).
     */
    private String resolveMaven(ProjectRequest request, Consumer<String> onLine) {
        String exe = isWindows() ? "mvn.cmd" : "mvn";
        // 1. version-compatible Maven from runtime/maven
        String selected = selectMavenHome(request.bootVersion(), request.javaVersion(), onLine);
        String fromSelected = mavenFromHome(selected, exe);
        if (fromSelected != null) { onLine.accept("[sourceforge] Maven (runtime/maven): " + fromSelected); return fromSelected; }
        // 2. configured property
        String fromHome = mavenFromHome(mavenHome, exe);
        if (fromHome != null) { onLine.accept("[sourceforge] Maven (configured): " + fromHome); return fromHome; }
        // 3. environment variables
        for (String var : new String[]{"MAVEN_HOME", "M2_HOME"}) {
            String env = System.getenv(var);
            String fromEnv = mavenFromHome(env, exe);
            if (fromEnv != null) { onLine.accept("[sourceforge] Maven (from " + var + "): " + fromEnv); return fromEnv; }
        }
        // 4. PATH
        String onPath = resolve(isWindows() ? new String[]{"mvn.cmd", "mvn"} : new String[]{"mvn"});
        if (onPath != null) { onLine.accept("[sourceforge] Maven (from PATH): " + onPath); return onPath; }
        return null;
    }

    private String mavenFromHome(String home, String exe) {
        if (home == null || home.isBlank()) return null;
        Path candidate = Path.of(home.trim(), "bin", exe);
        return Files.isExecutable(candidate) ? candidate.toString() : null;
    }

    private String exampleMavenHome() {
        if (isWindows()) return "C:\\\\apache-maven-3.9.9";
        return System.getProperty("os.name", "").toLowerCase().contains("mac")
                ? "/opt/homebrew/Cellar/maven/3.9.9/libexec or /usr/local/Cellar/..."
                : "/opt/apache-maven-3.9.9";
    }

    private List<String> pythonCommand(ProjectRequest request, Path workDir, Consumer<String> onLine) {
        String python = resolve(isWindows() ? new String[]{"python", "python3"} : new String[]{"python3", "python"});
        if (python == null) {
            onLine.accept("[sourceforge] ERROR: Python was not found on PATH.");
            onLine.accept("[sourceforge] Fix: install Python 3 and ensure 'python3' (or 'python' on Windows) is on PATH, then restart this server.");
            return null;
        }
        onLine.accept("[sourceforge] Python (from PATH): " + python);
        // Poetry project
        if ("poetry".equals(request.type())) {
            String poetry = resolve("poetry");
            if (poetry != null) {
                onLine.accept("[sourceforge] using Poetry: " + poetry);
                return List.of(poetry, "install", "--no-interaction");
            }
            onLine.accept("[sourceforge] poetry not installed; falling back to a syntax check (compileall).");
        } else {
            // pip project: install then byte-compile the package.
            String pip = resolve(isWindows() ? new String[]{"pip", "pip3"} : new String[]{"pip3", "pip"});
            if (pip != null) {
                onLine.accept("[sourceforge] using pip: " + pip);
                if (isWindows()) {
                    // cmd.exe chains with &&; run install then compile
                    return List.of("cmd.exe", "/c", pip + " install . && " + python + " -m compileall -q src");
                }
                return List.of("sh", "-c", pip + " install . && " + python + " -m compileall -q src");
            }
            onLine.accept("[sourceforge] pip not installed; falling back to a syntax check (compileall).");
        }
        // Fallback: byte-compile all sources for a syntax check
        return List.of(python, "-m", "compileall", "-q", ".");
    }

    private int runProcess(ProjectRequest request, List<String> command, Path workDir, Consumer<String> onLine)
            throws Exception {
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.directory(workDir.toFile());
        pb.redirectErrorStream(true);
        var env = pb.environment();
        // Keep Maven from emitting colour codes that would clutter the browser log.
        env.put("MAVEN_OPTS", "-Djansi.force=false");
        // Choose the JDK, in order:
        //   1. runtime/jdk/jdk-<version> matching the selected Java version
        //   2. sourceforge.build.java-home (explicit override)
        //   3. user's JAVA_HOME env var
        //   4. java on PATH
        // (The company JDK's cacerts already trusts Artifactory, so no cert import.)
        String selectedJdk = request.isJava() ? selectJdkHome(request.javaVersion(), onLine) : null;
        String jdkSource;
        String effectiveJavaHome;
        if (selectedJdk != null) {
            effectiveJavaHome = selectedJdk;
            jdkSource = "runtime/jdk for Java " + request.javaVersion();
        } else if (!javaHome.isBlank()) {
            effectiveJavaHome = javaHome;
            jdkSource = "configured java-home";
        } else if (System.getenv("JAVA_HOME") != null && !System.getenv("JAVA_HOME").isBlank()) {
            effectiveJavaHome = System.getenv("JAVA_HOME").trim();
            jdkSource = "JAVA_HOME env";
        } else {
            effectiveJavaHome = "";
            jdkSource = "";
        }
        if (request.isJava() && selectedJdk == null && jdkDir != null && !jdkDir.isBlank()) {
            onLine.accept("[sourceforge] note: no jdk-" + request.javaVersion()
                    + " found under " + jdkDir + "; falling back to java-home/JAVA_HOME/PATH.");
        }
        if (!effectiveJavaHome.isBlank()) {
            Path javaBin = Path.of(effectiveJavaHome, "bin", isWindows() ? "java.exe" : "java");
            if (Files.isExecutable(javaBin)) {
                env.put("JAVA_HOME", effectiveJavaHome);
                String binDir = Path.of(effectiveJavaHome, "bin").toString();
                String sep = isWindows() ? ";" : ":";
                env.put("PATH", binDir + sep + env.getOrDefault("PATH", ""));
                onLine.accept("[sourceforge] JDK (" + jdkSource + "): " + effectiveJavaHome);
            } else {
                onLine.accept("[sourceforge] WARNING: JDK home '" + effectiveJavaHome
                        + "' has no java executable; falling back to the java on PATH.");
            }
        } else if (request.isJava()) {
            onLine.accept("[sourceforge] no JDK found (runtime/jdk, java-home or JAVA_HOME);"
                    + " using the java on PATH if present.");
        }
        Process proc = pb.start();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                onLine.accept(stripAnsi(line));
            }
        }
        boolean finished = proc.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        if (!finished) {
            proc.destroyForcibly();
            onLine.accept("[sourceforge] build timed out after " + timeoutSeconds + "s; aborted.");
            return 124;
        }
        return proc.exitValue();
    }

    private static String stripAnsi(String s) {
        return s.replaceAll("\u001B\\[[;\\d]*m", "");
    }

    private String resolve(String... candidates) {
        for (String c : candidates) {
            try {
                Process p = new ProcessBuilder(isWindows() ? "where" : "which", c)
                        .redirectErrorStream(true).start();
                if (p.waitFor(5, TimeUnit.SECONDS) && p.exitValue() == 0) return c;
            } catch (Exception ignore) { /* next */ }
        }
        return null;
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    private void deleteRecursive(Path root) {
        try {
            Files.walk(root).sorted(Comparator.reverseOrder())
                    .forEach(p -> { try { Files.deleteIfExists(p); } catch (Exception ignore) {} });
        } catch (Exception ignore) { /* best effort */ }
    }
}
