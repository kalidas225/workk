# Release Guardian

A release-readiness checker, written entirely in **Node.js** (no Java, no
database). For every Jira subject tagged for a release, it verifies:

1. The **Octane test cases** listed on the Jira issue actually exist in Octane.
2. The required **on-prem SharePoint folders** each contain the right file:
   `PR`, `UnitTest`, `Estimation`, `PRExcel`, `OctaneReview`, `OctaneExecution`.

If **even one** item is missing, it emails the responsible developer a clear,
branded summary — optionally rephrased by your **company AI** into friendlier
wording. It runs as a **scheduled job** (Kubernetes CronJob on IBM Cloud) and is
**parallel-release safe**: each release has a date window, and once a release's
end date passes it's ignored automatically.

---

## Contents

- [What you do and don't need](#what-you-do-and-dont-need)
- [The two questions you asked, answered](#the-two-questions-you-asked-answered)
- [Step-by-step installation](#step-by-step-installation)
- [Defining releases (multiple / parallel)](#defining-releases-multiple--parallel)
- [The SharePoint folders (multiple folders)](#the-sharepoint-folders-multiple-folders)
- [Octane test cases](#octane-test-cases)
- [Email: From, To, and the EMA server](#email-from-to-and-the-ema-server)
- [Company AI (optional)](#company-ai-optional)
- [Running it](#running-it)
- [Deploying to IBM Cloud](#deploying-to-ibm-cloud)
- [Troubleshooting](#troubleshooting)
- [Project layout](#project-layout)

---

## What you do and don't need

| | |
|---|---|
| **Java** | ❌ Not needed. 100% Node.js. |
| **Database (Oracle)** | ❌ Not needed. Releases live in `config/releases.json`; the "don't email twice a day" log is a small JSON file. |
| **Node.js 18+** | ✅ Required (Node 20 recommended; Docker image uses Node 20). |
| **Jira token** | ✅ To read the subjects tagged for a release. |
| **Octane API keys** | ✅ To verify the test-case IDs exist. |
| **On-prem SharePoint account** | ✅ Domain account (NTLM) that can read the library. |
| **EMA SMTP relay** | ✅ To send the emails. |
| **Company AI endpoint** | ⬜ Optional. Improves email wording; off by default. |
| **IBM Cloud / Kubernetes** | ✅ To run it on a schedule. |

---

## The two questions you asked, answered

**"I can provide a Jira ID to take the subjects tagged for a release."**
Yes — each release in `config/releases.json` says how to find its subjects, and
you can choose any of three ways:

- `fixVersion` — subjects are epics with that fix version (e.g. `25.07`).
- `parentEpicKey` — subjects are the issues under a parent epic (e.g. `REL-2000`).
- `jql` — you provide a raw JQL string for full control.

**"Can we include the company AI configuration, doing both email wording and a summary?"**
Yes — see [Company AI](#company-ai-optional). It does both: it rephrases each
developer email AND writes an overall readiness summary for the managers. It's
optional and safe — if the AI is unreachable, emails still go out with built-in
wording.

---

## Step-by-step installation

Follow these in order. Each step is safe to repeat.

**Step 1 — Install Node.js 18+**
Check what you have:
```bash
node --version    # need v18 or higher
npm --version
```
If missing, install Node 20 LTS from nodejs.org (or your package manager).

**Step 2 — Get the code and install dependencies**
```bash
cd release-guardian
npm install
```
This downloads the libraries into `node_modules/`. No global installs, no Oracle
client, nothing else to set up.

**Step 3 — Create your config file**
```bash
cp .env.example .env
```
Open `.env` in any editor and fill in the values. Every field is documented in
the file itself and in the sections below. Start with Jira, Octane, SharePoint,
and SMTP; leave AI off (`AI_ENABLED=false`) for now.

**Step 4 — Define your releases**
Edit `config/releases.json` (see
[Defining releases](#defining-releases-multiple--parallel)). Add one entry per
active release, each with a `startDate`, `endDate`, and how to find its subjects.

**Step 5 — (Optional) tune what gets checked**
Edit `config/artifacts.json` only if your SharePoint folder names or file-naming
differ from the defaults (see
[The SharePoint folders](#the-sharepoint-folders-multiple-folders)).

**Step 6 — Verify connectivity to every system**
```bash
npm run test:config
```
This checks that all required values are present, then connects to SMTP, Octane,
SharePoint, and (if enabled) AI, and confirms your releases file loads. Fix
anything that reports `FAILED` before moving on. **This step catches almost all
setup mistakes.**

**Step 7 — Do a dry run (no emails sent)**
```bash
npm run check:dry
```
It does the full check and logs exactly who *would* be emailed and what's
missing — but sends nothing. Review the output.

**Step 8 — Run for real**
```bash
npm run check
```
Now it sends emails. When you're happy, schedule it on IBM Cloud (see
[Deploying](#deploying-to-ibm-cloud)).

---

## Defining releases (multiple / parallel)

All releases live in **`config/releases.json`**. This is what replaces the
database. Example:

```json
{
  "releases": [
    {
      "name": "25.07",
      "startDate": "2026-05-01",
      "endDate": "2026-06-15",
      "subjectSource": { "type": "fixVersion", "value": "25.07" },
      "sharepointRelease": "25.07"
    },
    {
      "name": "25.08",
      "startDate": "2026-05-10",
      "endDate": "2026-07-01",
      "subjectSource": { "type": "parentEpicKey", "value": "REL-2000" },
      "sharepointRelease": "25.08"
    }
  ]
}
```

| Field | Meaning |
|---|---|
| `name` | Your label for the release (used in emails and the dedupe log). |
| `startDate` / `endDate` | `YYYY-MM-DD`. The release is checked only while today is inside this window. |
| `subjectSource.type` | `fixVersion`, `parentEpicKey`, or `jql`. |
| `subjectSource.value` | The fix version string, the parent epic key, or the raw JQL. |
| `sharepointRelease` | The folder name used in SharePoint paths (often same as `name`, but can differ). |

**How parallel releases stay separate:** every run, the tool loads this file and
keeps only the releases whose window includes **today**. Two releases running at
once are each checked independently with their own subjects and their own
SharePoint folder. When a release's `endDate` passes, the next run simply stops
including it — no edits, no cleanup. To extend a release, push its `endDate` out;
to retire one early, set `endDate` to today.

---

## The SharePoint folders (multiple folders)

What to check is defined in **`config/artifacts.json`**. Each entry is one
required item. The six SharePoint folders plus the Octane check are pre-defined;
you edit folder names / match rules to fit your library, or add more.

```json
{
  "key": "ESTIMATION_SHEET",
  "label": "Estimation sheet",
  "enabled": true,
  "source": "sharepoint",
  "folder": "/Estimation",
  "match": { "type": "nameContains", "all": ["estimat"], "extensions": [".xlsx", ".xls", ".csv"] },
  "minFiles": 1
}
```

**How the full folder path is built**, for each epic:

```
<SHAREPOINT_BASE_URL site>/<SHAREPOINT_LIBRARY_NAME>/<SHAREPOINT_ROOT_PATH>/<folder>
```
with `{RELEASE}` replaced by the release's `sharepointRelease` and `{EPIC}` by
the Jira key. With the defaults, the Estimation folder for epic `REL-1042` in
release `25.07` is:
```
/sites/Releases/Documents/Releases/25.07/REL-1042/Estimation
```

**Match rule types** (how a file "counts"):

- `extension` — any file with one of the listed `extensions`.
- `nameContains` — filename contains **all** strings in `all` (case-insensitive)
  and matches `extensions` if given.
- `regex` — filename matches `pattern` (optional `flags`, default `i`).

**Add a folder to check:** copy any `sharepoint` block, give it a unique `key`,
set its `folder` and `match`. **Stop checking one:** set `"enabled": false`.

---

## Octane test cases

The link is owned by **Jira**: each subject has a custom field (set
`JIRA_OCTANE_LINK_FIELD` to its id, e.g. `customfield_10075`) listing the Octane
test-case IDs, separated by commas or spaces, e.g. `100123, 100124 100125`.

Each run the tool reads those IDs and asks Octane which ones really exist, then
applies the rules in the `OCTANE_TESTS_LINKED` entry of `config/artifacts.json`:

- `minTestCases` — how many valid IDs are required (default 1).
- `requireAll` — `true` (default) means **every** listed ID must exist, and the
  email names any that don't; `false` passes as long as `minTestCases` exist.

If a subject lists no IDs at all, the check fails with a clear message.

---

## Email: From, To, and the EMA server

**Connecting to your EMA mail server** — these go in `.env`:

```bash
SMTP_HOST=ema-relay.yourcompany.com   # your EMA relay hostname
SMTP_PORT=587                         # 587 = STARTTLS (typical), 465 = implicit TLS
SMTP_SECURE=false                     # true ONLY for port 465
SMTP_USER=                            # leave blank if the relay allows anonymous internal relay
SMTP_PASSWORD=                        # only if the relay requires login
SMTP_TLS_REJECT_UNAUTHORIZED=true     # set false ONLY for a self-signed relay cert
```
Most internal EMA relays accept anonymous relay from inside the network — in that
case leave `SMTP_USER`/`SMTP_PASSWORD` blank. If yours needs credentials, fill
them in. Confirm it works with `npm run test:config` (it reports `SMTP: OK`).

**The From address** (who the mail appears to come from):
```bash
MAIL_FROM_NAME=Release Guardian
MAIL_FROM_ADDRESS=release-guardian@yourcompany.com
```

**The To address is resolved automatically per subject**, in this order:
1. The Jira field named by `JIRA_DEVELOPER_FIELD` (if it holds an email).
2. The subject's **assignee** email.
3. The subject's **reporter** email.
4. If none resolve → **`MAIL_FALLBACK_TO`** (set this to a team DL so an alert is
   never lost).

**CC / BCC / Reply-To** (optional, comma-separated for multiple):
```bash
MAIL_REPLY_TO=release-team@yourcompany.com
MAIL_CC=release-managers@yourcompany.com
MAIL_BCC=
```

**Subject line** (tokens are substituted):
```bash
MAIL_SUBJECT_TEMPLATE=[Release {RELEASE}] Action needed on {EPIC} — {MISSING_COUNT} item(s) missing
```
`{RELEASE}` → release name, `{EPIC}` → Jira key, `{MISSING_COUNT}` → number missing.

**Branding** (header + footer):
```bash
COMPANY_NAME=Acme Corp
COMPANY_LOGO_URL=https://acme.com/logo.png    # optional; replaces the name text
RELEASE_PORTAL_URL=https://wiki.acme.com/releases   # optional; adds a button
```
The HTML lives in `src/email/template.js`; colors are variables at the top of
`buildEmail`. A preview is shipped as `sample-email.png` (built-in wording) and
`sample-email-ai.png` (AI-rephrased wording).

---

## Company AI (optional)

Off by default. When on, the AI does **two** things, both safe — if the AI
errors or is unreachable, the tool logs a warning and falls back to built-in
text, and emails still send:

1. **Rewrites the per-developer email intro** into clearer, friendlier wording.
2. **Writes an overall release-readiness summary** across all releases and sends
   it to your release managers (whoever is in `MAIL_SUMMARY_TO`). The summary
   email has the AI prose at the top and a per-release table (subjects, how many
   have gaps, emails sent). See `sample-summary.png`.

```bash
AI_ENABLED=true
AI_BASE_URL=https://your-internal-ai-gateway.corp/v1   # OpenAI-compatible, no trailing slash
AI_API_KEY=your_key
AI_API_KEY_HEADER=        # blank = use "Authorization: Bearer". For Azure-style, set e.g. api-key
AI_MODEL=gpt-4o-mini      # the model/deployment name your gateway expects
AI_TIMEOUT_MS=15000

# Who gets the overall summary email (comma separated). BLANK = no summary email.
MAIL_SUMMARY_TO=release-managers@yourcompany.com
```
This targets the standard **OpenAI-compatible Chat Completions** API
(`POST <base>/chat/completions`), which most internal AI gateways and Azure
OpenAI expose. Verify with `npm run test:config` (reports `AI: checked`).

> The summary email is sent **even if AI is off**, as long as `MAIL_SUMMARY_TO`
> is set — it just uses a plain factual summary instead of AI prose. To turn the
> summary off entirely, leave `MAIL_SUMMARY_TO` blank.

---

## Running it

| Command | What it does |
|---|---|
| `npm run check` | Check all **active** releases and email gaps |
| `npm run check:dry` | Same, but **send no email** (logs intentions) |
| `npm run check:release -- "25.07"` | Check **one** named release (ignores its date window) |
| `npm run test:config` | Validate config + connectivity to every system |

The tool runs once and exits — there's no long-running server.

---

## Deploying to IBM Cloud

It runs as a **Kubernetes CronJob**: a short-lived pod that runs one check and
exits. Kubernetes owns the schedule.

**1. Build & push the image** to IBM Cloud Container Registry:
```bash
ibmcloud cr namespace-add myns        # once
ibmcloud cr build -t us.icr.io/myns/release-guardian:1.0 .
```

**2. Create the secret** from your `.env` (keeps secrets out of the manifest):
```bash
kubectl create secret generic release-guardian-env --from-env-file=.env
```

**3. Edit `k8s-cronjob.yaml`** — replace `IMAGE_PLACEHOLDER` and set the
`schedule`. **The cluster runs cron in UTC**, so convert from local time
(07:00 IST = `30 1 * * 1-5`). Then apply:
```bash
kubectl apply -f k8s-cronjob.yaml
```

**4. Test immediately** without waiting for the schedule:
```bash
kubectl create job --from=cronjob/release-guardian rg-manual-1
kubectl logs job/rg-manual-1 -f
```

**Optional — keep dedupe across restarts:** the "don't email twice a day" log is
written to `NOTIF_LOG_PATH`. If you want it to survive pod restarts, mount a
small PersistentVolume at that path and point `NOTIF_LOG_PATH` at it. Without a
volume, the only downside of a restart is possibly one duplicate email — harmless.

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `test:config` → **SMTP: FAILED** | Wrong `SMTP_HOST`/`PORT`/`SECURE`; relay needs auth; firewall |
| `test:config` → **SharePoint: FAILED** | Wrong `SHAREPOINT_BASE_URL`; NTLM creds/domain wrong; account lacks read; self-signed cert (set `SHAREPOINT_TLS_REJECT_UNAUTHORIZED=false`) |
| `test:config` → **Octane: FAILED** | Wrong client id/secret or shared-space/workspace ids |
| `test:config` → **AI: FAILED** | Wrong `AI_BASE_URL`/key/header; gateway down (emails still send) |
| **Releases file: FAILED** | `config/releases.json` has a JSON syntax error |
| No subjects found | `subjectSource` doesn't match your Jira (try the `jql` type to test) |
| Folder always "missing" | The `folder` in `artifacts.json` doesn't match SharePoint exactly (case/space sensitive) |
| File present but not detected | Adjust the `match` rule (extensions / `nameContains`) |
| Developer not emailed | Email couldn't be resolved → check it lands in `MAIL_FALLBACK_TO` |
| Same person emailed twice | Across a pod restart without a mounted volume; mount one to prevent it |

Set `LOG_LEVEL=debug` and `LOG_PRETTY=true` while diagnosing.

---

## Project layout

```
release-guardian/
├── .env.example              # copy to .env; every placeholder, documented
├── config/
│   ├── releases.json         # YOUR releases (replaces the database)
│   └── artifacts.json        # WHAT to check (folders + match rules)
├── src/
│   ├── config.js             # loads & validates config (the only env reader)
│   ├── logger.js
│   ├── cli.js                # run / validate-config commands (entry point)
│   ├── connectors/
│   │   ├── jira.js           # find subjects (fixVersion/parentEpic/jql) + dev email
│   │   ├── octane.js         # verify the Jira-listed Octane IDs exist
│   │   └── sharepoint.js     # on-prem REST (NTLM): list folder files
│   ├── core/
│   │   └── checker.js        # the orchestrator
│   ├── store/
│   │   └── fileStore.js      # releases.json + JSON dedupe log (no DB)
│   ├── ai/
│   │   └── assist.js         # optional OpenAI-compatible email rewriter
│   └── email/
│       ├── template.js       # the HTML/text email builder
│       └── mailer.js         # nodemailer SMTP sender
├── Dockerfile
├── k8s-cronjob.yaml          # IBM Cloud CronJob manifest
├── sample-email.png          # preview (built-in wording)
├── sample-email-ai.png       # preview (AI-rephrased developer email)
├── sample-summary.png        # preview (AI release-readiness summary)
└── README.md
```

---

## Security notes

- `.env` is gitignored. On IBM Cloud, inject it as a **Kubernetes Secret**, never
  bake it into the image.
- The container runs as a **non-root** user.
- Use a **dedicated service account** for Jira/Octane/SharePoint/AI with
  least-privilege (read-only is enough for the source systems).
