'use strict';

/**
 * Core readiness orchestrator.
 *
 * For each ACTIVE release:
 *   1. Pull its subjects (epics) from Jira (via fixVersion / parent epic / jql).
 *   2. For each epic, run every enabled artifact check:
 *        - sharepoint artifacts -> folder/file existence
 *        - octane artifact       -> the Jira-listed Octane IDs exist
 *   3. If anything is missing, email the responsible developer (once/day),
 *      then record it in the file store.
 *
 * Parallel releases are handled by the file store: only releases whose date
 * window includes today are returned, so a finished release is silently
 * dropped on the next run.
 */

const { config, loadArtifacts } = require('../config');
const logger = require('../logger');
const jira = require('../connectors/jira');
const octane = require('../connectors/octane');
const sharepoint = require('../connectors/sharepoint');
const store = require('../store/fileStore');
const { sendMissingArtifactsEmail } = require('../email/mailer');

function expandPath(template, releaseName, epicKey) {
  return template.replace(/\{RELEASE\}/g, releaseName).replace(/\{EPIC\}/g, epicKey);
}

function jiraEpicUrl(epicKey) {
  return `${config.jira.baseUrl}/browse/${epicKey}`;
}

/**
 * Run all artifact checks for a single epic.
 * Returns an array of { key, label, present, detail }.
 */
async function checkEpic(release, epic) {
  const artifacts = loadArtifacts();
  const checks = [];

  for (const art of artifacts) {
    try {
      if (art.source === 'octane') {
        const ids = epic.octaneIdsFromJira || [];
        if (ids.length === 0) {
          // Jira didn't list any Octane IDs on this epic at all.
          checks.push({
            key: art.key,
            label: art.label,
            present: false,
            detail: `No Octane IDs listed on Jira field "${config.jira.octaneLinkField}"`,
          });
        } else {
          const res = await octane.verifyTestCaseIds(ids);
          // Pass if at least minTestCases IDs exist AND (by default) none are
          // bogus. Set "requireAll": false in artifacts.json to allow partial.
          const enoughFound = res.found >= (art.minTestCases || 1);
          const allValid = art.requireAll === false ? true : res.missingIds.length === 0;
          const present = enoughFound && allValid;
          let detail;
          if (present) {
            detail = `${res.found}/${res.requested} Octane test case(s) verified`;
          } else if (res.found === 0) {
            detail = `None of the ${res.requested} listed Octane ID(s) exist in Octane`;
          } else {
            detail = `Only ${res.found}/${res.requested} exist; missing IDs: ${res.missingIds.join(', ')}`;
          }
          checks.push({ key: art.key, label: art.label, present, detail });
        }
      } else if (art.source === 'sharepoint') {
        const spRelease = release.sharepointRelease || release.name;
        const root = expandPath(config.sharepoint.rootPath, spRelease, epic.key);
        const folderPath = `${root}${art.folder}`;
        const res = await sharepoint.checkArtifactFolder(folderPath, art.match, art.minFiles);
        checks.push({
          key: art.key,
          label: art.label,
          present: res.present,
          detail: res.present
            ? `Found: ${res.matchedFiles.slice(0, 3).join(', ')}${res.matchedFiles.length > 3 ? '…' : ''}`
            : `No matching file in ${folderPath}`,
        });
      } else {
        logger.warn({ art }, 'Unknown artifact source, skipping');
      }
    } catch (err) {
      // A connector failure should not silently pass the check — mark missing.
      logger.error({ err: err.message, epic: epic.key, artifact: art.key }, 'Artifact check error');
      checks.push({
        key: art.key,
        label: art.label,
        present: false,
        detail: `Check failed: ${err.message}`,
      });
    }
  }
  return checks;
}

/**
 * Process one release end-to-end.
 * @returns summary object for reporting.
 */
async function processRelease(release, { dryRun }) {
  logger.info({ release: release.name, endDate: release.endDate }, 'Processing release');
  const epics = await jira.getReleaseEpics(release);

  const summary = { release: release.name, epics: [], emailsSent: 0, epicsWithGaps: 0 };

  for (const epic of epics) {
    const checks = await checkEpic(release, epic);
    const missing = checks.filter((c) => !c.present);
    const epicResult = {
      key: epic.key,
      developerEmail: epic.developerEmail,
      missing: missing.map((m) => m.key),
      total: checks.length,
    };

    if (missing.length === 0) {
      logger.info({ epic: epic.key }, 'All artifacts present');
      summary.epics.push(epicResult);
      continue;
    }

    summary.epicsWithGaps += 1;
    const to = epic.developerEmail || config.mail.fallbackTo;

    // Dedupe: don't re-email the same dev about the same epic the same day.
    const dup = store.alreadyNotifiedToday(release.name, epic.key, to);
    if (dup) {
      logger.info({ epic: epic.key, to }, 'Already notified today, skipping email');
      epicResult.skippedDuplicate = true;
      summary.epics.push(epicResult);
      continue;
    }

    // Optionally let company AI write a friendlier intro paragraph.
    let aiIntro = null;
    try {
      const ai = require('../ai/assist');
      aiIntro = await ai.rewriteIntro({
        developerName: epic.developerName,
        releaseName: release.name,
        epicKey: epic.key,
        epicSummary: epic.summary,
        missing: missing.map((m) => ({ label: m.label, detail: m.detail })),
      });
    } catch (e) {
      logger.warn({ err: e.message }, 'AI assist unavailable; using default intro');
    }

    const sendRes = await sendMissingArtifactsEmail(
      {
        developerName: epic.developerName,
        developerEmail: epic.developerEmail,
        releaseName: release.name,
        epicKey: epic.key,
        epicSummary: epic.summary,
        epicUrl: jiraEpicUrl(epic.key),
        checks,
        aiIntro,
      },
      { dryRun }
    );

    if (sendRes.sent) {
      summary.emailsSent += 1;
      store.recordNotification(release.name, epic.key, to, epicResult.missing);
    }
    epicResult.emailedTo = sendRes.to;
    summary.epics.push(epicResult);
  }

  logger.info(
    { release: release.name, epics: epics.length, gaps: summary.epicsWithGaps, emails: summary.emailsSent },
    'Release processed'
  );
  return summary;
}

/**
 * Main entry: check all active releases (or a single named release).
 * @param {object} opts
 * @param {boolean} opts.dryRun
 * @param {string}  [opts.releaseName] — if set, check only this release.
 */
async function runCheck(opts = {}) {
  const dryRun = opts.dryRun != null ? opts.dryRun : config.dryRun;

  let releases;
  if (opts.releaseName) {
    const r = store.getReleaseByName(opts.releaseName);
    if (!r) throw new Error(`Release "${opts.releaseName}" not found in config/releases.json`);
    releases = [r];
  } else {
    releases = store.getActiveReleases();
  }

  if (releases.length === 0) {
    logger.info('No active releases to process');
    return { releases: [], dryRun };
  }

  logger.info({ count: releases.length, dryRun }, 'Starting readiness check');
  const results = [];
  for (const release of releases) {
    // Process releases sequentially to keep API rate limits sane.
    // eslint-disable-next-line no-await-in-loop
    const s = await processRelease(release, { dryRun });
    results.push(s);
  }

  const report = { releases: results, dryRun };

  // Overall AI summary -> managers (only if MAIL_SUMMARY_TO is set).
  if (config.mail.summaryTo && config.mail.summaryTo.length) {
    let aiSummary = null;
    try {
      const ai = require('../ai/assist');
      aiSummary = await ai.summarizeReleases(report);
    } catch (e) {
      logger.warn({ err: e.message }, 'AI summary unavailable; using default summary text');
    }
    try {
      const { sendSummaryEmail } = require('../email/mailer');
      await sendSummaryEmail({ aiSummary, report }, { dryRun });
    } catch (e) {
      logger.error({ err: e.message }, 'Failed to send summary email');
    }
  }

  return report;
}

module.exports = { runCheck, processRelease, checkEpic };
