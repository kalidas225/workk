'use strict';

/**
 * Optional AI assist (company AI). Two capabilities, both optional and safe:
 *
 *   1. rewriteIntro()      — rephrase the per-developer "what's missing" email
 *                            opening into friendlier wording.
 *   2. summarizeReleases() — write an overall release-readiness summary across
 *                            all releases/epics, for the release managers.
 *
 * If AI_ENABLED=false, or the call fails for ANY reason, both return null and
 * the tool falls back to deterministic built-in text. Emails always send.
 *
 * Targets the OpenAI-compatible Chat Completions API that most internal company
 * AI gateways and Azure OpenAI expose.
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../logger');

/**
 * Shared low-level call. Returns trimmed content string, or null on any failure.
 */
async function chat(systemPrompt, userPrompt, maxTokens) {
  if (!config.ai.enabled) return null;
  if (!config.ai.baseUrl) {
    logger.warn('AI_ENABLED but AI_BASE_URL is empty; skipping AI');
    return null;
  }

  const url = `${config.ai.baseUrl}/chat/completions`;
  const headers = { 'Content-Type': 'application/json' };
  if (config.ai.apiKey) headers.Authorization = `Bearer ${config.ai.apiKey}`;
  // Azure-style gateways sometimes want the key in a custom header instead.
  if (config.ai.apiKeyHeader && config.ai.apiKey) {
    delete headers.Authorization;
    headers[config.ai.apiKeyHeader] = config.ai.apiKey;
  }

  const body = {
    model: config.ai.model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    temperature: 0.4,
    max_tokens: maxTokens || 200,
  };

  try {
    const resp = await axios.post(url, body, { headers, timeout: config.ai.timeoutMs });
    const text =
      resp.data &&
      resp.data.choices &&
      resp.data.choices[0] &&
      resp.data.choices[0].message &&
      resp.data.choices[0].message.content;
    return text && text.trim() ? text.trim() : null;
  } catch (err) {
    logger.warn({ err: err.message }, 'AI call failed; falling back to default text');
    return null;
  }
}

/**
 * Rephrase the per-developer email intro. Returns a paragraph or null.
 */
async function rewriteIntro(ctx) {
  if (!config.ai.enabled) return null;
  const missingList = ctx.missing.map((m) => `- ${m.label}: ${m.detail}`).join('\n');
  const system = 'You are a concise assistant that writes clear internal engineering emails.';
  const user =
    `Write a short, friendly, professional intro (2-3 sentences, no greeting, no sign-off) ` +
    `for an automated email to a developer named ${ctx.developerName || 'the developer'} ` +
    `about release "${ctx.releaseName}", epic ${ctx.epicKey}` +
    (ctx.epicSummary ? ` ("${ctx.epicSummary}")` : '') +
    `. The following required items are missing and need their attention:\n${missingList}\n` +
    `Be encouraging and concise. Do not invent facts. Do not list the items again; ` +
    `the email already shows them in a table below your text.`;
  const out = await chat(system, user, 200);
  if (out) logger.info({ epic: ctx.epicKey }, 'AI rewrote email intro');
  return out;
}

/**
 * Produce an overall readiness summary across releases. Returns prose or null.
 *
 * @param {object} report  the runCheck result: { releases: [ { release, epics:[
 *                         {key, missing:[...], total, developerEmail} ], epicsWithGaps,
 *                         emailsSent } ] }
 */
async function summarizeReleases(report) {
  if (!config.ai.enabled) return null;

  // Build a compact, factual digest for the model (no invented data).
  const lines = [];
  for (const r of report.releases || []) {
    const total = r.epics.length;
    const withGaps = r.epicsWithGaps;
    lines.push(`Release ${r.release}: ${total} subject(s), ${withGaps} with missing items.`);
    for (const e of r.epics) {
      if (e.missing && e.missing.length) {
        lines.push(`  - ${e.key}: missing ${e.missing.join(', ')}`);
      }
    }
  }
  if (lines.length === 0) lines.push('No active releases / nothing to report.');

  const system =
    'You are a release manager assistant. You write concise, factual status ' +
    'summaries for engineering leadership. Never invent data beyond what is given.';
  const user =
    `Write a brief release-readiness summary (one short paragraph, then optionally ` +
    `a few bullet highlights) based ONLY on this data. Call out which releases are ` +
    `most at risk and the overall picture. Keep it under 150 words.\n\n` +
    lines.join('\n');

  const out = await chat(system, user, 350);
  if (out) logger.info('AI generated release summary');
  return out;
}

/**
 * Connectivity check for validate-config.
 */
async function ping() {
  if (!config.ai.enabled) return 'disabled';
  const out = await chat(
    'You are a test assistant.',
    'Reply with the single word: ok',
    10
  );
  return out ? 'ok' : 'reachable-but-empty';
}

module.exports = { rewriteIntro, summarizeReleases, ping };
