'use strict';

/**
 * Central configuration. Reads .env once, exposes a typed config object,
 * and can validate that required values are present.
 *
 * Nothing else in the codebase should read process.env directly.
 */

const path = require('path');
const fs = require('fs');
require('dotenv').config();

function bool(v, def = false) {
  if (v === undefined || v === null || v === '') return def;
  return String(v).toLowerCase() === 'true';
}

function int(v, def) {
  const n = parseInt(v, 10);
  return Number.isNaN(n) ? def : n;
}

function list(v) {
  if (!v) return [];
  return String(v)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

const config = {
  env: process.env.NODE_ENV || 'development',
  port: int(process.env.PORT, 8080),
  log: {
    level: process.env.LOG_LEVEL || 'info',
    pretty: bool(process.env.LOG_PRETTY, false),
  },
  cron: {
    schedule: process.env.CRON_SCHEDULE || '0 7 * * 1-5',
    tz: process.env.CRON_TZ || 'UTC',
    enabled: bool(process.env.CRON_ENABLED, true),
  },
  dryRun: bool(process.env.DRY_RUN, false),

  jira: {
    baseUrl: (process.env.JIRA_BASE_URL || '').replace(/\/+$/, ''),
    authMode: (process.env.JIRA_AUTH_MODE || 'basic').toLowerCase(),
    email: process.env.JIRA_EMAIL || '',
    apiToken: process.env.JIRA_API_TOKEN || '',
    pat: process.env.JIRA_PAT || '',
    epicJql: process.env.JIRA_EPIC_JQL || 'issuetype = Epic AND fixVersion = "{RELEASE}"',
    developerField: process.env.JIRA_DEVELOPER_FIELD || 'assignee',
    octaneLinkField: process.env.JIRA_OCTANE_LINK_FIELD || '',
  },

  octane: {
    baseUrl: (process.env.OCTANE_BASE_URL || '').replace(/\/+$/, ''),
    sharedSpaceId: process.env.OCTANE_SHARED_SPACE_ID || '',
    workspaceId: process.env.OCTANE_WORKSPACE_ID || '',
    clientId: process.env.OCTANE_CLIENT_ID || '',
    clientSecret: process.env.OCTANE_CLIENT_SECRET || '',
    // Octane IDs come FROM the Jira epic field; we just verify they exist.
  },

  sharepoint: {
    // On-prem SharePoint REST. baseUrl is the SITE collection URL, e.g.
    // https://sharepoint.corp.local/sites/Releases
    baseUrl: (process.env.SHAREPOINT_BASE_URL || '').replace(/\/+$/, ''),
    authMode: (process.env.SHAREPOINT_AUTH_MODE || 'ntlm').toLowerCase(),
    username: process.env.SHAREPOINT_USERNAME || '',
    password: process.env.SHAREPOINT_PASSWORD || '',
    domain: process.env.SHAREPOINT_DOMAIN || '',
    workstation: process.env.SHAREPOINT_WORKSTATION || '',
    libraryName: process.env.SHAREPOINT_LIBRARY_NAME || 'Documents',
    rootPath: process.env.SHAREPOINT_ROOT_PATH || '/Releases/{RELEASE}/{EPIC}',
    rejectUnauthorized: bool(process.env.SHAREPOINT_TLS_REJECT_UNAUTHORIZED, true),
  },

  store: {
    // Where the dedupe notification log JSON is written. On Kubernetes, mount
    // a PersistentVolume here if you want dedupe to survive pod restarts.
    notifLogPath: process.env.NOTIF_LOG_PATH || './data/notification-log.json',
  },

  ai: {
    enabled: bool(process.env.AI_ENABLED, false),
    // OpenAI-compatible base URL, NO trailing slash. Examples:
    //   https://api.openai.com/v1
    //   https://your-internal-ai-gateway.corp/v1
    baseUrl: (process.env.AI_BASE_URL || '').replace(/\/+$/, ''),
    apiKey: process.env.AI_API_KEY || '',
    // Some gateways (Azure-style) want the key in a custom header instead of
    // Authorization: Bearer. Set e.g. "api-key" to use that header.
    apiKeyHeader: process.env.AI_API_KEY_HEADER || '',
    model: process.env.AI_MODEL || 'gpt-4o-mini',
    timeoutMs: int(process.env.AI_TIMEOUT_MS, 15000),
  },

  mail: {
    host: process.env.SMTP_HOST || '',
    port: int(process.env.SMTP_PORT, 587),
    secure: bool(process.env.SMTP_SECURE, false),
    user: process.env.SMTP_USER || '',
    password: process.env.SMTP_PASSWORD || '',
    rejectUnauthorized: bool(process.env.SMTP_TLS_REJECT_UNAUTHORIZED, true),
    fromName: process.env.MAIL_FROM_NAME || 'Release Guardian',
    fromAddress: process.env.MAIL_FROM_ADDRESS || '',
    replyTo: process.env.MAIL_REPLY_TO || '',
    cc: list(process.env.MAIL_CC),
    bcc: list(process.env.MAIL_BCC),
    fallbackTo: process.env.MAIL_FALLBACK_TO || '',
    // Who receives the overall AI release-readiness summary (comma separated).
    // Leave blank to disable the summary email entirely.
    summaryTo: list(process.env.MAIL_SUMMARY_TO),
    subjectTemplate:
      process.env.MAIL_SUBJECT_TEMPLATE ||
      '[Release {RELEASE}] Action needed on {EPIC} — {MISSING_COUNT} item(s) missing',
    companyName: process.env.COMPANY_NAME || 'Your Company',
    companyLogoUrl: process.env.COMPANY_LOGO_URL || '',
    portalUrl: process.env.RELEASE_PORTAL_URL || '',
  },
};

/**
 * Load the artifact definitions (config/artifacts.json).
 * Cached after first read.
 */
let _artifacts = null;
function loadArtifacts() {
  if (_artifacts) return _artifacts;
  const p = path.join(__dirname, '..', 'config', 'artifacts.json');
  const raw = fs.readFileSync(p, 'utf8');
  const parsed = JSON.parse(raw);
  _artifacts = (parsed.artifacts || []).filter((a) => a.enabled !== false);
  return _artifacts;
}

/**
 * Validate that the values needed for a real run are present.
 * Returns { ok: boolean, problems: string[] }.
 */
function validate() {
  const problems = [];
  const need = (cond, msg) => {
    if (!cond) problems.push(msg);
  };

  need(config.jira.baseUrl, 'JIRA_BASE_URL is empty');
  if (config.jira.authMode === 'basic') {
    need(config.jira.email, 'JIRA_EMAIL is empty (basic auth)');
    need(config.jira.apiToken, 'JIRA_API_TOKEN is empty (basic auth)');
  } else {
    need(config.jira.pat, 'JIRA_PAT is empty (bearer auth)');
  }

  need(config.octane.baseUrl, 'OCTANE_BASE_URL is empty');
  need(config.octane.sharedSpaceId, 'OCTANE_SHARED_SPACE_ID is empty');
  need(config.octane.workspaceId, 'OCTANE_WORKSPACE_ID is empty');
  need(config.octane.clientId, 'OCTANE_CLIENT_ID is empty');
  need(config.octane.clientSecret, 'OCTANE_CLIENT_SECRET is empty');
  need(
    config.jira.octaneLinkField,
    'JIRA_OCTANE_LINK_FIELD is empty (required: the Jira field that stores Octane IDs)'
  );

  need(config.sharepoint.baseUrl, 'SHAREPOINT_BASE_URL is empty');
  if (config.sharepoint.authMode === 'ntlm') {
    need(config.sharepoint.username, 'SHAREPOINT_USERNAME is empty (ntlm)');
    need(config.sharepoint.password, 'SHAREPOINT_PASSWORD is empty (ntlm)');
  } else {
    need(config.sharepoint.username, 'SHAREPOINT_USERNAME is empty (basic)');
    need(config.sharepoint.password, 'SHAREPOINT_PASSWORD is empty (basic)');
  }

  need(config.mail.host, 'SMTP_HOST is empty');
  need(config.mail.fromAddress, 'MAIL_FROM_ADDRESS is empty');

  if (config.ai.enabled) {
    need(config.ai.baseUrl, 'AI_BASE_URL is empty (AI_ENABLED=true)');
  }

  return { ok: problems.length === 0, problems };
}

module.exports = { config, loadArtifacts, validate };
