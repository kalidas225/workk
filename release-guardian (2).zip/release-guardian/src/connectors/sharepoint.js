'use strict';

/**
 * On-prem SharePoint connector (SharePoint 2016 / 2019 / Subscription Edition)
 * using the REST API at <site>/_api/web.
 *
 * On-prem SharePoint typically uses NTLM auth (domain account). This connector
 * supports two auth modes via SHAREPOINT_AUTH_MODE:
 *   "ntlm"  -> NTLM with domain\user + password (most common on-prem).
 *   "basic" -> HTTP Basic (only if your farm is configured to allow it,
 *              e.g. behind a reverse proxy that terminates auth).
 *
 * We use GetFolderByServerRelativeUrl(...)/Files to list a folder's files and
 * decide whether a required artifact is present.
 */

const axios = require('axios');
const https = require('https');
const { NtlmClient } = require('axios-ntlm');
const { config } = require('../config');
const logger = require('../logger');

let _client = null;

/**
 * Build (and cache) an HTTP client appropriate for the configured auth mode.
 */
function client() {
  if (_client) return _client;

  // On-prem farms often use internal/self-signed certs. This is configurable.
  const httpsAgent = new https.Agent({
    rejectUnauthorized: config.sharepoint.rejectUnauthorized,
  });

  const common = {
    baseURL: config.sharepoint.baseUrl, // e.g. https://sp.corp.local/sites/Releases
    timeout: 30000,
    httpsAgent,
    headers: { Accept: 'application/json;odata=nometadata' },
  };

  if (config.sharepoint.authMode === 'basic') {
    _client = axios.create({
      ...common,
      auth: { username: config.sharepoint.username, password: config.sharepoint.password },
    });
  } else {
    // NTLM. Username may be "DOMAIN\\user" or "user" with separate domain.
    const creds = {
      username: config.sharepoint.username,
      password: config.sharepoint.password,
      domain: config.sharepoint.domain || '',
      workstation: config.sharepoint.workstation || '',
    };
    _client = NtlmClient(creds, common);
  }
  return _client;
}

/**
 * The server-relative URL of the site (path part of the base URL).
 *   https://sp.corp.local/sites/Releases  ->  /sites/Releases
 */
function siteServerRelativeUrl() {
  try {
    const u = new URL(config.sharepoint.baseUrl);
    return u.pathname.replace(/\/+$/, '') || '';
  } catch (e) {
    return '';
  }
}

/**
 * Build the full server-relative folder URL for a given logical folder path.
 * The library + folderPath are appended under the site.
 *   site=/sites/Releases, library="Documents", folderPath="/Releases/25.07/REL-1/PR"
 *   -> /sites/Releases/Documents/Releases/25.07/REL-1/PR
 */
function buildServerRelativeFolder(folderPath) {
  const site = siteServerRelativeUrl();
  const lib = config.sharepoint.libraryName.replace(/^\/+|\/+$/g, '');
  const clean = folderPath.replace(/^\/+|\/+$/g, '');
  return `${site}/${lib}/${clean}`.replace(/\/{2,}/g, '/');
}

/**
 * List files in a folder via the REST API. Returns an array of { Name }.
 * A non-existent folder yields a 404, which we treat as "no files".
 */
async function listFolderFiles(folderPath) {
  const api = client();
  const serverRel = buildServerRelativeFolder(folderPath);
  // GetFolderByServerRelativeUrl needs the path URL-encoded inside quotes.
  const encoded = encodeURIComponent(serverRel);
  const url = `/_api/web/GetFolderByServerRelativeUrl('${encoded}')/Files?$select=Name,TimeLastModified&$top=500`;

  try {
    const resp = await api.get(url);
    // odata=nometadata returns { value: [...] }; some farms return { d: { results } }.
    const body = resp.data || {};
    const files = body.value || (body.d && body.d.results) || [];
    return files.map((f) => ({ name: f.Name, modified: f.TimeLastModified }));
  } catch (err) {
    const status = err.response && err.response.status;
    if (status === 404) {
      logger.warn({ folderPath, serverRel }, 'SharePoint folder not found (treated as empty)');
      return [];
    }
    logger.error(
      { err: err.message, status, folderPath, serverRel },
      'SharePoint REST listing failed'
    );
    throw err;
  }
}

/**
 * Decide whether a file name satisfies a match rule (same rules as before).
 */
function fileMatches(file, match) {
  const name = (file.name || '').toLowerCase();

  const extOk = (exts) => {
    if (!exts || exts.length === 0) return true;
    return exts.some((e) => name.endsWith(e.toLowerCase()));
  };

  if (!match || match.type === 'extension') {
    return extOk(match && match.extensions);
  }
  if (match.type === 'nameContains') {
    const all = (match.all || []).every((sub) => name.includes(String(sub).toLowerCase()));
    return all && extOk(match.extensions);
  }
  if (match.type === 'regex') {
    try {
      const re = new RegExp(match.pattern, match.flags || 'i');
      return re.test(file.name || '');
    } catch (e) {
      logger.error({ pattern: match.pattern }, 'Invalid regex in artifacts.json');
      return false;
    }
  }
  return false;
}

/**
 * Check one artifact folder. Returns { present, matchedFiles, total, folderPath }.
 */
async function checkArtifactFolder(folderPath, match, minFiles = 1) {
  const files = await listFolderFiles(folderPath);
  const matched = files.filter((f) => fileMatches(f, match));
  return {
    present: matched.length >= (minFiles || 1),
    matchedFiles: matched.map((m) => m.name),
    total: files.length,
    folderPath,
  };
}

/**
 * Connectivity check used by validate-config: read the site title.
 */
async function ping() {
  const api = client();
  const resp = await api.get('/_api/web?$select=Title');
  const body = resp.data || {};
  return body.Title || (body.d && body.d.Title) || 'unknown';
}

module.exports = { checkArtifactFolder, listFolderFiles, ping };
