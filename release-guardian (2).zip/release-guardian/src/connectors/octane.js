'use strict';

/**
 * OpenText / Micro Focus ALM Octane connector.
 *
 * LINKING MODEL (per your setup): the Jira EPIC stores the Octane test-case IDs
 * in a custom field. So we DON'T search Octane by Jira key. Instead we take the
 * list of IDs that Jira gave us and VERIFY each one exists as a test case in
 * Octane. The result tells us how many of the claimed IDs are real.
 *
 * Auth uses Octane API client credentials (cookie-based session).
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../logger');

let cookieJar = null;

function api() {
  const instance = axios.create({
    baseURL: config.octane.baseUrl,
    timeout: 30000,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
  });
  instance.interceptors.request.use((cfg) => {
    if (cookieJar) cfg.headers.Cookie = cookieJar;
    return cfg;
  });
  return instance;
}

async function authenticate() {
  if (cookieJar) return;
  const resp = await axios.post(
    `${config.octane.baseUrl}/authentication/sign_in`,
    { client_id: config.octane.clientId, client_secret: config.octane.clientSecret },
    { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
  );
  const setCookie = resp.headers['set-cookie'] || [];
  cookieJar = setCookie.map((c) => c.split(';')[0]).join('; ');
  if (!cookieJar) throw new Error('Octane authentication did not return a session cookie');
  logger.info('Authenticated with Octane');
}

function wsBase() {
  return `/api/shared_spaces/${config.octane.sharedSpaceId}/workspaces/${config.octane.workspaceId}`;
}

/**
 * Verify which of the given Octane test-case IDs actually exist.
 *
 * @param {string[]} octaneIds  IDs taken from the Jira epic field.
 * @returns {Promise<{requested:number, found:number, foundIds:string[], missingIds:string[], sample:object[]}>}
 */
async function verifyTestCaseIds(octaneIds) {
  const ids = (octaneIds || []).map((s) => String(s).trim()).filter(Boolean);
  if (ids.length === 0) {
    return { requested: 0, found: 0, foundIds: [], missingIds: [], sample: [] };
  }

  await authenticate();

  // Octane "in" query: id IN (1,2,3). IDs are numeric in Octane.
  const inList = ids.map((id) => `${id}`).join(',');
  const query = `"id IN ${inList}"`;
  const url = `${wsBase()}/test_cases`;

  const doGet = async () =>
    api().get(url, { params: { query, fields: 'id,name', limit: Math.max(ids.length, 1) } });

  let resp;
  try {
    resp = await doGet();
  } catch (err) {
    const status = err.response && err.response.status;
    if (status === 401) {
      cookieJar = null;
      await authenticate();
      resp = await doGet();
    } else {
      logger.error({ err: err.message, status, ids }, 'Octane verify failed');
      throw err;
    }
  }

  const data = resp.data || {};
  const items = data.data || [];
  const foundIds = items.map((t) => String(t.id));
  const missingIds = ids.filter((id) => !foundIds.includes(id));

  return {
    requested: ids.length,
    found: foundIds.length,
    foundIds,
    missingIds,
    sample: items.slice(0, 5).map((t) => ({ id: t.id, name: t.name })),
  };
}

module.exports = { authenticate, verifyTestCaseIds };
