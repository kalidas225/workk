'use strict';

/**
 * Jira connector.
 * - Finds the epics belonging to a release (via configurable JQL).
 * - Resolves the responsible developer's email for each epic.
 * - Optionally reads an Octane-link custom field off the epic.
 *
 * Works with Jira Cloud (basic auth: email + API token) and
 * Jira Data Center (bearer auth: Personal Access Token).
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../logger');

function authHeader() {
  if (config.jira.authMode === 'bearer') {
    return { Authorization: `Bearer ${config.jira.pat}` };
  }
  const basic = Buffer.from(`${config.jira.email}:${config.jira.apiToken}`).toString('base64');
  return { Authorization: `Basic ${basic}` };
}

function client() {
  return axios.create({
    baseURL: `${config.jira.baseUrl}/rest/api/2`,
    headers: { ...authHeader(), Accept: 'application/json' },
    timeout: 30000,
  });
}

/**
 * Build the JQL that finds a release's subjects, from its subjectSource.
 *   { type: 'fixVersion',    value: '25.07' }
 *   { type: 'parentEpicKey', value: 'REL-2000' }   // children/linked of an epic
 *   { type: 'jql',           value: '<raw jql>' }
 *
 * The {RELEASE} token (and {VALUE}) can still be used inside a raw jql and in
 * the JIRA_EPIC_JQL template for the fixVersion case.
 */
function buildJql(release) {
  const src = release.subjectSource || { type: 'fixVersion', value: release.name };
  const val = src.value;

  if (src.type === 'jql') {
    return val.replace(/\{RELEASE\}/g, release.name).replace(/\{VALUE\}/g, val);
  }

  if (src.type === 'parentEpicKey') {
    // Issues whose Epic Link / parent is this epic. "parentEpic" works on most
    // modern Jira; we OR a couple of common forms for portability.
    return `("Epic Link" = ${val} OR parent = ${val} OR parentEpic = ${val}) ORDER BY key ASC`;
  }

  // Default: fixVersion, via the configurable template (so users can tweak it).
  return config.jira.epicJql
    .replace(/\{RELEASE\}/g, val)
    .replace(/\{VALUE\}/g, val);
}

/**
 * Fetch all subjects (epics) for a release, paging through results.
 * @param {object} release  normalized release object (has name + subjectSource)
 * Returns an array of normalized epic objects.
 */
async function getReleaseEpics(release) {
  const api = client();
  const jql = buildJql(release);
  logger.info({ jql, release: release.name }, 'Querying Jira for release subjects');

  const fields = ['summary', 'status', 'assignee', 'reporter'];
  if (config.jira.developerField && config.jira.developerField !== 'assignee') {
    fields.push(config.jira.developerField);
  }
  if (config.jira.octaneLinkField) fields.push(config.jira.octaneLinkField);

  const epics = [];
  let startAt = 0;
  const maxResults = 50;

  // Page until we've retrieved everything.
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const resp = await api.get('/search', {
      params: { jql, startAt, maxResults, fields: fields.join(',') },
    });
    const data = resp.data;
    for (const issue of data.issues || []) {
      epics.push(normalizeEpic(issue));
    }
    startAt += maxResults;
    if (startAt >= (data.total || 0)) break;
  }

  logger.info({ count: epics.length, release: release.name }, 'Fetched release subjects');
  return epics;
}

function normalizeEpic(issue) {
  const f = issue.fields || {};
  return {
    key: issue.key,
    summary: f.summary || '',
    status: (f.status && f.status.name) || 'Unknown',
    developerEmail: resolveDeveloperEmail(f),
    developerName: resolveDeveloperName(f),
    octaneIdsFromJira: resolveOctaneIds(f),
    raw: issue,
  };
}

function resolveDeveloperEmail(fields) {
  const fld = config.jira.developerField;

  // Custom field path, e.g. customfield_10050 — could be a user object or string.
  if (fld && fld !== 'assignee') {
    const v = fields[fld];
    if (v) {
      if (typeof v === 'string' && v.includes('@')) return v.trim();
      if (v.emailAddress) return v.emailAddress;
    }
  }
  // Standard assignee.
  if (fields.assignee && fields.assignee.emailAddress) return fields.assignee.emailAddress;
  // Fallback to reporter.
  if (fields.reporter && fields.reporter.emailAddress) return fields.reporter.emailAddress;

  return null; // Caller falls back to MAIL_FALLBACK_TO.
}

function resolveDeveloperName(fields) {
  const fld = config.jira.developerField;
  if (fld && fld !== 'assignee' && fields[fld] && fields[fld].displayName) {
    return fields[fld].displayName;
  }
  if (fields.assignee && fields.assignee.displayName) return fields.assignee.displayName;
  if (fields.reporter && fields.reporter.displayName) return fields.reporter.displayName;
  return 'Developer';
}

function resolveOctaneIds(fields) {
  const fld = config.jira.octaneLinkField;
  if (!fld || !fields[fld]) return [];
  return String(fields[fld])
    .split(/[, ]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

module.exports = { getReleaseEpics, buildJql };
