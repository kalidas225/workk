'use strict';

/**
 * SMTP mailer wrapping nodemailer, wired to your EMA relay settings.
 * Honours dry-run: in dry-run we log instead of sending.
 */

const nodemailer = require('nodemailer');
const { config } = require('../config');
const logger = require('../logger');
const { buildEmail, buildSummaryEmail } = require('./template');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  const opts = {
    host: config.mail.host,
    port: config.mail.port,
    secure: config.mail.secure,
    tls: { rejectUnauthorized: config.mail.rejectUnauthorized },
  };
  if (config.mail.user) {
    opts.auth = { user: config.mail.user, pass: config.mail.password };
  }
  transporter = nodemailer.createTransport(opts);
  return transporter;
}

function subjectFor(releaseName, epicKey, missingCount) {
  return config.mail.subjectTemplate
    .replace(/\{RELEASE\}/g, releaseName)
    .replace(/\{EPIC\}/g, epicKey)
    .replace(/\{MISSING_COUNT\}/g, String(missingCount));
}

/**
 * Send (or, in dry-run, simulate) one alert email.
 * @returns {Promise<{sent:boolean, to:string}>}
 */
async function sendMissingArtifactsEmail(params, { dryRun }) {
  const to = params.developerEmail || config.mail.fallbackTo;
  const missingCount = params.checks.filter((c) => !c.present).length;
  const subject = subjectFor(params.releaseName, params.epicKey, missingCount);
  const { html, text } = buildEmail(params);

  const message = {
    from: `"${config.mail.fromName}" <${config.mail.fromAddress}>`,
    to,
    subject,
    html,
    text,
  };
  if (config.mail.replyTo) message.replyTo = config.mail.replyTo;
  if (config.mail.cc.length) message.cc = config.mail.cc;
  if (config.mail.bcc.length) message.bcc = config.mail.bcc;

  if (dryRun) {
    logger.info(
      { to, subject, missingCount, epic: params.epicKey, release: params.releaseName },
      'DRY-RUN: email not sent'
    );
    return { sent: false, to };
  }

  const info = await getTransporter().sendMail(message);
  logger.info({ to, subject, messageId: info.messageId, epic: params.epicKey }, 'Email sent');
  return { sent: true, to };
}

/**
 * Send (or simulate) the overall release-readiness summary to managers.
 * @returns {Promise<{sent:boolean, to:string}|null>} null if no recipients.
 */
async function sendSummaryEmail({ aiSummary, report }, { dryRun }) {
  const to = config.mail.summaryTo;
  if (!to || to.length === 0) {
    logger.info('No MAIL_SUMMARY_TO configured; skipping summary email');
    return null;
  }
  const { html, text } = buildSummaryEmail({ aiSummary, report });
  const subject = `[Release readiness] Summary — ${(report.releases || []).length} active release(s)`;

  const message = {
    from: `"${config.mail.fromName}" <${config.mail.fromAddress}>`,
    to: to.join(', '),
    subject,
    html,
    text,
  };
  if (config.mail.replyTo) message.replyTo = config.mail.replyTo;

  if (dryRun) {
    logger.info({ to, subject }, 'DRY-RUN: summary email not sent');
    return { sent: false, to: to.join(', ') };
  }
  const info = await getTransporter().sendMail(message);
  logger.info({ to, messageId: info.messageId }, 'Summary email sent');
  return { sent: true, to: to.join(', ') };
}

/**
 * Verify SMTP connectivity (used by validate-config).
 */
async function verifyConnection() {
  return getTransporter().verify();
}

module.exports = { sendMissingArtifactsEmail, sendSummaryEmail, verifyConnection, subjectFor };
