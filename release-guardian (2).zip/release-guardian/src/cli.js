'use strict';

/**
 * Command-line interface.
 *
 *   node src/cli.js run                    -> check all active releases
 *   node src/cli.js run --dry-run          -> compute but send no email
 *   node src/cli.js run --release "25.07"  -> check one named release
 *   node src/cli.js validate-config        -> verify config + connectivity
 */

const logger = require('./logger');
const { validate } = require('./config');
const { runCheck } = require('./core/checker');

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (a === '--dry-run') args.dryRun = true;
    else if (a === '--release') {
      args.releaseName = argv[i + 1];
      i += 1;
    } else args._.push(a);
  }
  return args;
}

async function cmdRun(args) {
  const result = await runCheck({ dryRun: args.dryRun, releaseName: args.releaseName });
  // Compact human summary at the end.
  let totalEmails = 0;
  let totalGaps = 0;
  for (const r of result.releases) {
    totalEmails += r.emailsSent;
    totalGaps += r.epicsWithGaps;
    logger.info(
      { release: r.release, epics: r.epics.length, epicsWithGaps: r.epicsWithGaps, emailsSent: r.emailsSent },
      'Release summary'
    );
  }
  logger.info(
    { releases: result.releases.length, totalEpicsWithGaps: totalGaps, totalEmails, dryRun: result.dryRun },
    'Run complete'
  );
}

async function cmdValidateConfig() {
  const { ok, problems } = validate();
  if (!ok) {
    logger.error({ problems }, 'Config validation FAILED');
    process.exitCode = 1;
    return;
  }
  logger.info('Config values present. Checking connectivity…');

  // SMTP
  try {
    const { verifyConnection } = require('./email/mailer');
    await verifyConnection();
    logger.info('SMTP: OK');
  } catch (e) {
    logger.error({ err: e.message }, 'SMTP: FAILED');
  }

  // Releases file
  try {
    const store = require('./store/fileStore');
    const active = store.getActiveReleases();
    logger.info({ activeReleases: active.map((r) => r.name) }, 'Releases file: OK');
  } catch (e) {
    logger.error({ err: e.message }, 'Releases file: FAILED');
  }

  // Octane
  try {
    await require('./connectors/octane').authenticate();
    logger.info('Octane: OK');
  } catch (e) {
    logger.error({ err: e.message }, 'Octane: FAILED');
  }

  // SharePoint (on-prem REST)
  try {
    const title = await require('./connectors/sharepoint').ping();
    logger.info({ siteTitle: title }, 'SharePoint: OK');
  } catch (e) {
    logger.error({ err: e.message }, 'SharePoint: FAILED');
  }

  // AI (only if enabled)
  try {
    const status = await require('./ai/assist').ping();
    logger.info({ status }, 'AI: checked');
  } catch (e) {
    logger.error({ err: e.message }, 'AI: FAILED');
  }

  logger.info('Validation finished');
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];
  try {
    if (cmd === 'run') await cmdRun(args);
    else if (cmd === 'validate-config') await cmdValidateConfig();
    else {
      logger.error({ cmd }, 'Unknown command. Use: run | validate-config');
      process.exitCode = 2;
    }
  } catch (e) {
    logger.error({ err: e.message, stack: e.stack }, 'Command failed');
    process.exitCode = 1;
  }
}

main();
