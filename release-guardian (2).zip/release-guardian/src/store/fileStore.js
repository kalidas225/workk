'use strict';

/**
 * File-based store. Replaces the Oracle database.
 *
 *  - Releases come from config/releases.json (you edit that file).
 *  - The notification log (used to avoid emailing the same person about the
 *    same epic twice in one day) is a small JSON file under data/.
 *
 * No database, no server. Everything is local files, which is ideal for a
 * short-lived CronJob pod.
 *
 * NOTE for Kubernetes: the notification log is written to NOTIF_LOG_PATH.
 * If you want dedupe to survive across pod restarts, mount a small
 * PersistentVolume at that path (see k8s-cronjob.yaml). If you don't, the
 * worst case is a duplicate email after a restart — harmless but noisy.
 */

const fs = require('fs');
const path = require('path');
const { config } = require('../config');
const logger = require('../logger');

function loadReleasesFile() {
  const p = path.join(__dirname, '..', '..', 'config', 'releases.json');
  const raw = fs.readFileSync(p, 'utf8');
  const parsed = JSON.parse(raw);
  return parsed.releases || [];
}

/**
 * Parse YYYY-MM-DD as a date at local midnight. endDate is inclusive
 * (treated as end-of-day).
 */
function parseDate(s, endOfDay = false) {
  if (!s) return null;
  const [y, m, d] = String(s).split('-').map((n) => parseInt(n, 10));
  if (!y || !m || !d) return null;
  return endOfDay
    ? new Date(y, m - 1, d, 23, 59, 59, 999)
    : new Date(y, m - 1, d, 0, 0, 0, 0);
}

function normalizeRelease(r) {
  return {
    name: r.name,
    startDate: parseDate(r.startDate, false),
    endDate: parseDate(r.endDate, true),
    subjectSource: r.subjectSource || { type: 'fixVersion', value: r.name },
    sharepointRelease: r.sharepointRelease || r.name,
    raw: r,
  };
}

/**
 * Releases whose window includes "now". This is what makes parallel releases
 * safe: a release with a past endDate is simply not returned.
 */
function getActiveReleases(now = new Date()) {
  const releases = loadReleasesFile().map(normalizeRelease);
  const active = releases.filter((r) => {
    const startOk = !r.startDate || r.startDate <= now;
    const endOk = !r.endDate || r.endDate >= now;
    return startOk && endOk;
  });
  logger.info({ total: releases.length, active: active.length }, 'Loaded releases');
  return active;
}

/**
 * Fetch one release by name regardless of its window (for --release flag).
 */
function getReleaseByName(name) {
  const releases = loadReleasesFile().map(normalizeRelease);
  return releases.find((r) => r.name === name) || null;
}

// ---------------------------------------------------------------------------
// Notification log (dedupe) — a JSON file: { "YYYY-MM-DD": ["rel|epic|email"] }
// ---------------------------------------------------------------------------

function logPath() {
  return config.store.notifLogPath;
}

function todayKey(now = new Date()) {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function readLog() {
  try {
    return JSON.parse(fs.readFileSync(logPath(), 'utf8'));
  } catch (e) {
    return {}; // No file yet, or unreadable -> empty log.
  }
}

function writeLog(obj) {
  const p = logPath();
  fs.mkdirSync(path.dirname(p), { recursive: true });
  // Keep only the last 14 days so the file can't grow forever.
  const keys = Object.keys(obj).sort();
  while (keys.length > 14) delete obj[keys.shift()];
  fs.writeFileSync(p, JSON.stringify(obj, null, 2));
}

function entryKey(releaseName, epicKey, email) {
  return `${releaseName}|${epicKey}|${email}`;
}

function alreadyNotifiedToday(releaseName, epicKey, email, now = new Date()) {
  const log = readLog();
  const list = log[todayKey(now)] || [];
  return list.includes(entryKey(releaseName, epicKey, email));
}

function recordNotification(releaseName, epicKey, email, _missing, now = new Date()) {
  const log = readLog();
  const k = todayKey(now);
  if (!log[k]) log[k] = [];
  const ek = entryKey(releaseName, epicKey, email);
  if (!log[k].includes(ek)) log[k].push(ek);
  writeLog(log);
}

module.exports = {
  getActiveReleases,
  getReleaseByName,
  alreadyNotifiedToday,
  recordNotification,
};
