# Compile verification

## Frontend (Angular 19)
Built cleanly with the Angular CLI:
```
ng build  ->  Application bundle generation complete.
```
The UI was run and screenshotted live (see screenshots/). All new features —
health meter, systems status panel, ServiceNow card — render and behave
correctly.

## Backend (Java 21 + Spring Boot)
This sandbox blocks Maven Central, so a full `mvn package` (which downloads
Spring jars) cannot run here. Instead, **every backend source file was
type-checked with `javac 21`** against API-shaped stubs for the Spring / Lombok
/ Jakarta types it uses. All 14 source files compile to 14 classes with zero
errors, which verifies every type signature, generic, and method call across the
codebase — including the new HealthService, StatusService, StatusController, and
the ServiceNow config + model.

In your environment, build normally with your BNP Artifactory mirror:
```
cd backend && mvn clean package
```

## Core-logic assertions
The two pieces of date/score intelligence were executed with assertions:
- Checkpoint math: PPD = release−14d, End-UAT = release−21d, and the
  Upcoming→Due-soon→Overdue transitions — all pass.
- Health score: healthy→EXCELLENT, mid→AT_RISK, critical→CRITICAL, and the
  score moves monotonically with readiness — all pass.

## Update — themes, reporter, HTML emails
- Frontend rebuilt cleanly (`ng build`), all three themes (light/dark/glass)
  rendered and screenshotted live.
- Backend re-type-checked with javac: 15 classes, zero errors (adds
  EmailTemplate; MailService now sends HTML MIME to developer+reporter, CC
  managers).
- Both HTML email templates were compiled and rendered to verify layout (see
  screenshots/email-gap.png and email-summary.png).

## Update — redesign, ServiceNow, per-subject config
- Backend re-type-checked with javac: 18 classes, zero errors. Adds
  SubjectConfigService + controller (per-subject check overrides, JSON-backed),
  ServiceNowService (Table API + mock tickets), and the ServiceNow endpoint.
- Frontend fully rebuilt (`ng build`) in the data-dense terminal style; both
  themes (light/dark, glass baked in), all three tabs (Dashboard / ServiceNow /
  Check config), and modern Chart.js visuals verified live via screenshots.
- Config tab toggles verified interactive (env/BCM/SharePoint-skip flip and
  persist via PUT /api/checks/{key}).

## Update — PPD timeline, filters, modern dropdown, scheduler, real names
- Backend re-type-checked with javac: 19 classes, zero errors. Adds
  CheckpointOverrideService; CheckpointService now emits the full milestone
  timeline (PPD-1, rollback, PPD-2, LCAB, End-UAT, Release) with JSON overrides;
  the scheduler gained a configurable auto-check (every 3h default) that can
  email gaps + a manager summary.
- PPD date math verified with assertions: PPD-1 = release-14d, rollback same
  day, PPD-2 = next Monday after PPD-1, LCAB = Tuesday of release week,
  End-UAT = release-21d.
- Frontend rebuilt clean; verified live: modern custom dropdown (fixes
  dark-mode white select), 6-milestone timeline, grid search + column filters,
  per-system refresh + loaders, real team names/emails, "Reporter" label,
  "18d to release", favicon removed, End-UAT/Timeline health tooltip.

## Update — dependency fix (build errors resolved)
Reported build errors on the user's machine were missing packages:
`org.springframework.web.reactive.function.client` (WebClient),
`org.springframework.mail.javamail` (JavaMailSender), and `jakarta.mail.internet`
— i.e. spring-boot-starter-webflux and spring-boot-starter-mail were not
resolving on the internal mirror.

Fix: removed BOTH starters.
- WebClient -> replaced with the JDK's java.net.http.HttpClient in
  StatusService and ServiceNowService (no external dependency).
- JavaMailSender/MimeMessage -> MailService now writes Outlook-ready .eml draft
  files (X-Unsent:1), same approach as Release Guardian. No mail dependency.
- Also dropped the unused validation starter.

Final pom dependencies: spring-boot-starter-web, spring-boot-starter-cache,
lombok (+ test). All standard, mirror-safe.

Re-verified with javac against a classpath that EXCLUDES webflux/mail stubs (so
the check reflects the real reduced dependency tree): 19 classes, zero errors.
Full `mvn clean package` runs in the user's environment with the Artifactory
mirror.
