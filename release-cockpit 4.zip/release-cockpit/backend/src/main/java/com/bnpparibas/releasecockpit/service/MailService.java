package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.format.DateTimeFormatter;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Produces HTML readiness emails as .eml draft files.
 *
 * Why .eml (not JavaMailSender/SMTP)?  This avoids the spring-boot-starter-mail
 * and Jakarta Mail dependencies — which aren't always present on a locked-down
 * Artifactory mirror — and matches the approach used in Release Guardian: each
 * email is written as an Outlook-ready .eml file (X-Unsent:1) that opens in the
 * compose window for the user to send through their own mail client / EMA relay.
 *
 * Recipients:  To = developer + reporter,  CC = managers (cockpit.mail.managers-cc).
 *
 * In mock mode it just logs. Otherwise it writes .eml files to
 * cockpit.mail.draft-dir (default ./mail-drafts). To switch to real SMTP later,
 * implement send() differently — nothing else changes.
 */
@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final String jiraBaseUrl;

    public MailService(CockpitProperties props) {
        this.props = props;
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
    }

    /** Email one developer + reporter (managers CC) about a subject's gaps. */
    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        List<String> to = recipientsFor(subject);
        String[] cc = props.getMail().getManagersCc();
        String subjectLine = "[Release " + releaseName + "] Action needed on " + subject.key()
                + " — " + subject.readiness().missingCount() + " item(s) missing";

        String html = EmailTemplate.gapEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null && cp.ppdStart() != null ? cp.ppdStart().toString() : "",
                cp != null && cp.endUatDone() != null ? cp.endUatDone().toString() : "",
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key());

        return send(to, cc, subjectLine, html, "gap-" + subject.key());
    }

    /** Email all developers who have a not-ready subject. */
    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0) {
                sendSubjectAlert(releaseName, s, cp);
                sent++;
            }
        }
        return sent;
    }

    /** Email the overall release-status summary to the managers / summary list. */
    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = new ArrayList<>();
        for (String m : props.getMail().getSummaryTo()) if (!m.isBlank()) to.add(m.trim());
        for (String m : props.getMail().getManagersCc()) if (!m.isBlank()) to.add(m.trim());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());

        List<Subject> atRisk = subjects.stream()
                .filter(s -> s.readiness().missingCount() > 0)
                .sorted((a, b) -> b.readiness().missingCount() - a.readiness().missingCount())
                .toList();

        String subjectLine = "[Release " + releaseName + "] Status — " + health.grade()
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, atRisk);

        return send(to, new String[0], subjectLine, html, "summary-" + releaseName);
    }

    // ── helpers ──────────────────────────────────────────────────────────────
    private List<String> recipientsFor(Subject s) {
        List<String> to = new ArrayList<>();
        if (s.developerEmail() != null && !s.developerEmail().isBlank()) to.add(s.developerEmail());
        if (s.reporterEmail() != null && !s.reporterEmail().isBlank()
                && !s.reporterEmail().equalsIgnoreCase(s.developerEmail())) to.add(s.reporterEmail());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());
        return to;
    }

    /**
     * Writes the email as an Outlook-ready .eml draft (X-Unsent:1). Returns a
     * short status string for the UI toast.
     */
    private String send(List<String> to, String[] cc, String subjectLine, String html, String tag) {
        if (props.isMockMode()) {
            log.info("MOCK MAIL [{}] to={} cc={} subject='{}' (html {} chars)",
                    tag, to, List.of(cc), subjectLine, html.length());
            return "Simulated draft for " + String.join(", ", to)
                    + (cc.length > 0 ? " (cc " + String.join(", ", cc) + ")" : "") + " — mock mode";
        }
        try {
            String dir = props.getMail().getDraftDir();
            File outDir = new File(dir);
            if (!outDir.exists()) outDir.mkdirs();

            String eml = buildEml(to, cc, subjectLine, html);
            String fname = tag + "-" + System.currentTimeMillis() + ".eml";
            File f = new File(outDir, fname);
            Files.writeString(f.toPath(), eml, StandardCharsets.UTF_8);
            log.info("Wrote mail draft [{}] -> {}", tag, f.getPath());
            return "Draft written: " + f.getName() + " (to " + String.join(", ", to) + ")";
        } catch (Exception e) {
            log.error("Mail draft failed [{}]: {}", tag, e.getMessage());
            return "Draft failed: " + e.getMessage();
        }
    }

    /** Builds a minimal RFC-822 .eml with a base64 HTML body and X-Unsent:1. */
    private String buildEml(List<String> to, String[] cc, String subjectLine, String html) {
        String date = ZonedDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME);
        String from = props.getMail().getFromName() + " <" + props.getMail().getFromAddress() + ">";
        String b64 = Base64.getMimeEncoder().encodeToString(html.getBytes(StandardCharsets.UTF_8));

        StringBuilder sb = new StringBuilder();
        sb.append("X-Unsent: 1\r\n");
        sb.append("From: ").append(from).append("\r\n");
        sb.append("To: ").append(String.join(", ", to)).append("\r\n");
        if (cc.length > 0) sb.append("Cc: ").append(String.join(", ", cc)).append("\r\n");
        sb.append("Subject: ").append(subjectLine).append("\r\n");
        sb.append("Date: ").append(date).append("\r\n");
        sb.append("MIME-Version: 1.0\r\n");
        sb.append("Content-Type: text/html; charset=UTF-8\r\n");
        sb.append("Content-Transfer-Encoding: base64\r\n");
        sb.append("\r\n");
        sb.append(b64).append("\r\n");
        return sb.toString();
    }

    private String companyName() { return "BNP Paribas"; }
}
