import { Component, EventEmitter, Input, Output, computed, signal } from '@angular/core';
import { ConflictFile, Segment, Side } from '../core/models';

interface Choice { side: Side; }

@Component({
  selector: 'app-conflict-editor',
  standalone: true,
  template: `
  <div class="ce">
    <div class="ce-head">
      <div class="ce-head-main">
        <div class="ce-title-row">
          <span class="ce-icon">⚠</span>
          <div>
            <strong>Resolve conflicts</strong>
            <small>commit <code>{{ sha }}</code> · {{ files.length }} file(s) need a decision · order files were already auto-merged</small>
          </div>
        </div>
      </div>
      <div class="ce-head-actions">
        <span class="ce-progress" [class.complete]="allResolved()">{{ resolvedCount() }} / {{ totalConflicts() }} resolved</span>
        <button class="ce-btn primary" [disabled]="!allResolved()" (click)="emitResolved()">
          @if (allResolved()) { Apply &amp; continue → } @else { {{ totalConflicts() - resolvedCount() }} left }
        </button>
        <button class="ce-x" (click)="cancelled.emit()" title="Cancel cherry-pick" aria-label="Cancel cherry-pick">×</button>
      </div>
    </div>

    <div class="ce-body">
    @for (f of files; track f.file; let fi = $index) {
      <div class="ce-file" [class.collapsed]="isCollapsed(fi)">
        <div class="ce-file-head" (click)="toggleFile(fi)">
          <span class="caret">{{ isCollapsed(fi) ? '▸' : '▾' }}</span>
          <span class="fname mono">{{ f.file }}</span>
          @if (isTextFile(f)) {
            <span class="fbadge" [class.done]="fileResolved(f, fi)">{{ resolvedInFile(f, fi) }} / {{ conflictsIn(f).length }} resolved</span>
            <span class="file-quick" (click)="$event.stopPropagation()">
              <button class="quick-btn" (click)="resolveFile(fi, f, 'ours')" title="Keep all release for this file">all ours</button>
              <button class="quick-btn" (click)="resolveFile(fi, f, 'theirs')" title="Keep all incoming for this file">all theirs</button>
            </span>
          } @else {
            <span class="fbadge kind">{{ f.kind }}</span>
            <span class="fbadge" [class.done]="!!fileChoiceFor(fi)">{{ fileChoiceFor(fi) ? '1 / 1' : '0 / 1' }} resolved</span>
          }
        </div>

        @if (!isCollapsed(fi)) {
          <div class="ce-file-body">
          @if (!isTextFile(f)) {
            <!-- non-text conflict: explicit file-level decision -->
            <div class="filelevel">
              <p class="fl-explain">
                @if (f.kind === 'modify-delete') { This file was <b>modified on release</b> but <b>deleted by the incoming commit</b>. Choose what to keep. }
                @else if (f.kind === 'delete-modify') { This file was <b>deleted on release</b> but <b>modified by the incoming commit</b>. Choose what to keep. }
                @else if (f.kind === 'add-add') { This file was <b>added on both sides</b> with different content. Choose which version to keep. }
                @else if (f.kind === 'binary') { This is a <b>binary file</b> that changed on both sides and can't be merged line-by-line. Choose a version. }
                @else { This file conflicts in a way that can't be merged line-by-line. Choose a version. }
              </p>
              <div class="fl-choices">
                <button class="fl-btn" [class.on]="fileChoiceFor(fi) === 'ours'" (click)="pickFile(fi, 'ours')">
                  ◀ {{ f.ours || 'Keep release version' }}
                </button>
                <button class="fl-btn" [class.on]="fileChoiceFor(fi) === 'theirs'" (click)="pickFile(fi, 'theirs')">
                  {{ f.theirs || 'Keep incoming version' }} ▶
                </button>
                <button class="fl-btn danger" [class.on]="fileChoiceFor(fi) === 'delete'" (click)="pickFile(fi, 'delete')">
                  Delete this file
                </button>
              </div>
              @if (f.kind === 'add-add' || f.kind === 'modify-delete' || f.kind === 'delete-modify') {
                <div class="fl-preview">
                  @if (f.oursContent) { <div class="fl-col"><div class="col-tag">ours · release</div><pre class="mono">{{ f.oursContent }}</pre></div> }
                  @if (f.theirsContent) { <div class="fl-col"><div class="col-tag">theirs · incoming</div><pre class="mono">{{ f.theirsContent }}</pre></div> }
                </div>
              }
            </div>
          } @else {
          @for (seg of f.segments; track $index; let si = $index) {
            @if (seg.type === 'context') {
              @if (nonEmpty(seg.lines)) {
                <pre class="ctx mono">{{ joinLines(seg.lines) }}</pre>
              }
            } @else {
              <div class="hunk" [attr.data-side]="choiceFor(fi, si)?.side ?? 'none'">
                <div class="hunk-bar">
                  <span class="hunk-n">conflict #{{ conflictOrdinal(f, si) }} @if (choiceFor(fi, si)) { <span class="hunk-done">✓</span> }</span>
                  <div class="hunk-actions">
                    <button class="side-btn ours" [class.on]="choiceFor(fi, si)?.side === 'ours'" (click)="pick(fi, si, 'ours')">
                      ◀ Keep {{ seg.oursLabel || 'release' }}
                    </button>
                    <button class="side-btn theirs" [class.on]="choiceFor(fi, si)?.side === 'theirs'" (click)="pick(fi, si, 'theirs')">
                      Keep {{ seg.theirsLabel || 'incoming' }} ▶
                    </button>
                    <button class="side-btn both" [class.on]="choiceFor(fi, si)?.side === 'both'" (click)="pick(fi, si, 'both')">
                      Both
                    </button>
                  </div>
                </div>
                <div class="hunk-cols">
                  <div class="col ours" [class.dim]="choiceFor(fi, si)?.side === 'theirs'" [class.chosen]="choiceFor(fi, si)?.side === 'ours' || choiceFor(fi, si)?.side === 'both'">
                    <div class="col-tag">ours · release</div>
                    <pre class="mono">{{ joinLines(seg.ours) || '(empty)' }}</pre>
                  </div>
                  <div class="col theirs" [class.dim]="choiceFor(fi, si)?.side === 'ours'" [class.chosen]="choiceFor(fi, si)?.side === 'theirs' || choiceFor(fi, si)?.side === 'both'">
                    <div class="col-tag">theirs · incoming</div>
                    <pre class="mono">{{ joinLines(seg.theirs) || '(empty)' }}</pre>
                  </div>
                </div>
              </div>
            }
          }
          }
          </div>
        }
      </div>
    }

    </div>

    <div class="ce-foot">
      <button class="ce-btn ghost" (click)="cancelled.emit()">Cancel cherry-pick</button>
      <button class="ce-btn primary" [disabled]="!allResolved()" (click)="emitResolved()">
        @if (allResolved()) { Apply &amp; continue → } @else { {{ totalConflicts() - resolvedCount() }} conflict(s) left }
      </button>
    </div>
  </div>
  `,
  styleUrl: './conflict-editor.component.css',
})
export class ConflictEditorComponent {
  @Input({ required: true }) files: ConflictFile[] = [];
  @Input() sha = '';
  @Output() resolved = new EventEmitter<{ file: string; content?: string; side?: "ours" | "theirs" | "delete" }[]>();
  @Output() cancelled = new EventEmitter<void>();

  // choices keyed "fileIndex:segIndex"
  private choices = signal<Map<string, Choice>>(new Map());
  private collapsed = signal<Set<number>>(new Set());

  private k(fi: number, si: number) { return `${fi}:${si}`; }
  choiceFor(fi: number, si: number) { return this.choices().get(this.k(fi, si)); }
  pick(fi: number, si: number, side: Side) {
    const m = new Map(this.choices()); m.set(this.k(fi, si), { side }); this.choices.set(m);
    // auto-collapse a file once all its conflicts are resolved, to guide the eye to what's left
    const f = this.files[fi];
    if (f && this.conflictsIn(f).every((_, idx) => this.choiceFor(fi, f.segments.indexOf(this.conflictsIn(f)[idx])))) {
      // no-op; collapsing handled by user. (kept simple + predictable)
    }
  }
  resolveFile(fi: number, f: ConflictFile, side: Side) {
    const m = new Map(this.choices());
    f.segments.forEach((seg, si) => { if (seg.type === 'conflict') m.set(this.k(fi, si), { side }); });
    this.choices.set(m);
  }

  isCollapsed(fi: number) { return this.collapsed().has(fi); }
  toggleFile(fi: number) { const s = new Set(this.collapsed()); s.has(fi) ? s.delete(fi) : s.add(fi); this.collapsed.set(s); }

  conflictsIn(f: ConflictFile) { return f.segments.filter((s) => s.type === 'conflict'); }
  resolvedInFile(f: ConflictFile, fi: number) {
    let n = 0; f.segments.forEach((seg, si) => { if (seg.type === 'conflict' && this.choiceFor(fi, si)) n++; }); return n;
  }
  fileResolved(f: ConflictFile, fi: number) { return this.resolvedInFile(f, fi) === this.conflictsIn(f).length && this.conflictsIn(f).length > 0; }
  nonEmpty(lines?: string[]) { return !!lines && lines.some((l) => l.trim() !== ''); }
  joinLines(lines?: string[]) { return (lines || []).join('\n'); }
  conflictOrdinal(f: ConflictFile, si: number) {
    let n = 0; for (let i = 0; i <= si; i++) if (f.segments[i].type === 'conflict') n++; return n;
  }

  totalConflicts = computed(() =>
    this.files.reduce((a, f) => a + ((!f.kind || f.kind === 'text')
      ? f.segments.filter((s) => s.type === 'conflict').length
      : 1), 0));
  resolvedCount = computed(() => this.choices().size + this.fileChoices().size);
  allResolved = computed(() => this.resolvedCount() === this.totalConflicts() && this.totalConflicts() > 0);

  // file-level choices for non-text conflicts, keyed by file index
  private fileChoices = signal<Map<number, 'ours' | 'theirs' | 'delete'>>(new Map());
  fileChoiceFor(fi: number) { return this.fileChoices().get(fi); }
  pickFile(fi: number, side: 'ours' | 'theirs' | 'delete') {
    const m = new Map(this.fileChoices()); m.set(fi, side); this.fileChoices.set(m);
  }
  isTextFile(f: ConflictFile) { return !f.kind || f.kind === 'text'; }

  emitResolved() {
    const out: { file: string; content?: string; side?: 'ours' | 'theirs' | 'delete' }[] = [];
    this.files.forEach((f, fi) => {
      if (!this.isTextFile(f)) {
        // non-text: emit the file-level side choice
        const side = this.fileChoiceFor(fi);
        if (side) out.push({ file: f.file, side });
        return;
      }
      const lines: string[] = [];
      f.segments.forEach((seg, si) => {
        if (seg.type === 'context') lines.push(...(seg.lines || []));
        else {
          const c = this.choiceFor(fi, si)?.side ?? 'ours';
          if (c === 'ours') lines.push(...(seg.ours || []));
          else if (c === 'theirs') lines.push(...(seg.theirs || []));
          else lines.push(...(seg.ours || []), ...(seg.theirs || []));
        }
      });
      out.push({ file: f.file, content: lines.join('\n') });
    });
    this.resolved.emit(out);
  }
}
