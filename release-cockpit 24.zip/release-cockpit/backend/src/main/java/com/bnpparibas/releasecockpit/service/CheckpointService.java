package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.Milestone;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Computes the release timeline from the Jira release date.
 *
 * Milestones (auto-computed; any can be overridden in subject/release config):
 *   - PPD-1            : 2 weeks (14 days) before the release date
 *   - PPD-1 rollback   : same day as PPD-1
 *   - PPD-2            : the Monday of the week AFTER PPD-1
 *   - LCAB             : the Tuesday of the release week
 *   - End-UAT done     : 3 weeks (21 days) before the release date
 *   - Release          : the release date itself
 *
 * Statuses are relative to "today" so the UI can colour them and the scheduler
 * can decide when to fire approaching-deadline alerts.
 *
 * Overrides: pass a map of milestoneKey -> ISO date to replace any computed
 * date (e.g. when PPD dates shift). The map typically comes from a JSON file in
 * the backend so dates can be corrected without code changes.
 */
@Service
public class CheckpointService {

    public static final int PPD1_LEAD_DAYS = 14;     // 2 weeks
    public static final int END_UAT_LEAD_DAYS = 21;  // 3 weeks
    public static final int DUE_SOON_DAYS = 4;

    public Checkpoints compute(LocalDate releaseDate) {
        return compute(releaseDate, LocalDate.now(), Map.of());
    }

    public Checkpoints compute(LocalDate releaseDate, Map<String, LocalDate> overrides) {
        return compute(releaseDate, LocalDate.now(), overrides);
    }

    public Checkpoints compute(LocalDate releaseDate, LocalDate today, Map<String, LocalDate> overrides) {
        if (releaseDate == null) {
            return new Checkpoints(null, null, null, "UNKNOWN", "UNKNOWN", 0, List.of());
        }
        if (overrides == null) overrides = Map.of();

        // Releases are always on a Saturday. If Jira's date lands on another
        // weekday, snap to the Saturday of that week so the milestone math stays
        // aligned to the release week.
        if (releaseDate.getDayOfWeek() != DayOfWeek.SATURDAY) {
            releaseDate = releaseDate.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY));
        }

        // Milestone rule (anchored to the release week):
        //   PPD-2  = Monday of the release week (Monday before the Sat release)
        //   PPD-1  = the Monday one week before PPD-2
        //   Rollback = same day as PPD-1
        //   LCAB   = Tuesday of the release week (day after PPD-2)
        //   End-UAT = the Monday one week before PPD-1 (UAT sign-off week)
        // Example: release Sat 4 Jul 2026 ->
        //   PPD-1 Mon 22 Jun, Rollback 22 Jun, PPD-2 Mon 29 Jun, LCAB Tue 30 Jun.
        LocalDate releaseWeekMonday = releaseDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate ppd2 = ov(overrides, "PPD2", releaseWeekMonday);
        LocalDate ppd1 = ov(overrides, "PPD1", ppd2.minusWeeks(1));
        LocalDate rollback = ov(overrides, "PPD1_ROLLBACK", ppd1); // same day as PPD-1
        LocalDate lcab = ov(overrides, "LCAB", releaseWeekMonday.plusDays(1)); // Tuesday
        LocalDate endUat = ov(overrides, "END_UAT", ppd1.minusWeeks(1));

        // The REAL release date always comes from Jira and is never overridden here.
        // A separate DOC_CUTOFF (documents deadline) pushes developers to submit
        // artifacts. It defaults to the FRIDAY of the week BEFORE PPD-1 (PPD-1 is a
        // Monday), i.e. documentation closes the Friday before the PPD-1 week.
        // Can be overridden in Config. It does NOT change the release date or math.
        LocalDate ppd1Monday = ppd1.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate autoDocCutoff = ppd1Monday.minusDays(3); // Friday of the previous week
        LocalDate docCutoff = ov(overrides, "DOC_CUTOFF", autoDocCutoff);

        long daysToRelease = ChronoUnit.DAYS.between(today, releaseDate);

        List<Milestone> timeline = new ArrayList<>();
        timeline.add(milestone("END_UAT", "End-UAT done", endUat, today, overrides.containsKey("END_UAT"), true));
        timeline.add(milestone("DOC_CUTOFF", "Document cutoff", docCutoff, today, overrides.containsKey("DOC_CUTOFF"), true));
        timeline.add(milestone("PPD1", "PPD-1", ppd1, today, overrides.containsKey("PPD1"), false));
        timeline.add(milestone("PPD1_ROLLBACK", "PPD-1 rollback", rollback, today, overrides.containsKey("PPD1_ROLLBACK"), false));
        timeline.add(milestone("PPD2", "PPD-2", ppd2, today, overrides.containsKey("PPD2"), false));
        timeline.add(milestone("LCAB", "LCAB", lcab, today, overrides.containsKey("LCAB"), false));
        timeline.add(milestone("RELEASE", "Release", releaseDate, today, false, false));

        // Legacy status fields used by the health/timeline score.
        String ppdStatus = statusForWindow(today, ppd1, releaseDate);
        String endUatStatus = statusForDeadline(today, endUat);

        return new Checkpoints(releaseDate, ppd1, endUat, ppdStatus, endUatStatus,
                daysToRelease, timeline, docCutoff);
    }

    private LocalDate ov(Map<String, LocalDate> o, String key, LocalDate fallback) {
        return o.getOrDefault(key, fallback);
    }

    /** Deadline-type milestone (a single target date). */
    private Milestone milestone(String key, String label, LocalDate date, LocalDate today,
                                boolean overridden, boolean deadline) {
        String status = deadline ? statusForDeadline(today, date) : statusForDate(today, date);
        return new Milestone(key, label, date, status, overridden);
    }

    /** Generic point-in-time status. */
    private String statusForDate(LocalDate today, LocalDate date) {
        long days = ChronoUnit.DAYS.between(today, date);
        if (days < 0) return "DONE";
        if (days == 0) return "ACTIVE";
        if (days <= DUE_SOON_DAYS) return "DUE_SOON";
        return "UPCOMING";
    }

    private String statusForWindow(LocalDate today, LocalDate start, LocalDate end) {
        if (today.isBefore(start)) return "UPCOMING";
        if (!today.isAfter(end)) return "ACTIVE";
        return "DONE";
    }

    private String statusForDeadline(LocalDate today, LocalDate deadline) {
        long days = ChronoUnit.DAYS.between(today, deadline);
        if (days > DUE_SOON_DAYS) return "UPCOMING";
        if (days >= 0) return "DUE_SOON";
        // Past the deadline date -> treat as DONE (the milestone window has closed),
        // rather than OVERDUE, per the release process convention.
        return "DONE";
    }

    public boolean isEndUatApproachingOrPassed(LocalDate releaseDate, LocalDate today) {
        if (releaseDate == null) return false;
        if (releaseDate.getDayOfWeek() != DayOfWeek.SATURDAY) {
            releaseDate = releaseDate.with(TemporalAdjusters.nextOrSame(DayOfWeek.SATURDAY));
        }
        // End-UAT = the Monday two weeks before the release-week Monday.
        LocalDate releaseWeekMonday = releaseDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate endUat = releaseWeekMonday.minusWeeks(2);
        long days = ChronoUnit.DAYS.between(today, endUat);
        return days <= DUE_SOON_DAYS;
    }
}
