package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.connector.HttpClientFactory;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final HttpClient http;
    private final ObjectMapper mapper = new ObjectMapper();
    private final String jiraBaseUrl;

    public MailService(CockpitProperties props, HttpClientFactory clients) {
        this.props = props;
        this.http = clients.proxied();
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
    }

    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        List<String> to = recipientsDefault();
        String subjectLine = "[Release " + releaseName + "] Action needed on " + subject.key()
                + " - " + subject.readiness().missingCount() + " item(s) missing";
        String html = EmailTemplate.gapEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null && cp.ppdStart() != null ? cp.ppdStart().toString() : "",
                cp != null && cp.endUatDone() != null ? cp.endUatDone().toString() : "",
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key());
        return send(to, subjectLine, html, "gap:" + subject.key());
    }

    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0) { sendSubjectAlert(releaseName, s, cp); sent++; }
        }
        return sent;
    }

    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = recipientsDefault();
        List<Subject> atRisk = subjects.stream()
                .filter(s -> s.readiness().missingCount() > 0)
                .sorted((a, b) -> b.readiness().missingCount() - a.readiness().missingCount())
                .toList();
        String subjectLine = "[Release " + releaseName + "] Status - " + health.grade()
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, atRisk);
        return send(to, subjectLine, html, "summary:" + releaseName);
    }

    private List<String> recipientsDefault() {
        List<String> to = new ArrayList<>();
        String fallback = props.getMail().getFallbackTo();
        if (fallback != null && !fallback.isBlank()) {
            for (String a : fallback.split(",")) if (!a.isBlank()) to.add(a.trim());
        }
        return to;
    }

    private String send(List<String> to, String subjectLine, String html, String tag) {
        var mail = props.getMail();
        if (props.isMockMode() || isBlank(mail.getSecuredMailUrl())) {
            log.info("MOCK/UNSENT MAIL [{}] from={} to={} subject='{}' ({} chars)",
                    tag, mail.getFromAddress(), to, subjectLine, html.length());
            return "Simulated send to " + String.join(", ", to);
        }
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("FromEmail", mail.getFromAddress());
            payload.put("ToEmail", to);
            payload.put("CcEmail", List.of());
            payload.put("BccEmail", List.of());
            payload.put("Subject", subjectLine);
            payload.put("emailMessage", html);
            payload.put("Body", html);
            payload.put("ClientName", "Release Cockpit");
            payload.put("IsBodyHtml", true);
            String body = mapper.writeValueAsString(payload);
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(mail.getSecuredMailUrl()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.error("SecuredMail [{}] HTTP {} body={}", tag, r.statusCode(), r.body());
                return "Send failed: HTTP " + r.statusCode();
            }
            log.info("SecuredMail sent [{}] to {} (HTTP {})", tag, to, r.statusCode());
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("Mail send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String companyName() { return "BNP Paribas"; }
}
