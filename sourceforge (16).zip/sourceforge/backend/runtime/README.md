# Runtime toolchain (version-aware JDK + Maven + Artifactory settings)

Drop your company-provided toolchains here. The build runner picks the right
JDK for the selected Java version and a Maven compatible with the Boot+Java
selection. Mount this folder at runtime (Docker volume) so credentials never
live in the source zip.

## 1. JDKs  ->  runtime/jdk/<jdk-N>
One folder per Java version. The folder for the selected Java version is used.
    runtime/jdk/jdk-17/bin/java
    runtime/jdk/jdk-21/bin/java
    runtime/jdk/jdk-25/bin/java
    runtime/jdk/jdk-26/bin/java
(macOS bundles are fine too: runtime/jdk/jdk-21/Contents/Home/bin/java)

Each JDK's lib/security/cacerts should already trust your Artifactory TLS — so
no separate certificate import is needed. Selecting Java 21 in the UI runs the
build with runtime/jdk/jdk-21 as JAVA_HOME.

Override the base dir with: SOURCEFORGE_JDK_DIR=/abs/path/to/jdk   (default backend/runtime/jdk)

## 2. Maven  ->  runtime/maven/<distribution>
One or more Maven distributions. The newest version compatible with the
Boot + Java selection is chosen automatically:
    runtime/maven/apache-maven-3.9.9/bin/mvn   (Spring Boot 3.5+/4.x, Java 17-26)
    runtime/maven/apache-maven-3.8.8/bin/mvn   (older projects)
Rule: Spring Boot 3.5+ and 4.x (and Java 25+) require Maven 3.9+; otherwise the
newest available is used.

Override the base dir with: SOURCEFORGE_MAVEN_DIR=/abs/path/to/maven (default backend/runtime/maven)

## 3. settings.xml  ->  runtime/settings.xml
Artifactory mirror + server credentials. Credentials read from env so they stay
out of source (see settings.xml.example). Point at it with:
    SOURCEFORGE_MAVEN_SETTINGS=/abs/path/runtime/settings.xml

## Resolution order (each, highest priority first)
JDK   : runtime/jdk/jdk-<selected version>  ->  build.java-home  ->  JAVA_HOME env  ->  java on PATH
Maven : compatible dist in runtime/maven    ->  build.maven-home ->  MAVEN_HOME/M2_HOME env  ->  mvn on PATH

If nothing is found, the live build log prints exactly what was checked and how
to fix it.

## Default Maven group
New projects default to group  com.bnpparibas.cib2s .

## Troubleshooting (from real runs)

### "package org.springframework.boot does not exist" during build
This is NOT a code bug. It means Maven could not download Spring dependencies.
Fix: configure your Artifactory settings.xml so dependencies resolve:
  - place it at backend/runtime/settings.xml
  - set SOURCEFORGE_MAVEN_SETTINGS=backend/runtime/settings.xml (or absolute path)
The build log will then print "using Maven settings: <path>" plus a summary of
the mirror URLs / server ids found in that file. Until it can download
spring-boot-starter-parent, every Spring import shows "does not exist".

### "no jdk-21 found under backend/runtime/jdk" even though you placed it there
Two common causes, both now handled/explained in the log:
  1. Relative path resolved against the wrong working directory. Use an ABSOLUTE
     path: SOURCEFORGE_JDK_DIR=C:\path\to\backend\runtime\jdk
  2. Nested extraction: jdk-21\jdk-21.0.1\bin\java.exe. The selector now searches
     one level deeper automatically. It must end at .../bin/java(.exe).
The log now prints exactly which folder it looked in and the directory contents,
e.g. "no usable jdk-21 here. Contents of <dir>: ...".

## ⚠ Boot 4.x + Maven 3.9 requirement (this WILL bite you on Windows)

Spring Boot 4.x (and 3.5+) need Maven 3.9 or newer. Maven 3.8.x on Windows
resolves the Boot 4.x BOM transitives incompletely, causing
"package org.springframework.boot.test.autoconfigure.web.servlet does not exist"
during test compile even though spring-boot-starter-test is declared. The pre-flight
now detects this and prints a clear [WARN] when your Maven CLI is too old, but the
real fix is to drop apache-maven-3.9.x into backend/runtime/maven/.
