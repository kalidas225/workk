# Connectors — going live (porting from Release Guardian)

## Per-subject check overrides (subject-checks.json)

The dashboard now has a **Check config** tab backed by `subject-checks.json`
(loaded/saved by `SubjectConfigService`, exposed at `/api/checks`). When you
port the live connectors, read the effective config per subject via
`SubjectConfigService.forSubject(key)` and apply it:

- **octaneEnvironments** — only require/verify Octane runs for these
  environments. E.g. `["UAT"]` means skip IST and DEV, require UAT. Maps to the
  `environments` field in your `artifacts.json` OCTANE_TESTS_LINKED rule, but
  per-subject.
- **bcmEndToEnd** — when true, additionally require the BCM end-to-end Octane
  test (your `BCM_TESTING` artifact with `testTypePattern "end to end|end-to-end"`).
- **skipSharePoint** — artifact keys (PR, PR_EXCEL, ESTIMATION_SHEET, …) that do
  not apply to this subject; the SharePoint check skips those folders entirely.

So a subject's readiness should be computed as: for each enabled artifact in
`artifacts.json`, unless its key is in `skipSharePoint` (for SharePoint
artifacts) or unless the Octane environment is excluded, run the existing check.
This is exactly the gap between the generic `artifacts.json` rules and what
actually applies to a given epic.


The dashboard ships with `MockConnector` so it runs with no credentials. To go
live, implement `LiveConnector` (a `@Component` annotated with
`@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")`)
that fulfils the same `ReleaseDataConnector` contract:

```java
List<Release> listReleases();
List<Subject> listSubjects(String releaseName);
```

The logic is a direct port of the Node connectors you already have in Release
Guardian. Below is the mapping and the exact REST calls.

---

## 1. Jira — releases + subjects + developer + Octane IDs

**Releases** = the fixVersions configured on your Jira project(s) for the year.

```
GET {JIRA_BASE_URL}/rest/api/2/project/{projectKey}/versions
```
Map each version to `Release(id, name, releaseDate=releaseDate, released, desc)`.
The `releaseDate` field on a Jira version is exactly the date the checkpoints
are derived from.

**Subjects** = epics tagged for that release. Reuse your JQL:
```
GET {JIRA_BASE_URL}/rest/api/2/search
    ?jql=issuetype = Epic AND fixVersion = "{RELEASE}" ORDER BY key ASC
    &fields=summary,status,assignee,reporter,created,{octaneLinkField}
    &startAt=..&maxResults=50      (page until startAt >= total)
```
Per issue, build a `Subject`:
- `developerEmail` — from `assignee.emailAddress` (fallbacks: the configured
  developer field, then reporter), same resolution order as Release Guardian.
- `octaneIds` — split the `{octaneLinkField}` value on commas/spaces.
- `createdDate` — from `fields.created` (used by the late-add detector).

Auth: Basic (email + API token) or Bearer (PAT), same as Release Guardian.

---

## 2. Octane — verify the Jira-listed IDs exist

For each subject, verify the `octaneIds` from Jira actually exist (same model as
Release Guardian — Jira owns the link):

```
POST {OCTANE_BASE_URL}/authentication/sign_in   { client_id, client_secret }
   -> keep the LWSSO session cookie

GET  {OCTANE_BASE_URL}/api/shared_spaces/{ss}/workspaces/{ws}/test_cases
     ?query="id IN {comma-separated-ids}"&fields=id,name
```
`readiness.octaneTestsLinked` = (found count ≥ 1 and, if you require all, none
missing). Reuse the exact pass/fail rule from your `artifacts.json`
(`minTestCases`, `requireAll`).

---

## 3. SharePoint (on-prem REST, NTLM) — the six folders

For each subject, check the six folders under the release/epic root, same as
Release Guardian:

```
GET {SHAREPOINT_BASE_URL}/_api/web/GetFolderByServerRelativeUrl('{path}')/Files
    ?$select=Name
```
where `{path}` = `<site>/<library>/<rootPath with {RELEASE},{EPIC}>/<folder>`.

In Java, NTLM auth is cleanest via Apache HttpClient with an
`NTCredentials(user, pass, workstation, domain)` and a `CredentialsProvider`,
wrapped behind a small `SharePointClient` service. (Spring's `WebClient` doesn't
do NTLM out of the box; Apache HttpClient does.) Map each folder's presence to
the corresponding `Readiness` boolean using the same match rules
(`extension` / `nameContains` / `regex`) you defined in `artifacts.json`.

> If your farm uses Kerberos or forms auth instead of NTLM, swap the
> `CredentialsProvider` accordingly — the rest of the flow is identical.

---

## 4. Mail

`MailService` already uses Spring's `JavaMailSender`, configured from
`spring.mail.*` (your EMA relay). In mock mode it logs instead of sending. No
porting needed — just set `cockpit.mock-mode=false` and the SMTP env vars.

---

## 5. Production hardening checklist

- **Persist late-add dedupe** — replace the in-memory `Set` in
  `IntelligentCheckScheduler` with a small table or the file-log approach used
  in Release Guardian, so restarts don't re-alert.
- **Cache** — swap `ConcurrentMapCacheManager` for Caffeine (TTL) or Redis if
  you run multiple instances.
- **Secrets** — inject via your Vault / Kubernetes Secret, never in
  `application.yml`.
- **Auth on the API** — add Spring Security (your SSO / OAuth2) before exposing
  the dashboard.
- **Threading** — `listSubjects` does N Octane + N SharePoint calls; parallelise
  with a bounded executor for large releases.

## Going live — what's now wired

Run live with your secrets in `application-local.yml` (gitignored):

```
java -jar target/release-cockpit.jar --spring.profiles.active=local
```

- **Jira (internal, direct):** bearer/PAT auth against `https://jira.group.echonet`.
  Releases come from project `fixVersions`; subjects from
  `issuetype = Epic AND fixVersion = "{RELEASE}"`. Set `cockpit.jira.project-keys`
  to your TA project key(s).
- **Octane (SaaS, via proxy):** signs in with client_id/secret, caches the
  LWSSO cookie, and checks each subject's linked test ids exist. Routes through
  the corporate proxy (`cockpit.proxy.*`).
- **SharePoint Online (SaaS, via proxy):** cookie auth (FedAuth + rtFa) against
  `GetFolderByServerRelativeUrl(...)/Files` to confirm each required artifact
  folder has files. Cookies expire ~weekly — refresh them when SharePoint 401s.
- **Proxy:** `HttpClientFactory` builds a direct client (Jira) and a proxied
  client (Octane/SharePoint/ServiceNow) with Basic proxy auth over HTTPS
  tunnels.

Everything degrades gracefully: any unconfigured/unreachable system returns
empty results (logged), so the app always starts and each module lights up as
it connects.

### Tuning to your real structure
Two places use assumptions you should confirm against your data:
1. `LiveConnector.artifactFolder(...)` — maps each artifact key to its SharePoint
   subfolder. Adjust to match your real folder names (from artifacts.json).
2. `cockpit.jira.octane-link-field` — the Jira custom field holding Octane ids.

## ServiceNow — what's needed to switch it on
Set in `application-local.yml` (or env):
- `cockpit.servicenow.enabled: true`
- `cockpit.servicenow.base-url:` your instance, e.g. `https://bnpparibas.service-now.com`
- `cockpit.servicenow.username` / `password:` a service account (or wire OAuth)
- `cockpit.servicenow.table:` defaults to `change_request`
- `cockpit.servicenow.release-field:` the field linking a ticket to a release,
  plus what value it holds (e.g. the release name `25.07`)
