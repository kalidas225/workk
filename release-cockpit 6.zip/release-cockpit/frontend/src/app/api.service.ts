import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import {
  Release, Checkpoints, Subject, ReleaseSummary, Page, Readiness,
  ReleaseHealth, ConnectionStatus, ServiceNowTicket, SubjectCheckConfig, ChecksConfig, Milestone,
} from './models';

/**
 * Data service. When USE_MOCK is true it serves deterministic in-browser demo
 * data (so the UI runs with no backend — used for screenshots/demos). Set it to
 * false to call the Spring Boot API at API_BASE.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly USE_MOCK = true;
  private readonly API_BASE = 'http://localhost:8080/api';

  private readonly PEOPLE: [string, string][] = [
    ['Sreenath Babu Vairavasingh', 'sreenathbabu.vairavasingh@asia.bnpparibas.com'],
    ['Srinivasan Nagarajan', 'srinivasan.nagarajan@asia.bnpparibas.com'],
    ['Selvakumar C', 'selvakumar.c@asia.bnpparibas.com'],
    ['Kameshwaran Pandi', 'kameshwaran.pandi@asia.bnpparibas.com'],
    ['Krishna Prakash Thangadurai', 'krishnaprakash.thangadurai@asia.bnpparibas.com'],
    ['Soundarya Selvam', 'soundarya.selvam@asia.bnpparibas.com'],
    ['Akhila Gowrishankar', 'akhila.gowrishankar@asia.bnpparibas.com'],
    ['K Anjuna Raj', 'anjunaraj.k@asia.bnpparibas.com'],
    ['Mayank Kumar', 'mayank.1.kumar@asia.bnpparibas.com'],
    ['Pratik Bhakte', 'pratik.bhakte@asia.bnpparibas.com'],
    ['Sapthagiri Kalyanakumar', 'sapthagiri.kalyanakumar@ext.asia.bnpparibas.com'],
    ['Kalidas Singamsetty', 'kalidas.singamsetty@asia.bnpparibas.com'],
    ['Krishnaraj L', 'krishnaraj.l@asia.bnpparibas.com'],
    ['Ramabathren Lakshminarayanan', 'ramabathren.lakshminarayanan@asia.bnpparibas.com'],
    ['Chandraleela Kamalamurthy', 'chandraleela.kamalamurthy@asia.bnpparibas.com'],
    ['Akshaya R Srinivasan', 'akshaya.rajagopalansrinivasan@asia.bnpparibas.com'],
    ['Sowmya Unnikrishnan', 'sowmya.unnikrishnan@asia.bnpparibas.com'],
    ['Sivanesh Murugan', 'sivanesh.murugan@asia.bnpparibas.com'],
    ['Mukesh J', 'mukesh.j@asia.bnpparibas.com'],
    ['P D Nancy', 'nancy.pd@asia.bnpparibas.com'],
    ['Manusri Boppana', 'manusri.boppana@asia.bnpparibas.com'],
    ['Aruna Rathinam', 'aruna.rathinam@ext.asia.bnpparibas.com'],
  ];
  private readonly SUMMARIES = [
    'Payments reconciliation service', 'Authentication token rotation',
    'Trade settlement batch optimisation', 'Client onboarding KYC flow',
    'Regulatory reporting export', 'Liquidity dashboard widgets',
    'FX rate ingestion pipeline', 'Audit log retention policy',
    'Margin call notification engine', 'Counterparty risk scoring',
  ];
  private readonly STATUSES = ['In Progress', 'In Review', 'Ready for UAT', 'Blocked', 'Done'];

  constructor(private http: HttpClient) {}

  getReleases(): Observable<Release[]> {
    if (!this.USE_MOCK) return this.http.get<Release[]>(`${this.API_BASE}/releases`);
    const today = new Date();
    const releases: Release[] = [];
    for (let i = -3; i <= 6; i++) {
      const d = new Date(today);
      d.setDate(15);
      d.setMonth(today.getMonth() + i);
      const monthNum = ((today.getMonth() + i + 12) % 12) + 1;
      releases.push({
        id: 'v' + (1000 + i),
        name: `25.${String(monthNum).padStart(2, '0')}`,
        releaseDate: d.toISOString().slice(0, 10),
        released: d < new Date(today.getTime() - 86400000),
        description: 'Monthly platform release',
      });
    }
    return of(releases).pipe(delay(120));
  }

  getCheckpoints(name: string): Observable<Checkpoints> {
    if (!this.USE_MOCK) return this.http.get<Checkpoints>(`${this.API_BASE}/releases/${name}/checkpoints`);
    const rel = this.releaseDateFor(name);
    const today = new Date();
    const d = (base: Date, days: number) => { const x = new Date(base); x.setDate(base.getDate() + days); return x; };
    const ppd1 = d(rel, -14);
    const rollback = new Date(ppd1);
    const ppd2 = this.nextMonday(ppd1);
    const lcab = this.tuesdayOfWeek(rel);
    const endUat = d(rel, -21);
    const days = Math.round((rel.getTime() - today.getTime()) / 86400000);
    const iso = (x: Date) => x.toISOString().slice(0, 10);
    const st = (x: Date, deadline = false): Milestone['status'] => {
      const dd = Math.round((x.getTime() - today.getTime()) / 86400000);
      if (deadline) return dd > 4 ? 'UPCOMING' : dd >= 0 ? 'DUE_SOON' : 'OVERDUE';
      if (dd < 0) return 'DONE'; if (dd === 0) return 'ACTIVE'; if (dd <= 4) return 'DUE_SOON'; return 'UPCOMING';
    };
    const timeline: Milestone[] = [
      { key: 'END_UAT', label: 'End-UAT done', date: iso(endUat), status: st(endUat, true), overridden: false },
      { key: 'PPD1', label: 'PPD-1', date: iso(ppd1), status: st(ppd1), overridden: false },
      { key: 'PPD1_ROLLBACK', label: 'PPD-1 rollback', date: iso(rollback), status: st(rollback), overridden: false },
      { key: 'PPD2', label: 'PPD-2', date: iso(ppd2), status: st(ppd2), overridden: false },
      { key: 'LCAB', label: 'LCAB', date: iso(lcab), status: st(lcab), overridden: false },
      { key: 'RELEASE', label: 'Release', date: iso(rel), status: st(rel), overridden: false },
    ];
    return of({
      releaseDate: iso(rel), ppdStart: iso(ppd1), endUatDone: iso(endUat),
      ppdStatus: st(ppd1) === 'DONE' ? 'DONE' : (days >= 0 ? 'ACTIVE' : 'DONE'),
      endUatStatus: st(endUat, true), daysToRelease: days, timeline,
    } as Checkpoints).pipe(delay(80));
  }

  private nextMonday(from: Date): Date {
    const x = new Date(from); const day = x.getDay();
    const add = ((8 - day) % 7) || 7; // strictly next Monday
    x.setDate(x.getDate() + add); return x;
  }
  private tuesdayOfWeek(rel: Date): Date {
    const x = new Date(rel); const day = x.getDay(); // 0 Sun .. 6 Sat
    const monday = new Date(x); monday.setDate(x.getDate() - ((day + 6) % 7));
    monday.setDate(monday.getDate() + 1); return monday; // Tuesday
  }

  getSummary(name: string): Observable<ReleaseSummary> {
    if (!this.USE_MOCK) return this.http.get<ReleaseSummary>(`${this.API_BASE}/releases/${name}/summary`);
    const subjects = this.mockSubjects(name);
    const ready = subjects.filter(s => s.readiness.missingCount === 0).length;
    const byDev = new Map<string, number>();
    subjects.forEach(s => byDev.set(s.developerName, (byDev.get(s.developerName) || 0) + 1));
    const dist = [...byDev.entries()]
      .map(([developer, subjectCount]) => ({ developer, subjectCount }))
      .sort((a, b) => b.subjectCount - a.subjectCount);
    const octaneOk = subjects.filter(s => s.readiness.octaneTestsLinked).length;
    const spOk = subjects.filter(s => this.spComplete(s.readiness)).length;
    return of({
      releaseName: name,
      totalSubjects: subjects.length,
      ready, notReady: subjects.length - ready,
      developerDistribution: dist,
      readinessBreakdown: {
        octaneOk, octaneMissing: subjects.length - octaneOk,
        sharepointOk: spOk, sharepointMissing: subjects.length - spOk,
      },
    }).pipe(delay(100));
  }

  getSubjects(name: string, page: number, size: number): Observable<Page<Subject>> {
    if (!this.USE_MOCK) {
      return this.http.get<Page<Subject>>(
        `${this.API_BASE}/releases/${name}/subjects?page=${page}&size=${size}`);
    }
    const all = this.mockSubjects(name);
    const from = page * size;
    const content = all.slice(from, from + size);
    return of({ content, page, size, totalElements: all.length }).pipe(delay(100));
  }

  sendMail(name: string, key: string): Observable<{ status: string }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ status: string }>(
        `${this.API_BASE}/releases/${name}/subjects/${key}/mail`, {});
    }
    return of({ status: 'Simulated send (mock mode)' }).pipe(delay(150));
  }

  mailAll(name: string): Observable<{ sent: number }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ sent: number }>(`${this.API_BASE}/releases/${name}/mail-all`, {});
    }
    const n = this.mockSubjects(name).filter(s => s.readiness.missingCount > 0).length;
    return of({ sent: n }).pipe(delay(200));
  }

  mailSummary(name: string): Observable<{ status: string }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ status: string }>(`${this.API_BASE}/releases/${name}/mail-summary`, {});
    }
    return of({ status: 'Release-status summary queued to managers (mock mode)' }).pipe(delay(200));
  }

  getHealth(name: string): Observable<ReleaseHealth> {
    if (!this.USE_MOCK) return this.http.get<ReleaseHealth>(`${this.API_BASE}/releases/${name}/health`);
    const subjects = this.mockSubjects(name);
    const total = Math.max(1, subjects.length);
    const ready = subjects.filter(s => s.readiness.missingCount === 0).length;
    const octaneOk = subjects.filter(s => s.readiness.octaneTestsLinked).length;
    const spOk = subjects.filter(s => this.spComplete(s.readiness)).length;
    const r = Math.round((ready / total) * 100);
    const o = Math.round((octaneOk / total) * 100);
    const sp = Math.round((spOk / total) * 100);
    // Timeline from checkpoint mock.
    const rel = this.releaseDateFor(name);
    const endUat = new Date(rel); endUat.setDate(rel.getDate() - 21);
    const uatDays = Math.round((endUat.getTime() - Date.now()) / 86400000);
    const timeline = uatDays > 4 ? 90 : (uatDays >= 0 ? 60 : 25);
    const score = Math.round(r * 0.40 + o * 0.25 + sp * 0.20 + timeline * 0.15);
    const grade = score >= 85 ? 'EXCELLENT' : score >= 70 ? 'GOOD' : score >= 50 ? 'AT_RISK' : 'CRITICAL';
    const risks: string[] = [];
    if (r < 60) risks.push((total - ready) + ' of ' + total + ' subjects still have gaps');
    if (o < 70) risks.push('Octane coverage is low (' + o + '%)');
    if (sp < 70) risks.push('SharePoint artifacts incomplete (' + sp + '%)');
    if (uatDays < 0) risks.push('End-UAT deadline has passed');
    else if (uatDays <= 4) risks.push('End-UAT deadline is approaching');
    if (risks.length === 0) risks.push('On track — no major risks detected');
    return of({
      score, grade: grade as ReleaseHealth['grade'],
      readinessScore: r, octaneScore: o, sharepointScore: sp, timelineScore: timeline, risks,
    }).pipe(delay(110));
  }

  getServiceNow(name: string): Observable<ServiceNowTicket[]> {
    if (!this.USE_MOCK) return this.http.get<ServiceNowTicket[]>(`${this.API_BASE}/releases/${name}/servicenow`);
    const rng = this.seeded(this.hash(name) ^ 0x5a17);
    const states = ['New', 'Assess', 'Authorize', 'Scheduled', 'Implement', 'Review', 'Closed'];
    const prios = ['1 - Critical', '2 - High', '3 - Moderate', '4 - Low'];
    const devs = this.PEOPLE.map(p => p[0]);
    const descs = ['Production deployment for release ' + name, 'Database schema migration',
      'Firewall rule change for new endpoints', 'Config rollout to UAT', 'Certificate renewal',
      'Load balancer update', 'Batch job schedule change', 'Rollback plan validation'];
    const n = 3 + Math.floor(rng() * 5);
    const out: ServiceNowTicket[] = [];
    for (let i = 0; i < n; i++) {
      out.push({
        number: 'CHG' + String(30000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: descs[Math.floor(rng() * descs.length)],
        state: states[Math.floor(rng() * states.length)],
        priority: prios[Math.floor(rng() * prios.length)],
        assignedTo: devs[Math.floor(rng() * devs.length)],
        type: 'change_request', url: '#',
      });
    }
    return of(out).pipe(delay(120));
  }

  getChecks(): Observable<ChecksConfig> {
    if (!this.USE_MOCK) return this.http.get<ChecksConfig>(`${this.API_BASE}/checks`);
    return of({
      default: { octaneEnvironments: ['IST', 'DEV', 'UAT'], bcmEndToEnd: false, skipSharePoint: [], note: '' },
      overrides: {
        'REL-1042': { octaneEnvironments: ['UAT'], bcmEndToEnd: true, skipSharePoint: ['ESTIMATION_SHEET'], note: 'Octane IST/DEV not applicable; BCM e2e required; no estimation sheet.' },
        'REL-1043': { octaneEnvironments: ['DEV', 'UAT'], bcmEndToEnd: false, skipSharePoint: ['PR_EXCEL', 'ESTIMATION_SHEET'], note: 'Skip IST; PR Excel and estimation not applicable.' },
        'REL-1044': { octaneEnvironments: ['UAT'], bcmEndToEnd: true, skipSharePoint: [], note: 'UAT-only Octane with BCM end-to-end.' },
      },
    } as ChecksConfig).pipe(delay(100));
  }

  putCheck(key: string, cfg: SubjectCheckConfig): Observable<SubjectCheckConfig> {
    if (!this.USE_MOCK) return this.http.put<SubjectCheckConfig>(`${this.API_BASE}/checks/${key}`, cfg);
    return of(cfg).pipe(delay(80));
  }

  getStatus(): Observable<ConnectionStatus[]> {
    if (!this.USE_MOCK) return this.http.get<ConnectionStatus[]>(`${this.API_BASE}/status`);
    return of([
      { system: 'JIRA', status: 'MOCK', detail: 'Mock data — not connecting to Jira', latencyMs: 0 },
      { system: 'SHAREPOINT', status: 'MOCK', detail: 'Mock — cookie auth (FedAuth + rtFa)', latencyMs: 0 },
      { system: 'OCTANE', status: 'MOCK', detail: 'Mock — client credentials', latencyMs: 0 },
      { system: 'SERVICENOW', status: 'MOCK', detail: 'Mock — Table API (change_request)', latencyMs: 0 },
    ] as ConnectionStatus[]).pipe(delay(90));
  }

  // ---- mock helpers (deterministic per release name) ----
  private releaseDateFor(name: string): Date {
    const releases = [];
    const today = new Date();
    for (let i = -3; i <= 6; i++) {
      const d = new Date(today); d.setDate(15); d.setMonth(today.getMonth() + i);
      const monthNum = ((today.getMonth() + i + 12) % 12) + 1;
      releases.push({ name: `25.${String(monthNum).padStart(2, '0')}`, d });
    }
    return (releases.find(r => r.name === name)?.d) || new Date();
  }

  private isShipped(name: string): boolean {
    const rel = this.releaseDateFor(name);
    return rel < new Date(Date.now() - 86400000);
  }

  private toEmail(name: string): string {
    return name.toLowerCase().replace(/'/g, '').replace(/ /g, '.') + '@bnpparibas.com';
  }

  private spComplete(r: Readiness): boolean {
    return r.prDoc && r.unitTest && r.estimationSheet && r.prExcel
      && r.octaneReviewDoc && r.octaneExecutionDoc;
  }

  private mockSubjects(name: string): Subject[] {
    const rng = this.seeded(this.hash(name));
    const healthy = this.isShipped(name);
    const count = 14 + Math.floor(rng() * 34);
    const subjects: Subject[] = [];
    const today = new Date();
    for (let i = 0; i < count; i++) {
      const devP = this.PEOPLE[Math.floor(rng() * this.PEOPLE.length)];
      let repP = this.PEOPLE[Math.floor(rng() * this.PEOPLE.length)];
      if (repP[0] === devP[0]) repP = this.PEOPLE[this.PEOPLE.length - 1 - Math.floor(rng() * this.PEOPLE.length)];
      const r = this.mockReadiness(rng, healthy);
      const created = new Date(today); created.setDate(today.getDate() - Math.floor(rng() * 40));
      const ids: string[] = [];
      const n = Math.floor(rng() * 4);
      for (let k = 0; k < n; k++) ids.push(String(100000 + Math.floor(rng() * 9999)));
      subjects.push({
        key: `REL-${1000 + (this.hash(name) % 100) + i}`,
        summary: this.SUMMARIES[Math.floor(rng() * this.SUMMARIES.length)],
        status: this.STATUSES[Math.floor(rng() * this.STATUSES.length)],
        developerName: devP[0],
        developerEmail: devP[1],
        reporterName: repP[0],
        reporterEmail: repP[1],
        createdDate: created.toISOString().slice(0, 10),
        octaneIds: ids,
        readiness: r,
      });
    }
    return subjects;
  }

  private mockReadiness(rng: () => number, healthy = false): Readiness {
    const p = (pct: number) => Math.floor(rng() * 100) < pct;
    // Shipped releases are mostly complete -> exercises the healthy meter states.
    const octane = healthy ? p(96) : p(70);
    const pr = healthy ? p(97) : p(80);
    const unit = healthy ? p(95) : p(75);
    const est = healthy ? p(98) : p(85);
    const prx = healthy ? p(96) : p(78);
    const rev = healthy ? p(94) : p(65);
    const exec = healthy ? p(93) : p(60);
    const missing: string[] = [];
    if (!octane) missing.push('OCTANE_TESTS_LINKED');
    if (!pr) missing.push('PR');
    if (!unit) missing.push('UNIT_TEST');
    if (!est) missing.push('ESTIMATION_SHEET');
    if (!prx) missing.push('PR_EXCEL');
    if (!rev) missing.push('OCTANE_REVIEW_DOC');
    if (!exec) missing.push('OCTANE_EXECUTION_DOC');
    return {
      octaneTestsLinked: octane, prDoc: pr, unitTest: unit, estimationSheet: est,
      prExcel: prx, octaneReviewDoc: rev, octaneExecutionDoc: exec,
      missingCount: missing.length, missing,
    };
  }

  private hash(s: string): number {
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; }
    return Math.abs(h);
  }
  private seeded(seed: number): () => number {
    let s = seed % 2147483647; if (s <= 0) s += 2147483646;
    const next = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    // Warm up: the first few LCG outputs are correlated across nearby seeds.
    for (let i = 0; i < 8; i++) next();
    return next;
  }
}
