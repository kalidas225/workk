import { Component, EventEmitter, HostListener, Input, Output, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface DropdownOption {
  value: string;
  label: string;
  tag?: string;        // optional small tag on the right (e.g. "shipped")
  tagLive?: boolean;   // green "active" style tag
}

/**
 * A single modern dropdown used everywhere (release picker + all filters) so
 * every dropdown looks identical. Renders a solid frosted menu that sits ABOVE
 * page content (high z-index + solid background) — no transparent overlap.
 */
@Component({
  selector: 'app-dropdown',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dd" [class.open]="open" [class.dd-block]="block">
      <button type="button" class="dd-btn" (click)="toggle($event)" [style.min-width.px]="minWidth">
        <span class="dd-lab" *ngIf="label">{{ label }}</span>
        <span class="dd-val" [class.mono]="mono">{{ selectedLabel }}</span>
        <svg class="dd-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      </button>
      <div class="dd-menu" *ngIf="open">
        <button type="button" class="dd-item" *ngFor="let o of options"
                [class.sel]="o.value === value" (click)="choose(o)">
          <span [class.mono]="mono">{{ o.label }}</span>
          <span class="dd-item-tag" *ngIf="o.tag" [class.live]="o.tagLive">{{ o.tag }}</span>
          <svg class="dd-check" *ngIf="o.value === value" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
        </button>
      </div>
    </div>
  `,
})
export class DropdownComponent {
  @Input() options: DropdownOption[] = [];
  @Input() value = '';
  @Input() label = '';
  @Input() placeholder = 'Select';
  @Input() mono = false;
  @Input() block = false;     // full-width (for filters)
  @Input() minWidth = 0;
  @Output() valueChange = new EventEmitter<string>();

  open = false;

  constructor(private host: ElementRef) {}

  get selectedLabel(): string {
    const found = this.options.find(o => o.value === this.value);
    return found ? found.label : this.placeholder;
  }

  toggle(e: MouseEvent): void { e.stopPropagation(); this.open = !this.open; }
  choose(o: DropdownOption): void { this.open = false; if (o.value !== this.value) this.valueChange.emit(o.value); }

  @HostListener('document:click', ['$event'])
  onDoc(e: MouseEvent): void {
    if (this.open && !this.host.nativeElement.contains(e.target)) this.open = false;
  }
}
