package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane bearer token (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    public LiveConnector(CockpitProperties props, HttpClientFactory clients) {
        this.props = props;
        this.clients = clients;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl()) || isBlank(j.getProjectKeys())) {
            log.warn("Jira not configured (base-url/project-keys); returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();
        try {
            for (String project : j.getProjectKeys().split(",")) {
                project = project.trim();
                if (project.isEmpty()) continue;
                String body = getJira("/rest/api/2/project/" + project + "/versions");
                if (body == null) continue;
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        String rd = v.path("releaseDate").asText(null);
                        boolean released = v.path("released").asBoolean(false);
                        LocalDate date = rd != null ? safeDate(rd) : null;
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                }
            }
        } catch (Exception e) {
            log.warn("listReleases failed gracefully: {}", e.getMessage());
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String url = "/rest/api/2/search?jql=" + enc(jql)
                    + "&maxResults=200&fields=summary,status,assignee,reporter,created,"
                    + (j.getOctaneLinkField() == null ? "" : j.getOctaneLinkField());
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                String dev = f.path("assignee").path("displayName").asText("");
                String devEmail = f.path("assignee").path("emailAddress").asText("");
                String rep = f.path("reporter").path("displayName").asText("");
                String repEmail = f.path("reporter").path("emailAddress").asText("");
                LocalDate created = safeDate(f.path("created").asText("").replaceAll("T.*", ""));
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                // Real readiness: Octane (tests linked + passed) + SharePoint
                // (required artifact folders/files). Each check degrades to false
                // on any error so a single subject can't crash the scan.
                boolean octaneOk = checkOctane(octaneIds);
                Readiness r = buildReadiness(key, octaneOk);
                out.add(new Subject(key, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        dev, devEmail, rep, repEmail, created, octaneIds, r));
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject. Octane result is passed in; SharePoint
     * artifact presence is checked per-folder. Any check that errors counts as
     * "not present" (false) so gaps surface rather than crashing.
     */
    private Readiness buildReadiness(String epicKey, boolean octaneOk) {
        boolean pr = checkSharePoint(epicKey, "PR");
        boolean prExcel = checkSharePoint(epicKey, "PR_EXCEL");
        boolean est = checkSharePoint(epicKey, "ESTIMATION_SHEET");
        boolean rev = checkSharePoint(epicKey, "OCTANE_REVIEW_DOC");
        boolean exec = checkSharePoint(epicKey, "OCTANE_EXECUTION_DOC");
        boolean unit = checkSharePoint(epicKey, "UNIT_TEST");

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");
        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing);
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    private boolean checkOctane(List<String> octaneIds) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl()) || octaneIds == null || octaneIds.isEmpty()) return false;
        try {
            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return false;
            // Query test cases by id list: /api/shared_spaces/{ss}/workspaces/{ws}/tests?query="..."
            String ids = String.join(" || ", octaneIds.stream().map(i -> "id=" + i).toList());
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests?fields=id,name,last_runs&query=\"" + enc("(" + ids + ")") + "\"";
            HttpResponse<String> r = octaneGet(url);
            if (r != null && r.statusCode() == 401) { octaneSignIn(); r = octaneGet(url); }
            if (r == null || r.statusCode() >= 400) return false;
            int total = mapper.readTree(r.body()).path("total_count").asInt(0);
            return total > 0;
        } catch (Exception e) {
            log.warn("Octane check failed gracefully: {}", e.getMessage());
            return false;
        }
    }

    private void octaneSignIn() {
        var o = props.getOctane();
        try {
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() < 400) {
                // capture the LWSSO_COOKIE_KEY from Set-Cookie
                String cookie = r.headers().allValues("set-cookie").stream()
                        .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                        .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                octaneCookie = cookie;
                log.info("Octane sign-in {}", cookie != null ? "OK" : "returned no cookie");
            } else {
                log.warn("Octane sign-in HTTP {}", r.statusCode());
            }
        } catch (Exception e) {
            log.warn("Octane sign-in failed gracefully: {}", e.getMessage());
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", octaneCookie)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    // ---- SharePoint ----
    /**
     * Checks whether the required artifact folder for an epic contains at least
     * one file. Uses cookie auth (FedAuth + rtFa). The folder path is
     * {root-path}/{EPIC}/{artifact subfolder}. Returns false on any error.
     *
     * NOTE: the precise subfolder names + file-type rules come from your
     * artifacts.json (Release Guardian). This implements the existence check;
     * map ARTIFACT keys to their real subfolders in artifactFolder().
     */
    private boolean checkSharePoint(String epicKey, String artifactKey) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return false;
        try {
            String folder = sp.getRootPath() + "/" + epicKey + "/" + artifactFolder(artifactKey);
            String serverRel = sp.getBaseUrl().replaceFirst("https?://[^/]+", "") + "/"
                    + sp.getLibraryName() + folder;
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + enc(serverRel) + "')/Files?$select=Name";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + sp.getRtFa())
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) return false;
            JsonNode files = mapper.readTree(r.body()).path("value");
            return files.isArray() && files.size() > 0;
        } catch (Exception e) {
            log.warn("SharePoint check failed gracefully ({} {}): {}", epicKey, artifactKey, e.getMessage());
            return false;
        }
    }

    /** Maps an artifact key to its SharePoint subfolder (adjust to artifacts.json). */
    private String artifactFolder(String key) {
        return switch (key) {
            case "PR" -> "01 - PR";
            case "PR_EXCEL" -> "01 - PR";
            case "ESTIMATION_SHEET" -> "02 - Estimation";
            case "OCTANE_REVIEW_DOC" -> "03 - Quality/Review";
            case "OCTANE_EXECUTION_DOC" -> "03 - Quality/Execution";
            case "UNIT_TEST" -> "04 - Unit Test";
            default -> key;
        };
    }
    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(12)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
