package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import org.springframework.stereotype.Component;

import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.ProxySelector;
import java.net.http.HttpClient;
import java.time.Duration;

/**
 * Builds HttpClients for the connectors.
 *
 *  - direct(): no proxy (internal systems like Jira on the corporate network).
 *  - proxied(): routes through the corporate proxy with Basic proxy auth
 *    (for SaaS targets — Octane, SharePoint Online). If proxy is disabled it
 *    returns a direct client, so the same call site works in both setups.
 *
 * Proxy Basic auth via java.net.Authenticator requires allowing the
 * "Proxy-Authorization" header to be set on tunnelled connections; we set the
 * system property jdk.http.auth.tunneling.disabledSchemes="" once at init so
 * Basic proxy auth works through CONNECT tunnels (HTTPS via proxy).
 */
@Component
public class HttpClientFactory {

    private final CockpitProperties props;
    private final HttpClient direct;
    private final HttpClient proxied;

    public HttpClientFactory(CockpitProperties props) {
        this.props = props;
        // Allow Basic auth on HTTPS-over-proxy tunnels.
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        System.setProperty("jdk.http.auth.proxying.disabledSchemes", "");

        this.direct = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(12))
                .version(HttpClient.Version.HTTP_1_1)
                .build();

        var p = props.getProxy();
        if (p.isEnabled() && p.getHost() != null && !p.getHost().isBlank()) {
            HttpClient.Builder b = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(15))
                    .version(HttpClient.Version.HTTP_1_1)
                    .proxy(ProxySelector.of(new InetSocketAddress(p.getHost(), p.getPort())));
            if (p.getUser() != null && !p.getUser().isBlank()) {
                b.authenticator(new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        // Only answer for the proxy, not target-site auth.
                        if (getRequestorType() == RequestorType.PROXY) {
                            return new PasswordAuthentication(p.getUser(),
                                    (p.getPass() == null ? "" : p.getPass()).toCharArray());
                        }
                        return null;
                    }
                });
            }
            this.proxied = b.build();
        } else {
            this.proxied = this.direct;
        }
    }

    public HttpClient direct() { return direct; }
    public HttpClient proxied() { return proxied; }
}
