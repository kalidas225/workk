// Cherry Deck server — plain Node, zero dependencies.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const gs = require('./lib/gitService');
const disc = require('./lib/repoDiscovery');
const gl = require('./lib/gitlab');
const { fixSqlFile } = require('./lib/sqlLint');

const PORT = process.env.PORT || 5173;
const DIST = path.join(__dirname, 'public');

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };

function send(res, code, body, type = 'application/json') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': type, 'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
  res.end(data);
}
function readBody(req) {
  return new Promise((resolve) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } }); });
}

// resolve repoKey -> working tree (clones into cache on demand for GitLab repos)
async function wt(repoKey) {
  const lp = await disc.resolveWorkingTree(repoKey);
  if (!lp) throw new gs.GitError(`Could not resolve a working copy for: ${repoKey}`);
  return lp;
}

const routes = {
  'GET /api/repos': async () => ({ groups: await disc.discover(), gitlab: disc.gitlabEnabled() }),

  'POST /api/connect': async (q, body) => {
    const lp = await wt(body.repoKey);
    return { ok: true, root: await gs.root(lp), currentBranch: await gs.currentBranch(lp), repoKey: body.repoKey, workingCopy: lp };
  },

  'GET /api/branches': async (q) => ({ branches: await gs.branches(await wt(q.repoKey)) }),
  'POST /api/fetch': async (q, body) => ({ ok: true, output: await gs.fetchAll(await wt(body.repoKey)) }),
  'GET /api/protected': async (q) => ({ branch: q.branch, isProtected: await gs.isProtected(await wt(q.repoKey), q.branch) }),
  'GET /api/commits': async (q) => gs.commits(await wt(q.repoKey), q.source || 'develop', q.target || ''),

  'POST /api/dry-run': async (q, body) => gs.dryRun(await wt(body.repoKey), body),
  'POST /api/cherry-pick/start': async (q, body) => gs.startCherryPick(await wt(body.repoKey), body),
  'POST /api/cherry-pick/resolve': async (q, body) => gs.resolveAndContinue(await wt(body.repoKey), body.workBranch, body.resolutions || []),
  'POST /api/cherry-pick/abort': async (q, body) => gs.abortCherryPick(await wt(body.repoKey), body.workBranch),

  'POST /api/push': async (q, body) => gs.push(await wt(body.repoKey), body.branch, !!body.setUpstream),

  'POST /api/merge-request': async (q, body) => {
    const projectId = await disc.gitlabIdFor(body.repoKey);
    if (!projectId) throw new gs.GitError('No GitLab project id for this repo — can\'t raise an MR.');
    return gl.createMergeRequest(projectId, body);
  },

  'POST /api/fix-sql': async (q, body) => {
    const repo = await wt(body.repoKey);
    return { ok: true, file: body.file, fixed: fixSqlFile(repo, body.file) };
  },
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, '');
  const u = new URL(req.url, `http://localhost:${PORT}`);
  const key = `${req.method} ${u.pathname}`;
  if (routes[key]) {
    try {
      const q = Object.fromEntries(u.searchParams.entries());
      const body = req.method === 'POST' ? await readBody(req) : {};
      return send(res, 200, await routes[key](q, body));
    } catch (e) {
      return send(res, e instanceof gs.GitError ? 400 : 500, { error: e.message || 'Unexpected error' });
    }
  }
  if (req.method === 'GET' && !u.pathname.startsWith('/api/')) {
    let fp = path.join(DIST, u.pathname === '/' ? 'index.html' : u.pathname.slice(1));
    if (!fs.existsSync(fp) || !fs.statSync(fp).isFile()) fp = path.join(DIST, 'index.html');
    if (fs.existsSync(fp)) return send(res, 200, fs.readFileSync(fp), MIME[path.extname(fp)] || 'application/octet-stream');
    return send(res, 404, 'UI not built.', 'text/plain');
  }
  send(res, 404, { error: 'Not found' });
});
server.listen(PORT, () => console.log(`Cherry Deck (plain Node) on http://localhost:${PORT}`));
