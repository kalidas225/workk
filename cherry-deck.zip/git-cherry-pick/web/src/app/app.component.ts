import { Component, computed, inject, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { GitApi } from './core/git-api.service';
import {
  Branch, CherryPickState, ConflictFile, DryItem, MrResponse, ProjectGroup, PushResponse,
  RepoRef, SqlWarning, SubjectGroup,
} from './core/models';
import { ThemeToggleComponent } from './shared/theme-toggle.component';
import { ConflictEditorComponent } from './shared/conflict-editor.component';

type Step = 'repos' | 'pick';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, ThemeToggleComponent, ConflictEditorComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  private api = inject(GitApi);

  step = signal<Step>('repos');
  busy = signal(false);
  error = signal<string | null>(null);
  toast = signal<string | null>(null);

  projectGroups = signal<ProjectGroup[]>([]);
  gitlabOn = signal(false);
  repoFilter = signal('');
  activeRepo = signal<RepoRef | null>(null);
  repoRoot = signal('');
  get repoKey() { return this.repoRoot() || ''; }

  branches = signal<Branch[]>([]);
  source = signal('develop');
  target = signal('');

  groups = signal<SubjectGroup[]>([]);
  total = signal(0);
  selected = signal<Set<string>>(new Set());
  filter = signal('');
  collapsed = signal<Set<string>>(new Set());

  targetProtected = signal(false);
  forceNewBranch = signal(false);
  newBranch = signal('');

  dryResults = signal<DryItem[] | null>(null);
  state = signal<CherryPickState | null>(null); // active cherry-pick (conflict or done)
  pushed = signal<PushResponse | null>(null);
  sqlFixed = signal<Set<string>>(new Set());

  // merge request
  showMr = signal(false);
  mrTitle = signal('');
  mrDesc = signal('');
  mrTarget = signal('');
  mrLabels = signal('');
  mrRemoveSource = signal(false);
  mrSquash = signal(false);
  mrResult = signal<MrResponse | null>(null);

  conflictFiles = computed<ConflictFile[]>(() => this.state()?.files ?? []);
  inConflict = computed(() => this.state()?.status === 'conflict');
  done = computed(() => this.state()?.status === 'done');

  filteredRepoGroups = computed(() => {
    const q = this.repoFilter().trim().toLowerCase();
    if (!q) return this.projectGroups();
    return this.projectGroups()
      .map((g) => ({ ...g, repos: g.repos.filter((r) => r.name.toLowerCase().includes(q) || r.path.toLowerCase().includes(q)) }))
      .filter((g) => g.repos.length > 0 || g.group.toLowerCase().includes(q));
  });

  localBranches = computed(() => this.branches().filter((b) => !b.remote));
  remoteBranches = computed(() => this.branches().filter((b) => b.remote));

  filteredGroups = computed(() => {
    const q = this.filter().trim().toLowerCase();
    if (!q) return this.groups();
    return this.groups()
      .map((g) => ({ ...g, commits: g.commits.filter((c) =>
        c.subject.toLowerCase().includes(q) || c.subjectKey.toLowerCase().includes(q) ||
        c.author.toLowerCase().includes(q) || c.shortHash.includes(q)) }))
      .filter((g) => g.commits.length > 0 || g.key.toLowerCase().includes(q));
  });

  selectedCount = computed(() => this.selected().size);
  selectedCommitsOrdered = computed(() => {
    const out: string[] = [];
    for (const g of this.groups()) for (const c of g.commits) if (this.selected().has(c.hash)) out.push(c.hash);
    return out;
  });
  mustBranch = computed(() => this.targetProtected() || this.forceNewBranch());
  canRun = computed(() => {
    if (this.selectedCount() === 0 || !this.target()) return false;
    if (this.mustBranch() && !this.newBranch().trim()) return false;
    return true;
  });

  ngOnInit() { this.loadRepos(); }
  loadRepos() { this.run(this.api.repos(), (r) => { this.projectGroups.set(r.groups); this.gitlabOn.set(r.gitlab); }); }

  chooseRepo(r: RepoRef) {
    if (!r.localPath) { this.error.set(`"${r.name}" isn't cloned locally. Clone it first to operate on it.`); return; }
    this.activeRepo.set(r);
    const key = r.localPath;
    this.busy.set(true); this.error.set(null);
    this.api.connect(key).subscribe({
      next: (res) => {
        this.busy.set(false);
        this.repoRoot.set(res.repoKey || res.root);
        this.source.set(res.currentBranch || 'develop');
        this.loadBranches(() => { if (!this.branches().some((b) => b.name === this.source())) this.source.set(res.currentBranch); });
        this.step.set('pick');
      },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Connect failed.'); },
    });
  }
  changeRepo() {
    this.step.set('repos'); this.groups.set([]); this.selected.set(new Set());
    this.state.set(null); this.dryResults.set(null); this.pushed.set(null);
  }

  loadBranches(then?: () => void) { this.run(this.api.branches(this.repoKey), (r) => { this.branches.set(r.branches); then?.(); }); }
  fetchAll() { this.run(this.api.fetchAll(this.repoKey), (r) => { this.flash(r.output || 'Fetched.'); this.loadBranches(); }); }
  loadCommits() {
    if (!this.source()) return;
    this.run(this.api.commits(this.repoKey, this.source(), this.target()), (r) => {
      this.groups.set(r.groups); this.total.set(r.total);
      this.selected.set(new Set()); this.dryResults.set(null); this.state.set(null); this.pushed.set(null);
    });
    if (this.target()) this.checkProtection();
  }
  checkProtection() {
    if (!this.target()) return;
    this.api.protectedCheck(this.repoKey, this.target()).subscribe({
      next: (r) => { this.targetProtected.set(r.isProtected); if (r.isProtected && !this.newBranch()) this.newBranch.set(this.suggestBranchName()); },
      error: () => {},
    });
  }
  suggestBranchName() {
    const t = this.target().replace(/^remotes\/[^/]+\//, '').replace(/[^\w./-]/g, '-');
    return `cherry/${t}-${new Date().toISOString().slice(0, 10)}`;
  }

  toggleCommit(h: string) { const s = new Set(this.selected()); s.has(h) ? s.delete(h) : s.add(h); this.selected.set(s); }
  isSelected(h: string) { return this.selected().has(h); }
  toggleGroup(g: SubjectGroup) {
    const s = new Set(this.selected());
    const allOn = g.commits.every((c) => s.has(c.hash));
    for (const c of g.commits) allOn ? s.delete(c.hash) : s.add(c.hash);
    this.selected.set(s);
  }
  groupState(g: SubjectGroup): 'all' | 'some' | 'none' {
    const on = g.commits.filter((c) => this.selected().has(c.hash)).length;
    if (on === 0) return 'none'; return on === g.commits.length ? 'all' : 'some';
  }
  toggleCollapse(k: string) { const s = new Set(this.collapsed()); s.has(k) ? s.delete(k) : s.add(k); this.collapsed.set(s); }
  selectAll() { const s = new Set<string>(); for (const g of this.filteredGroups()) for (const c of g.commits) s.add(c.hash); this.selected.set(s); }
  clearAll() { this.selected.set(new Set()); }

  dryRun() {
    if (!this.canRun()) return;
    this.run(this.api.dryRun({ repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(), newBranch: this.newBranch() }),
      (r) => this.dryResults.set(r.results));
  }

  apply() {
    if (!this.canRun()) return;
    this.busy.set(true); this.error.set(null); this.dryResults.set(null);
    this.api.start({
      repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(),
      forceNewBranch: this.forceNewBranch(), newBranch: this.mustBranch() ? this.newBranch().trim() : undefined,
    }).subscribe({
      next: (s) => { this.busy.set(false); this.state.set(s); if (s.status === 'done') { this.prefillMr(s); this.flash(`Applied ${s.applied} commit(s).`); } },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Cherry-pick failed.'); },
    });
  }

  onResolved(resolutions: { file: string; content: string }[]) {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.busy.set(true); this.error.set(null);
    this.api.resolve({ repoKey: this.repoKey, workBranch: wb, resolutions }).subscribe({
      next: (s) => { this.busy.set(false); this.state.set(s);
        if (s.status === 'done') { this.prefillMr(s); this.flash(`Resolved & applied ${s.applied} commit(s).`); }
        else this.flash('Resolved — next conflict.'); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Resolve failed.'); },
    });
  }
  onAbort() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.api.abort({ repoKey: this.repoKey, workBranch: wb }).subscribe({
      next: () => { this.state.set(null); this.flash('Cherry-pick aborted. Nothing applied.'); },
      error: (e) => this.error.set(e?.error?.error || 'Abort failed.'),
    });
  }

  prefillMr(s: CherryPickState) {
    this.mrTarget.set(this.target());
    this.mrTitle.set(`Cherry-pick ${s.applied} commit(s) into ${this.target()}`);
    this.mrResult.set(null); this.showMr.set(false);
  }
  openMr() { this.showMr.set(true); }
  raiseMr() {
    const wb = this.state()?.workBranch; if (!wb || !this.mrTitle().trim() || !this.mrTarget().trim()) return;
    const labels = this.mrLabels().split(',').map((x) => x.trim()).filter(Boolean);
    this.busy.set(true); this.error.set(null);
    this.api.mergeRequest({ repoKey: this.repoKey, sourceBranch: wb, targetBranch: this.mrTarget().trim(),
      title: this.mrTitle().trim(), description: this.mrDesc(), removeSourceBranch: this.mrRemoveSource(),
      squash: this.mrSquash(), labels }).subscribe({
      next: (r) => { this.busy.set(false); this.mrResult.set(r); if (r.ok) this.flash(`MR !${r.iid} created.`); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'MR failed.'); },
    });
  }
  push() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.busy.set(true); this.error.set(null);
    this.api.push({ repoKey: this.repoKey, branch: wb, setUpstream: true }).subscribe({
      next: (r) => { this.busy.set(false); this.pushed.set(r); this.flash(`Pushed ${wb}.`); },
      error: (e) => { this.busy.set(false); this.error.set(e?.error?.error || 'Push failed.'); },
    });
  }
  fixSql(w: SqlWarning) {
    this.api.fixSql(this.repoKey, w.file).subscribe({
      next: () => { const s = new Set(this.sqlFixed()); s.add(w.file); this.sqlFixed.set(s); this.flash(`Added trailing / to ${w.file}`); },
      error: (e) => this.error.set(e?.error?.error || 'Fix failed.'),
    });
  }
  isFixed(f: string) { return this.sqlFixed().has(f); }
  copy(t: string) { navigator.clipboard?.writeText(t); this.flash('Copied.'); }

  private run<T>(obs: Observable<T>, ok: (r: T) => void) {
    this.busy.set(true); this.error.set(null);
    obs.subscribe({ next: (r: T) => { this.busy.set(false); ok(r); },
      error: (e: any) => { this.busy.set(false); this.error.set(e?.error?.error || 'Request failed.'); } });
  }
  private flash(m: string) { this.toast.set(m); setTimeout(() => this.toast.set(null), 3200); }
}
