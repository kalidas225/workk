package com.bnpparibas.releasecockpit.model;

import java.time.LocalDate;
import java.util.List;

/**
 * Core domain models for the Release Guardian, expressed as immutable Java
 * records (Java 21). These are the shapes that flow from connectors -> services
 * -> REST DTOs.
 */
public final class Domain {

    private Domain() {}

    /** A release configured in Jira (a fixVersion) for the year. */
    public record Release(
            String id,
            String name,            // e.g. "25.07"
            LocalDate releaseDate,  // the GA / production date from Jira
            boolean released,       // true once releaseDate has passed / archived
            String description
    ) {}

    /**
     * The intelligent date checkpoints derived from the release date.
     * Legacy fields (ppdStart, endUatDone) are retained for the health/timeline
     * logic; the richer milestone set drives the modern timeline.
     */
    public record Checkpoints(
            LocalDate releaseDate,
            LocalDate ppdStart,       // legacy: releaseDate - 14 days (== ppd1)
            LocalDate endUatDone,     // releaseDate - 21 days
            String ppdStatus,
            String endUatStatus,
            long daysToRelease,
            List<Milestone> timeline, // ordered milestones for the UI
            LocalDate docCutoff       // documents deadline (pushes devs); does NOT change releaseDate
    ) {
        // Backwards-compatible constructor without docCutoff.
        public Checkpoints(LocalDate releaseDate, LocalDate ppdStart, LocalDate endUatDone,
                           String ppdStatus, String endUatStatus, long daysToRelease, List<Milestone> timeline) {
            this(releaseDate, ppdStart, endUatDone, ppdStatus, endUatStatus, daysToRelease, timeline, null);
        }
    }

    /** One milestone on the release timeline. */
    public record Milestone(
            String key,        // PPD1 | PPD1_ROLLBACK | PPD2 | LCAB | END_UAT | RELEASE
            String label,
            LocalDate date,
            String status,     // UPCOMING | DUE_SOON | ACTIVE | OVERDUE | DONE
            boolean overridden // true if the date came from a JSON override
    ) {}

    /** A single subject (Jira epic) tagged for a release. */
    public record Subject(
            String key,             // e.g. "REL-1042"
            String summary,
            String status,
            String developerName,
            String developerEmail,
            String reporterName,
            String reporterEmail,
            LocalDate createdDate,
            List<String> octaneIds, // Octane test-case IDs listed on the epic
            Readiness readiness
    ) {}

    /** Readiness of one subject across Octane + SharePoint artifacts. */
    public record Readiness(
            boolean octaneTestsLinked,
            boolean prDoc,
            boolean unitTest,
            boolean estimationSheet,
            boolean prExcel,
            boolean octaneReviewDoc,
            boolean octaneExecutionDoc,
            int missingCount,
            List<String> missing,   // keys of missing items, for the email
            String octaneUrl,       // Octane test-tab URL for this subject's feature
            List<String> octaneMissingEnvs, // required env buckets with problems (Dev/IST/UAT/BCM)
            int totalRuns,          // total Octane runs across envs
            int passedRuns,
            int failedRuns,
            java.util.Map<String,String> octaneEnvSummary, // env -> "3✓" / "1✗" / "no run"
            List<String> octaneDetail, // per-test transparency lines (which test, state, run)
            List<String> sharepointDetail // per-artifact SharePoint lines (found/missing + folder link)
    ) {
        // Backwards-compatible constructor without sharepointDetail.
        public Readiness(boolean octaneTestsLinked, boolean prDoc, boolean unitTest, boolean estimationSheet,
                         boolean prExcel, boolean octaneReviewDoc, boolean octaneExecutionDoc, int missingCount,
                         List<String> missing, String octaneUrl, List<String> octaneMissingEnvs,
                         int totalRuns, int passedRuns, int failedRuns,
                         java.util.Map<String,String> octaneEnvSummary, List<String> octaneDetail) {
            this(octaneTestsLinked, prDoc, unitTest, estimationSheet, prExcel, octaneReviewDoc, octaneExecutionDoc,
                 missingCount, missing, octaneUrl, octaneMissingEnvs, totalRuns, passedRuns, failedRuns,
                 octaneEnvSummary, octaneDetail, List.of());
        }
    }

    /** Aggregated counts for the pie charts on the dashboard. */
    public record ReleaseSummary(
            String releaseName,
            int totalSubjects,
            int ready,
            int notReady,
            List<DeveloperLoad> developerDistribution,
            ReadinessBreakdown readinessBreakdown
    ) {}

    public record DeveloperLoad(String developer, int subjectCount) {}

    public record ReadinessBreakdown(
            int octaneOk, int octaneMissing,
            int sharepointOk, int sharepointMissing
    ) {}

    /**
     * A composite "release health" score (0-100) plus a letter grade and the
     * factors that fed it, for the health meter on the dashboard.
     */
    public record ReleaseHealth(
            int score,              // 0-100
            String grade,           // EXCELLENT | GOOD | AT_RISK | CRITICAL
            int readinessScore,     // % of subjects fully ready
            int octaneScore,        // % with Octane linked
            int sharepointScore,    // % SharePoint-complete
            int timelineScore,      // derived from checkpoint statuses
            List<String> risks      // human-readable risk notes
    ) {}

    /** Live connection status of one upstream system (Jira/SharePoint/Octane/ServiceNow). */
    public record ConnectionStatus(
            String system,          // JIRA | SHAREPOINT | OCTANE | SERVICENOW
            String status,          // UP | DOWN | DEGRADED | MOCK | NOT_CONFIGURED
            String detail,          // e.g. resolved site title, or error text
            long latencyMs
    ) {}

    /**
     * A ServiceNow ticket linked to a release (change request / incident / etc).
     * Surfaced in the dashboard so users don't leave to check ServiceNow.
     */
    public record ServiceNowTicket(
            String number,          // e.g. CHG0030456
            String shortDescription,
            String state,           // e.g. New, Assess, Implement, Closed
            String priority,
            String assignedTo,
            String type,            // change_request | incident | problem
            String url,             // deep link into ServiceNow
            String env,             // PPD1 | PPD2 | PROD | "" (derived from title tag)
            String startDate,       // planned start (change) — drives timeline dates
            String endDate,         // planned end
            List<CTask> ctasks      // change tasks under this change
    ) {
        // Backwards-compatible constructors.
        public ServiceNowTicket(String number, String shortDescription, String state,
                                String priority, String assignedTo, String type, String url) {
            this(number, shortDescription, state, priority, assignedTo, type, url, "", "", "", List.of());
        }
        public ServiceNowTicket(String number, String shortDescription, String state,
                                String priority, String assignedTo, String type, String url, String env) {
            this(number, shortDescription, state, priority, assignedTo, type, url, env, "", "", List.of());
        }
    }

    /** A ServiceNow change task (CTASK) under a change. */
    public record CTask(
            String number,          // CTASKxxxx
            String shortDescription,
            String state,
            String assignedTo,
            String plannedStart,
            String plannedEnd,
            boolean rollback        // true if this is a rollback task
    ) {}

    /**
     * All ServiceNow records tied to a release: changes grouped by environment
     * (PPD-1, PPD-2, Prod), plus incidents and problems linked to those changes
     * (caused-by), surfaced after the Prod release.
     */
    public record ReleaseChanges(
            List<ServiceNowTicket> ppd1,
            List<ServiceNowTicket> ppd2,
            List<ServiceNowTicket> prod,
            List<ServiceNowTicket> incidents,
            List<ServiceNowTicket> problems,
            boolean enabled,
            List<ServiceNowTicket> extraPpd   // PPD-3 and beyond (each carries its env)
    ) {}


    /**
     * Per-subject check override. Controls which checks apply to a subject:
     *   - octaneEnvironments: which Octane environments must pass (e.g. UAT only)
     *   - bcmEndToEnd: whether BCM end-to-end testing is required
     *   - skipSharePoint: artifact keys (folders) that don't apply to this subject
     */
    public record SubjectCheckConfig(
            List<String> octaneEnvironments,
            boolean bcmEndToEnd,
            List<String> skipSharePoint,
            String note
    ) {}
}
