// Mirrors the backend domain model (com.bnpparibas.releasecockpit.model.Domain)

export interface Release {
  id: string;
  name: string;
  releaseDate: string;      // ISO date
  released: boolean;
  description: string;
}

export interface Milestone {
  key: string;
  label: string;
  date: string;
  status: 'UPCOMING' | 'DUE_SOON' | 'ACTIVE' | 'OVERDUE' | 'DONE' | 'CANCELLED';
  overridden: boolean;
  changeNumber?: string;
  changeUrl?: string;
}

export interface Checkpoints {
  releaseDate: string;
  ppdStart: string;
  endUatDone: string;
  ppdStatus: 'UPCOMING' | 'ACTIVE' | 'OVERDUE' | 'DONE' | 'UNKNOWN';
  endUatStatus: 'UPCOMING' | 'DUE_SOON' | 'OVERDUE' | 'DONE' | 'UNKNOWN';
  daysToRelease: number;
  timeline: Milestone[];
}

export interface Readiness {
  octaneTestsLinked: boolean;
  prDoc: boolean;
  unitTest: boolean;
  estimationSheet: boolean;
  prExcel: boolean;
  octaneReviewDoc: boolean;
  octaneExecutionDoc: boolean;
  missingCount: number;
  missing: string[];
  octaneUrl?: string | null;
  octaneMissingEnvs?: string[];
  totalRuns?: number;
  passedRuns?: number;
  failedRuns?: number;
  octaneEnvSummary?: Record<string, string>;
  octaneDetail?: string[];
  sharepointDetail?: string[];
}

export interface Subject {
  key: string;
  summary: string;
  status: string;
  developerName: string;
  developerEmail: string;
  reporterName: string;
  reporterEmail: string;
  createdDate: string;
  octaneIds: string[];
  readiness: Readiness;
}

export interface DeveloperLoad { developer: string; subjectCount: number; }

export interface ReadinessBreakdown {
  octaneOk: number; octaneMissing: number;
  sharepointOk: number; sharepointMissing: number;
}

export interface ReleaseSummary {
  releaseName: string;
  totalSubjects: number;
  ready: number;
  notReady: number;
  developerDistribution: DeveloperLoad[];
  readinessBreakdown: ReadinessBreakdown;
}

export interface ReleaseHealth {
  score: number;
  grade: 'EXCELLENT' | 'GOOD' | 'AT_RISK' | 'CRITICAL';
  readinessScore: number;
  octaneScore: number;
  sharepointScore: number;
  timelineScore: number;
  risks: string[];
}

export interface ConnectionStatus {
  system: 'JIRA' | 'SHAREPOINT' | 'OCTANE' | 'SERVICENOW';
  status: 'UP' | 'DOWN' | 'DEGRADED' | 'MOCK' | 'NOT_CONFIGURED';
  detail: string;
  latencyMs: number;
}

export interface CTask {
  number: string;
  shortDescription: string;
  state: string;
  assignedTo: string;
  plannedStart: string;
  plannedEnd: string;
  rollback: boolean;
}

export interface ServiceNowTicket {
  number: string;
  shortDescription: string;
  state: string;
  priority: string;
  assignedTo: string;
  type: string;
  url: string;
  env?: string;   // PPD1 | PPD2 | PROD | ''
  startDate?: string;
  endDate?: string;
  ctasks?: CTask[];
}

export interface ReleaseChanges {
  ppd1: ServiceNowTicket[];
  ppd2: ServiceNowTicket[];
  prod: ServiceNowTicket[];
  extraPpd?: ServiceNowTicket[];
  incidents: ServiceNowTicket[];
  problems: ServiceNowTicket[];
  enabled: boolean;
}

export interface SubjectCheckConfig {
  octaneEnvironments: string[];
  bcmEndToEnd: boolean;
  skipSharePoint: string[];
  note?: string;
}

export interface ChecksConfig {
  default: SubjectCheckConfig;
  overrides: Record<string, SubjectCheckConfig>;
}

export interface Page<T> {
  content: T[];
  page: number;
  size: number;
  totalElements: number;
}

export const ARTIFACT_LABELS: Record<string, string> = {
  OCTANE_TESTS_LINKED: 'Octane tests linked',
  PR: 'PR document',
  UNIT_TEST: 'Unit test',
  ESTIMATION_SHEET: 'Estimation sheet',
  PR_EXCEL: 'Peer Review Document',
  OCTANE_REVIEW_DOC: 'Octane Testcase Review Document',
  OCTANE_EXECUTION_DOC: 'Octane Testcase Execution Document',
};
