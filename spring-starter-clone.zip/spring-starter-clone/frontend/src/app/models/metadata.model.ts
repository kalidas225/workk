export interface Dependency {
  id: string;
  name: string;
  description: string;
  groupId: string;
  artifactId: string;
  version: string | null;
  scope: string;
  category: string;
  incompatibleWith: string[];
  minBootVersion: string | null;
  maxBootVersion: string | null;
}

export interface DependencyCategory {
  name: string;
  dependencies: Dependency[];
}

export interface ProjectDefaults {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
}

export interface MetadataResponse {
  types: string[];
  languages: string[];
  bootVersions: string[];
  packagings: string[];
  javaVersions: string[];
  defaults: ProjectDefaults;
  dependencies: DependencyCategory[];
}

export interface ProjectRequest {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
  dependencies: string[];
}
