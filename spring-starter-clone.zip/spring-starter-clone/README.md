# Spring Starter Clone

A self-hosted clone of [start.spring.io](https://start.spring.io) — generates ready-to-run Spring Boot project zips. Frontend in **Angular 18**, backend in **Java 21 + Spring Boot 3.3.5**.

The generator service itself runs on Java 21, but the *generated* projects can target Java 8, 11, 17, 21, 22, or 23 — the selected version is injected into the produced POM / `build.gradle`.

---

## Features

- **Build tool**: Maven, Gradle (Groovy DSL), Gradle (Kotlin DSL)
- **Language**: Java, Kotlin, Groovy
- **Spring Boot versions**: 3.3.5, 3.3.4, 3.2.11, 3.1.12
- **Java versions**: 8, 11, 17, 21, 22, 23 — the selection drives `<java.version>` in the generated POM and the Gradle toolchain block
- **Packaging**: JAR or WAR (WAR adds `spring-boot-starter-tomcat` as `provided` / `providedRuntime`)
- **40+ starter dependencies** grouped by category, matching the start.spring.io taxonomy:
  - Developer Tools (Devtools, Lombok, Configuration Processor, Docker Compose)
  - Web (Web, Reactive Web, GraphQL, WebSocket, Session, Data REST)
  - Template Engines (Thymeleaf, Freemarker, Mustache, Groovy Templates)
  - Security (Spring Security, OAuth2 Client / Resource Server / Auth Server)
  - SQL (JPA, JDBC, MySQL, PostgreSQL, H2, HSQL, Derby, MSSQL, Oracle, Flyway, Liquibase)
  - NoSQL (Redis, MongoDB, Elasticsearch, Cassandra, Neo4j)
  - Messaging (RabbitMQ, Kafka, Kafka Streams, ActiveMQ, Artemis)
  - I/O (Batch, Integration, Validation, Mail, Quartz)
  - Ops (Actuator, Prometheus, Cloud Config, Eureka)
  - Testing (Testcontainers, REST Docs)
- **Smart Lombok handling**: emitted as `provided` + `optional`, and excluded from the Spring Boot Maven plugin repackage step
- **Live form**: package name auto-derives from group + artifact (until you edit it manually)
- **Searchable dependency picker**: full-text search across name, category, and description with keyboard navigation (↑/↓/Enter/Esc)
- **Keyboard shortcuts**: `⌘B` opens dependency picker · `⌘Enter` generates
- **Validation**: server- and client-side — invalid group/artifact/package names rejected with clear messages

---

## Project structure

```
spring-starter-clone/
├── backend/                          # Java 21 / Spring Boot 3.3.5
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/starterclone/generator/
│       │   ├── GeneratorApplication.java       (entry point)
│       │   ├── config/CorsConfig.java
│       │   ├── controller/
│       │   │   ├── MetadataController.java     (GET /api/metadata)
│       │   │   └── GeneratorController.java    (POST /api/generate)
│       │   ├── exception/
│       │   │   ├── GenerationException.java
│       │   │   └── GlobalExceptionHandler.java
│       │   ├── model/                          (Java records: Dependency, ProjectRequest, etc.)
│       │   └── service/
│       │       ├── DependencyCatalogService.java   (in-memory starter catalog)
│       │       ├── MetadataService.java
│       │       ├── ProjectGeneratorService.java    (assembles the ZIP)
│       │       ├── PomBuilder.java                 (writes pom.xml)
│       │       ├── GradleBuilder.java              (writes build.gradle[.kts])
│       │       └── SourceTemplateService.java      (main class, tests, .gitignore, README, application.properties)
│       ├── main/resources/application.properties
│       └── test/java/com/starterclone/generator/
│           ├── GeneratorApplicationTests.java
│           └── ProjectGeneratorServiceTests.java
│
└── frontend/                         # Angular 18 (standalone components, signals)
    ├── package.json
    ├── angular.json
    ├── proxy.conf.json               (dev proxy /api -> http://localhost:8080)
    └── src/
        ├── index.html
        ├── styles.scss
        ├── main.ts
        └── app/
            ├── app.config.ts          (HttpClient + Animations providers)
            ├── app.component.{ts,html,scss}
            ├── models/metadata.model.ts
            └── services/starter-api.service.ts
```

---

## Running locally

### Prerequisites

- **Java 21+** (for the backend)
- **Maven 3.6+** (or use the wrapper)
- **Node 18+** and **npm**
- An internet connection on first run, so Maven and npm can fetch dependencies

### 1. Start the backend

```bash
cd backend
mvn spring-boot:run
```

The backend listens on **`http://localhost:8080`**. Two endpoints:

| Method | Path | Description |
| ------ | ---- | ----------- |
| `GET`  | `/api/metadata` | Returns options + dependency catalog as JSON |
| `POST` | `/api/generate` | Body: `ProjectRequest` JSON. Returns the project as `application/zip` with a `Content-Disposition` filename. |

You can sanity-check it with curl:

```bash
curl http://localhost:8080/api/metadata | head -c 400

curl -X POST http://localhost:8080/api/generate \
  -H "Content-Type: application/json" \
  -d '{"type":"maven","language":"java","bootVersion":"3.3.5","groupId":"com.example","artifactId":"demo","name":"demo","description":"Demo","packageName":"com.example.demo","packaging":"jar","javaVersion":"21","dependencies":["web","data-jpa","h2"]}' \
  -o demo.zip
unzip -l demo.zip
```

### 2. Start the frontend

```bash
cd frontend
npm install      # first time only
npm start        # runs `ng serve` on :4200 with the API proxy
```

Open **`http://localhost:4200`** in a browser. The dev server proxies `/api/**` to the backend on port 8080, so there's no CORS in development.

### 3. Production build of the frontend

```bash
cd frontend
npm run build
# output is in dist/frontend/browser — static files you can serve from any static host
```

---

## Backend tests

```bash
cd backend
mvn test
```

Includes `ProjectGeneratorServiceTests` which:
- Generates a Maven + Java project with several deps and asserts every expected file is in the zip
- Generates a Gradle + Kotlin project with WAR packaging and asserts the Kotlin-specific entries are present

---

## How the generator works

`ProjectGeneratorService` is the orchestrator:

1. **Resolve dependencies** — IDs from the request are looked up in `DependencyCatalogService`. Unknown IDs are rejected with `GenerationException`.
2. **Build the build file** —
   - Maven → `PomBuilder` writes `pom.xml` with the selected Spring Boot parent, `<java.version>` from the request, all selected starters with correct scopes, plus the test starter. Lombok is added as `provided` + `optional` and excluded from the Spring Boot plugin repackage.
   - Gradle Groovy → `GradleBuilder.buildGroovy` writes `build.gradle` with `id 'org.springframework.boot' version '<bootVersion>'` and `JavaLanguageVersion.of(<javaVersion>)`.
   - Gradle Kotlin → `GradleBuilder.buildKotlin` writes `build.gradle.kts` with the same.
3. **Write source files** — Language-aware: Java → `.java`, Kotlin → `.kt`, Groovy → `.groovy`. Class name derived from the artifact ID (`demo` → `DemoApplication`). A matching `*ApplicationTests` test class is generated.
4. **Add resources** — `application.properties`, empty `static/` and `templates/` directories.
5. **Add metadata files** — `.gitignore` (build-tool-aware), `README.md`, `HELP.md` listing every selected dependency with description and coordinates.
6. **Stream into a `ZipOutputStream`** — returned to the controller as `byte[]`. The controller sets `Content-Type: application/zip` and `Content-Disposition: attachment; filename="<artifactId>.zip"`.

---

## Notes & design choices

- **In-memory catalog vs. metadata YAML.** Spring's real Initializr loads its catalog from a YAML file. We keep ours in code (`DependencyCatalogService`) so the service is self-contained and works fully offline once running.
- **Maven & Gradle wrappers.** The real start.spring.io ships `mvnw` / `gradlew` binaries in the zip. We include a stub `README.md` inside `.mvn/wrapper/` (or `gradle/wrapper/`) telling the user to run `mvn -N wrapper:wrapper` (or `gradle wrapper`) themselves — this avoids shipping binary blobs and keeps the generated project text-only.
- **Signals + standalone components.** The frontend uses Angular 18's standalone components and `signal()`/`computed()` rather than the classic NgModules + RxJS BehaviorSubject pattern — simpler state, fewer subscriptions to manage.
- **Editorial UI.** The look is intentionally not the typical SaaS template: serif display type (Fraunces), monospace for technical text (JetBrains Mono), warm paper palette with a single burnt-sienna accent. The result is closer to a print magazine than a generic webapp form.
- **No external CSS framework.** Everything is hand-written SCSS with CSS variables for tokens — easier to audit and modify than wrestling Tailwind config.

---

## License

MIT — do whatever you like with this.
