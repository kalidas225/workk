package com.starterclone.generator.service;

import com.starterclone.generator.model.MetadataResponse;
import com.starterclone.generator.model.ProjectDefaults;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MetadataService {

    public static final List<String> BUILD_TYPES = List.of("maven", "gradle-groovy", "gradle-kotlin");
    public static final List<String> LANGUAGES = List.of("java", "kotlin", "groovy");
    public static final List<String> BOOT_VERSIONS = List.of("3.3.5", "3.3.4", "3.2.11", "3.1.12");
    public static final List<String> PACKAGINGS = List.of("jar", "war");
    public static final List<String> JAVA_VERSIONS = List.of("21", "17", "11", "8");

    private final DependencyCatalogService catalog;

    public MetadataService(DependencyCatalogService catalog) {
        this.catalog = catalog;
    }

    public MetadataResponse getMetadata() {
        ProjectDefaults defaults = new ProjectDefaults(
                "maven",
                "java",
                "3.3.5",
                "com.example",
                "demo",
                "demo",
                "Demo project for Spring Boot",
                "com.example.demo",
                "jar",
                "21"
        );
        return new MetadataResponse(
                BUILD_TYPES,
                LANGUAGES,
                BOOT_VERSIONS,
                PACKAGINGS,
                JAVA_VERSIONS,
                defaults,
                catalog.getCategories()
        );
    }
}
