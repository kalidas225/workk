package com.starterclone.generator.service;

import com.starterclone.generator.model.ProjectRequest;
import org.springframework.stereotype.Component;

@Component
public class SourceTemplateService {

    public String mainClass(ProjectRequest req) {
        String className = toClassName(req.artifactId()) + "Application";
        return switch (req.language()) {
            case "kotlin" -> kotlinMain(req, className);
            case "groovy" -> groovyMain(req, className);
            default -> javaMain(req, className);
        };
    }

    public String testClass(ProjectRequest req) {
        String className = toClassName(req.artifactId()) + "ApplicationTests";
        return switch (req.language()) {
            case "kotlin" -> kotlinTest(req, className);
            case "groovy" -> groovyTest(req, className);
            default -> javaTest(req, className);
        };
    }

    public String mainClassName(ProjectRequest req) {
        return toClassName(req.artifactId()) + "Application";
    }

    public String testClassName(ProjectRequest req) {
        return toClassName(req.artifactId()) + "ApplicationTests";
    }

    public String applicationProperties() {
        return "# Default Spring Boot configuration\n" +
                "spring.application.name=app\n";
    }

    public String gitignore(String type) {
        boolean maven = "maven".equals(type);
        StringBuilder sb = new StringBuilder();
        sb.append("HELP.md\n");
        if (maven) {
            sb.append("target/\n");
            sb.append("!.mvn/wrapper/maven-wrapper.jar\n");
            sb.append("!**/src/main/**/target/\n");
            sb.append("!**/src/test/**/target/\n\n");
        } else {
            sb.append(".gradle\n");
            sb.append("build/\n");
            sb.append("!gradle/wrapper/gradle-wrapper.jar\n");
            sb.append("!**/src/main/**/build/\n");
            sb.append("!**/src/test/**/build/\n\n");
        }
        sb.append("### STS ###\n.apt_generated\n.classpath\n.factorypath\n.project\n.settings\n.springBeans\n.sts4-cache\n\n");
        sb.append("### IntelliJ IDEA ###\n.idea\n*.iws\n*.iml\n*.ipr\n\n");
        sb.append("### NetBeans ###\n/nbproject/private/\n/nbbuild/\n/dist/\n/nbdist/\n/.nb-gradle/\nbuild/\n!**/src/main/**/build/\n!**/src/test/**/build/\n\n");
        sb.append("### VS Code ###\n.vscode/\n");
        return sb.toString();
    }

    public String readme(ProjectRequest req) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(req.name()).append("\n\n");
        if (req.description() != null && !req.description().isBlank()) {
            sb.append(req.description()).append("\n\n");
        }
        sb.append("Generated with the Spring Initializr clone.\n\n");
        sb.append("## Quick Start\n\n");
        if ("maven".equals(req.type())) {
            sb.append("```bash\n./mvnw spring-boot:run\n```\n\n");
        } else {
            sb.append("```bash\n./gradlew bootRun\n```\n\n");
        }
        sb.append("## Build\n\n");
        if ("maven".equals(req.type())) {
            sb.append("```bash\n./mvnw clean package\n```\n");
        } else {
            sb.append("```bash\n./gradlew build\n```\n");
        }
        return sb.toString();
    }

    // --- Java templates ---
    private String javaMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + ";\n\n" +
                "import org.springframework.boot.SpringApplication;\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication;\n\n" +
                "@SpringBootApplication\n" +
                "public class " + className + " {\n\n" +
                "    public static void main(String[] args) {\n" +
                "        SpringApplication.run(" + className + ".class, args);\n" +
                "    }\n" +
                "}\n";
    }

    private String javaTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + ";\n\n" +
                "import org.junit.jupiter.api.Test;\n" +
                "import org.springframework.boot.test.context.SpringBootTest;\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    void contextLoads() {\n" +
                "    }\n\n" +
                "}\n";
    }

    private String kotlinMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication\n" +
                "import org.springframework.boot.runApplication\n\n" +
                "@SpringBootApplication\n" +
                "class " + className + "\n\n" +
                "fun main(args: Array<String>) {\n" +
                "    runApplication<" + className + ">(*args)\n" +
                "}\n";
    }

    private String kotlinTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.junit.jupiter.api.Test\n" +
                "import org.springframework.boot.test.context.SpringBootTest\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    fun contextLoads() {\n" +
                "    }\n" +
                "}\n";
    }

    private String groovyMain(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.springframework.boot.SpringApplication\n" +
                "import org.springframework.boot.autoconfigure.SpringBootApplication\n\n" +
                "@SpringBootApplication\n" +
                "class " + className + " {\n\n" +
                "    static void main(String[] args) {\n" +
                "        SpringApplication.run(" + className + ", args)\n" +
                "    }\n" +
                "}\n";
    }

    private String groovyTest(ProjectRequest req, String className) {
        return "package " + req.packageName() + "\n\n" +
                "import org.junit.jupiter.api.Test\n" +
                "import org.springframework.boot.test.context.SpringBootTest\n\n" +
                "@SpringBootTest\n" +
                "class " + className + " {\n\n" +
                "    @Test\n" +
                "    void contextLoads() {\n" +
                "    }\n" +
                "}\n";
    }

    private static String toClassName(String artifactId) {
        StringBuilder sb = new StringBuilder();
        boolean upper = true;
        for (char c : artifactId.toCharArray()) {
            if (c == '-' || c == '_' || c == '.') {
                upper = true;
                continue;
            }
            if (upper) {
                sb.append(Character.toUpperCase(c));
                upper = false;
            } else {
                sb.append(c);
            }
        }
        if (sb.length() == 0) return "Application";
        return sb.toString();
    }
}
