package com.starterclone.generator.model;

import java.util.List;

public record MetadataResponse(
        List<String> types,
        List<String> languages,
        List<String> bootVersions,
        List<String> packagings,
        List<String> javaVersions,
        ProjectDefaults defaults,
        List<DependencyCategory> dependencies
) {
}
