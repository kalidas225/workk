package com.starterclone.generator.service;

import com.starterclone.generator.exception.GenerationException;
import com.starterclone.generator.model.Dependency;
import com.starterclone.generator.model.ProjectRequest;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Assembles a Spring Boot project as a ZIP file in memory based on a request.
 */
@Service
public class ProjectGeneratorService {

    private final DependencyCatalogService catalog;
    private final PomBuilder pomBuilder;
    private final GradleBuilder gradleBuilder;
    private final SourceTemplateService templates;

    public ProjectGeneratorService(DependencyCatalogService catalog,
                                   PomBuilder pomBuilder,
                                   GradleBuilder gradleBuilder,
                                   SourceTemplateService templates) {
        this.catalog = catalog;
        this.pomBuilder = pomBuilder;
        this.gradleBuilder = gradleBuilder;
        this.templates = templates;
    }

    public byte[] generate(ProjectRequest request) {
        // Resolve and de-duplicate dependencies
        List<Dependency> resolved = resolveAndValidate(request);

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             ZipOutputStream zip = new ZipOutputStream(baos)) {

            String root = request.artifactId() + "/";

            // Source folder layout depends on language
            String langDir = switch (request.language()) {
                case "kotlin" -> "kotlin";
                case "groovy" -> "groovy";
                default -> "java";
            };

            String packagePath = request.packageName().replace('.', '/');
            String mainSrc = root + "src/main/" + langDir + "/" + packagePath + "/";
            String testSrc = root + "src/test/" + langDir + "/" + packagePath + "/";
            String resourcesDir = root + "src/main/resources/";

            // Build script
            if ("maven".equals(request.type())) {
                writeEntry(zip, root + "pom.xml", pomBuilder.build(request, resolved));
                writeWrapperEntries(zip, root, true);
            } else if ("gradle-kotlin".equals(request.type())) {
                writeEntry(zip, root + "build.gradle.kts", gradleBuilder.buildKotlin(request, resolved));
                writeEntry(zip, root + "settings.gradle.kts", gradleBuilder.settingsKotlin(request));
                writeWrapperEntries(zip, root, false);
            } else {
                writeEntry(zip, root + "build.gradle", gradleBuilder.buildGroovy(request, resolved));
                writeEntry(zip, root + "settings.gradle", gradleBuilder.settingsGroovy(request));
                writeWrapperEntries(zip, root, false);
            }

            // Source files
            String mainExt = switch (request.language()) {
                case "kotlin" -> ".kt";
                case "groovy" -> ".groovy";
                default -> ".java";
            };
            writeEntry(zip, mainSrc + templates.mainClassName(request) + mainExt, templates.mainClass(request));
            writeEntry(zip, testSrc + templates.testClassName(request) + mainExt, templates.testClass(request));

            // Resources
            writeEntry(zip, resourcesDir + "application.properties", templates.applicationProperties());

            // create empty static and templates dirs by adding placeholder files
            writeEntry(zip, resourcesDir + "static/.gitkeep", "");
            writeEntry(zip, resourcesDir + "templates/.gitkeep", "");

            // root-level files
            writeEntry(zip, root + ".gitignore", templates.gitignore(request.type()));
            writeEntry(zip, root + "README.md", templates.readme(request));

            // Optional: HELP.md listing dependencies
            writeEntry(zip, root + "HELP.md", buildHelp(request, resolved));

            zip.finish();
            return baos.toByteArray();
        } catch (IOException e) {
            throw new GenerationException("Failed to generate project zip: " + e.getMessage(), e);
        }
    }

    private List<Dependency> resolveAndValidate(ProjectRequest request) {
        Set<String> seen = new HashSet<>();
        List<Dependency> out = new ArrayList<>();
        List<String> unknown = new ArrayList<>();
        for (String id : request.dependencies()) {
            if (id == null || id.isBlank() || !seen.add(id)) continue;
            var match = catalog.findById(id);
            if (match.isEmpty()) {
                unknown.add(id);
            } else {
                out.add(match.get());
            }
        }
        if (!unknown.isEmpty()) {
            throw new GenerationException("Unknown dependency id(s): " + String.join(", ", unknown));
        }
        return out;
    }

    private String buildHelp(ProjectRequest req, List<Dependency> deps) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Getting Started\n\n");
        sb.append("This project was generated by the Spring Initializr clone.\n\n");
        sb.append("## Project metadata\n\n");
        sb.append("- **Group**: ").append(req.groupId()).append("\n");
        sb.append("- **Artifact**: ").append(req.artifactId()).append("\n");
        sb.append("- **Name**: ").append(req.name()).append("\n");
        sb.append("- **Package**: ").append(req.packageName()).append("\n");
        sb.append("- **Java**: ").append(req.javaVersion()).append("\n");
        sb.append("- **Language**: ").append(req.language()).append("\n");
        sb.append("- **Packaging**: ").append(req.packaging()).append("\n");
        sb.append("- **Spring Boot**: ").append(req.bootVersion()).append("\n");
        sb.append("- **Build**: ").append(req.type()).append("\n\n");
        sb.append("## Dependencies\n\n");
        if (deps.isEmpty()) {
            sb.append("_No starters were selected._\n");
        } else {
            for (Dependency d : deps) {
                sb.append("### ").append(d.name()).append("\n");
                sb.append(d.description()).append("\n\n");
                sb.append("- Coordinates: `").append(d.groupId()).append(":").append(d.artifactId()).append("`\n");
                sb.append("- Scope: `").append(d.scope()).append("`\n\n");
            }
        }
        return sb.toString();
    }

    /**
     * Adds *placeholders* for the build wrappers so the layout matches start.spring.io.
     * Distributing the actual binary mvnw / gradlew JARs is out of scope; we add a README
     * note instructing users to run `mvn -N wrapper:wrapper` or `gradle wrapper`.
     */
    private void writeWrapperEntries(ZipOutputStream zip, String root, boolean maven) throws IOException {
        if (maven) {
            writeEntry(zip, root + ".mvn/wrapper/README.md",
                    "Run `mvn -N io.takari:maven:wrapper` or `mvn -N wrapper:wrapper` to generate the Maven Wrapper files.\n");
        } else {
            writeEntry(zip, root + "gradle/wrapper/README.md",
                    "Run `gradle wrapper` (with a local Gradle install) to generate the Gradle Wrapper files (gradlew, gradlew.bat, gradle-wrapper.jar, gradle-wrapper.properties).\n");
        }
    }

    private void writeEntry(ZipOutputStream zip, String name, String content) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        if (content != null && !content.isEmpty()) {
            zip.write(content.getBytes(StandardCharsets.UTF_8));
        }
        zip.closeEntry();
    }
}
