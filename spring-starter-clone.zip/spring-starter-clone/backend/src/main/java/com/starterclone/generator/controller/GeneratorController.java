package com.starterclone.generator.controller;

import com.starterclone.generator.model.ProjectRequest;
import com.starterclone.generator.service.ProjectGeneratorService;
import jakarta.validation.Valid;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class GeneratorController {

    private final ProjectGeneratorService generator;

    public GeneratorController(ProjectGeneratorService generator) {
        this.generator = generator;
    }

    @PostMapping(value = "/generate", produces = "application/zip")
    public ResponseEntity<byte[]> generate(@Valid @RequestBody ProjectRequest request) {
        byte[] zip = generator.generate(request);
        ContentDisposition cd = ContentDisposition.attachment()
                .filename(request.artifactId() + ".zip")
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/zip"));
        headers.setContentDisposition(cd);
        headers.setContentLength(zip.length);
        return new ResponseEntity<>(zip, headers, org.springframework.http.HttpStatus.OK);
    }
}
