package com.starterclone.generator.model;

import java.util.List;

/**
 * Represents a single Spring Boot starter / dependency entry in the catalog.
 * Mirrors the structure used by start.spring.io.
 */
public record Dependency(
        String id,
        String name,
        String description,
        String groupId,
        String artifactId,
        String version,           // null => inherit Spring Boot BOM
        String scope,             // compile (default), runtime, test, provided
        String category,          // Web, SQL, NoSQL, Security, etc.
        List<String> incompatibleWith,
        String minBootVersion,    // null => any
        String maxBootVersion     // null => any
) {
    public Dependency {
        if (incompatibleWith == null) {
            incompatibleWith = List.of();
        }
        if (scope == null || scope.isBlank()) {
            scope = "compile";
        }
    }
}
