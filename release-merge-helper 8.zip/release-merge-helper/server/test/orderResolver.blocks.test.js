const { parseBlocks, mergeOrderFiles, resolveOrderConflict } = require('../lib/orderResolver');

// release order file (base/ours)
const release = `#PAY-100
schema/base.sql

#PAY-150
schema/hotfix.sql`;

// develop introduces PAY-220 (new) and adds a file to PAY-100 (existing)
const develop = `#PAY-100
schema/base.sql
schema/base_grant.sql

#PAY-220
schema/add_iban.sql
schema/grant_iban.sql`;

console.log("=== parse release ===");
console.log(JSON.stringify(parseBlocks(release).blocks));

console.log("\n=== merge develop INTO release ===");
const merged = mergeOrderFiles(release, develop);
console.log(merged);
console.log("checks:");
console.log("  PAY-100 keeps base + gains base_grant:", merged.includes("schema/base_grant.sql"));
console.log("  PAY-150 (release-only) preserved:", merged.includes("#PAY-150"));
console.log("  PAY-220 appended at end:", merged.trimEnd().endsWith("schema/grant_iban.sql"));
console.log("  no duplicate base.sql:", (merged.match(/schema\/base\.sql/g)||[]).length === 1);

console.log("\n=== conflict-marker resolution ===");
const conflicted = `#PAY-100
schema/base.sql
<<<<<<< HEAD
#PAY-150
schema/hotfix.sql
=======
#PAY-220
schema/add_iban.sql
>>>>>>> develop`;
const r = resolveOrderConflict(conflicted);
console.log("merged:", r.merged);
console.log(r.content);
console.log("  has PAY-150:", r.content.includes("#PAY-150"));
console.log("  has PAY-220:", r.content.includes("#PAY-220"));
console.log("  no markers:", !/[<>=]{7}/.test(r.content));
