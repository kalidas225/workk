process.env.LOCAL_SCAN_ROOTS = '/tmp/clones';
const disc = require('../lib/repoDiscovery');
const gs = require('../lib/gitService');
(async () => {
  console.log('gitlabEnabled:', disc.gitlabEnabled());
  const groups = await disc.discover((p) => gs.originUrl(p));
  console.log('groups:', JSON.stringify(groups, null, 1));
  const lp = await disc.resolveLocalPath('local/payments-core', (p)=>gs.originUrl(p));
  console.log('resolve local/payments-core ->', lp);
})().catch(e=>{console.error('ERR',e.message);process.exit(1);});
