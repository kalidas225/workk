const { parseConflicts, serializeResolution, hasConflicts } = require('../lib/conflictParser');

const file = `line A
line B
<<<<<<< HEAD
release version line 1
release version line 2
=======
develop version line 1
>>>>>>> abc123 (feat: PAY-220)
line C
<<<<<<< HEAD
ours only
=======
theirs only
>>>>>>> abc123
line D`;

console.log("hasConflicts:", hasConflicts(file));
const segs = parseConflicts(file);
console.log("segments:", segs.length, "conflicts:", segs.filter(s=>s.type==='conflict').length);
segs.forEach((s,i)=>{
  if(s.type==='conflict') console.log(`  conflict ${i}: ours=${JSON.stringify(s.ours)} theirs=${JSON.stringify(s.theirs)} labels=[${s.oursLabel}|${s.theirsLabel}]`);
});

// resolve: first conflict -> theirs, second -> ours
const r = serializeResolution(segs, [{side:'theirs'},{side:'ours'}]);
console.log("\n--- resolved (theirs, then ours) ---");
console.log(r);
console.log("no markers:", !/[<>=]{7}/.test(r));

// diff3 style with base
const d3 = `x
<<<<<<< HEAD
ours
||||||| base
orig
=======
theirs
>>>>>>> y
z`;
const s3 = parseConflicts(d3);
console.log("\ndiff3 conflict ours/theirs:", JSON.stringify(s3.find(s=>s.type==='conflict')));
