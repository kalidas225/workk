const gs = require('../lib/gitService');
const { serializeResolution } = require('../lib/conflictParser');
(async () => {
  const repo = '/tmp/icp';
  const c = await gs.commits(repo, 'develop', 'release/24.1');
  const sha = c.groups.flatMap(g => g.commits).find(x => x.subject.includes('PAY-220')).hash;
  console.log('1) START cherry-pick of', sha.slice(0,8), '-> release/24.1 (protected)');

  let r = await gs.startCherryPick(repo, { target: 'release/24.1', commits: [sha], newBranch: 'cherry/itest' });
  console.log('   status:', r.status);
  if (r.status === 'conflict') {
    console.log('   conflicted file:', r.files[0].file, '| hunks:', r.files[0].conflictCount);
    const f = r.files[0];
    const conf = f.segments.find(s => s.type === 'conflict');
    console.log('   OURS (release):', JSON.stringify(conf.ours));
    console.log('   THEIRS (develop):', JSON.stringify(conf.theirs));

    // developer chooses THEIRS for this hunk
    const choices = f.segments.filter(s=>s.type==='conflict').map(()=>({side:'theirs'}));
    const resolvedContent = serializeResolution(f.segments, choices);
    console.log('2) developer picked THEIRS; resolved content:');
    console.log('   ' + resolvedContent.replace(/\n/g,' | '));

    r = await gs.resolveAndContinue(repo, 'cherry/itest', [{ file: f.file, content: resolvedContent }]);
    console.log('3) after continue status:', r.status, '| applied:', r.applied);
  }
  console.log('   final config.txt on branch:');
  console.log('   ' + require('child_process').execSync('git -C /tmp/icp show cherry/itest:config.txt').toString().replace(/\n/g,' | '));
  console.log('   develop intact:', require('child_process').execSync('git -C /tmp/icp rev-parse --short develop').toString().trim());
  console.log('   release intact:', require('child_process').execSync('git -C /tmp/icp rev-parse --short release/24.1').toString().trim());
  console.log('   current branch:', await gs.currentBranch(repo));
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
