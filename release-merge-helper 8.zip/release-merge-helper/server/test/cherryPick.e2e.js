const gs = require('../lib/gitService');
(async () => {
  const repo = '/tmp/cpconf';
  const feat = require('child_process').execSync('git -C /tmp/cpconf rev-parse refs/heads/develop').toString().trim();

  // get the feat commit hash from develop tip
  const c = await gs.commits(repo, 'develop', 'release/24.1');
  const sha = c.groups.flatMap(g => g.commits).find(x => x.subject.includes('PAY-220')).hash;
  console.log('picking', sha.slice(0,8), '-> release/24.1 (protected)');

  // dry run first
  const dry = await gs.cherryPick(repo, { target: 'release/24.1', commits: [sha],
    newBranch: 'cherry/rel-test', dryRun: true });
  console.log('DRY:', JSON.stringify(dry.dryResults));

  // real apply
  const r = await gs.cherryPick(repo, { target: 'release/24.1', commits: [sha],
    newBranch: 'cherry/rel-test', dryRun: false });
  console.log('APPLIED:', r.applied, 'onto', r.workBranch, 'created:', r.createdNewBranch);
  console.log('autoResolved:', JSON.stringify(r.autoResolved));
  console.log('sqlWarnings:', JSON.stringify(r.sqlWarnings, null, 0));

  // verify resulting order file = release wins + PAY-220 appended
  const fs = require('fs');
  console.log('\n--- order_of_execution_release.info on cherry/rel-test ---');
  console.log(require('child_process').execSync('git -C /tmp/cpconf show cherry/rel-test:order_of_execution_release.info').toString());
  console.log('--- develop & release intact ---');
  console.log('develop head:', require('child_process').execSync('git -C /tmp/cpconf rev-parse --short develop').toString().trim());
  console.log('release head:', require('child_process').execSync('git -C /tmp/cpconf rev-parse --short release/24.1').toString().trim());
  console.log('current branch:', await gs.currentBranch(repo));
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
