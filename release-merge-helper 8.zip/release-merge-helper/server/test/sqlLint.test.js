const { lintSqlFiles, checkSqlContent, fixSqlFile } = require('../lib/sqlLint');
const res = lintSqlFiles('/tmp/sqltest', ['schema/good.sql','schema/missing.sql','schema/nopkg.sql'], true);
console.log("lint results:");
res.forEach(r => console.log(`  ${r.ok ? 'OK ' : 'BAD'} ${r.file} — ${r.reason} (last: ${JSON.stringify(r.lastLine)})`));
console.log("\nfix missing.sql:", fixSqlFile('/tmp/sqltest','schema/missing.sql'));
console.log("recheck:", checkSqlContent(require('fs').readFileSync('/tmp/sqltest/schema/missing.sql','utf8')).ok);
