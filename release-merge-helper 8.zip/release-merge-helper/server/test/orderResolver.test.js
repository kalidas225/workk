const { resolveOrderFile, isOrderFile } = require('../lib/orderResolver');

// Simulated conflicted file: release (ours) has PAY-100, PAY-110;
// incoming (theirs) has PAY-100 (changed path), PAY-220, PAY-225 (new)
const conflicted = `# Release 24.1 deployment order
PAY-100=schema/base.sql
PAY-110=schema/accounts.sql
<<<<<<< HEAD
PAY-115=schema/audit.sql
=======
PAY-115=schema/audit.sql
PAY-220=schema/add_iban.sql
PAY-225=schema/sepa_split.sql
>>>>>>> abc123 (feat: cherry-pick)
PAY-130=schema/final.sql`;

const r = resolveOrderFile(conflicted);
console.log("resolved hunks:", r.resolved);
console.log("--- output ---");
console.log(r.content);
console.log("--- checks ---");
console.log("has appended marker:", r.content.includes("appended by Cherry Deck"));
console.log("PAY-220 present:", r.content.includes("PAY-220=schema/add_iban.sql"));
console.log("PAY-225 present:", r.content.includes("PAY-225=schema/sepa_split.sql"));
console.log("PAY-130 preserved after hunk:", r.content.includes("PAY-130=schema/final.sql"));
console.log("no markers left:", !/[<>=]{7}/.test(r.content));
console.log("isOrderFile test:", isOrderFile("deploy/order_of_execution_release.info"), isOrderFile("foo.sql"));

// conflict where release CHANGED a shared id's path -> release must win
const c2 = `<<<<<<< HEAD
PAY-300=schema/RELEASE_version.sql
=======
PAY-300=schema/develop_version.sql
>>>>>>> x`;
const r2 = resolveOrderFile(c2);
console.log("\n--- shared-id conflict (release wins) ---");
console.log(r2.content);
console.log("release path won:", r2.content.includes("RELEASE_version") && !r2.content.includes("develop_version"));
