import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { gitlabHeadersInterceptor } from './app/core/gitlab-headers.interceptor';
import { httpErrorInterceptor } from './app/core/http-error.interceptor';

bootstrapApplication(AppComponent, {
  providers: [provideHttpClient(withFetch(), withInterceptors([gitlabHeadersInterceptor, httpErrorInterceptor]))],
}).catch((err) => console.error(err));
