import { Component, inject } from '@angular/core';
import { ThemeService } from '../core/theme.service';

@Component({
  selector: 'app-theme-toggle',
  standalone: true,
  template: `
    <button class="toggle" (click)="theme.toggle()"
            [attr.aria-label]="theme.theme() === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'">
      <span class="track" [class.light]="theme.theme() === 'light'">
        <span class="knob">
          @if (theme.theme() === 'dark') {
            <svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a5.39 5.39 0 0 1-8.54-7A8.97 8.97 0 0 0 12 3z"/></svg>
          } @else {
            <svg viewBox="0 0 24 24" width="13" height="13"><path fill="currentColor" d="M12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-13a1 1 0 0 1 1 1v1a1 1 0 1 1-2 0V5a1 1 0 0 1 1-1zm0 14a1 1 0 0 1 1 1v1a1 1 0 1 1-2 0v-1a1 1 0 0 1 1-1zM4 12a1 1 0 0 1 1-1h1a1 1 0 1 1 0 2H5a1 1 0 0 1-1-1zm14 0a1 1 0 0 1 1-1h1a1 1 0 1 1 0 2h-1a1 1 0 0 1-1-1z"/></svg>
          }
        </span>
      </span>
    </button>
  `,
  styles: [`
    .toggle { background: none; border: none; padding: 0; }
    .track {
      width: 52px; height: 28px; border-radius: 999px;
      background: var(--surface-3); border: 1px solid var(--line);
      display: flex; align-items: center; padding: 3px;
      transition: background 0.3s var(--ease);
    }
    .track.light { justify-content: flex-end; }
    .knob {
      width: 20px; height: 20px; border-radius: 50%;
      background: var(--accent); color: #fff;
      display: grid; place-items: center;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3);
      transition: transform 0.35s var(--ease);
    }
  `],
})
export class ThemeToggleComponent {
  theme = inject(ThemeService);
}
