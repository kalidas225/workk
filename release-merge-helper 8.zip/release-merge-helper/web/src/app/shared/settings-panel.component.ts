import { Component, EventEmitter, Output, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SettingsService } from '../core/settings.service';
import { GitApi } from '../core/git-api.service';

@Component({
  selector: 'app-settings-panel',
  standalone: true,
  imports: [FormsModule],
  template: `
  <div class="sp-backdrop" (click)="close.emit()"></div>
  <div class="sp" role="dialog" aria-label="GitLab settings">
    <div class="sp-head">
      <div><strong>GitLab connection</strong><small>Your personal access token stays in this browser only.</small></div>
      <button class="sp-x" (click)="close.emit()" aria-label="Close">×</button>
    </div>

    <label class="sp-label">GitLab URL</label>
    <input class="sp-field mono" [ngModel]="baseUrl()" (ngModelChange)="baseUrl.set($event)" placeholder="https://gitlab-dogen.group.echonet" spellcheck="false" />

    <label class="sp-label">Group path <span>where your projects live</span></label>
    <input class="sp-field mono" [ngModel]="group()" (ngModelChange)="group.set($event)" placeholder="Wholesale/cib/bp2s/sts" spellcheck="false" />

    <label class="sp-label">Personal access token <span>scope: api</span></label>
    <div class="sp-token">
      <input class="sp-field mono" [type]="reveal() ? 'text' : 'password'" [ngModel]="token()" (ngModelChange)="token.set($event)" placeholder="glpat-••••••••••••" spellcheck="false" />
      <button class="sp-eye" (click)="reveal.set(!reveal())" type="button">{{ reveal() ? 'Hide' : 'Show' }}</button>
    </div>
    <p class="sp-help">Create one in GitLab → Preferences → Access Tokens. Each developer uses their own, so pushes and merge requests are attributed to you.</p>

    @if (verified(); as v) { <div class="sp-ok">✓ Connected as <b>{{ v.name }}</b> (&#64;{{ v.username }})</div> }
    @if (err(); as e) { <div class="sp-err">{{ e }}</div> }

    <div class="sp-actions">
      <button class="btn ghost sm" (click)="clear()">Clear token</button>
      <div class="sp-right">
        <button class="btn ghost" (click)="test()" [disabled]="busy() || !baseUrl() || !token()">@if (busy()) { Testing… } @else { Test connection }</button>
        <button class="btn primary" (click)="saveAndClose()" [disabled]="!baseUrl()">Save</button>
      </div>
    </div>
  </div>
  `,
  styleUrl: './settings-panel.component.css',
})
export class SettingsPanelComponent {
  private settings = inject(SettingsService);
  private api = inject(GitApi);
  @Output() close = new EventEmitter<void>();
  @Output() saved = new EventEmitter<void>();

  baseUrl = signal(this.settings.settings().baseUrl);
  group = signal(this.settings.settings().group);
  token = signal(this.settings.settings().token);
  reveal = signal(false);
  busy = signal(false);
  verified = signal<{ username: string; name: string } | null>(this.settings.verified());
  err = signal<string | null>(null);

  private persist() { this.settings.save({ baseUrl: this.baseUrl().trim(), group: this.group().trim(), token: this.token().trim() }); }

  test() {
    this.persist(); this.busy.set(true); this.err.set(null);
    this.api.gitlabCheck().subscribe({
      next: (r) => { this.busy.set(false); this.verified.set(r); this.settings.verified.set(r); },
      error: (e) => { this.busy.set(false); this.verified.set(null); this.err.set(e?.error?.error || 'Could not connect. Check URL and token.'); },
    });
  }
  saveAndClose() { this.persist(); this.saved.emit(); this.close.emit(); }
  clear() { this.token.set(''); this.verified.set(null); this.settings.clearToken(); }
}
