import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { catchError, throwError } from 'rxjs';

// A tiny shared bus so the interceptor can push toasts that the root component renders.
@Injectable({ providedIn: 'root' })
export class ToastBus {
  readonly items = signal<{ id: number; kind: 'error' | 'success' | 'info'; msg: string }[]>([]);
  private seq = 0;
  push(kind: 'error' | 'success' | 'info', msg: string) {
    const id = ++this.seq;
    this.items.update((t) => [...t, { id, kind, msg }]);
    setTimeout(() => this.dismiss(id), kind === 'error' ? 7000 : 3500);
  }
  dismiss(id: number) { this.items.update((t) => t.filter((x) => x.id !== id)); }
}

export const httpErrorInterceptor: HttpInterceptorFn = (req, next) => {
  const bus = inject(ToastBus);
  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      // Only auto-toast API calls; let component-level handlers still run too.
      if (req.url.includes('/api/')) {
        const msg = err?.error?.error || err?.message || `Request failed (${err.status || 'network'})`;
        // de-dup identical consecutive messages
        const last = bus.items()[bus.items().length - 1];
        if (!last || last.msg !== msg) bus.push('error', msg);
      }
      return throwError(() => err);
    })
  );
};
