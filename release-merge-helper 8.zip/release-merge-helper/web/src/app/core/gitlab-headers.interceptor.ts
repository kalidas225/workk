import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { SettingsService } from './settings.service';

// Attach each developer's GitLab config to every API request as headers.
export const gitlabHeadersInterceptor: HttpInterceptorFn = (req, next) => {
  const s = inject(SettingsService).settings();
  if (req.url.startsWith('/api/') && (s.baseUrl || s.token || s.group)) {
    req = req.clone({
      setHeaders: {
        'X-GitLab-Url': s.baseUrl || '',
        'X-GitLab-Group': s.group || '',
        'X-GitLab-Token': s.token || '',
      },
    });
  }
  return next(req);
};
