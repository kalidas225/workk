import { Injectable, signal } from '@angular/core';

export interface GitlabSettings { baseUrl: string; group: string; token: string; }

const KEY = 'cd-gitlab-settings';

@Injectable({ providedIn: 'root' })
export class SettingsService {
  readonly settings = signal<GitlabSettings>(this.load());
  readonly verified = signal<{ username: string; name: string } | null>(null);

  private load(): GitlabSettings {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw);
    } catch { /* */ }
    return { baseUrl: 'https://gitlab-dogen.group.echonet', group: 'Wholesale/cib/bp2s/sts', token: '' };
  }
  save(s: GitlabSettings) {
    this.settings.set(s);
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* */ }
  }
  hasToken() { return !!this.settings().token; }
  clearToken() {
    const s = { ...this.settings(), token: '' };
    this.save(s); this.verified.set(null);
  }
}
