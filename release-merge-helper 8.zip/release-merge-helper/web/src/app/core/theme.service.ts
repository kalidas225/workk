import { Injectable, signal } from '@angular/core';

type Theme = 'dark' | 'light';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  readonly theme = signal<Theme>(this.initial());

  private initial(): Theme {
    const saved = localStorage.getItem('cd-theme') as Theme | null;
    if (saved === 'dark' || saved === 'light') {
      this.apply(saved);
      return saved;
    }
    const prefersLight = window.matchMedia?.('(prefers-color-scheme: light)').matches;
    const t: Theme = prefersLight ? 'light' : 'dark';
    this.apply(t);
    return t;
  }

  toggle() {
    const next: Theme = this.theme() === 'dark' ? 'light' : 'dark';
    this.theme.set(next);
    this.apply(next);
    localStorage.setItem('cd-theme', next);
  }

  private apply(t: Theme) {
    document.documentElement.setAttribute('data-theme', t);
  }
}
