import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import {
  Release, Checkpoints, Subject, ReleaseSummary, Page, Readiness,
  ReleaseHealth, ConnectionStatus, ServiceNowTicket, CTask, ReleaseChanges, SubjectCheckConfig, ChecksConfig, Milestone,
} from './models';

/**
 * Data service. When USE_MOCK is true it serves deterministic in-browser demo
 * data (so the UI runs with no backend — used for screenshots/demos). Set it to
 * false to call the Spring Boot API at API_BASE.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  // Mock vs live, and the API base, are resolved at runtime so nothing is
  // hardcoded to localhost. A deployment can drop a window.__cockpit config
  // (e.g. via index.html or an env-config.js) to override these:
  //   window.__cockpit = { useMock: false, apiBase: '/api' }
  // Default: live mode against a RELATIVE '/api' (same origin as the app).
  private readonly cfg = (typeof window !== 'undefined' && (window as any).__cockpit) || {};
  private readonly USE_MOCK = this.cfg.useMock !== undefined ? !!this.cfg.useMock : false;
  private readonly API_BASE = this.cfg.apiBase || '/api';

  private readonly PEOPLE: [string, string][] = [
    ['Sreenath Babu Vairavasingh', 'sreenathbabu.vairavasingh@asia.bnpparibas.com'],
    ['Srinivasan Nagarajan', 'srinivasan.nagarajan@asia.bnpparibas.com'],
    ['Selvakumar C', 'selvakumar.c@asia.bnpparibas.com'],
    ['Kameshwaran Pandi', 'kameshwaran.pandi@asia.bnpparibas.com'],
    ['Krishna Prakash Thangadurai', 'krishnaprakash.thangadurai@asia.bnpparibas.com'],
    ['Soundarya Selvam', 'soundarya.selvam@asia.bnpparibas.com'],
    ['Akhila Gowrishankar', 'akhila.gowrishankar@asia.bnpparibas.com'],
    ['K Anjuna Raj', 'anjunaraj.k@asia.bnpparibas.com'],
    ['Mayank Kumar', 'mayank.1.kumar@asia.bnpparibas.com'],
    ['Pratik Bhakte', 'pratik.bhakte@asia.bnpparibas.com'],
    ['Sapthagiri Kalyanakumar', 'sapthagiri.kalyanakumar@ext.asia.bnpparibas.com'],
    ['Kalidas Singamsetty', 'kalidas.singamsetty@asia.bnpparibas.com'],
    ['Krishnaraj L', 'krishnaraj.l@asia.bnpparibas.com'],
    ['Ramabathren Lakshminarayanan', 'ramabathren.lakshminarayanan@asia.bnpparibas.com'],
    ['Chandraleela Kamalamurthy', 'chandraleela.kamalamurthy@asia.bnpparibas.com'],
    ['Akshaya R Srinivasan', 'akshaya.rajagopalansrinivasan@asia.bnpparibas.com'],
    ['Sowmya Unnikrishnan', 'sowmya.unnikrishnan@asia.bnpparibas.com'],
    ['Sivanesh Murugan', 'sivanesh.murugan@asia.bnpparibas.com'],
    ['Mukesh J', 'mukesh.j@asia.bnpparibas.com'],
    ['P D Nancy', 'nancy.pd@asia.bnpparibas.com'],
    ['Manusri Boppana', 'manusri.boppana@asia.bnpparibas.com'],
    ['Aruna Rathinam', 'aruna.rathinam@ext.asia.bnpparibas.com'],
  ];
  private readonly SUMMARIES = [
    'Payments reconciliation service', 'Authentication token rotation',
    'Trade settlement batch optimisation', 'Client onboarding KYC flow',
    'Regulatory reporting export', 'Liquidity dashboard widgets',
    'FX rate ingestion pipeline', 'Audit log retention policy',
    'Margin call notification engine', 'Counterparty risk scoring',
  ];
  private readonly STATUSES = ['In Progress', 'In Review', 'Ready for UAT', 'Blocked', 'Done'];

  constructor(private http: HttpClient) {}

  getReleases(): Observable<Release[]> {
    if (!this.USE_MOCK) return this.http.get<Release[]>(`${this.API_BASE}/releases`);
    const today = new Date();
    const releases: Release[] = [];
    for (let i = -3; i <= 6; i++) {
      const d = new Date(today);
      d.setDate(15);
      d.setMonth(today.getMonth() + i);
      const monthNum = ((today.getMonth() + i + 12) % 12) + 1;
      releases.push({
        id: 'v' + (1000 + i),
        name: `25.${String(monthNum).padStart(2, '0')}`,
        releaseDate: d.toISOString().slice(0, 10),
        released: d < new Date(today.getTime() - 86400000),
        description: 'Monthly platform release',
      });
    }
    return of(releases).pipe(delay(120));
  }

  getCheckpoints(name: string): Observable<Checkpoints> {
    if (!this.USE_MOCK) return this.http.get<Checkpoints>(`${this.API_BASE}/releases/${name}/checkpoints`);
    const rel = this.releaseDateFor(name);
    const today = new Date();
    const d = (base: Date, days: number) => { const x = new Date(base); x.setDate(base.getDate() + days); return x; };
    const ppd1 = d(rel, -14);
    const rollback = new Date(ppd1);
    const ppd2 = this.nextMonday(ppd1);
    const lcab = this.tuesdayOfWeek(rel);
    const endUat = d(rel, -21);
    const days = Math.round((rel.getTime() - today.getTime()) / 86400000);
    const iso = (x: Date) => x.toISOString().slice(0, 10);
    const st = (x: Date, deadline = false): Milestone['status'] => {
      const dd = Math.round((x.getTime() - today.getTime()) / 86400000);
      if (deadline) return dd > 4 ? 'UPCOMING' : dd >= 0 ? 'DUE_SOON' : 'OVERDUE';
      if (dd < 0) return 'DONE'; if (dd === 0) return 'ACTIVE'; if (dd <= 4) return 'DUE_SOON'; return 'UPCOMING';
    };
    const docCutoff = d(ppd1, -3);  // Friday before the PPD-1 week
    const timeline: Milestone[] = [
      { key: 'END_UAT', label: 'End-UAT done', date: iso(endUat), status: st(endUat, true), overridden: false },
      { key: 'DOC_CUTOFF', label: 'Document cutoff', date: iso(docCutoff), status: st(docCutoff, true), overridden: false },
      { key: 'PPD1', label: 'PPD-1', date: iso(ppd1), status: st(ppd1), overridden: false },
      { key: 'PPD1_ROLLBACK', label: 'PPD-1 rollback', date: iso(rollback), status: st(rollback), overridden: false },
      { key: 'PPD2', label: 'PPD-2', date: iso(ppd2), status: st(ppd2), overridden: false },
      { key: 'LCAB', label: 'LCAB', date: iso(lcab), status: st(lcab), overridden: false },
      { key: 'RELEASE', label: 'Release', date: iso(rel), status: st(rel), overridden: false },
    ];
    // Apply mock overrides (dates + extra PPD stages) so add/remove works in mock.
    const ov = this.mockCpOverrides[name] || {};
    for (const [k, v] of Object.entries(ov)) {
      const existing = timeline.find(m => m.key === k);
      if (existing) { existing.date = v; existing.overridden = true; }
      else if (/^PPD[3-9]$/.test(k)) {
        const n = k.replace('PPD', '');
        const idx = timeline.findIndex(m => m.key === 'LCAB');
        timeline.splice(idx < 0 ? timeline.length : idx, 0,
          { key: k, label: 'PPD-' + n, date: v, status: st(new Date(v)), overridden: true });
      }
    }
    return of({
      releaseDate: iso(rel), ppdStart: iso(ppd1), endUatDone: iso(endUat),
      ppdStatus: st(ppd1) === 'DONE' ? 'DONE' : (days >= 0 ? 'ACTIVE' : 'DONE'),
      endUatStatus: st(endUat, true), daysToRelease: days, timeline,
    } as Checkpoints).pipe(delay(80));
  }

  private nextMonday(from: Date): Date {
    const x = new Date(from); const day = x.getDay();
    const add = ((8 - day) % 7) || 7; // strictly next Monday
    x.setDate(x.getDate() + add); return x;
  }
  private tuesdayOfWeek(rel: Date): Date {
    const x = new Date(rel); const day = x.getDay(); // 0 Sun .. 6 Sat
    const monday = new Date(x); monday.setDate(x.getDate() - ((day + 6) % 7));
    monday.setDate(monday.getDate() + 1); return monday; // Tuesday
  }

  getSummary(name: string): Observable<ReleaseSummary> {
    if (!this.USE_MOCK) return this.http.get<ReleaseSummary>(`${this.API_BASE}/releases/${name}/summary`);
    const subjects = this.mockSubjects(name);
    const ready = subjects.filter(s => s.readiness.missingCount === 0).length;
    const byDev = new Map<string, number>();
    subjects.forEach(s => byDev.set(s.developerName, (byDev.get(s.developerName) || 0) + 1));
    const dist = [...byDev.entries()]
      .map(([developer, subjectCount]) => ({ developer, subjectCount }))
      .sort((a, b) => b.subjectCount - a.subjectCount);
    const octaneOk = subjects.filter(s => s.readiness.octaneTestsLinked).length;
    const spOk = subjects.filter(s => this.spComplete(s.readiness)).length;
    return of({
      releaseName: name,
      totalSubjects: subjects.length,
      ready, notReady: subjects.length - ready,
      developerDistribution: dist,
      readinessBreakdown: {
        octaneOk, octaneMissing: subjects.length - octaneOk,
        sharepointOk: spOk, sharepointMissing: subjects.length - spOk,
      },
    }).pipe(delay(100));
  }

  getSubjects(name: string, page: number, size: number): Observable<Page<Subject>> {
    if (!this.USE_MOCK) {
      return this.http.get<Page<Subject>>(
        `${this.API_BASE}/releases/${name}/subjects?page=${page}&size=${size}`);
    }
    const all = this.mockSubjects(name);
    const from = page * size;
    const content = all.slice(from, from + size);
    return of({ content, page, size, totalElements: all.length }).pipe(delay(100));
  }

  refreshRelease(name: string): Observable<{ refreshed: boolean }> {
    if (!this.USE_MOCK) return this.http.post<any>(`${this.API_BASE}/releases/${name}/refresh`, {});
    return of({ refreshed: true }).pipe(delay(50));
  }
  refreshSubject(release: string, key: string): Observable<Subject> {
    if (!this.USE_MOCK) return this.http.post<Subject>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/subjects/${key}/refresh`, {});
    return of(this.mockSubjects(release).find(s => s.key === key)!).pipe(delay(400));
  }

  getConfig(): Observable<{ defaultRelease: string | null; jiraBaseUrl: string | null }> {
    if (!this.USE_MOCK) return this.http.get<any>(`${this.API_BASE}/config`);
    return of({ defaultRelease: null, jiraBaseUrl: 'https://jira.group.echonet' }).pipe(delay(20));
  }

  getScanStatus(name: string): Observable<{ scanning: boolean; lastChecked: string | null; nextCheck: string | null; subjectCount: number }> {
    if (!this.USE_MOCK) {
      return this.http.get<any>(`${this.API_BASE}/releases/${name}/scan-status`);
    }
    return of({ scanning: false, lastChecked: new Date().toISOString(), nextCheck: null, subjectCount: this.mockSubjects(name).length }).pipe(delay(50));
  }

  sendMail(name: string, key: string): Observable<{ status: string }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ status: string }>(
        `${this.API_BASE}/releases/${name}/subjects/${key}/mail`, {});
    }
    return of({ status: 'Simulated send (mock mode)' }).pipe(delay(150));
  }

  mailAll(name: string): Observable<{ sent: number }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ sent: number }>(`${this.API_BASE}/releases/${name}/mail-all`, {});
    }
    const n = this.mockSubjects(name).filter(s => s.readiness.missingCount > 0).length;
    return of({ sent: n }).pipe(delay(200));
  }

  mailSummary(name: string): Observable<{ status: string }> {
    if (!this.USE_MOCK) {
      return this.http.post<{ status: string }>(`${this.API_BASE}/releases/${name}/mail-summary`, {});
    }
    return of({ status: 'Release-status summary queued to managers (mock mode)' }).pipe(delay(200));
  }

  getHealth(name: string): Observable<ReleaseHealth> {
    if (!this.USE_MOCK) return this.http.get<ReleaseHealth>(`${this.API_BASE}/releases/${name}/health`);
    const subjects = this.mockSubjects(name);
    const total = Math.max(1, subjects.length);
    const ready = subjects.filter(s => s.readiness.missingCount === 0).length;
    const octaneOk = subjects.filter(s => s.readiness.octaneTestsLinked).length;
    const spOk = subjects.filter(s => this.spComplete(s.readiness)).length;
    const r = Math.round((ready / total) * 100);
    const o = Math.round((octaneOk / total) * 100);
    const sp = Math.round((spOk / total) * 100);
    // Timeline from checkpoint mock.
    const rel = this.releaseDateFor(name);
    const endUat = new Date(rel); endUat.setDate(rel.getDate() - 21);
    const uatDays = Math.round((endUat.getTime() - Date.now()) / 86400000);
    const timeline = uatDays > 4 ? 90 : (uatDays >= 0 ? 60 : 25);
    const score = Math.round(r * 0.40 + o * 0.25 + sp * 0.20 + timeline * 0.15);
    const grade = score >= 85 ? 'EXCELLENT' : score >= 70 ? 'GOOD' : score >= 50 ? 'AT_RISK' : 'CRITICAL';
    const risks: string[] = [];
    if (r < 60) risks.push((total - ready) + ' of ' + total + ' subjects still have gaps');
    if (o < 70) risks.push('Octane coverage is low (' + o + '%)');
    if (sp < 70) risks.push('SharePoint artifacts incomplete (' + sp + '%)');
    if (uatDays < 0) risks.push('End-UAT deadline has passed');
    else if (uatDays <= 4) risks.push('End-UAT deadline is approaching');
    if (risks.length === 0) risks.push('On track — no major risks detected');
    return of({
      score, grade: grade as ReleaseHealth['grade'],
      readinessScore: r, octaneScore: o, sharepointScore: sp, timelineScore: timeline, risks,
    }).pipe(delay(110));
  }

  getServiceNow(name: string): Observable<ServiceNowTicket[]> {
    if (!this.USE_MOCK) return this.http.get<ServiceNowTicket[]>(`${this.API_BASE}/releases/${name}/servicenow`);
    const rng = this.seeded(this.hash(name) ^ 0x5a17);
    const states = ['New', 'Assess', 'Authorize', 'Scheduled', 'Implement', 'Review', 'Closed'];
    const prios = ['1 - Critical', '2 - High', '3 - Moderate', '4 - Low'];
    const devs = this.PEOPLE.map(p => p[0]);
    const descs = ['Production deployment for release ' + name, 'Database schema migration',
      'Firewall rule change for new endpoints', 'Config rollout to UAT', 'Certificate renewal',
      'Load balancer update', 'Batch job schedule change', 'Rollback plan validation'];
    const n = 3 + Math.floor(rng() * 5);
    const out: ServiceNowTicket[] = [];
    for (let i = 0; i < n; i++) {
      out.push({
        number: 'CHG' + String(30000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: descs[Math.floor(rng() * descs.length)],
        state: states[Math.floor(rng() * states.length)],
        priority: prios[Math.floor(rng() * prios.length)],
        assignedTo: devs[Math.floor(rng() * devs.length)],
        type: 'change_request', url: '#',
      });
    }
    return of(out).pipe(delay(120));
  }

  getReleaseChanges(name: string, refresh: boolean = false): Observable<ReleaseChanges> {
    if (!this.USE_MOCK) return this.http.get<ReleaseChanges>(`${this.API_BASE}/releases/${encodeURIComponent(name)}/servicenow/changes${refresh ? '?refresh=true' : ''}`);
    const rng = this.seeded(this.hash(name) ^ 0x33ce);
    const devs = this.PEOPLE.map(p => p[0]);
    const st = ['Scheduled', 'Implement', 'Review', 'Closed'];
    const base = new Date(); base.setDate(base.getDate() - 20);
    const dstr = (off: number) => { const d = new Date(base); d.setDate(d.getDate() + off); return d.toISOString().slice(0, 10) + ' 18:00:00'; };
    const mkTasks = (env: string, off: number): CTask[] => {
      const tasks: CTask[] = [{
        number: 'CTASK' + String(100000 + Math.floor(rng() * 99999)).padStart(7, '0'),
        shortDescription: 'Deploy ' + env, state: st[Math.floor(rng() * st.length)],
        assignedTo: devs[Math.floor(rng() * devs.length)], plannedStart: dstr(off), plannedEnd: dstr(off), rollback: false,
      }];
      if (env === 'PPD1') tasks.push({
        number: 'CTASK' + String(100000 + Math.floor(rng() * 99999)).padStart(7, '0'),
        shortDescription: 'Rollback plan for PPD-1', state: 'Scheduled',
        assignedTo: devs[Math.floor(rng() * devs.length)], plannedStart: dstr(off), plannedEnd: dstr(off), rollback: true,
      });
      return tasks;
    };
    const mk = (env: string, off: number, label: string): ServiceNowTicket => ({
      number: 'CHG' + String(1360000 + Math.floor(rng() * 99999)).padStart(7, '0'),
      shortDescription: label, state: st[Math.floor(rng() * st.length)],
      priority: '4 - Low', assignedTo: devs[Math.floor(rng() * devs.length)],
      type: 'change_request', url: 'https://bnpp.service-now.com/nav_to.do?uri=change_request.do?sys_id=demo', env,
      startDate: dstr(off), endDate: dstr(off), ctasks: mkTasks(env, off),
    });
    return of({
      ppd1: [mk('PPD1', 0, '[ANSIBLE][PPD] STS X5.2026.0 Rehearsal 1'), mk('PPD1', 7, '[ANSIBLE][PPD] STS X5.2026.0 Rehearsal 1')],
      ppd2: [mk('PPD2', 14, '[ANSIBLE][PPD] STS X5.2026.0 Rehearsal 2')],
      prod: [mk('PROD', 21, '[ANSIBLE][PROD] STS X5.2026.0 Release')],
      incidents: [{
        number: 'INC' + String(20000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: `Post-release latency spike after ${name}`, state: 'In Progress',
        priority: '2 - High', assignedTo: devs[0], type: 'incident', url: '#', env: '',
      }],
      problems: [{
        number: 'PRB' + String(10000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: `Root cause analysis for ${name} regression`, state: 'Assess',
        priority: '3 - Moderate', assignedTo: devs[1], type: 'problem', url: '#', env: '',
      }],
      enabled: true,
    } as ReleaseChanges).pipe(delay(140));
  }

  /** Lazily fetch CTASKs for one change (on expand). */
  getChangeCtasks(changeNumber: string): Observable<CTask[]> {
    if (!this.USE_MOCK) return this.http.get<CTask[]>(`${this.API_BASE}/releases/servicenow/changes/${encodeURIComponent(changeNumber)}/ctasks`);
    const rng = this.seeded(this.hash(changeNumber));
    const devs = this.PEOPLE.map(p => p[0]);
    const isRollbackCtx = changeNumber.charCodeAt(changeNumber.length - 1) % 2 === 0;
    const out: CTask[] = [{
      number: 'CTASK' + String(100000 + Math.floor(rng() * 99999)).padStart(7, '0'),
      shortDescription: 'Deployment task', state: 'Closed',
      assignedTo: devs[Math.floor(rng() * devs.length)], plannedStart: '', plannedEnd: '', rollback: false,
    }];
    if (isRollbackCtx) out.push({
      number: 'CTASK' + String(100000 + Math.floor(rng() * 99999)).padStart(7, '0'),
      shortDescription: 'Rollback plan', state: 'Scheduled',
      assignedTo: devs[Math.floor(rng() * devs.length)], plannedStart: '', plannedEnd: '', rollback: true,
    });
    return of(out).pipe(delay(200));
  }

  /** Lazily fetch incidents + problems caused by this release (ServiceNow tab). */
  getServiceNowIssues(name: string): Observable<ReleaseChanges> {
    if (!this.USE_MOCK) return this.http.get<ReleaseChanges>(`${this.API_BASE}/releases/${encodeURIComponent(name)}/servicenow/issues`);
    const rng = this.seeded(this.hash(name) ^ 0x77aa);
    const devs = this.PEOPLE.map(p => p[0]);
    return of({
      ppd1: [], ppd2: [], prod: [],
      incidents: [{
        number: 'INC' + String(20000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: `Post-release latency spike after ${name}`, state: 'In Progress',
        priority: '2 - High', assignedTo: devs[0], type: 'incident',
        url: 'https://bnpp.service-now.com/nav_to.do?uri=incident.do?sys_id=demo', env: '',
      }],
      problems: [{
        number: 'PRB' + String(10000 + Math.floor(rng() * 9999)).padStart(7, '0'),
        shortDescription: `Root cause analysis for ${name} regression`, state: 'Assess',
        priority: '3 - Moderate', assignedTo: devs[1], type: 'problem',
        url: 'https://bnpp.service-now.com/nav_to.do?uri=problem.do?sys_id=demo', env: '',
      }],
      enabled: true,
    } as ReleaseChanges).pipe(delay(160));
  }

  getChecks(release: string = ''): Observable<ChecksConfig> {
    if (!this.USE_MOCK) return this.http.get<ChecksConfig>(`${this.API_BASE}/checks?release=${encodeURIComponent(release)}`);
    return of({
      default: { octaneEnvironments: ['IST', 'DEV', 'UAT'], bcmEndToEnd: false, skipSharePoint: [], note: '' },
      overrides: {},
    } as ChecksConfig).pipe(delay(100));
  }

  putCheck(key: string, cfg: SubjectCheckConfig, release: string = ''): Observable<SubjectCheckConfig> {
    if (!this.USE_MOCK) return this.http.put<SubjectCheckConfig>(`${this.API_BASE}/checks/${key}?release=${encodeURIComponent(release)}`, cfg);
    return of(cfg).pipe(delay(80));
  }

  private mockCpOverrides: Record<string, Record<string, string>> = {};
  setCheckpoint(release: string, stage: string, date: string | null): Observable<Checkpoints> {
    if (!this.USE_MOCK) return this.http.put<Checkpoints>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/checkpoints/${stage}`, { date: date ?? '' });
    this.mockCpOverrides[release] = this.mockCpOverrides[release] || {};
    if (date) this.mockCpOverrides[release][stage] = date;
    else delete this.mockCpOverrides[release][stage];
    return this.getCheckpoints(release);
  }

  resetCheckpoints(release: string): Observable<Checkpoints> {
    if (!this.USE_MOCK) return this.http.delete<Checkpoints>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/checkpoints`);
    return of({} as Checkpoints).pipe(delay(80));
  }

  getEnvLinks(release: string): Observable<Record<string, {label: string; url: string}>> {
    if (!this.USE_MOCK) return this.http.get<Record<string, {label: string; url: string}>>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/env-links`);
    return of({
      PPD1: { label: 'PPD-1 env', url: 'https://ppd1.example.bnpparibas' },
      PPD2: { label: 'PPD-2 env', url: 'https://ppd2.example.bnpparibas' },
      PROD_SERVICENOW: { label: 'CHG0045821', url: 'https://servicenow.bnpparibas/chg/CHG0045821' },
    } as Record<string, {label: string; url: string}>).pipe(delay(60));
  }
  setEnvLink(release: string, envKey: string, label: string, url: string): Observable<Record<string, {label: string; url: string}>> {
    if (!this.USE_MOCK) return this.http.put<Record<string, {label: string; url: string}>>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/env-links/${envKey}`, { label, url });
    return of({ [envKey]: { label, url } } as Record<string, {label: string; url: string}>).pipe(delay(60));
  }
  setStatusOverride(release: string, stageKey: string, status: string): Observable<{overrides: Record<string,string>; checkpoints: Checkpoints}> {
    if (!this.USE_MOCK) return this.http.put<{overrides: Record<string,string>; checkpoints: Checkpoints}>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/status-overrides/${stageKey}`, { status });
    return of({ overrides: { [stageKey]: status }, checkpoints: {} as Checkpoints }).pipe(delay(60));
  }
  getStatusOverrides(release: string): Observable<Record<string,string>> {
    if (!this.USE_MOCK) return this.http.get<Record<string,string>>(`${this.API_BASE}/releases/${encodeURIComponent(release)}/status-overrides`);
    return of({} as Record<string,string>).pipe(delay(50));
  }

  getStatus(): Observable<ConnectionStatus[]> {
    if (!this.USE_MOCK) return this.http.get<ConnectionStatus[]>(`${this.API_BASE}/status`);
    return of([
      { system: 'JIRA', status: 'MOCK', detail: 'Mock data — not connecting to Jira', latencyMs: 0 },
      { system: 'SHAREPOINT', status: 'MOCK', detail: 'Mock — cookie auth (FedAuth + rtFa)', latencyMs: 0 },
      { system: 'OCTANE', status: 'MOCK', detail: 'Mock — client credentials', latencyMs: 0 },
      { system: 'SERVICENOW', status: 'MOCK', detail: 'Mock — Table API (change_request)', latencyMs: 0 },
    ] as ConnectionStatus[]).pipe(delay(90));
  }

  // ---- mock helpers (deterministic per release name) ----
  private releaseDateFor(name: string): Date {
    const releases = [];
    const today = new Date();
    for (let i = -3; i <= 6; i++) {
      const d = new Date(today); d.setDate(15); d.setMonth(today.getMonth() + i);
      const monthNum = ((today.getMonth() + i + 12) % 12) + 1;
      releases.push({ name: `25.${String(monthNum).padStart(2, '0')}`, d });
    }
    return (releases.find(r => r.name === name)?.d) || new Date();
  }

  private isShipped(name: string): boolean {
    const rel = this.releaseDateFor(name);
    return rel < new Date(Date.now() - 86400000);
  }

  private toEmail(name: string): string {
    return name.toLowerCase().replace(/'/g, '').replace(/ /g, '.') + '@bnpparibas.com';
  }

  private spComplete(r: Readiness): boolean {
    return r.prDoc && r.unitTest && r.estimationSheet && r.prExcel
      && r.octaneReviewDoc && r.octaneExecutionDoc;
  }

  private mockSubjects(name: string): Subject[] {
    const rng = this.seeded(this.hash(name));
    const healthy = this.isShipped(name);
    const count = 14 + Math.floor(rng() * 34);
    const subjects: Subject[] = [];
    const today = new Date();
    for (let i = 0; i < count; i++) {
      const devP = this.PEOPLE[Math.floor(rng() * this.PEOPLE.length)];
      let repP = this.PEOPLE[Math.floor(rng() * this.PEOPLE.length)];
      if (repP[0] === devP[0]) repP = this.PEOPLE[this.PEOPLE.length - 1 - Math.floor(rng() * this.PEOPLE.length)];
      const r = this.mockReadiness(rng, healthy);
      const created = new Date(today); created.setDate(today.getDate() - Math.floor(rng() * 40));
      const ids: string[] = [];
      const n = Math.floor(rng() * 4);
      for (let k = 0; k < n; k++) ids.push(String(100000 + Math.floor(rng() * 9999)));
      subjects.push({
        key: `REL-${1000 + (this.hash(name) % 100) + i}`,
        summary: this.SUMMARIES[Math.floor(rng() * this.SUMMARIES.length)],
        status: this.STATUSES[Math.floor(rng() * this.STATUSES.length)],
        developerName: devP[0],
        developerEmail: devP[1],
        reporterName: repP[0],
        reporterEmail: repP[1],
        createdDate: created.toISOString().slice(0, 10),
        octaneIds: ids,
        readiness: r,
      });
    }
    return subjects;
  }

  private mockReadiness(rng: () => number, healthy = false): Readiness {
    const p = (pct: number) => Math.floor(rng() * 100) < pct;
    // Shipped releases are mostly complete -> exercises the healthy meter states.
    const octane = healthy ? p(96) : p(70);
    const pr = healthy ? p(97) : p(80);
    const unit = healthy ? p(95) : p(75);
    const est = healthy ? p(98) : p(85);
    const prx = healthy ? p(96) : p(78);
    const rev = healthy ? p(94) : p(65);
    const exec = healthy ? p(93) : p(60);
    const missing: string[] = [];
    if (!octane) missing.push('OCTANE_TESTS_LINKED');
    if (!pr) missing.push('PR');
    if (!unit) missing.push('UNIT_TEST');
    if (!est) missing.push('ESTIMATION_SHEET');
    if (!prx) missing.push('PR_EXCEL');
    if (!rev) missing.push('OCTANE_REVIEW_DOC');
    if (!exec) missing.push('OCTANE_EXECUTION_DOC');
    // Octane env detail: problems when octane failed, else ~30% carry a yellow
    // "needs attention" flag even though the subject is otherwise ready.
    const envs = ['DEV', 'IST', 'UAT'];
    const octaneMissingEnvs: string[] = [];
    if (!octane) {
      const reasons = [' (failed)', ' (never run)', ' (wrong release)', ' (no test)'];
      octaneMissingEnvs.push(envs[Math.floor(rng() * 3)] + reasons[Math.floor(rng() * 4)]);
    } else if (Math.floor(rng() * 100) < 30) {
      octaneMissingEnvs.push(envs[Math.floor(rng() * 3)] + ' (needs attention)');
    }
    const octaneUrl = 'https://almoctane-eur.saas.microfocus.com/ui/entity-navigation?p=503004/41001&entityType=work_item&id=1285035&tabName=tests_in_backlog';
    const octaneDetail: string[] = [];
    const verdict = !octane ? ((octaneMissingEnvs[0] || '').match(/failed|never run|no test|wrong release/)?.[0] || 'failed')
      : (octaneMissingEnvs.length ? 'needs attention' : 'passed');
    octaneDetail.push(`Overall Octane result: ${verdict} ||${octaneUrl}`);
    // Demo the mixed flip on ~1 in 6 passing subjects.
    if (octane && !octaneMissingEnvs.length && Math.floor(rng() * 6) === 0) {
      octaneDetail.push('Latest run per test overrides the lifetime coverage counts: coverage showed 1 failed over time, but the most recent run of each test is now 3 passed / 0 failed → passed.');
    }
    octaneDetail.push(`DEV: testcase for Turn on/off switch — ${verdict} ||${octaneUrl}`);
    octaneDetail.push(`IST: eStars - cash matrices — ${verdict} ||${octaneUrl}`);
    octaneDetail.push(`UAT: eStars - cash matrices — ${verdict} ||${octaneUrl}`);
    const spBase = 'https://sharepoint.bnpparibas/sites/STS/Documents';
    const sharepointDetail: string[] = [
      `Peer Review Document: ${prx ? 'found' : 'missing'} ||${spBase}/PeerReview`,
      `Octane Testcase Review Document: ${rev ? 'found' : 'missing'} ||${spBase}/OctaneReview`,
      `Octane Testcase Execution Document: ${exec ? 'found' : 'missing'} ||${spBase}/OctaneExecution`,
    ];
    return {
      octaneTestsLinked: octane, prDoc: pr, unitTest: unit, estimationSheet: est,
      prExcel: prx, octaneReviewDoc: rev, octaneExecutionDoc: exec,
      missingCount: missing.length, missing, octaneUrl, octaneMissingEnvs, octaneDetail, sharepointDetail,
    };
  }

  private hash(s: string): number {
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = (h << 5) - h + s.charCodeAt(i); h |= 0; }
    return Math.abs(h);
  }
  private seeded(seed: number): () => number {
    let s = seed % 2147483647; if (s <= 0) s += 2147483646;
    const next = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
    // Warm up: the first few LCG outputs are correlated across nearby seeds.
    for (let i = 0; i < 8; i++) next();
    return next;
  }
}
