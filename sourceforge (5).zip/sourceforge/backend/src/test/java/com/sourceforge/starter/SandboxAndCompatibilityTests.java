package com.sourceforge.starter;

import com.sourceforge.starter.model.CosConfig;
import com.sourceforge.starter.model.DatabaseConfig;
import com.sourceforge.starter.model.DmzrConfig;
import com.sourceforge.starter.model.EnvironmentConfig;
import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.CompanyLlmClient;
import com.sourceforge.starter.service.SandboxCompileService;
import com.sourceforge.starter.service.VersionCatalog;
import com.sourceforge.starter.service.VersionCompatibilityService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests for the two services added for: LLM-backed compatible-version dropdowns
 * and the in-UI sandbox compile. The LLM is disabled by default so these run
 * fully offline (static compatibility map exercised; LLM path degrades gracefully).
 */
@SpringBootTest
class SandboxAndCompatibilityTests {

    @Autowired
    VersionCompatibilityService compat;

    @Autowired
    SandboxCompileService sandbox;

    @Autowired
    CompanyLlmClient llm;

    private ProjectRequest javaReq(Map<String, String> edited) {
        return new ProjectRequest(
                "maven", "java", "4.0.6",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21", "standard",
                List.of(), Map.of(), edited,
                new DatabaseConfig("h2", "", "sa", "", "update"),
                EnvironmentConfig.disabled(), DmzrConfig.disabled(),
                "ap00001", CosConfig.disabled());
    }

    @Test
    void llmDisabledByDefault() {
        assertFalse(llm.isEnabled(), "LLM must be disabled unless explicitly configured");
    }

    @Test
    void compatibleVersionsFallBackToStaticMap() {
        List<String> pg = compat.compatibleVersions("postgresql", "java", "4.0.6", "21");
        assertNotNull(pg);
        assertFalse(pg.isEmpty());
        assertEquals(VersionCatalog.MANAGED, pg.get(0), "managed must be first option");
        assertTrue(pg.size() > 1, "static map should provide concrete versions too");
    }

    @Test
    void unknownDependencyDefaultsToManaged() {
        List<String> opts = compat.compatibleVersions("totally-unknown-dep", "java", "4.0.6", "21");
        assertEquals(List.of(VersionCatalog.MANAGED), opts);
    }

    @Test
    void batchReturnsOneEntryPerDependency() {
        Map<String, List<String>> map =
                compat.compatibleVersionsBatch(List.of("postgresql", "lombok"), "java", "4.0.6", "21");
        assertTrue(map.containsKey("postgresql"));
        assertTrue(map.containsKey("lombok"));
    }

    @Test
    void sandboxCompilesValidGeneratedSources() {
        SandboxCompileService.CompileResult result = sandbox.compile(javaReq(Map.of()));
        assertTrue(result.compilerAvailable(), "JDK compiler must be available in the test JVM");
        assertTrue(result.ok(), "freshly generated standard project should compile: " + result.summary());
        assertEquals(0, result.errorCount());
    }

    @Test
    void sandboxReportsErrorsForBrokenEditedSource() {
        String badPath = "demo/src/main/java/com/example/demo/DemoApplication.java";
        String broken = "package com.example.demo;\npublic class DemoApplication { void x() { int y = ; } }\n";
        SandboxCompileService.CompileResult result = sandbox.compile(javaReq(Map.of(badPath, broken)));
        assertTrue(result.compilerAvailable());
        assertFalse(result.ok(), "broken edited source must fail compilation");
        assertTrue(result.errorCount() >= 1);
        assertTrue(result.diagnostics().stream().anyMatch(d -> "ERROR".equals(d.kind())));
    }
}
