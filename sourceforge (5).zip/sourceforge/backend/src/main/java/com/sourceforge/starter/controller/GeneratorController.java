package com.sourceforge.starter.controller;

import com.sourceforge.starter.model.ProjectRequest;
import com.sourceforge.starter.service.ProjectGeneratorService;
import com.sourceforge.starter.service.SandboxCompileService;
import com.sourceforge.starter.service.VersionCompatibilityService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class GeneratorController {

    private static final Logger log = LoggerFactory.getLogger(GeneratorController.class);

    private final ProjectGeneratorService generator;
    private final VersionCompatibilityService versionCompat;
    private final SandboxCompileService sandbox;

    public GeneratorController(ProjectGeneratorService generator,
                               VersionCompatibilityService versionCompat,
                               SandboxCompileService sandbox) {
        this.generator = generator;
        this.versionCompat = versionCompat;
        this.sandbox = sandbox;
    }

    /** Returns the full set of generated files as { path: content } for the Explore preview. */
    @PostMapping(value = "/preview", produces = "application/json")
    public ResponseEntity<Map<String, String>> preview(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        Map<String, String> files = generator.previewFiles(request);
        log.info("POST /api/preview  artifact={}  files={}  took={}ms",
                request.artifactId(), files.size(), System.currentTimeMillis() - start);
        return ResponseEntity.ok(files);
    }

    /**
     * Returns the compatible version dropdown options for each requested dependency,
     * given the selected Spring Boot + Java version. Resolved from the static
     * compatibility map, refined by the company LLM when configured.
     */
    @PostMapping(value = "/compatible-versions", produces = "application/json")
    public ResponseEntity<Map<String, List<String>>> compatibleVersions(@RequestBody CompatibilityRequest req) {
        Map<String, List<String>> out = versionCompat.compatibleVersionsBatch(
                req.dependencies() == null ? List.of() : req.dependencies(),
                req.language(), req.bootVersion() == null ? "" : req.bootVersion(), req.javaVersion());
        return ResponseEntity.ok(out);
    }

    public record CompatibilityRequest(List<String> dependencies, String language,
                                       String bootVersion, String javaVersion) {}

    /**
     * Compiles the generated Java sources in a sandbox (javac via the Compiler API)
     * and returns structured diagnostics so the UI can show errors before download.
     */
    @PostMapping(value = "/compile", produces = "application/json")
    public ResponseEntity<SandboxCompileService.CompileResult> compile(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        var result = sandbox.compile(request);
        log.info("POST /api/compile  artifact={}  ok={}  errors={}  took={}ms",
                request.artifactId(), result.ok(), result.errorCount(), System.currentTimeMillis() - start);
        return ResponseEntity.ok(result);
    }

    @PostMapping(value = "/generate", produces = "application/zip")
    public ResponseEntity<byte[]> generate(@Valid @RequestBody ProjectRequest request) {
        long start = System.currentTimeMillis();
        log.info("POST /api/generate  artifact={}  language={}  build={}  runtime={}  deps={}  db={}  arch={}  envs={}  dmzr={}",
                request.artifactId(),
                request.language(),
                request.type(),
                request.javaVersion(),
                request.dependencies().size(),
                request.database() != null ? request.database().type() : "none",
                request.architecture(),
                request.environments() != null && request.environments().enabled()
                        ? request.environments().environments() : "off",
                request.dmzr() != null && request.dmzr().enabled() ? "on" : "off");

        byte[] zip = generator.generate(request);

        log.info("POST /api/generate  artifact={}  size={}KB  took={}ms",
                request.artifactId(), zip.length / 1024, System.currentTimeMillis() - start);

        ContentDisposition cd = ContentDisposition.attachment()
                .filename(request.artifactId() + ".zip")
                .build();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/zip"));
        headers.setContentDisposition(cd);
        headers.setContentLength(zip.length);
        return new ResponseEntity<>(zip, headers, HttpStatus.OK);
    }
}
