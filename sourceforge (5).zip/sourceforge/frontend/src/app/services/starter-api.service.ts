import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MetadataResponse, ProjectRequest } from '../models/metadata.model';

@Injectable({ providedIn: 'root' })
export class StarterApiService {
  private readonly baseUrl = '/api';

  constructor(private http: HttpClient) {}

  getMetadata(): Observable<MetadataResponse> {
    return this.http.get<MetadataResponse>(`${this.baseUrl}/metadata`);
  }

  /** Returns { path: content } for the Explore preview. */
  previewProject(request: ProjectRequest): Observable<Record<string, string>> {
    return this.http.post<Record<string, string>>(`${this.baseUrl}/preview`, request);
  }

  generateProject(request: ProjectRequest): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/generate`, request, {
      responseType: 'blob'
    });
  }

  /** Compatible version dropdown options per dependency for the selected Boot/Java. */
  compatibleVersions(body: {
    dependencies: string[]; language: string; bootVersion: string; javaVersion: string;
  }): Observable<Record<string, string[]>> {
    return this.http.post<Record<string, string[]>>(`${this.baseUrl}/compatible-versions`, body);
  }

  /** Sandbox-compile the generated Java; returns structured diagnostics. */
  compileProject(request: ProjectRequest): Observable<CompileResult> {
    return this.http.post<CompileResult>(`${this.baseUrl}/compile`, request);
  }
}

export interface CompileDiagnostic {
  kind: string;
  path: string;
  line: number;
  column: number;
  message: string;
}

export interface CompileResult {
  ok: boolean;
  compilerAvailable: boolean;
  errorCount: number;
  warningCount: number;
  diagnostics: CompileDiagnostic[];
  summary: string;
}
