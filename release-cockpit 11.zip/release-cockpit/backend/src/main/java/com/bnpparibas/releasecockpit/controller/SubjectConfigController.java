package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.model.Domain.SubjectCheckConfig;
import com.bnpparibas.releasecockpit.service.SubjectConfigService;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Per-subject check configuration API, scoped by release so overrides for one
 * release never appear in another.
 *
 *   GET    /api/checks?release=..            -> { default, overrides:{key:cfg} }
 *   GET    /api/checks/{key}?release=..       -> effective config for one subject
 *   PUT    /api/checks/{key}?release=..       -> set a subject's override (body: cfg)
 *   DELETE /api/checks/{key}?release=..       -> revert subject to default
 */
@RestController
@RequestMapping("/api/checks")
public class SubjectConfigController {

    private final SubjectConfigService service;

    public SubjectConfigController(SubjectConfigService service) {
        this.service = service;
    }

    @GetMapping
    public Map<String, Object> all(@RequestParam(required = false, defaultValue = "") String release) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("default", service.getDefault());
        out.put("overrides", service.getOverrides(release));
        return out;
    }

    @GetMapping("/{key}")
    public SubjectCheckConfig one(@PathVariable String key,
                                  @RequestParam(required = false, defaultValue = "") String release) {
        return service.forSubject(release, key);
    }

    @PutMapping("/{key}")
    public SubjectCheckConfig update(@PathVariable String key,
                                     @RequestParam(required = false, defaultValue = "") String release,
                                     @RequestBody SubjectCheckConfig cfg) {
        return service.update(release, key, cfg);
    }

    @DeleteMapping("/{key}")
    public Map<String, Object> remove(@PathVariable String key,
                                      @RequestParam(required = false, defaultValue = "") String release) {
        service.remove(release, key);
        return Map.of("removed", key, "release", release);
    }
}
