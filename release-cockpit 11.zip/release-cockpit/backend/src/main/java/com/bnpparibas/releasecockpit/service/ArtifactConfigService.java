package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.ArtifactSpec;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Loads artifacts.json (the artifact definitions). Falls back to an empty list
 * if the file is missing or malformed, so the app never fails to start.
 */
@Slf4j
@Service
public class ArtifactConfigService {

    private static final String RESOURCE = "artifacts.json";
    private final ObjectMapper mapper = new ObjectMapper();
    private List<ArtifactSpec> specs = List.of();

    public ArtifactConfigService() {
        load();
    }

    private void load() {
        try {
            var res = new ClassPathResource(RESOURCE);
            if (!res.exists()) {
                log.warn("{} not found; SharePoint/Octane artifact checks disabled.", RESOURCE);
                return;
            }
            try (var in = res.getInputStream()) {
                specs = List.of(mapper.readValue(in, ArtifactSpec[].class));
            }
            log.info("Loaded {} artifact definitions from {}.", specs.size(), RESOURCE);
        } catch (Exception e) {
            log.warn("Could not load {} ({}); artifact checks disabled.", RESOURCE, e.getMessage());
            specs = List.of();
        }
    }

    public List<ArtifactSpec> all() { return specs; }

    public List<ArtifactSpec> sharePointArtifacts() {
        return specs.stream().filter(s -> "sharepoint".equalsIgnoreCase(s.source) && s.enabled).toList();
    }

    public List<ArtifactSpec> octaneArtifacts() {
        return specs.stream().filter(s -> "octane".equalsIgnoreCase(s.source) && s.enabled).toList();
    }
}
