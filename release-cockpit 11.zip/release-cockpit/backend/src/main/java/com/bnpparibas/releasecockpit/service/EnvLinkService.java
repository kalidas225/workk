package com.bnpparibas.releasecockpit.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores manually-entered environment links per release (PPD-1, PPD-2, and the
 * Prod ServiceNow change record). These are informational links shown under the
 * timeline in the Config tab. Persisted to config/env-links.json so they survive
 * restarts. Keys are release-scoped: "{release}::{envKey}".
 */
@Service
public class EnvLinkService {

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(EnvLinkService.class);
    /** Recognised environment link keys. */
    public static final java.util.List<String> KEYS = java.util.List.of(
            "PPD1", "PPD2", "PPD3", "PPD4", "PPD5", "PPD6", "PPD7", "PPD8", "PROD_SERVICENOW");

    private final ObjectMapper mapper = new ObjectMapper();
    private final File store = new File("config/env-links.json");
    private final Map<String, String> links = new ConcurrentHashMap<>();

    public EnvLinkService() { load(); }

    private void load() {
        try {
            if (store.exists()) {
                @SuppressWarnings("unchecked")
                Map<String, String> m = mapper.readValue(store, Map.class);
                links.putAll(m);
            }
        } catch (Exception e) { log.warn("Could not load env-links.json: {}", e.getMessage()); }
    }

    private synchronized void save() {
        try {
            store.getParentFile().mkdirs();
            Files.writeString(store.toPath(), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(links));
        } catch (Exception e) { log.warn("Could not save env-links.json: {}", e.getMessage()); }
    }

    /** All links for a release, as envKey -> {label, url} (only non-blank). */
    public Map<String, Map<String, String>> forRelease(String release) {
        Map<String, Map<String, String>> out = new LinkedHashMap<>();
        for (String k : KEYS) {
            String v = links.get(key(release, k));
            if (v != null && !v.isBlank()) {
                // Stored as "label\turl"; label optional.
                String label = "", url = v;
                int tab = v.indexOf('\t');
                if (tab >= 0) { label = v.substring(0, tab); url = v.substring(tab + 1); }
                Map<String, String> entry = new LinkedHashMap<>();
                entry.put("label", label);
                entry.put("url", url);
                out.put(k, entry);
            }
        }
        return out;
    }

    /** Sets (or clears when both blank) one env link for a release. */
    public synchronized Map<String, Map<String, String>> set(String release, String envKey, String label, String url) {
        if (!KEYS.contains(envKey)) throw new IllegalArgumentException("Unknown env link key: " + envKey);
        String k = key(release, envKey);
        String lbl = label == null ? "" : label.trim();
        String u = url == null ? "" : url.trim();
        if (lbl.isBlank() && u.isBlank()) links.remove(k);
        else links.put(k, lbl + "\t" + u);
        save();
        return forRelease(release);
    }

    private String key(String release, String envKey) { return release + "::" + envKey; }
}
