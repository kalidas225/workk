package com.bnpparibas.releasecockpit.scheduler;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.bnpparibas.releasecockpit.service.CheckpointService;
import com.bnpparibas.releasecockpit.service.HealthService;
import com.bnpparibas.releasecockpit.service.MailService;
import com.bnpparibas.releasecockpit.service.ReleaseService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Scheduled checks.
 *
 *  1. Periodic auto-check (every 2-3h, configurable cron): for each active
 *     release it refreshes data and — if cockpit.scheduler.auto-mail=true —
 *     emails developers about their gaps and sends a release-status summary to
 *     managers. This is the "auto check + trigger mails" loop.
 *
 *  2. Late-add detection (hourly): if a subject was added recently AND its
 *     release's end-UAT deadline is close, alert the developer once.
 *
 * In-memory dedupe prevents spamming; persist it for production so it survives
 * restarts.
 */
@Slf4j
@Component
public class IntelligentCheckScheduler {

    private final ReleaseService releaseService;
    private final CheckpointService checkpointService;
    private final HealthService healthService;
    private final MailService mailService;
    private final CockpitProperties props;

    private final Set<String> alertedLateAdds = new HashSet<>();
    private static final int LATE_ADD_WINDOW_DAYS = 5;

    public IntelligentCheckScheduler(ReleaseService releaseService,
                                     CheckpointService checkpointService,
                                     HealthService healthService,
                                     MailService mailService,
                                     CockpitProperties props) {
        this.releaseService = releaseService;
        this.checkpointService = checkpointService;
        this.healthService = healthService;
        this.mailService = mailService;
        this.props = props;
    }

    /**
     * Periodic auto-check. Default cron = every 3 hours
     * (configurable via cockpit.scheduler.auto-check-cron). When
     * cockpit.scheduler.auto-mail=true it emails gaps + a manager summary per
     * active release; otherwise it just refreshes the cached data.
     */
    @Scheduled(cron = "${cockpit.scheduler.auto-check-cron:0 0 */3 * * *}")
    public void autoCheck() {
        if (!props.getScheduler().isAutoCheckEnabled()) {
            log.debug("Auto-check skipped (cockpit.scheduler.auto-check-enabled=false)");
            return;
        }
        boolean autoMail = props.getScheduler().isAutoMail();
        log.info("Auto-check running (autoMail={})", autoMail);
        releaseService.refreshAll();

        for (Release release : releaseService.getReleases()) {
            if (release.released()) continue;
            List<Subject> subjects = releaseService.getAllSubjects(release.name());
            var checkpoints = releaseService.getCheckpoints(release.name());

            if (!autoMail) continue;

            int sent = mailService.sendAllAlerts(release.name(), subjects, checkpoints);

            ReleaseSummary summary = releaseService.getSummary(release.name());
            ReleaseHealth health = healthService.compute(summary, checkpoints);
            mailService.sendReleaseSummary(release.name(), summary, health, checkpoints, subjects);

            log.info("Auto-check {}: emailed {} developer(s) + summary", release.name(), sent);
        }
    }

    /** Late-add detection (every 3h by default; only End-UAT-approaching releases). */
    @Scheduled(cron = "${cockpit.scheduler.late-add-cron:0 0 */3 * * *}")
    public void detectLateAddsAndAlert() {
        if (!props.getScheduler().isAutoCheckEnabled()) return;
        LocalDate today = LocalDate.now();
        for (Release release : releaseService.getReleases()) {
            if (release.released()) continue;
            if (!checkpointService.isEndUatApproachingOrPassed(release.releaseDate(), today)) continue;

            for (Subject s : releaseService.getAllSubjects(release.name())) {
                boolean recentlyAdded = s.createdDate() != null
                        && !s.createdDate().isBefore(today.minusDays(LATE_ADD_WINDOW_DAYS));
                if (!recentlyAdded) continue;

                String dedupeKey = release.name() + "|" + s.key();
                if (alertedLateAdds.contains(dedupeKey)) continue;

                log.info("Late-add detected: {} in {} — end-UAT approaching. Alerting {}",
                        s.key(), release.name(), s.developerEmail());
                mailService.sendSubjectAlert(release.name(), s,
                        releaseService.getCheckpoints(release.name()));
                alertedLateAdds.add(dedupeKey);
            }
        }
    }
}
