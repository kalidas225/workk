package com.bnpparibas.releasecockpit.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Simple in-memory cache (swap for Caffeine/Redis in production) and CORS so
 * a separate-origin frontend can call the API (origins are config-driven).
 */
@Configuration
public class CacheConfig implements WebMvcConfigurer {

    private final CockpitProperties props;

    public CacheConfig(CockpitProperties props) {
        this.props = props;
    }

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("releases", "subjects");
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // Origins are config-driven (cockpit.cors.allowed-origins). When the
        // frontend is served by this same app (built into static resources),
        // CORS isn't needed at all; the default of "*" patterns covers dev.
        String[] origins = props.getCors().getAllowedOrigins();
        var mapping = registry.addMapping("/api/**")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*");
        if (origins != null && origins.length > 0) {
            mapping.allowedOriginPatterns(origins);
        } else {
            mapping.allowedOriginPatterns("*");
        }
    }
}
