package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * In-memory mock connector. Active when cockpit.mock-mode=true (the default),
 * so the dashboard runs immediately with realistic data and no credentials.
 *
 * The data is deterministic per release name (seeded RNG) so the UI is stable
 * across refreshes during demos and screenshots.
 */
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "true", matchIfMissing = true)
public class MockConnector implements ReleaseDataConnector {

    // Real team members (name + email). Used instead of random placeholders.
    private static final String[][] PEOPLE = {
            {"Sreenath Babu Vairavasingh", "sreenathbabu.vairavasingh@asia.bnpparibas.com"},
            {"Srinivasan Nagarajan", "srinivasan.nagarajan@asia.bnpparibas.com"},
            {"Selvakumar C", "selvakumar.c@asia.bnpparibas.com"},
            {"Kameshwaran Pandi", "kameshwaran.pandi@asia.bnpparibas.com"},
            {"Krishna Prakash Thangadurai", "krishnaprakash.thangadurai@asia.bnpparibas.com"},
            {"Soundarya Selvam", "soundarya.selvam@asia.bnpparibas.com"},
            {"Akhila Gowrishankar", "akhila.gowrishankar@asia.bnpparibas.com"},
            {"K Anjuna Raj", "anjunaraj.k@asia.bnpparibas.com"},
            {"Mayank Kumar", "mayank.1.kumar@asia.bnpparibas.com"},
            {"Pratik Bhakte", "pratik.bhakte@asia.bnpparibas.com"},
            {"Sapthagiri Kalyanakumar", "sapthagiri.kalyanakumar@ext.asia.bnpparibas.com"},
            {"Kalidas Singamsetty", "kalidas.singamsetty@asia.bnpparibas.com"},
            {"Krishnaraj L", "krishnaraj.l@asia.bnpparibas.com"},
            {"Ramabathren Lakshminarayanan", "ramabathren.lakshminarayanan@asia.bnpparibas.com"},
            {"Chandraleela Kamalamurthy", "chandraleela.kamalamurthy@asia.bnpparibas.com"},
            {"Akshaya R Srinivasan", "akshaya.rajagopalansrinivasan@asia.bnpparibas.com"},
            {"Sowmya Unnikrishnan", "sowmya.unnikrishnan@asia.bnpparibas.com"},
            {"Sivanesh Murugan", "sivanesh.murugan@asia.bnpparibas.com"},
            {"Mukesh J", "mukesh.j@asia.bnpparibas.com"},
            {"P D Nancy", "nancy.pd@asia.bnpparibas.com"},
            {"Manusri Boppana", "manusri.boppana@asia.bnpparibas.com"},
            {"Aruna Rathinam", "aruna.rathinam@ext.asia.bnpparibas.com"},
    };

    @Override
    public List<Release> listReleases() {
        // A year of monthly releases; dates spread around "now" so checkpoints
        // show a mix of upcoming / active / overdue states in the demo.
        LocalDate today = LocalDate.now();
        List<Release> releases = new ArrayList<>();
        for (int i = -3; i <= 6; i++) {
            // Snap each mock release to a Saturday so the demo timeline matches
            // the real "release always Saturday" rule.
            LocalDate relDate = today.plusWeeks(i * 4L)
                    .with(java.time.temporal.TemporalAdjusters.nextOrSame(java.time.DayOfWeek.SATURDAY));
            String name = String.format("25.%02d", ((today.getMonthValue() + i - 1 + 12) % 12) + 1);
            boolean released = relDate.isBefore(today.minusDays(1));
            releases.add(new Release(
                    "v" + (1000 + i),
                    name,
                    relDate,
                    released,
                    "Monthly platform release " + name
            ));
        }
        return releases;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        Random rng = new Random(releaseName.hashCode());
        int count = 8 + rng.nextInt(30); // between 8 and 37 subjects -> exercises pagination
        List<Subject> subjects = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (int i = 0; i < count; i++) {
            String[] devP = PEOPLE[rng.nextInt(PEOPLE.length)];
            String dev = devP[0];
            String email = devP[1];
            String[] repP = PEOPLE[rng.nextInt(PEOPLE.length)];
            if (repP[0].equals(dev)) repP = PEOPLE[(PEOPLE.length - 1 - rng.nextInt(PEOPLE.length))];
            String reporter = repP[0];
            String reporterEmail = repP[1];
            // Some subjects fully ready, others missing 1-4 items.
            Readiness r = randomReadiness(rng);
            // A few subjects created very recently -> "late add" demo.
            LocalDate created = today.minusDays(rng.nextInt(40));

            List<String> octaneIds = new ArrayList<>();
            int nIds = rng.nextInt(4);
            for (int k = 0; k < nIds; k++) octaneIds.add(String.valueOf(100000 + rng.nextInt(9999)));

            subjects.add(new Subject(
                    "REL-" + (1000 + releaseName.hashCode() % 100 + i),
                    SUMMARIES[rng.nextInt(SUMMARIES.length)],
                    STATUSES[rng.nextInt(STATUSES.length)],
                    dev,
                    email,
                    reporter,
                    reporterEmail,
                    created,
                    octaneIds,
                    r
            ));
        }
        return subjects;
    }

    private Readiness randomReadiness(Random rng) {
        boolean octane = rng.nextInt(100) < 70;
        boolean pr = rng.nextInt(100) < 80;
        boolean unit = rng.nextInt(100) < 75;
        boolean est = rng.nextInt(100) < 85;
        boolean prx = rng.nextInt(100) < 78;
        boolean rev = rng.nextInt(100) < 65;
        boolean exec = rng.nextInt(100) < 60;

        List<String> missing = new ArrayList<>();
        if (!octane) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prx) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");

        // Mock some missing Octane environments for subjects with an Octane gap,
        // with a reason so the UI can show failed/never-run/wrong-release styling.
        List<String> octaneMissingEnvs = new ArrayList<>();
        if (!octane) {
            String[] envs = {"DEV", "IST", "UAT"};
            String[] reasons = {" (failed)", " (never run)", " (wrong release)", " (no test)"};
            octaneMissingEnvs.add(envs[rng.nextInt(envs.length)] + reasons[rng.nextInt(reasons.length)]);
        } else if (rng.nextInt(100) < 30) {
            // ~30% of otherwise-ready subjects carry a yellow "needs attention" flag.
            String[] envs = {"DEV", "IST", "UAT"};
            octaneMissingEnvs.add(envs[rng.nextInt(envs.length)] + " (needs attention)");
        }
        String octaneUrl = "https://almoctane-eur.saas.microfocus.com/ui/entity-navigation?p=503004/41001&entityType=work_item&id=1285035&tabName=tests_in_backlog";

        // Mock per-env run summary.
        java.util.Map<String,String> envSummary = new java.util.LinkedHashMap<>();
        int dp = rng.nextInt(4), ip = rng.nextInt(3), up = rng.nextInt(3);
        envSummary.put("DEV", dp > 0 ? dp + "✓" : "no run");
        envSummary.put("IST", ip > 0 ? ip + "✓" : "no run");
        envSummary.put("UAT", up > 0 ? up + "✓" : "no run");
        int totalRuns = dp + ip + up, passedRuns = totalRuns, failedRuns = 0;

        // Mock per-test transparency detail (clean format, with links).
        java.util.List<String> octaneDetail = new ArrayList<>();
        String verdict = !octane ? "failed" : (octaneMissingEnvs.isEmpty() ? "passed" : "needs attention");
        octaneDetail.add("Overall Octane result: " + verdict + " ||" + octaneUrl);
        octaneDetail.add("DEV: eStars regression suite — " + verdict + " ||" + octaneUrl);
        octaneDetail.add("IST: eStars - cash matrices — " + verdict + " ||" + octaneUrl);
        octaneDetail.add("UAT: eStars - cash matrices — " + verdict + " ||" + octaneUrl);

        // Mock SharePoint detail.
        java.util.List<String> sharepointDetail = new ArrayList<>();
        String spBase = "https://sharepoint.bnpparibas/sites/STS/Documents";
        sharepointDetail.add("Peer Review Document: " + (prx ? "found" : "missing") + " ||" + spBase + "/PeerReview");
        sharepointDetail.add("Octane Testcase Review Document: " + (rev ? "found" : "missing") + " ||" + spBase + "/OctaneReview");
        sharepointDetail.add("Octane Testcase Execution Document: " + (exec ? "found" : "missing") + " ||" + spBase + "/OctaneExecution");

        return new Readiness(octane, pr, unit, est, prx, rev, exec, missing.size(), missing,
                octaneUrl, octaneMissingEnvs, totalRuns, passedRuns, failedRuns, envSummary, octaneDetail, sharepointDetail);
    }

    private String toEmail(String name) {
        return name.toLowerCase()
                .replace("'", "")
                .replace(" ", ".") + "@bnpparibas.com";
    }

    private static final String[] STATUSES = {"In Progress", "In Review", "Ready for UAT", "Blocked", "Done"};
    private static final String[] SUMMARIES = {
            "Payments reconciliation service",
            "Authentication token rotation",
            "Trade settlement batch optimisation",
            "Client onboarding KYC flow",
            "Regulatory reporting export",
            "Liquidity dashboard widgets",
            "FX rate ingestion pipeline",
            "Audit log retention policy",
            "Margin call notification engine",
            "Counterparty risk scoring"
    };
}
