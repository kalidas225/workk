package com.bnpparibas.releasecockpit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableCaching
@EnableScheduling
public class ReleaseCockpitApplication {
    public static void main(String[] args) {
        // Must be set before ANY java.net.http.HttpClient is created (the JDK reads
        // it once at class-init). Without it, when a proxy Authenticator is present
        // the HttpClient silently drops per-request Authorization headers — which
        // breaks the ServiceNow OAuth2 token call ("Authorization header not valid
        // or not found"). Setting it here, first thing, guarantees it takes effect.
        String allowed = System.getProperty("jdk.httpclient.allowRestrictedHeaders", "");
        if (!allowed.toLowerCase().contains("authorization")) {
            System.setProperty("jdk.httpclient.allowRestrictedHeaders",
                    allowed.isBlank() ? "Authorization" : allowed + ",Authorization");
        }
        SpringApplication.run(ReleaseCockpitApplication.class, args);
    }
}
