package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.model.Domain.ConnectionStatus;
import com.bnpparibas.releasecockpit.service.StatusService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * System status API — powers the single "systems" panel that shows Jira,
 * SharePoint and Octane connection health in one place.
 *
 *   GET /api/status   -> [ {system, status, detail, latencyMs}, ... ]
 */
@RestController
@RequestMapping("/api/status")
public class StatusController {

    private final StatusService statusService;

    public StatusController(StatusService statusService) {
        this.statusService = statusService;
    }

    @GetMapping
    public List<ConnectionStatus> status() {
        return statusService.all();
    }
}
