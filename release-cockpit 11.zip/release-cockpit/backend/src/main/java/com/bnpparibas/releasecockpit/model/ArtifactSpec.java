package com.bnpparibas.releasecockpit.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * One artifact definition loaded from artifacts.json — mirrors the Release
 * Guardian artifact spec.
 *
 * SharePoint artifacts: a file matches when its name contains ALL of match.all
 * (after {EPIC} substitution) AND at least one of match.any AND (if extensions
 * is non-empty) ends with one of the listed extensions. goInside means recurse
 * into the folder's subfolders. minFiles is how many matches are required.
 *
 * Octane artifacts: source="octane" — handled by the Octane check, not here.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ArtifactSpec {
    public String key;
    public String label;
    public boolean enabled = true;
    public String source;            // "sharepoint" | "octane"
    public String folder = "";       // may contain {YEAR}; "" = library root
    public boolean goInside = false; // recurse into subfolders
    public Match match;
    public int minFiles = 1;

    // Octane-only fields (read by the Octane check)
    public Integer minTestCases;
    public Boolean requireAll;
    public List<String> environments = List.of();
    public Boolean mandatory;
    public String linkMode;
    public Boolean moduleAsKey;
    public Boolean requireRunsPassed;
    public String testTypePattern;

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Match {
        public String type;                 // "nameContains"
        public List<String> all = List.of();
        public List<String> any = List.of();
        public List<String> extensions = List.of();
    }
}
