package com.bnpparibas.releasecockpit.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.List;

/**
 * Builds and sends MIME messages through the EMA SMTP relay (JavaMailSender).
 * Used for the standard/production mailing path.
 */
public class EmailMessageFactory {

    private final JavaMailSender javaMailSender;

    public EmailMessageFactory(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public MimeMessage createMessage(String from, String replyTo, List<String> to, List<String> cc,
                                     String subject, String htmlBody) throws MessagingException {
        final MimeMessage message = javaMailSender.createMimeMessage();
        final MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

        helper.setFrom(new InternetAddress(from));
        helper.setReplyTo(new InternetAddress(
                (replyTo == null || replyTo.isBlank()) ? from : firstAddress(replyTo)));
        helper.setTo(to.toArray(new String[0]));
        if (cc != null && !cc.isEmpty()) helper.setCc(cc.toArray(new String[0]));
        helper.setSubject(subject);
        helper.setText(htmlBody, true);
        return message;
    }

    public void send(MimeMessage message) {
        javaMailSender.send(message);
    }

    private String firstAddress(String csv) {
        String first = csv.split(",")[0].trim();
        return first.isEmpty() ? csv : first;
    }
}
