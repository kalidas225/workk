package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.connector.ReleaseDataConnector;
import com.bnpparibas.releasecockpit.model.Domain.*;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central service. Aggregates connector data into the shapes the dashboard
 * needs: paginated subjects, pie-chart summaries, and per-release checkpoints.
 *
 * Hybrid caching: results are cached (see CacheConfig) and served instantly;
 * the UI's "Refresh" button calls evict* to force a re-fetch.
 */
@Service
public class ReleaseService {

    private final ReleaseDataConnector connector;
    private final CheckpointService checkpointService;
    private final CheckpointOverrideService overrideService;
    private final StatusOverrideService statusOverrideService;
    private final ScanService scanService;

    public ReleaseService(ReleaseDataConnector connector, CheckpointService checkpointService,
                          CheckpointOverrideService overrideService, StatusOverrideService statusOverrideService,
                          ScanService scanService) {
        this.connector = connector;
        this.checkpointService = checkpointService;
        this.overrideService = overrideService;
        this.statusOverrideService = statusOverrideService;
        this.scanService = scanService;
    }

    @Cacheable("releases")
    public List<Release> getReleases() {
        // Null-safe: some Jira versions have no release date — sort those last.
        return connector.listReleases().stream()
                .sorted(Comparator.comparing(Release::releaseDate,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());
    }

    public Release getRelease(String releaseName) {
        return getReleases().stream()
                .filter(r -> r.name().equals(releaseName))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Release not found: " + releaseName));
    }

    public Checkpoints getCheckpoints(String releaseName) {
        Checkpoints cp = checkpointService.compute(getRelease(releaseName).releaseDate(),
                overrideService.forRelease(releaseName));
        // Apply manual per-stage status overrides from the Config tab.
        Map<String, String> statusOv = statusOverrideService.forRelease(releaseName);
        if (statusOv.isEmpty() || cp.timeline() == null) return cp;
        java.util.List<Milestone> tl = new java.util.ArrayList<>();
        for (Milestone m : cp.timeline()) {
            String ov = statusOv.get(m.key());
            tl.add(ov != null ? new Milestone(m.key(), m.label(), m.date(), ov, m.overridden()) : m);
        }
        return new Checkpoints(cp.releaseDate(), cp.ppdStart(), cp.endUatDone(), cp.ppdStatus(),
                cp.endUatStatus(), cp.daysToRelease(), tl, cp.docCutoff());
    }

    /** Sets or clears a single checkpoint stage override, returns updated checkpoints. */
    public Checkpoints setCheckpointOverride(String releaseName, String stage, java.time.LocalDate date) {
        overrideService.setOverride(releaseName, stage, date);
        return getCheckpoints(releaseName);
    }

    /** Clears all checkpoint overrides for a release (reset to Jira-derived). */
    public Checkpoints resetCheckpointOverrides(String releaseName) {
        overrideService.clearRelease(releaseName);
        return getCheckpoints(releaseName);
    }

    /** Subjects come from the background scan cache — returns instantly. */
    public List<Subject> getAllSubjects(String releaseName) {
        return scanService.getSubjects(releaseName);
    }

    /** A single subject by key from the freshest cached scan (or null if not found). */
    public Subject getSubject(String releaseName, String subjectKey) {
        return getAllSubjects(releaseName).stream()
                .filter(s -> s.key().equalsIgnoreCase(subjectKey))
                .findFirst().orElse(null);
    }

    /** Synchronously re-check a single subject and return its fresh data. */
    public Subject refreshOneSubject(String releaseName, String subjectKey) {
        return scanService.refreshOneSubject(releaseName, subjectKey);
    }

    /** Scan status for the UI (last/next check, scanning flag). */
    public ScanService.ScanState getScanState(String releaseName) {
        return scanService.state(releaseName);
    }

    /** Paginated slice of subjects (page is 0-based). */
    public Page<Subject> getSubjectsPage(String releaseName, int page, int size) {
        List<Subject> all = getAllSubjects(releaseName);
        int from = Math.max(0, page * size);
        int to = Math.min(all.size(), from + size);
        List<Subject> slice = from >= all.size() ? List.of() : all.subList(from, to);
        return new Page<>(slice, page, size, all.size());
    }

    /** Aggregates the data the pie charts need. */
    public ReleaseSummary getSummary(String releaseName) {
        List<Subject> all = getAllSubjects(releaseName);
        int ready = (int) all.stream().filter(s -> s.readiness().missingCount() == 0).count();
        int notReady = all.size() - ready;

        Map<String, Long> byDev = all.stream()
                .collect(Collectors.groupingBy(Subject::developerName, Collectors.counting()));
        List<DeveloperLoad> dist = byDev.entrySet().stream()
                .map(e -> new DeveloperLoad(e.getKey(), e.getValue().intValue()))
                .sorted(Comparator.comparingInt(DeveloperLoad::subjectCount).reversed())
                .collect(Collectors.toList());

        int octaneOk = (int) all.stream().filter(s -> s.readiness().octaneTestsLinked()).count();
        int spOk = (int) all.stream().filter(this::sharepointComplete).count();

        ReadinessBreakdown breakdown = new ReadinessBreakdown(
                octaneOk, all.size() - octaneOk,
                spOk, all.size() - spOk
        );

        return new ReleaseSummary(releaseName, all.size(), ready, notReady, dist, breakdown);
    }

    private boolean sharepointComplete(Subject s) {
        Readiness r = s.readiness();
        return r.prDoc() && r.unitTest() && r.estimationSheet()
                && r.prExcel() && r.octaneReviewDoc() && r.octaneExecutionDoc();
    }

    /** Force a refresh: clear caches so next read re-fetches from the source. */
    @CacheEvict(cacheNames = {"releases"}, allEntries = true)
    public void refreshAll() {
        // releases cache evicted by annotation; subject scans refreshed per release.
    }

    /** Refresh one release's scan in the background. */
    public void refreshRelease(String releaseName) {
        scanService.refresh(releaseName);
    }

    /** A minimal page wrapper (avoids dragging in Spring Data). */
    public record Page<T>(List<T> content, int page, int size, int totalElements) {
        public int totalPages() {
            return size == 0 ? 0 : (int) Math.ceil((double) totalElements / size);
        }
    }
}
