package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Lightweight UI config — lets the frontend self-configure (default release to
 * auto-select, Jira base URL for subject links) from the backend properties so
 * nothing is hardcoded in the client.
 *
 *   GET /api/config -> { defaultRelease, jiraBaseUrl }
 */
@RestController
@RequestMapping("/api/config")
public class ConfigController {

    private final CockpitProperties props;
    private final com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts;

    public ConfigController(CockpitProperties props,
                            com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts) {
        this.props = props;
        this.artifacts = artifacts;
    }

    @GetMapping
    public Map<String, Object> config() {
        Map<String, Object> m = new HashMap<>();
        m.put("defaultRelease", props.getJira().getDefaultRelease());
        m.put("jiraBaseUrl", props.getJira().getBaseUrl());
        m.put("sharePointBaseUrl", props.getSharepoint().getBaseUrl());
        m.put("sharePointLibrary", props.getSharepoint().getLibraryName());
        // artifact folder templates (with {YEAR}) so the UI can build "create here" links
        Map<String, Object> folders = new HashMap<>();
        for (var a : artifacts.sharePointArtifacts()) {
            Map<String, Object> one = new HashMap<>();
            one.put("folder", a.folder);
            one.put("goInside", a.goInside);
            one.put("label", a.label);
            folders.put(a.key, one);
        }
        m.put("sharePointArtifacts", folders);
        return m;
    }
}
