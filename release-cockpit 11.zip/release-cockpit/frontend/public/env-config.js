// Runtime config — edit AFTER build without recompiling. Loaded before the app.
//   useMock : true  = in-browser demo data (no backend)
//             false = call the real API at apiBase
//   apiBase : the API root. Local dev points straight at the backend on 8080.
window.__cockpit = {
  useMock: false,
  apiBase: 'http://localhost:8080/api',
  jiraBaseUrl: 'https://jira.group.echonet'
};
