import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MetadataResponse, ProjectRequest } from '../models/metadata.model';

@Injectable({ providedIn: 'root' })
export class StarterApiService {
  private readonly baseUrl = '/api';

  constructor(private http: HttpClient) {}

  getMetadata(): Observable<MetadataResponse> {
    return this.http.get<MetadataResponse>(`${this.baseUrl}/metadata`);
  }

  /** Returns { path: content } for the Explore preview. */
  previewProject(request: ProjectRequest): Observable<Record<string, string>> {
    return this.http.post<Record<string, string>>(`${this.baseUrl}/preview`, request);
  }

  generateProject(request: ProjectRequest): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/generate`, request, {
      responseType: 'blob'
    });
  }
}
