package com.sourceforge.starter.model;

/**
 * Per-environment deployment settings supplied by the user.
 * Each selected profile (dev, ist, uat, ppd, prod) can have its own values,
 * which are substituted into bootstrap-{env}.yaml and the Helm values-*.yaml.
 */
public record EnvironmentSetting(
        String ecosystem,        // e.g. EC002I002789 / a BP2S ecosystem identifier
        String kubernetesPath,   // Vault kubernetes auth path, e.g. kubernetes_ku002i000843
        String namespace         // Vault / k8s namespace, e.g. UPM_BP2S/BP2SCLOUD/EC002I002789
) {
    public EnvironmentSetting {
        if (ecosystem == null) ecosystem = "";
        if (kubernetesPath == null) kubernetesPath = "";
        if (namespace == null) namespace = "";
    }

    public boolean isEmpty() {
        return ecosystem.isBlank() && kubernetesPath.isBlank() && namespace.isBlank();
    }
}
