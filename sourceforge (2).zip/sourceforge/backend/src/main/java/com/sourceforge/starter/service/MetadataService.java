package com.sourceforge.starter.service;

import com.sourceforge.starter.model.ArchitectureOption;
import com.sourceforge.starter.model.DependencyCategory;
import com.sourceforge.starter.model.LanguageMetadata;
import com.sourceforge.starter.model.MetadataResponse;
import com.sourceforge.starter.model.ProjectDefaults;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MetadataService {

    // Java — Maven only; Spring Boot 4.x requires Java 17+ and supports up to Java 26
    public static final List<String> JAVA_BUILD_TYPES = List.of("maven");
    public static final List<String> JAVA_VERSIONS    = List.of("26", "25", "21", "17");
    public static final List<String> JAVA_PACKAGINGS  = List.of("jar", "war");
    public static final List<String> BOOT_VERSIONS    = List.of("4.0.6", "4.0.5", "3.5.14", "3.5.13");

    // Python
    public static final List<String> PYTHON_BUILD_TYPES = List.of("poetry", "pip");
    public static final List<String> PYTHON_VERSIONS    = List.of("3.13", "3.12", "3.11", "3.10");
    public static final List<String> PYTHON_PACKAGINGS  = List.of("wheel", "sdist");

    public static final List<String> ENVIRONMENTS = List.of("dev", "ist", "uat", "ppd", "prod");

    private final DependencyCatalogService catalog;

    public MetadataService(DependencyCatalogService catalog) {
        this.catalog = catalog;
    }

    public MetadataResponse getMetadata() {
        LanguageMetadata java = new LanguageMetadata(
                "java", "Java",
                JAVA_BUILD_TYPES, JAVA_VERSIONS, JAVA_PACKAGINGS, BOOT_VERSIONS,
                new ProjectDefaults(
                        "maven", "java", "4.0.6",
                        "com.example", "demo", "demo",
                        "Demo project for Spring Boot", "com.example.demo",
                        "jar", "21"
                ),
                catalog.getJavaCategories()
        );

        LanguageMetadata python = new LanguageMetadata(
                "python", "Python",
                PYTHON_BUILD_TYPES, PYTHON_VERSIONS, PYTHON_PACKAGINGS, List.of(),
                new ProjectDefaults(
                        "poetry", "python", "",
                        "com.example", "demo", "demo",
                        "Demo Python project", "com.example.demo",
                        "wheel", "3.12"
                ),
                catalog.getPythonCategories()
        );

        return new MetadataResponse(
                List.of("java", "python"),
                "java",
                List.of(java, python),
                ENVIRONMENTS,
                List.of(
                        new ArchitectureOption("standard", "Standard",
                                "Just the application class — add your own structure."),
                        new ArchitectureOption("mvc", "MVC (layered)",
                                "Controller → Service → Repository → Model with a sample REST resource."),
                        new ArchitectureOption("microservice", "Microservice",
                                "Layered + REST client, externalised config, OpenAPI and global error handling.")
                ),
                buildVersionSuggestions()
        );
    }

    /** Suggested versions for every dependency in both catalogs (depId -> versions). */
    private Map<String, List<String>> buildVersionSuggestions() {
        Map<String, List<String>> out = new LinkedHashMap<>();
        for (DependencyCategory cat : catalog.getJavaCategories()) {
            for (var d : cat.dependencies()) out.put(d.id(), VersionCatalog.suggestionsFor(d.id()));
        }
        for (DependencyCategory cat : catalog.getPythonCategories()) {
            for (var d : cat.dependencies()) out.put(d.id(), VersionCatalog.suggestionsFor(d.id()));
        }
        return out;
    }
}
