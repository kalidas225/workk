package com.sourceforge.starter.service;

import com.sourceforge.starter.model.EnvironmentSetting;
import com.sourceforge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Generates the deployment chart assets under a single top-level chart/ folder
 * (outside src). Layout:
 *
 *   chart/
 *     files/httpd.conf
 *     templates/deployment.yaml
 *     templates/service.yaml
 *     templates/_helpers.tpl
 *     Chart.yaml
 *     chart-dependencies.info
 *     helmfile.yaml
 *     service-account.yaml
 *     values-default.yaml
 *     values-<env>.yaml          (one per selected profile)
 *
 * Profiles selected in the UI (dev/ist/uat/ppd/prod) map to helm environment
 * names (development/integration/staging|teststaging/pre-production/production).
 * Namespace and ecosystem come from the per-environment settings the user supplied.
 */
@Component
public class ChartAssetBuilder {

    /** Maps a selected Spring profile id to its Helm environment file name. */
    public static String helmEnvName(String profile) {
        return switch (profile) {
            case "dev"  -> "development";
            case "ist"  -> "integration";
            case "uat"  -> "staging";
            case "ppd"  -> "pre-production";
            case "prod" -> "production";
            default      -> profile;
        };
    }

    public String chartYaml(ProjectRequest req) {
        return ""
                + "apiVersion: v2\n"
                + "name: " + req.artifactId() + "\n"
                + "description: Helm chart for " + req.artifactId() + " (" + req.effectiveApplicationCode() + ")\n"
                + "type: application\n"
                + "version: 0.1.0\n"
                + "appVersion: \"0.1.0\"\n";
    }

    public String chartDependenciesInfo(ProjectRequest req) {
        return ""
                + "# chart-dependencies.info\n"
                + "# Resolved chart dependencies for " + req.artifactId() + " (" + req.effectiveApplicationCode() + ").\n"
                + "name: " + req.artifactId() + "\n"
                + "applicationCode: " + req.effectiveApplicationCode() + "\n"
                + "dependencies:\n"
                + "  - name: bp2s-microservice\n"
                + "    repository: https://artifactory-dogen.group.echonet/helm-charts\n"
                + "    version: 2.x\n";
    }

    /** helmfile referencing only the environments that were selected (+ default). */
    public String helmfileYaml(ProjectRequest req, List<String> selectedProfiles) {
        String app = req.artifactId();
        StringBuilder sb = new StringBuilder();
        sb.append("# helmfile.yaml - environments for ").append(app).append("\n");
        sb.append("environments:\n");
        sb.append("  default:\n");
        sb.append("    values:\n");
        sb.append("      - values-default.yaml\n");
        for (String profile : selectedProfiles) {
            String env = helmEnvName(profile);
            sb.append("  ").append(env).append(":\n");
            sb.append("    values:\n");
            sb.append("      - values-default.yaml\n");
            sb.append("      - values-").append(env).append(".yaml\n");
        }
        sb.append("---\n");
        sb.append("releases:\n");
        sb.append("  - name: ").append(app).append("\n");
        sb.append("    namespace: {{ .Environment.Values.namespace | default .Environment.Name }}\n");
        sb.append("    chart: bp2s-microservice/bp2s-microservice\n");
        sb.append("    values:\n");
        sb.append("      - values-default.yaml\n");
        sb.append("      - values-{{ .Environment.Name }}.yaml\n");
        return sb.toString();
    }

    public String serviceAccountYaml(ProjectRequest req) {
        String app = req.artifactId();
        String appCode = req.effectiveApplicationCode();
        String shortName = shortName(app);
        return ""
                + "apiVersion: v1\n"
                + "kind: ServiceAccount\n"
                + "metadata:\n"
                + "  name: " + app + "\n"
                + "  labels:\n"
                + "    app.kubernetes.io/name: " + app + "\n"
                + "    bnpp.applicationCode: " + appCode + "\n"
                + "  annotations:\n"
                + "    # Bound to the Vault Kubernetes auth role for this application.\n"
                + "    vault.role: ns002i008682_" + shortName + "-" + appCode + "-application\n";
    }

    /** values-default.yaml - shared defaults. */
    public String valuesDefault(ProjectRequest req) {
        String app = req.artifactId();
        String appCode = req.effectiveApplicationCode();
        return ""
                + "# values-default.yaml - shared defaults for " + app + "\n"
                + "application:\n"
                + "  name: " + app + "\n"
                + "  code: " + appCode + "\n"
                + "image:\n"
                + "  repository: base-images-catalog.artifactory-dogen.group.echonet/" + app + "\n"
                + "  pullPolicy: IfNotPresent\n"
                + "service:\n"
                + "  type: ClusterIP\n"
                + "  port: 8080\n"
                + "serviceAccount:\n"
                + "  create: true\n"
                + "  name: " + app + "\n"
                + "resources:\n"
                + "  requests:\n"
                + "    cpu: 200m\n"
                + "    memory: 512Mi\n"
                + "  limits:\n"
                + "    cpu: 1000m\n"
                + "    memory: 1Gi\n"
                + "probes:\n"
                + "  liveness: /actuator/health/liveness\n"
                + "  readiness: /actuator/health/readiness\n";
    }

    /** values-<env>.yaml - per-environment overrides incl. namespace + ecosystem. */
    public String valuesForProfile(ProjectRequest req, String profile, EnvironmentSetting setting) {
        String app = req.artifactId();
        String env = helmEnvName(profile);
        String namespace = setting.namespace().isBlank() ? env : setting.namespace();
        String ecosystem = setting.ecosystem().isBlank() ? defaultEcosystem(profile) : setting.ecosystem();
        return ""
                + "# values-" + env + ".yaml - overrides for the " + env + " environment (profile: " + profile + ")\n"
                + "namespace: " + namespace + "\n"
                + "ecosystem: " + ecosystem + "\n"
                + "springProfile: " + profile + "\n"
                + "replicaCount: " + replicasFor(profile) + "\n"
                + "image:\n"
                + "  tag: " + tagFor(profile) + "\n"
                + "ingress:\n"
                + "  enabled: true\n"
                + "  host: " + app + "-" + env + ".apps.echonet\n";
    }

    /** chart/files/httpd.conf - a basic Apache httpd config. */
    public String httpdConf(ProjectRequest req) {
        String app = req.artifactId();
        return ""
                + "# httpd.conf - basic reverse proxy front for " + app + "\n"
                + "ServerRoot \"/etc/httpd\"\n"
                + "Listen 8443\n"
                + "ServerName " + app + ".apps.echonet\n\n"
                + "LoadModule mpm_event_module modules/mod_mpm_event.so\n"
                + "LoadModule unixd_module modules/mod_unixd.so\n"
                + "LoadModule authz_core_module modules/mod_authz_core.so\n"
                + "LoadModule log_config_module modules/mod_log_config.so\n"
                + "LoadModule proxy_module modules/mod_proxy.so\n"
                + "LoadModule proxy_http_module modules/mod_proxy_http.so\n"
                + "LoadModule headers_module modules/mod_headers.so\n"
                + "LoadModule ssl_module modules/mod_ssl.so\n\n"
                + "User webadmin\n"
                + "Group web\n\n"
                + "ErrorLog \"/usr/local/instances/" + app + "/logs/httpd-error.log\"\n"
                + "LogLevel warn\n"
                + "LogFormat \"%h %l %u %t \\\"%r\\\" %>s %b\" common\n"
                + "CustomLog \"/usr/local/instances/" + app + "/logs/httpd-access.log\" common\n\n"
                + "<VirtualHost *:8443>\n"
                + "    ServerName " + app + ".apps.echonet\n\n"
                + "    SSLEngine on\n"
                + "    SSLCertificateFile \"/usr/local/certs/server.crt\"\n"
                + "    SSLCertificateKeyFile \"/usr/local/certs/server.key\"\n\n"
                + "    ProxyPreserveHost On\n"
                + "    ProxyPass        / http://127.0.0.1:8080/\n"
                + "    ProxyPassReverse / http://127.0.0.1:8080/\n\n"
                + "    RequestHeader set X-Forwarded-Proto \"https\"\n"
                + "</VirtualHost>\n";
    }

    public String deploymentTemplate(ProjectRequest req) {
        String app = req.artifactId();
        return ""
                + "apiVersion: apps/v1\n"
                + "kind: Deployment\n"
                + "metadata:\n"
                + "  name: " + app + "\n"
                + "  namespace: {{ .Values.namespace }}\n"
                + "  labels:\n"
                + "    app.kubernetes.io/name: " + app + "\n"
                + "spec:\n"
                + "  replicas: {{ .Values.replicaCount }}\n"
                + "  selector:\n"
                + "    matchLabels:\n"
                + "      app.kubernetes.io/name: " + app + "\n"
                + "  template:\n"
                + "    metadata:\n"
                + "      labels:\n"
                + "        app.kubernetes.io/name: " + app + "\n"
                + "    spec:\n"
                + "      serviceAccountName: {{ .Values.serviceAccount.name }}\n"
                + "      containers:\n"
                + "        - name: " + app + "\n"
                + "          image: \"{{ .Values.image.repository }}:{{ .Values.image.tag }}\"\n"
                + "          imagePullPolicy: {{ .Values.image.pullPolicy }}\n"
                + "          ports:\n"
                + "            - containerPort: {{ .Values.service.port }}\n"
                + "          env:\n"
                + "            - name: SPRING_PROFILES_ACTIVE\n"
                + "              value: {{ .Values.springProfile }}\n"
                + "          resources:\n"
                + "            requests:\n"
                + "              cpu: {{ .Values.resources.requests.cpu }}\n"
                + "              memory: {{ .Values.resources.requests.memory }}\n"
                + "            limits:\n"
                + "              cpu: {{ .Values.resources.limits.cpu }}\n"
                + "              memory: {{ .Values.resources.limits.memory }}\n";
    }

    public String serviceTemplate(ProjectRequest req) {
        String app = req.artifactId();
        return ""
                + "apiVersion: v1\n"
                + "kind: Service\n"
                + "metadata:\n"
                + "  name: " + app + "\n"
                + "  namespace: {{ .Values.namespace }}\n"
                + "spec:\n"
                + "  type: {{ .Values.service.type }}\n"
                + "  selector:\n"
                + "    app.kubernetes.io/name: " + app + "\n"
                + "  ports:\n"
                + "    - port: {{ .Values.service.port }}\n"
                + "      targetPort: {{ .Values.service.port }}\n";
    }

    public String helpersTpl(ProjectRequest req) {
        String app = req.artifactId();
        return ""
                + "{{/* Common helpers for " + app + " */}}\n"
                + "{{- define \"" + app + ".fullname\" -}}\n"
                + app + "\n"
                + "{{- end -}}\n";
    }

    /** Returns the full chart/ file map for the request and selected profiles. */
    public Map<String, String> chartFiles(ProjectRequest req, List<String> selectedProfiles) {
        Map<String, String> files = new LinkedHashMap<>();
        files.put("files/httpd.conf", httpdConf(req));
        files.put("templates/_helpers.tpl", helpersTpl(req));
        files.put("templates/deployment.yaml", deploymentTemplate(req));
        files.put("templates/service.yaml", serviceTemplate(req));
        files.put("Chart.yaml", chartYaml(req));
        files.put("chart-dependencies.info", chartDependenciesInfo(req));
        files.put("helmfile.yaml", helmfileYaml(req, selectedProfiles));
        files.put("service-account.yaml", serviceAccountYaml(req));
        files.put("values-default.yaml", valuesDefault(req));
        for (String profile : selectedProfiles) {
            String env = helmEnvName(profile);
            files.put("values-" + env + ".yaml",
                    valuesForProfile(req, profile, req.environments().settingFor(profile)));
        }
        return files;
    }

    private int replicasFor(String profile) {
        return switch (profile) {
            case "prod" -> 3;
            case "ppd"  -> 2;
            default      -> 1;
        };
    }

    private String tagFor(String profile) {
        return "prod".equals(profile) ? "stable" : "latest";
    }

    private String defaultEcosystem(String profile) {
        return "EC002I002789";
    }

    private String shortName(String artifactId) {
        if (artifactId == null || artifactId.isBlank()) return "app";
        int dash = artifactId.indexOf('-');
        return dash > 0 ? artifactId.substring(0, dash) : artifactId;
    }
}
