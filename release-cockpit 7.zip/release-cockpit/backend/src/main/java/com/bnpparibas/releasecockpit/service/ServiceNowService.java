package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ServiceNowTicket;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ServiceNow integration for BNP's API gateway.
 *
 * Ported from the working standalone service: OAuth2 client-credentials
 * (consumer key/secret -> bearer token) against a token endpoint, then calls
 * the gateway's /changes and /changes/{number} endpoints. Separate credentials
 * for the changes and attachments APIs, each token cached until expiry.
 *
 *   - Mock mode (or not enabled): returns deterministic demo tickets.
 *   - Live: OAuth2 token -> GET {baseUrl}/changes?sysparm_query=...
 *
 * Uses the JDK HttpClient via HttpClientFactory.proxied() so the corporate
 * proxy (with Basic proxy auth) is applied automatically.
 */
@Slf4j
@Service
public class ServiceNowService {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final CockpitProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;
    private final String proxyAuthHeader;

    /** Cached OAuth2 tokens keyed by "changes" / "attachments". */
    private final ConcurrentHashMap<String, TokenWithExpiry> tokenCache = new ConcurrentHashMap<>();

    public ServiceNowService(CockpitProperties props,
                             com.bnpparibas.releasecockpit.connector.HttpClientFactory clients) {
        this.props = props;
        // Use the NO-Authenticator proxied client: the JDK's Authenticator-equipped
        // client can silently drop our per-request Authorization header (that's the
        // "Authorization header not valid or not found" error). We add the proxy's
        // own Proxy-Authorization header manually instead.
        this.http = clients.proxiedNoAuth();
        this.proxyAuthHeader = clients.proxyAuthHeader();
    }

    public boolean isEnabled() {
        return props.getServicenow().isEnabled();
    }

    // ---- token handling -----------------------------------------------------

    private record TokenWithExpiry(String token, long expiresAt) {
        boolean isExpired() { return System.currentTimeMillis() >= expiresAt; }
    }

    /** OAuth2 client-credentials token for the given API ("changes" or "attachments"). */
    private synchronized String getAccessToken(String api) {
        var sn = props.getServicenow();
        var oauth = "attachments".equals(api) ? sn.getAttachments() : sn.getChanges();
        String cacheKey = api;

        TokenWithExpiry cached = tokenCache.get(cacheKey);
        if (cached != null && !cached.isExpired()) return cached.token();

        try {
            String creds = oauth.getConsumerKey() + ":" + oauth.getConsumerSecret();
            String encoded = Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8));
            String bodyStr = "grant_type=client_credentials";
            HttpRequest.Builder rb = HttpRequest.newBuilder()
                    .uri(URI.create(sn.getTokenUrl()))
                    .header("Authorization", "Basic " + encoded)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(bodyStr));
            // Proxy auth added manually (no Authenticator on this client).
            if (proxyAuthHeader != null) rb.header("Proxy-Authorization", proxyAuthHeader);
            HttpRequest req = rb.build();
            // DIAGNOSTIC: confirm what we're about to send. The Authorization value
            // is masked. allowRestrictedHeaders MUST include "authorization" or the
            // JDK will silently drop the header when the proxy Authenticator is set.
            log.info("ServiceNow token request -> {}", sn.getTokenUrl());
            log.info("  allowRestrictedHeaders='{}'", System.getProperty("jdk.httpclient.allowRestrictedHeaders", "<unset>"));
            log.info("  request headers (as built): {}", maskAuth(req.headers().map()));
            log.info("  consumerKey present={}, secret present={}, basic-len={}",
                    oauth.getConsumerKey() != null && !oauth.getConsumerKey().isBlank(),
                    oauth.getConsumerSecret() != null && !oauth.getConsumerSecret().isBlank(),
                    encoded.length());
            log.info("  body='{}'", bodyStr);
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow token endpoint HTTP {} for {} — body: {}",
                        resp.statusCode(), api, resp.body());
                throw new RuntimeException("Token request failed: HTTP " + resp.statusCode());
            }
            JsonNode body = mapper.readTree(resp.body());
            String token = body.path("access_token").asText("");
            if (token.isBlank()) throw new RuntimeException("No access_token in token response");
            long expiresIn = body.path("expires_in").asLong(300);
            long expiresAt = System.currentTimeMillis() + (expiresIn - 60) * 1000; // 60s buffer
            tokenCache.put(cacheKey, new TokenWithExpiry(token, expiresAt));
            log.info("ServiceNow {} token obtained (expires in {}s)", api, expiresIn);
            return token;
        } catch (Exception e) {
            log.error("ServiceNow {} token error: {}", api, e.getMessage());
            throw new RuntimeException("ServiceNow token error: " + e.getMessage(), e);
        }
    }

    public void clearTokenCache() { tokenCache.clear(); }

    /** Masks Authorization/Proxy-Authorization values in a header map for logging. */
    private java.util.Map<String, java.util.List<String>> maskAuth(java.util.Map<String, java.util.List<String>> headers) {
        java.util.Map<String, java.util.List<String>> out = new java.util.LinkedHashMap<>();
        headers.forEach((k, v) -> {
            if (k.equalsIgnoreCase("authorization") || k.equalsIgnoreCase("proxy-authorization")) {
                String first = v.isEmpty() ? "" : v.get(0);
                String scheme = first.contains(" ") ? first.substring(0, first.indexOf(' ')) : first;
                out.put(k, java.util.List.of(scheme + " ***(" + (first.length()) + " chars)"));
            } else {
                out.put(k, v);
            }
        });
        return out;
    }

    // ---- HTTP with 401 self-heal -------------------------------------------

    private HttpResponse<String> getWithAuth(String api, String url) throws Exception {
        String token = getAccessToken(api);
        HttpResponse<String> resp = doGet(url, token);
        if (resp.statusCode() == 401) {
            log.info("ServiceNow 401 on {} — refreshing token and retrying", api);
            tokenCache.remove(api);
            token = getAccessToken(api);
            resp = doGet(url, token);
        }
        return resp;
    }

    private HttpResponse<String> doGet(String url, String token) throws Exception {
        HttpRequest.Builder rb = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .timeout(Duration.ofSeconds(20)).GET();
        if (proxyAuthHeader != null) rb.header("Proxy-Authorization", proxyAuthHeader);
        return http.send(rb.build(), HttpResponse.BodyHandlers.ofString());
    }

    // ---- release ticket listing (used by the dashboard) --------------------

    public List<ServiceNowTicket> ticketsForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockTickets(releaseName);
        }
        try {
            // Filter changes by the release field when configured; otherwise return
            // recent changes for the environment. The gateway expects an UNencoded
            // encoded-query in sysparm_query (URL-encoded once).
            String query = (sn.getReleaseField() != null && !sn.getReleaseField().isBlank())
                    ? sn.getReleaseField() + "=" + releaseName
                    : "u_environment=" + sn.getEnvironment();
            String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                    + "start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=50";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow /changes HTTP {}", resp.statusCode());
                return List.of();
            }
            return parse(resp.body(), sn.getBaseUrl());
        } catch (Exception e) {
            log.error("ServiceNow fetch failed: {}", e.getMessage());
            return List.of();
        }
    }

    /** Fetch a single change by its number (e.g. CHG0045821). */
    public String getChangeDetails(String changeNumber) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) return "{}";
        try {
            String query = "number=" + changeNumber;
            String fields = "sys_id,number,short_description,description,state,priority,risk,impact,"
                    + "assignment_group,assigned_to,start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=1";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow change-details HTTP {}", resp.statusCode());
                return "{}";
            }
            JsonNode root = mapper.readTree(resp.body()).path("result");
            if (root.isArray() && root.size() > 0) return mapper.writeValueAsString(root.get(0));
            return "{}";
        } catch (Exception e) {
            log.error("ServiceNow change-details failed: {}", e.getMessage());
            return "{}";
        }
    }

    // ---- release changes grouped by env + linked incidents/problems ---------

    /**
     * All ServiceNow records for a release. Changes are matched by the release key
     * appearing in short_description (this instance's naming convention), then
     * bucketed into PPD-1 / PPD-2 / Prod. Incidents and problems linked to those
     * changes (caused-by) are also returned, for display after the Prod release.
     */
    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges changesForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockReleaseChanges(releaseName);
        }
        try {
            // Match the release key in EITHER short_description OR description.
            // The key appears in different formats: e.g. "STS-2026-X5" in the body
            // and "STS X5.2026.0" in the short description, so we OR several variants.
            String fields = "sys_id,number,short_description,description,state,priority,assigned_to,"
                    + "start_date,end_date,type,u_environment";
            String query = buildReleaseQuery(releaseName);
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=200";
            log.info("ServiceNow changes query for {}: {}", releaseName, query);
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow /changes HTTP {} for release {} — body: {}",
                        resp.statusCode(), releaseName, resp.body());
                return empty(true);
            }
            List<ServiceNowTicket> all = parse(resp.body(), sn.getBaseUrl());

            List<ServiceNowTicket> ppd1 = new ArrayList<>();
            List<ServiceNowTicket> ppd2 = new ArrayList<>();
            List<ServiceNowTicket> prod = new ArrayList<>();
            List<String> changeNumbers = new ArrayList<>();
            for (ServiceNowTicket t : all) {
                changeNumbers.add(t.number());
                switch (t.env()) {
                    case "PPD1" -> ppd1.add(t);
                    case "PPD2" -> ppd2.add(t);
                    default -> prod.add(t); // PROD or unknown -> Prod bucket
                }
            }

            List<ServiceNowTicket> incidents = linkedRecords("incidents", changeNumbers, sn);
            List<ServiceNowTicket> problems = linkedRecords("problems", changeNumbers, sn);

            log.info("ServiceNow release {} -> {} changes (PPD1={} PPD2={} PROD={}), {} incidents, {} problems",
                    releaseName, all.size(), ppd1.size(), ppd2.size(), prod.size(), incidents.size(), problems.size());
            return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                    ppd1, ppd2, prod, incidents, problems, true);
        } catch (Exception e) {
            log.error("ServiceNow changesForRelease failed: {}", e.getMessage());
            return empty(true);
        }
    }

    /** Incidents/problems linked to the release's changes via caused-by. */
    private List<ServiceNowTicket> linkedRecords(String api, List<String> changeNumbers,
                                                 CockpitProperties.ServiceNow sn) {
        if (changeNumbers.isEmpty()) return List.of();
        try {
            String type = "incidents".equals(api) ? "incident" : "problem";
            String query = "caused_byIN" + String.join(",", changeNumbers);
            String fields = "sys_id,number,short_description,state,priority,assigned_to,caused_by,rfc";
            String url = sn.getBaseUrl() + "/" + api
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=100";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.warn("ServiceNow /{} HTTP {}", api, resp.statusCode());
                return List.of();
            }
            List<ServiceNowTicket> out = new ArrayList<>();
            JsonNode result = mapper.readTree(resp.body()).path("result");
            for (JsonNode r : result) {
                out.add(new ServiceNowTicket(
                        dv(r, "number"), dv(r, "short_description"), dv(r, "state"),
                        dv(r, "priority"), dv(r, "assigned_to"), type,
                        sn.getBaseUrl() + "/" + api + "/" + dv(r, "number"), ""));
            }
            return out;
        } catch (Exception e) {
            log.warn("ServiceNow linked {} fetch failed: {}", api, e.getMessage());
            return List.of();
        }
    }

    /**
     * Derives the environment bucket from a change's env field + text.
     * Handles bracket tags used in change titles: [PPD-1]/[PPD1], [PPD-2]/[PPD2],
     * [PROD]/[PRODUCTION], and a bare [PPD] (pre-prod). Prod keywords win over PPD
     * so a "production" change isn't mis-bucketed. A bare [PPD] with no number maps
     * to PPD1 by default (adjust once PPD-1 vs PPD-2 examples are confirmed).
     */
    private String deriveEnv(String environment, String text) {
        String s = ((environment == null ? "" : environment) + " " + (text == null ? "" : text)).toLowerCase();
        // Production first (most specific / highest stage).
        if (s.contains("prod") || s.contains("production")) return "PROD";
        if (s.contains("ppd-2") || s.contains("ppd2") || s.contains("ppd 2")
                || s.contains("rehearsal 2") || s.contains("rehearsal2")) return "PPD2";
        if (s.contains("ppd-1") || s.contains("ppd1") || s.contains("ppd 1")
                || s.contains("rehearsal 1") || s.contains("rehearsal1")) return "PPD1";
        // Bare [ppd] with no number -> default to PPD1 (pre-prod).
        if (s.contains("ppd") || s.contains("pre-prod") || s.contains("preprod")) return "PPD1";
        return "";
    }

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges empty(boolean enabled) {
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                List.of(), List.of(), List.of(), List.of(), List.of(), enabled);
    }

    /**
     * Builds a ServiceNow encoded-query matching the release key in EITHER
     * short_description OR description, across the key's known format variants.
     * e.g. release "STS-2026-X5" -> also matches "STS X5.2026.0".
     * ServiceNow OR syntax: cond1^ORcond2^ORcond3...
     */
    private String buildReleaseQuery(String releaseName) {
        List<String> variants = releaseKeyVariants(releaseName);
        List<String> conds = new ArrayList<>();
        for (String v : variants) {
            conds.add("short_descriptionLIKE" + v);
            conds.add("descriptionLIKE" + v);
        }
        return String.join("^OR", conds);
    }

    /**
     * Known textual formats a release key can take in ServiceNow free-text fields.
     * "STS-2026-X5" -> ["STS-2026-X5", "STS X5.2026.0", "STS-X5-2026", "STS X5 2026"].
     * The parts (STS, 2026, X5) are recombined defensively so we catch the common
     * rearrangements teams use in change titles.
     */
    private List<String> releaseKeyVariants(String releaseName) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        out.add(releaseName);                       // STS-2026-X5 (raw)
        // Parse tokens: expect PREFIX-YEAR-XN  (STS, 2026, X5)
        String[] p = releaseName.split("[-_ .]+");
        String prefix = null, year = null, xn = null;
        for (String t : p) {
            if (t.matches("(?i)X\\d+")) xn = t.toUpperCase();
            else if (t.matches("\\d{4}")) year = t;
            else if (prefix == null) prefix = t;
        }
        if (prefix != null && year != null && xn != null) {
            // last digit(s) of year -> the ".0" style seen in "X5.2026.0"
            out.add(prefix + " " + xn + "." + year + ".0");  // STS X5.2026.0
            out.add(prefix + " " + xn + "." + year);          // STS X5.2026
            out.add(prefix + "-" + xn + "-" + year);          // STS-X5-2026
            out.add(prefix + " " + xn + " " + year);          // STS X5 2026
            out.add(prefix + " " + year + " " + xn);          // STS 2026 X5
        }
        return new ArrayList<>(out);
    }

    private List<ServiceNowTicket> parse(String json, String baseUrl) {
        List<ServiceNowTicket> out = new ArrayList<>();
        try {
            JsonNode result = mapper.readTree(json).path("result");
            for (JsonNode r : result) {
                String shortDesc = dv(r, "short_description");
                String desc = dv(r, "description");
                String env = deriveEnv(dv(r, "u_environment"), shortDesc + " " + desc);
                out.add(new ServiceNowTicket(
                        dv(r, "number"),
                        shortDesc,
                        dv(r, "state"),
                        dv(r, "priority"),
                        dv(r, "assigned_to"),
                        "change_request",
                        baseUrl + "/changes/" + dv(r, "number"),
                        env));
            }
        } catch (Exception e) {
            log.error("ServiceNow parse failed: {}", e.getMessage());
        }
        return out;
    }

    /**
     * Reads a field that may be a plain string OR a display-value object
     * {"display_value": "...", "value": "..."} (sysparm_display_value=all).
     */
    private String dv(JsonNode node, String field) {
        JsonNode f = node.path(field);
        if (f.isObject()) return f.path("display_value").asText(f.path("value").asText(""));
        return f.asText("");
    }

    // ---- demo data ----------------------------------------------------------

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges mockReleaseChanges(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x33CE);
        String[] states = {"Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Selvakumar C", "Kameshwaran Pandi"};
        java.util.function.BiFunction<String, String, ServiceNowTicket> mk = (env, desc) ->
                new ServiceNowTicket(
                        String.format("CHG%07d", 40000 + rng.nextInt(9999)),
                        desc + " " + releaseName,
                        states[rng.nextInt(states.length)],
                        prios[rng.nextInt(prios.length)],
                        devs[rng.nextInt(devs.length)],
                        "change_request", "#", env);
        List<ServiceNowTicket> ppd1 = List.of(mk.apply("PPD1", "PPD-1 deployment for"));
        List<ServiceNowTicket> ppd2 = List.of(mk.apply("PPD2", "PPD-2 deployment for"));
        List<ServiceNowTicket> prod = List.of(mk.apply("PROD", "Production rollout for"));
        List<ServiceNowTicket> incidents = List.of(new ServiceNowTicket(
                String.format("INC%07d", 20000 + rng.nextInt(9999)),
                "Post-release latency spike after " + releaseName,
                "In Progress", "2 - High", devs[0], "incident", "#", ""));
        List<ServiceNowTicket> problems = List.of(new ServiceNowTicket(
                String.format("PRB%07d", 10000 + rng.nextInt(9999)),
                "Root cause analysis for " + releaseName + " regression",
                "Assess", "3 - Moderate", devs[1], "problem", "#", ""));
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                ppd1, ppd2, prod, incidents, problems, true);
    }

    private List<ServiceNowTicket> mockTickets(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x5A17);
        String[] states = {"New", "Assess", "Authorize", "Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"1 - Critical", "2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Srinivasan Nagarajan", "Selvakumar C",
                "Kameshwaran Pandi", "Akhila Gowrishankar"};
        String[] descs = {
                "Production deployment for release " + releaseName,
                "Database schema migration", "Firewall rule change for new endpoints",
                "Config rollout to UAT", "Certificate renewal", "Load balancer update",
                "Batch job schedule change", "Rollback plan validation"
        };
        int n = 3 + rng.nextInt(5);
        List<ServiceNowTicket> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(new ServiceNowTicket(
                    String.format("CHG%07d", 30000 + rng.nextInt(9999)),
                    descs[rng.nextInt(descs.length)],
                    states[rng.nextInt(states.length)],
                    prios[rng.nextInt(prios.length)],
                    devs[rng.nextInt(devs.length)],
                    "change_request",
                    "#"));
        }
        return out;
    }
}
