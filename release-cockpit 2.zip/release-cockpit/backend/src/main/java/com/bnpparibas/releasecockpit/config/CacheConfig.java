package com.bnpparibas.releasecockpit.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Simple in-memory cache (swap for Caffeine/Redis in production) and CORS so
 * the Angular dev server (localhost:4200) can call the API.
 */
@Configuration
public class CacheConfig implements WebMvcConfigurer {

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("releases", "subjects");
    }

    @Bean
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins("http://localhost:4200")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS");
    }
}
