package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ConnectionStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.List;

/**
 * Reports the live connection status of the three upstream systems so the UI
 * can show a single "systems" panel.
 *
 * In mock mode it returns MOCK statuses (no network). In live mode it does a
 * cheap probe per system and reports UP / DEGRADED / DOWN with latency.
 *
 *   - Jira:       GET /rest/api/2/myself (auth check)
 *   - SharePoint: GET /_api/web?$select=Title (cookie/site check)
 *   - Octane:     POST /authentication/sign_in (client-credential check)
 *
 * The live probes are intentionally light and never throw to the caller; a
 * failure is reported as DOWN with the error detail.
 */
@Slf4j
@Service
public class StatusService {

    private final CockpitProperties props;
    private final WebClient.Builder webClientBuilder;

    public StatusService(CockpitProperties props, WebClient.Builder webClientBuilder) {
        this.props = props;
        this.webClientBuilder = webClientBuilder;
    }

    public List<ConnectionStatus> all() {
        return List.of(jira(), sharepoint(), octane(), servicenow());
    }

    public ConnectionStatus jira() {
        if (props.isMockMode()) return mock("JIRA", "Mock data — not connecting to Jira");
        long t0 = System.currentTimeMillis();
        try {
            String body = webClientBuilder.build().get()
                    .uri(props.getJira().getBaseUrl() + "/rest/api/2/myself")
                    .headers(h -> applyJiraAuth(h::set))
                    .retrieve().bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(8)).block();
            return up("JIRA", "Authenticated", System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("JIRA", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus sharepoint() {
        if (props.isMockMode()) return mock("SHAREPOINT", "Mock data — not connecting to SharePoint");
        long t0 = System.currentTimeMillis();
        try {
            // Cookie auth: FedAuth + rtFa (as in the production sharepoint.js).
            String cookie = "FedAuth=" + nz(System.getenv("SHAREPOINT_FEDAUTH"))
                    + "; rtFa=" + nz(System.getenv("SHAREPOINT_RTFA"));
            String title = webClientBuilder.build().get()
                    .uri(props.getSharepoint().getBaseUrl() + "/_api/web?$select=Title")
                    .header("Cookie", cookie)
                    .header("Accept", "application/json;odata=nometadata")
                    .retrieve().bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(10)).block();
            return up("SHAREPOINT", "Site reachable", System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("SHAREPOINT", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus octane() {
        if (props.isMockMode()) return mock("OCTANE", "Mock data — not connecting to Octane");
        long t0 = System.currentTimeMillis();
        try {
            var o = props.getOctane();
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            webClientBuilder.build().post()
                    .uri(o.getBaseUrl() + "/authentication/sign_in")
                    .header("Content-Type", "application/json")
                    .bodyValue(payload)
                    .retrieve().bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(10)).block();
            return up("OCTANE", "Signed in (shared space " + o.getSharedSpaceId() + ")",
                    System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("OCTANE", brief(e), System.currentTimeMillis() - t0);
        }
    }

    public ConnectionStatus servicenow() {
        var sn = props.getServicenow();
        if (!sn.isEnabled()) {
            return new ConnectionStatus("SERVICENOW", "NOT_CONFIGURED",
                    "Not connected yet — enable in config to link release tickets", 0);
        }
        if (props.isMockMode()) return mock("SERVICENOW", "Mock data — not connecting to ServiceNow");
        long t0 = System.currentTimeMillis();
        try {
            String basic = java.util.Base64.getEncoder()
                    .encodeToString((nz(sn.getUsername()) + ":" + nz(sn.getPassword())).getBytes());
            webClientBuilder.build().get()
                    .uri(sn.getBaseUrl() + "/api/now/table/" + sn.getTable() + "?sysparm_limit=1")
                    .header("Authorization", "Basic " + basic)
                    .header("Accept", "application/json")
                    .retrieve().bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(10)).block();
            return up("SERVICENOW", "Instance reachable (" + sn.getTable() + ")",
                    System.currentTimeMillis() - t0);
        } catch (Exception e) {
            return down("SERVICENOW", brief(e), System.currentTimeMillis() - t0);
        }
    }

    // ---- helpers ----
    private interface HeaderSetter { void set(String k, String v); }
    private void applyJiraAuth(HeaderSetter h) {
        var j = props.getJira();
        if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
            h.set("Authorization", "Bearer " + nz(j.getPat()));
        } else {
            String basic = java.util.Base64.getEncoder()
                    .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
            h.set("Authorization", "Basic " + basic);
        }
    }

    private ConnectionStatus up(String sys, String detail, long ms) {
        return new ConnectionStatus(sys, "UP", detail, ms);
    }
    private ConnectionStatus down(String sys, String detail, long ms) {
        log.warn("{} status DOWN: {}", sys, detail);
        return new ConnectionStatus(sys, "DOWN", detail, ms);
    }
    private ConnectionStatus mock(String sys, String detail) {
        return new ConnectionStatus(sys, "MOCK", detail, 0);
    }
    private String brief(Exception e) {
        String m = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        return m.length() > 140 ? m.substring(0, 140) : m;
    }
    private String nz(String s) { return s == null ? "" : s; }
}
