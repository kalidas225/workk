package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * BNP Paribas corporate HTML email templates (Release Guardian).
 * Primary green #009464 · Dark green #007348. Outlook-safe (inline styles +
 * tables), dependency-free. A per-gap link resolver is passed in so each
 * missing artifact carries its SharePoint folder link (or Octane link).
 */
public final class EmailTemplate {

    private EmailTemplate() {}

    private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd MMM yyyy");

    /** Resolver returning the SharePoint folder URL for an artifact key, or null. */
    public interface LinkResolver { String spFolder(String artifactKey); }

    private static final Map<String, String> LABEL = Map.ofEntries(
            Map.entry("OCTANE_TESTS_LINKED", "Octane test cases linked & passed"),
            Map.entry("BCM_TESTING", "BCM end-to-end testing"),
            Map.entry("PR", "Peer Review (PR) document — Change Request folder"),
            Map.entry("PR_EXCEL", "Peer Review (PR) — DEV - Code folder"),
            Map.entry("ESTIMATION_SHEET", "Estimation sheet"),
            Map.entry("OCTANE_REVIEW_DOC", "UAT test-case Review document"),
            Map.entry("OCTANE_EXECUTION_DOC", "UAT test-case Execution document"),
            Map.entry("UNIT_TEST", "Unit test evidence")
    );
    private static final Map<String, String> ACTION = Map.ofEntries(
            Map.entry("OCTANE_TESTS_LINKED", "Link the test cases to this Jira id in Octane and ensure all runs pass."),
            Map.entry("BCM_TESTING", "Execute the BCM end-to-end test in Octane and mark it passed."),
            Map.entry("PR", "Upload the Peer Review (PR Code) document to the epic's Change Request folder."),
            Map.entry("PR_EXCEL", "Place the Peer Review Excel (.xlsx) in 03 - Quality / 06 - Peer Reviews / DEV - Code."),
            Map.entry("ESTIMATION_SHEET", "Add the estimation sheet for this epic to the Change Request folder."),
            Map.entry("OCTANE_REVIEW_DOC", "Upload the UAT test-case review evidence to Test Case (UAT)."),
            Map.entry("OCTANE_EXECUTION_DOC", "Upload the UAT test-case execution evidence to Test Exec (UAT)."),
            Map.entry("UNIT_TEST", "Attach the unit-test report/coverage for this epic.")
    );
    private static String label(String k) { return LABEL.getOrDefault(k, k); }
    private static String action(String k) { return ACTION.getOrDefault(k, "Provide the missing artifact for this item."); }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static final String GREEN = "#009464", GREEN_D = "#007348", GREEN_L = "#E8F5F0";
    private static final String RED = "#c0392b", RED_L = "#fde8e8", AMBER = "#D98E04";

    private static final String CSS = ""
        + "body{margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;font-size:14px;color:#333}"
        + ".wrap{max-width:660px;margin:20px auto;background:#fff;border-radius:4px;box-shadow:0 1px 4px rgba(0,0,0,.12);overflow:hidden}"
        + ".hdr{background:#009464;padding:18px 28px}.hdr-title{color:#fff;font-size:20px;font-weight:bold}"
        + ".hdr-sub{color:#cceedf;font-size:12px;margin-top:3px}.body{padding:24px 28px}"
        + ".sec{font-size:11px;font-weight:bold;color:#009464;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid #e0e0e0;padding-bottom:4px;margin:20px 0 10px}"
        + ".epic-box{background:#E8F5F0;border-left:4px solid #009464;padding:12px 16px;border-radius:0 4px 4px 0;margin-bottom:16px}"
        + ".epic-key{font-weight:bold;font-size:16px;color:#007348}.epic-title{font-size:14px;color:#333;margin-top:3px}"
        + ".meta{font-size:12px;color:#666;margin-top:5px}.meta span{margin-right:16px}"
        + ".badge{background:#fde8e8;color:#c0392b;font-size:11px;font-weight:bold;padding:2px 7px;border-radius:3px;border:1px solid #f5c6c6;white-space:nowrap}"
        + ".detail{font-size:12px;color:#999;margin-top:3px}"
        + ".action{background:#fffbe6;border:1px solid #ffe082;border-radius:4px;padding:14px 16px;margin-top:20px}"
        + ".step{font-size:13px;color:#444;margin:5px 0}"
        + ".naming{background:#f8f8f8;border:1px solid #e0e0e0;border-radius:4px;padding:10px 14px;margin-top:14px;font-size:12px;color:#555}"
        + "code{background:#E8F5F0;color:#007348;padding:1px 4px;border-radius:2px;font-family:Consolas,monospace}"
        + ".ftr{background:#f0f0f0;padding:12px 28px;font-size:11px;color:#888;border-top:1px solid #e0e0e0}";

    public static String gapEmail(String company, String releaseName, String releaseDate,
                                  String ppdStart, String endUatDone, long daysToRelease,
                                  Subject s, String jiraUrl, LinkResolver links) {
        String today = LocalDate.now().format(DMY);
        List<String> missing = s.readiness().missing();
        String octaneUrl = s.readiness().octaneUrl();
        List<String> missingEnvs = s.readiness().octaneMissingEnvs();

        String assignee = firstNonBlank(s.developerName(), s.developerEmail(), "Developer");
        String reporter = firstNonBlank(s.reporterName(), s.reporterEmail(), "");
        String greeting = (!reporter.isBlank() && !reporter.equals(assignee))
                ? "Hello <strong>" + esc(assignee) + "</strong> &amp; <strong>" + esc(reporter) + "</strong>,"
                : "Hello <strong>" + esc(assignee) + "</strong>,";

        StringBuilder rows = new StringBuilder();
        for (String key : missing) {
            boolean isOctane = key.equals("OCTANE_TESTS_LINKED") || key.equals("BCM_TESTING");
            String spUrl = isOctane ? null : (links != null ? links.spFolder(key) : null);
            String detail = action(key);
            if (isOctane && missingEnvs != null && !missingEnvs.isEmpty())
                detail += " Missing environment(s): " + String.join(", ", missingEnvs) + ".";
            String linkRow = "";
            if (spUrl != null && !spUrl.isBlank())
                linkRow = "<div style=\"margin-top:6px\"><a href=\"" + esc(spUrl) + "\" target=\"_blank\" style=\"color:#009464;font-weight:bold\">&#128193; Open SharePoint Folder</a></div>";
            else if (isOctane && octaneUrl != null && !octaneUrl.isBlank())
                linkRow = "<div style=\"margin-top:6px\"><a href=\"" + esc(octaneUrl) + "\" target=\"_blank\" style=\"color:#009464;font-weight:bold\">&#128279; Open Octane Feature</a></div>";
            rows.append("<tr><td style=\"padding:9px 12px;border-bottom:1px solid #f0f0f0;vertical-align:top\">")
                .append("<span class=\"badge\">MISSING</span><strong style=\"margin-left:8px\">").append(esc(label(key))).append("</strong>")
                .append("<div class=\"detail\">").append(esc(detail)).append("</div>").append(linkRow).append("</td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>Release Guardian</title><style>" + CSS + "</style></head><body><div class=\"wrap\">"
                + "<div class=\"hdr\"><div class=\"hdr-title\">&#128737;&nbsp; Release Guardian</div>"
                + "<div class=\"hdr-sub\">" + esc(company) + " &middot; IT TA ADM &middot; Automated Release Check</div></div>"
                + "<div class=\"body\"><p style=\"margin-top:0\">" + greeting + "</p>"
                + "<p>The automated release readiness check found <strong>" + missing.size() + " missing artifact(s)</strong> "
                + "for your epic in release <strong>" + esc(releaseName) + "</strong>. Please provide the required items before the release cutoff.</p>"
                + "<div class=\"sec\">Epic Details</div><div class=\"epic-box\"><div class=\"epic-key\">"
                + (jiraUrl != null ? "<a href=\"" + esc(jiraUrl) + "\" style=\"color:#007348;text-decoration:none\">" + esc(s.key()) + "</a>" : esc(s.key()))
                + "</div><div class=\"epic-title\">" + esc(s.summary()) + "</div><div class=\"meta\">"
                + "<span><strong>Release:</strong> " + esc(releaseName) + "</span>"
                + "<span><strong>Assignee:</strong> " + esc(firstNonBlank(s.developerName(), s.developerEmail(), "-")) + "</span>"
                + "<span><strong>Reporter:</strong> " + esc(firstNonBlank(s.reporterName(), s.reporterEmail(), "-")) + "</span>"
                + "<span><strong>Checked:</strong> " + today + "</span></div></div>"
                + "<div class=\"sec\">Missing Artifacts (" + missing.size() + ")</div>"
                + "<table style=\"width:100%;border-collapse:collapse;font-size:13px\"><thead><tr>"
                + "<th style=\"background:#f5f5f5;padding:8px 12px;text-align:left;font-size:11px;font-weight:bold;color:#555;border-bottom:2px solid #009464\">Artifact &amp; Details</th>"
                + "</tr></thead><tbody>" + rows + "</tbody></table>"
                + "<div class=\"action\"><strong>&#9889; Action Required</strong>"
                + "<div class=\"step\">1. Upload the missing files to the SharePoint folders (links above)</div>"
                + "<div class=\"step\">2. For Octane gaps, add/link the missing test cases (link above)</div>"
                + "<div class=\"step\">3. Make sure filenames contain the required keyword (see guide below)</div>"
                + "<div class=\"step\">4. The next automated check will verify and clear this alert</div></div>"
                + namingGuide() + "</div></div></body></html>";
    }

    private static String namingGuide() {
        String[][] rules = {
                {"PR document", "PR_CODE", "Any"}, {"Unit Test evidence", "Unit Test", "Any"},
                {"Estimation sheet", "Estimate", "Any"}, {"PR tracking Excel", "PR_CODE", ".xlsx only"},
                {"Octane Review doc", "PR_Test Case", "Any"}, {"Octane Execution doc", "PR_Test Exec", "Any"},
        };
        StringBuilder r = new StringBuilder();
        for (String[] x : rules)
            r.append("<tr><td style=\"padding:3px 8px 3px 0;color:#444\">").append(esc(x[0]))
             .append("</td><td style=\"padding:3px 8px 3px 0\"><code>").append(esc(x[1]))
             .append("</code></td><td style=\"color:#666\">").append(esc(x[2])).append("</td></tr>");
        return "<div class=\"naming\"><strong>&#128203; File naming rules</strong> — keyword must appear anywhere in the filename (case-insensitive):"
                + "<table style=\"width:100%;margin-top:6px;border-collapse:collapse;font-size:12px\">"
                + "<tr style=\"color:#009464;font-weight:bold\"><td style=\"padding:2px 8px 2px 0\">Artifact</td>"
                + "<td style=\"padding:2px 8px 2px 0\">Keyword</td><td>Format</td></tr>" + r + "</table></div>";
    }

    public static String summaryEmail(String company, String releaseName, String releaseDate,
                                      long daysToRelease, ReleaseSummary sum, ReleaseHealth health,
                                      List<Subject> subjects, LinkResolver links) {
        String today = LocalDate.now().format(DMY);
        int total = subjects.size();
        int withGaps = (int) subjects.stream().filter(s -> s.readiness().missingCount() > 0).count();
        int ok = total - withGaps;
        int pct = total == 0 ? 0 : (int) Math.round(ok * 100.0 / total);
        String healthColor = health.score() >= 80 ? GREEN : health.score() >= 50 ? AMBER : RED;

        StringBuilder rows = new StringBuilder();
        for (Subject s : subjects) {
            boolean compliant = s.readiness().missingCount() == 0;
            String mark = compliant ? "&#10003;" : "&#10007;";
            String markColor = compliant ? GREEN : RED;
            StringBuilder gapLinks = new StringBuilder();
            if (!compliant) {
                for (String key : s.readiness().missing()) {
                    boolean isOctane = key.equals("OCTANE_TESTS_LINKED") || key.equals("BCM_TESTING");
                    String url = isOctane ? s.readiness().octaneUrl() : (links != null ? links.spFolder(key) : null);
                    String linkTag = (url != null && !url.isBlank())
                            ? " <a href=\"" + esc(url) + "\" target=\"_blank\" style=\"color:#009464;font-weight:bold\">(" + (isOctane ? "Octane" : "SP") + " Link)</a>" : "";
                    String envs = "";
                    if (isOctane && s.readiness().octaneMissingEnvs() != null && !s.readiness().octaneMissingEnvs().isEmpty())
                        envs = " [" + String.join(", ", s.readiness().octaneMissingEnvs()) + "]";
                    gapLinks.append("<div style=\"margin-top:2px;color:#c0392b;font-size:11px\">&#10007; ")
                            .append(esc(label(key))).append(esc(envs)).append(linkTag).append("</div>");
                }
            }
            rows.append("<tr><td style=\"padding:7px 10px;font-weight:bold;white-space:nowrap\">")
                .append("<span style=\"color:").append(markColor).append("\">").append(mark).append("</span>")
                .append("<span style=\"color:").append(compliant ? GREEN_D : RED).append(";margin-left:6px\">").append(esc(s.key())).append("</span></td>")
                .append("<td style=\"padding:7px 10px;font-size:12px;color:#444\">").append(esc(trim(s.summary(), 55))).append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:12px;color:#444\"><div>").append(esc(firstNonBlank(s.developerName(), s.developerEmail(), "-"))).append("</div>")
                .append(s.reporterName() != null && !s.reporterName().isBlank() ? "<div style=\"color:#888;font-size:11px\">Reporter: " + esc(s.reporterName()) + "</div>" : "").append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:12px\">")
                .append(compliant ? "<span style=\"color:#009464;font-size:11px\">Good for Release</span>" : gapLinks.toString()).append("</td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Release Guardian — Summary</title><style>" + CSS + "</style></head><body><div class=\"wrap\">"
                + "<div class=\"hdr\"><div class=\"hdr-title\">&#128737;&nbsp; Release Guardian — Summary</div>"
                + "<div class=\"hdr-sub\">" + esc(company) + " &middot; IT TA ADM &middot; " + esc(releaseName) + " &middot; " + today + "</div></div>"
                + "<div class=\"body\"><p>Release readiness for <strong>" + esc(releaseName) + "</strong> (" + daysToRelease + " day(s) to release). "
                + "<strong style=\"color:#009464\">" + ok + " good</strong> and <strong style=\"color:#c0392b\">" + withGaps + " with gaps</strong> out of <strong>" + total + "</strong>.</p>"
                + "<table style=\"width:100%;border-collapse:collapse;margin-bottom:14px\"><tr>"
                + statBox(ok, "COMPLIANT", GREEN_L, GREEN, GREEN_D) + "<td style=\"width:3%\"></td>"
                + statBox(withGaps, "WITH GAPS", RED_L, RED, RED) + "<td style=\"width:3%\"></td>"
                + statBox(total, "TOTAL", "#f0f0f0", "#555", "#666") + "</tr></table>"
                + "<div style=\"margin:6px 0 16px\"><div style=\"font-size:11px;color:#555;margin-bottom:4px\">Release health "
                + "<strong style=\"color:" + healthColor + "\">" + health.score() + "% &middot; " + gradeText(health.grade()) + "</strong> "
                + "(Octane " + health.octaneScore() + "% &middot; SharePoint " + health.sharepointScore() + "%)</div>"
                + "<table style=\"width:100%;border-collapse:collapse\"><tr>"
                + "<td style=\"height:14px;background:" + healthColor + ";width:" + Math.max(1, pct) + "%\"></td>"
                + "<td style=\"height:14px;background:#eee;width:" + (100 - pct) + "%\"></td></tr></table></div>"
                + "<table style=\"width:100%;border-collapse:collapse;font-size:13px\"><thead><tr style=\"background:#f0f0f0\">"
                + th("Epic") + th("Title") + th("Developer / Reporter") + th("Status") + "</tr></thead><tbody>" + rows + "</tbody></table>"
                + "</div><div class=\"ftr\">Automated summary from <strong>Release Guardian</strong> &middot; IT TA ADM &middot; " + today + "</div></div></body></html>";
    }

    private static String statBox(int n, String lbl, String bg, String numC, String lblC) {
        return "<td style=\"padding:10px 14px;border-radius:4px;text-align:center;width:30%;background:" + bg + "\">"
                + "<div style=\"font-size:24px;font-weight:bold;color:" + numC + "\">" + n + "</div>"
                + "<div style=\"font-size:11px;margin-top:2px;color:" + lblC + "\">" + lbl + "</div></td>";
    }
    private static String th(String t) { return "<th style=\"padding:8px 10px;font-size:11px;color:#555;text-align:left;border-bottom:2px solid #009464\">" + t + "</th>"; }
    private static String gradeText(String g) {
        return switch (g == null ? "" : g) {
            case "GOOD", "EXCELLENT" -> "Good"; case "AT_RISK" -> "At risk"; case "CRITICAL" -> "Critical"; default -> g;
        };
    }
    private static String trim(String s, int n) { if (s == null) return ""; return s.length() > n ? s.substring(0, n) + "…" : s; }
    private static String firstNonBlank(String... xs) { for (String x : xs) if (x != null && !x.isBlank()) return x; return ""; }
}
