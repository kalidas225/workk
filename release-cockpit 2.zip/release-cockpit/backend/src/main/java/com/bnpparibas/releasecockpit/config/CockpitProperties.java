package com.bnpparibas.releasecockpit.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Strongly-typed configuration bound from application.yml (cockpit.*).
 * Mirrors the placeholders documented there.
 */
@Data
@Component
@ConfigurationProperties(prefix = "cockpit")
public class CockpitProperties {

    /** When true, use in-memory mock connectors instead of live systems. */
    private boolean mockMode = true;

    private Jira jira = new Jira();
    private Octane octane = new Octane();
    private SharePoint sharepoint = new SharePoint();
    private ServiceNow servicenow = new ServiceNow();
    private Mail mail = new Mail();

    @Data
    public static class Jira {
        private String baseUrl;
        private String authMode = "basic"; // basic | bearer
        private String email;
        private String apiToken;
        private String pat;
        /** Custom field id holding Octane IDs, e.g. customfield_10075. */
        private String octaneLinkField;
        /** Project key(s) to scan for releases (fixVersions), comma separated. */
        private String projectKeys;
        /** JQL template to find subjects of a release. {RELEASE} is substituted. */
        private String subjectJql = "issuetype = Epic AND fixVersion = \"{RELEASE}\" ORDER BY key ASC";
    }

    @Data
    public static class Octane {
        private String baseUrl;
        private String sharedSpaceId;
        private String workspaceId;
        private String clientId;
        private String clientSecret;
    }

    @Data
    public static class SharePoint {
        private String baseUrl;
        private String authMode = "ntlm"; // ntlm | basic
        private String username;
        private String password;
        private String domain;
        private String libraryName = "Documents";
        private String rootPath = "/Releases/{RELEASE}/{EPIC}";
    }

    @Data
    public static class Mail {
        private String fromName = "Release Cockpit";
        private String fromAddress;
        private String fallbackTo;
        private String[] summaryTo = new String[0];
        /** Managers CC'd on every developer gap email (comma-separated env). */
        private String[] managersCc = new String[0];
    }

    @Data
    public static class ServiceNow {
        /** Off until you connect it. When false, the panel shows "Not configured". */
        private boolean enabled = false;
        private String baseUrl;       // https://yourinstance.service-now.com
        private String username;
        private String password;       // or an OAuth token if you prefer
        /** Table to query, e.g. "change_request" or "rm_release". */
        private String table = "change_request";
        /** Field on the ServiceNow record that carries the Jira/release key. */
        private String releaseField = "u_release";
    }
}
