package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * In-memory mock connector. Active when cockpit.mock-mode=true (the default),
 * so the dashboard runs immediately with realistic data and no credentials.
 *
 * The data is deterministic per release name (seeded RNG) so the UI is stable
 * across refreshes during demos and screenshots.
 */
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "true", matchIfMissing = true)
public class MockConnector implements ReleaseDataConnector {

    private static final String[] DEVELOPERS = {
            "Priya Sharma", "Arjun Mehta", "Sofia Rossi", "Liam O'Connor",
            "Chen Wei", "Fatima Noor", "Diego Alvarez", "Hannah Becker"
    };

    @Override
    public List<Release> listReleases() {
        // A year of monthly releases; dates spread around "now" so checkpoints
        // show a mix of upcoming / active / overdue states in the demo.
        LocalDate today = LocalDate.now();
        List<Release> releases = new ArrayList<>();
        for (int i = -3; i <= 6; i++) {
            LocalDate relDate = today.plusWeeks(i * 4L).withDayOfMonth(Math.min(15, today.lengthOfMonth()));
            String name = String.format("25.%02d", ((today.getMonthValue() + i - 1 + 12) % 12) + 1);
            boolean released = relDate.isBefore(today.minusDays(1));
            releases.add(new Release(
                    "v" + (1000 + i),
                    name,
                    relDate,
                    released,
                    "Monthly platform release " + name
            ));
        }
        return releases;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        Random rng = new Random(releaseName.hashCode());
        int count = 8 + rng.nextInt(30); // between 8 and 37 subjects -> exercises pagination
        List<Subject> subjects = new ArrayList<>();
        LocalDate today = LocalDate.now();

        for (int i = 0; i < count; i++) {
            String dev = DEVELOPERS[rng.nextInt(DEVELOPERS.length)];
            String email = toEmail(dev);
            // Reporter is a different person than the developer.
            String reporter = DEVELOPERS[(rng.nextInt(DEVELOPERS.length))];
            if (reporter.equals(dev)) reporter = DEVELOPERS[(DEVELOPERS.length - 1 - rng.nextInt(DEVELOPERS.length))];
            // Some subjects fully ready, others missing 1-4 items.
            Readiness r = randomReadiness(rng);
            // A few subjects created very recently -> "late add" demo.
            LocalDate created = today.minusDays(rng.nextInt(40));

            List<String> octaneIds = new ArrayList<>();
            int nIds = rng.nextInt(4);
            for (int k = 0; k < nIds; k++) octaneIds.add(String.valueOf(100000 + rng.nextInt(9999)));

            subjects.add(new Subject(
                    "REL-" + (1000 + releaseName.hashCode() % 100 + i),
                    SUMMARIES[rng.nextInt(SUMMARIES.length)],
                    STATUSES[rng.nextInt(STATUSES.length)],
                    dev,
                    email,
                    reporter,
                    toEmail(reporter),
                    created,
                    octaneIds,
                    r
            ));
        }
        return subjects;
    }

    private Readiness randomReadiness(Random rng) {
        boolean octane = rng.nextInt(100) < 70;
        boolean pr = rng.nextInt(100) < 80;
        boolean unit = rng.nextInt(100) < 75;
        boolean est = rng.nextInt(100) < 85;
        boolean prx = rng.nextInt(100) < 78;
        boolean rev = rng.nextInt(100) < 65;
        boolean exec = rng.nextInt(100) < 60;

        List<String> missing = new ArrayList<>();
        if (!octane) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prx) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");

        return new Readiness(octane, pr, unit, est, prx, rev, exec, missing.size(), missing);
    }

    private String toEmail(String name) {
        return name.toLowerCase()
                .replace("'", "")
                .replace(" ", ".") + "@bnpparibas.com";
    }

    private static final String[] STATUSES = {"In Progress", "In Review", "Ready for UAT", "Blocked", "Done"};
    private static final String[] SUMMARIES = {
            "Payments reconciliation service",
            "Authentication token rotation",
            "Trade settlement batch optimisation",
            "Client onboarding KYC flow",
            "Regulatory reporting export",
            "Liquidity dashboard widgets",
            "FX rate ingestion pipeline",
            "Audit log retention policy",
            "Margin call notification engine",
            "Counterparty risk scoring"
    };
}
