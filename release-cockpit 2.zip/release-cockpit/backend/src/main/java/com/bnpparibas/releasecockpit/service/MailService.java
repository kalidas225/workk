package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Sends HTML readiness emails.
 *
 * Recipients:
 *   To  = developer + reporter
 *   CC  = managers (cockpit.mail.managers-cc)
 *
 * In mock mode (or when no JavaMailSender is wired) it logs instead of sending,
 * so the dashboard's mail buttons work in a demo.
 */
@Slf4j
@Service
public class MailService {

    private final CockpitProperties props;
    private final JavaMailSender mailSender; // may be null in mock mode
    private final String jiraBaseUrl;

    public MailService(CockpitProperties props,
                       org.springframework.beans.factory.ObjectProvider<JavaMailSender> mailSenderProvider) {
        this.props = props;
        this.mailSender = mailSenderProvider.getIfAvailable();
        this.jiraBaseUrl = props.getJira().getBaseUrl() == null ? "" : props.getJira().getBaseUrl();
    }

    /** Email one developer + reporter (managers CC) about a subject's gaps. */
    public String sendSubjectAlert(String releaseName, Subject subject, Checkpoints cp) {
        List<String> to = recipientsFor(subject);
        String[] cc = props.getMail().getManagersCc();
        String subjectLine = "[Release " + releaseName + "] Action needed on " + subject.key()
                + " — " + subject.readiness().missingCount() + " item(s) missing";

        String html = EmailTemplate.gapEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null && cp.ppdStart() != null ? cp.ppdStart().toString() : "",
                cp != null && cp.endUatDone() != null ? cp.endUatDone().toString() : "",
                cp != null ? cp.daysToRelease() : 0,
                subject, jiraBaseUrl + "/browse/" + subject.key());

        return send(to, cc, subjectLine, html, "gap:" + subject.key());
    }

    /** Email all developers who have a not-ready subject. */
    public int sendAllAlerts(String releaseName, List<Subject> subjects, Checkpoints cp) {
        int sent = 0;
        for (Subject s : subjects) {
            if (s.readiness().missingCount() > 0) {
                sendSubjectAlert(releaseName, s, cp);
                sent++;
            }
        }
        return sent;
    }

    /** Email the overall release-status summary to the managers / summary list. */
    public String sendReleaseSummary(String releaseName, ReleaseSummary sum, ReleaseHealth health,
                                     Checkpoints cp, List<Subject> subjects) {
        List<String> to = new ArrayList<>();
        for (String m : props.getMail().getSummaryTo()) if (!m.isBlank()) to.add(m.trim());
        for (String m : props.getMail().getManagersCc()) if (!m.isBlank()) to.add(m.trim());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());

        List<Subject> atRisk = subjects.stream()
                .filter(s -> s.readiness().missingCount() > 0)
                .sorted((a, b) -> b.readiness().missingCount() - a.readiness().missingCount())
                .toList();

        String subjectLine = "[Release " + releaseName + "] Status — " + health.grade()
                + " (" + health.score() + "/100), " + sum.notReady() + " subject(s) need action";
        String html = EmailTemplate.summaryEmail(
                companyName(), releaseName,
                cp != null && cp.releaseDate() != null ? cp.releaseDate().toString() : "",
                cp != null ? cp.daysToRelease() : 0, sum, health, atRisk);

        return send(to, new String[0], subjectLine, html, "summary:" + releaseName);
    }

    // ── helpers ──────────────────────────────────────────────────────────────
    private List<String> recipientsFor(Subject s) {
        List<String> to = new ArrayList<>();
        if (s.developerEmail() != null && !s.developerEmail().isBlank()) to.add(s.developerEmail());
        if (s.reporterEmail() != null && !s.reporterEmail().isBlank()
                && !s.reporterEmail().equalsIgnoreCase(s.developerEmail())) to.add(s.reporterEmail());
        if (to.isEmpty() && props.getMail().getFallbackTo() != null) to.add(props.getMail().getFallbackTo());
        return to;
    }

    private String send(List<String> to, String[] cc, String subjectLine, String html, String tag) {
        if (mailSender == null || props.isMockMode()) {
            log.info("MOCK MAIL [{}] to={} cc={} subject='{}' (html {} chars)",
                    tag, to, cc, subjectLine, html.length());
            return "Simulated send to " + String.join(", ", to)
                    + (cc.length > 0 ? " (cc " + String.join(", ", cc) + ")" : "") + " — mock mode";
        }
        try {
            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper h = new MimeMessageHelper(msg, false, "UTF-8");
            h.setFrom(props.getMail().getFromAddress());
            h.setTo(to.toArray(new String[0]));
            if (cc.length > 0) h.setCc(cc);
            h.setSubject(subjectLine);
            h.setText(html, true); // HTML
            mailSender.send(msg);
            log.info("Sent [{}] to {} (cc {})", tag, to, List.of(cc));
            return "Sent to " + String.join(", ", to);
        } catch (Exception e) {
            log.error("Mail send failed [{}]: {}", tag, e.getMessage());
            return "Send failed: " + e.getMessage();
        }
    }

    private String companyName() { return "BNP Paribas"; }
}
