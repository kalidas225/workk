package com.bnpparibas.releasecockpit.model;

import java.time.LocalDate;
import java.util.List;

/**
 * Core domain models for the Release Cockpit, expressed as immutable Java
 * records (Java 21). These are the shapes that flow from connectors -> services
 * -> REST DTOs.
 */
public final class Domain {

    private Domain() {}

    /** A release configured in Jira (a fixVersion) for the year. */
    public record Release(
            String id,
            String name,            // e.g. "25.07"
            LocalDate releaseDate,  // the GA / production date from Jira
            boolean released,       // true once releaseDate has passed / archived
            String description
    ) {}

    /**
     * The intelligent date checkpoints derived from the release date:
     *   - PPD (pre-prod deployment) starts 2 weeks before release date
     *   - End-UAT must be done 3 weeks before release date
     */
    public record Checkpoints(
            LocalDate releaseDate,
            LocalDate ppdStart,     // releaseDate - 14 days
            LocalDate endUatDone,   // releaseDate - 21 days
            String ppdStatus,       // UPCOMING | ACTIVE | OVERDUE | DONE
            String endUatStatus,    // UPCOMING | DUE_SOON | OVERDUE | DONE
            long daysToRelease
    ) {}

    /** A single subject (Jira epic) tagged for a release. */
    public record Subject(
            String key,             // e.g. "REL-1042"
            String summary,
            String status,
            String developerName,
            String developerEmail,
            String reporterName,
            String reporterEmail,
            LocalDate createdDate,
            List<String> octaneIds, // Octane test-case IDs listed on the epic
            Readiness readiness
    ) {}

    /** Readiness of one subject across Octane + SharePoint artifacts. */
    public record Readiness(
            boolean octaneTestsLinked,
            boolean prDoc,
            boolean unitTest,
            boolean estimationSheet,
            boolean prExcel,
            boolean octaneReviewDoc,
            boolean octaneExecutionDoc,
            int missingCount,
            List<String> missing    // keys of missing items, for the email
    ) {}

    /** Aggregated counts for the pie charts on the dashboard. */
    public record ReleaseSummary(
            String releaseName,
            int totalSubjects,
            int ready,
            int notReady,
            List<DeveloperLoad> developerDistribution,
            ReadinessBreakdown readinessBreakdown
    ) {}

    public record DeveloperLoad(String developer, int subjectCount) {}

    public record ReadinessBreakdown(
            int octaneOk, int octaneMissing,
            int sharepointOk, int sharepointMissing
    ) {}

    /**
     * A composite "release health" score (0-100) plus a letter grade and the
     * factors that fed it, for the health meter on the dashboard.
     */
    public record ReleaseHealth(
            int score,              // 0-100
            String grade,           // EXCELLENT | GOOD | AT_RISK | CRITICAL
            int readinessScore,     // % of subjects fully ready
            int octaneScore,        // % with Octane linked
            int sharepointScore,    // % SharePoint-complete
            int timelineScore,      // derived from checkpoint statuses
            List<String> risks      // human-readable risk notes
    ) {}

    /** Live connection status of one upstream system (Jira/SharePoint/Octane/ServiceNow). */
    public record ConnectionStatus(
            String system,          // JIRA | SHAREPOINT | OCTANE | SERVICENOW
            String status,          // UP | DOWN | DEGRADED | MOCK | NOT_CONFIGURED
            String detail,          // e.g. resolved site title, or error text
            long latencyMs
    ) {}

    /**
     * A ServiceNow ticket linked to a release (change request / incident / etc).
     * Surfaced in the dashboard so users don't leave to check ServiceNow.
     */
    public record ServiceNowTicket(
            String number,          // e.g. CHG0030456
            String shortDescription,
            String state,           // e.g. New, Assess, Implement, Closed
            String priority,
            String assignedTo,
            String type,            // change_request | incident | ...
            String url              // deep link into ServiceNow
    ) {}

    /**
     * Per-subject check override. Controls which checks apply to a subject:
     *   - octaneEnvironments: which Octane environments must pass (e.g. UAT only)
     *   - bcmEndToEnd: whether BCM end-to-end testing is required
     *   - skipSharePoint: artifact keys (folders) that don't apply to this subject
     */
    public record SubjectCheckConfig(
            List<String> octaneEnvironments,
            boolean bcmEndToEnd,
            List<String> skipSharePoint,
            String note
    ) {}
}
