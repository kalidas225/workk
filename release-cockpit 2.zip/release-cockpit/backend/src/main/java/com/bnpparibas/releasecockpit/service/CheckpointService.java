package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Computes the intelligent release checkpoints from the Jira release date.
 *
 * Rules (configurable via constants):
 *   - PPD (pre-prod deployment) STARTS 2 weeks (14 days) before the release date.
 *   - End-UAT must be DONE 3 weeks (21 days) before the release date.
 *
 * Statuses are derived relative to "today" so the UI can colour them and the
 * scheduler can decide when to fire approaching-deadline alerts.
 */
@Service
public class CheckpointService {

    public static final int PPD_LEAD_DAYS = 14;      // 2 weeks
    public static final int END_UAT_LEAD_DAYS = 21;  // 3 weeks

    /** "Due soon" window: warn when end-UAT is within this many days. */
    public static final int DUE_SOON_DAYS = 4;

    public Checkpoints compute(LocalDate releaseDate) {
        return compute(releaseDate, LocalDate.now());
    }

    public Checkpoints compute(LocalDate releaseDate, LocalDate today) {
        if (releaseDate == null) {
            return new Checkpoints(null, null, null, "UNKNOWN", "UNKNOWN", 0);
        }
        LocalDate ppdStart = releaseDate.minusDays(PPD_LEAD_DAYS);
        LocalDate endUatDone = releaseDate.minusDays(END_UAT_LEAD_DAYS);
        long daysToRelease = ChronoUnit.DAYS.between(today, releaseDate);

        String ppdStatus = statusForWindow(today, ppdStart, releaseDate);
        String endUatStatus = statusForDeadline(today, endUatDone);

        return new Checkpoints(releaseDate, ppdStart, endUatDone,
                ppdStatus, endUatStatus, daysToRelease);
    }

    /**
     * PPD is a window that opens at ppdStart and runs until the release date.
     *   before start  -> UPCOMING
     *   in window     -> ACTIVE
     *   past release  -> DONE
     */
    private String statusForWindow(LocalDate today, LocalDate start, LocalDate end) {
        if (today.isBefore(start)) return "UPCOMING";
        if (!today.isAfter(end)) return "ACTIVE";
        return "DONE";
    }

    /**
     * End-UAT is a single deadline.
     *   more than DUE_SOON away  -> UPCOMING
     *   within DUE_SOON          -> DUE_SOON
     *   on/after deadline        -> OVERDUE (until externally marked DONE)
     */
    private String statusForDeadline(LocalDate today, LocalDate deadline) {
        long days = ChronoUnit.DAYS.between(today, deadline);
        if (days > DUE_SOON_DAYS) return "UPCOMING";
        if (days >= 0) return "DUE_SOON";
        return "OVERDUE";
    }

    /**
     * Should we fire an "end-UAT approaching" alert for a subject added today?
     * True when the end-UAT deadline is within the due-soon window or already
     * passed — i.e. a late-added subject has little/no runway.
     */
    public boolean isEndUatApproachingOrPassed(LocalDate releaseDate, LocalDate today) {
        if (releaseDate == null) return false;
        LocalDate endUatDone = releaseDate.minusDays(END_UAT_LEAD_DAYS);
        long days = ChronoUnit.DAYS.between(today, endUatDone);
        return days <= DUE_SOON_DAYS;
    }
}
