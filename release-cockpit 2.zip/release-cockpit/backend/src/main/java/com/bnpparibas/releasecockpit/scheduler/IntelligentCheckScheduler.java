package com.bnpparibas.releasecockpit.scheduler;

import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.bnpparibas.releasecockpit.service.CheckpointService;
import com.bnpparibas.releasecockpit.service.MailService;
import com.bnpparibas.releasecockpit.service.ReleaseService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Intelligent checks that run on a schedule.
 *
 * Late-add detection: if a subject was created recently AND its release's
 * end-UAT deadline is within the "due soon" window (or already passed), the
 * responsible developer is immediately alerted that end-UAT is approaching.
 *
 * A small in-memory set prevents re-alerting the same subject repeatedly.
 * (In production, persist this — e.g. a small table or the file log we used in
 * Release Guardian — so it survives restarts.)
 */
@Slf4j
@Component
public class IntelligentCheckScheduler {

    private final ReleaseService releaseService;
    private final CheckpointService checkpointService;
    private final MailService mailService;

    /** Subjects we've already alerted, so we don't spam. */
    private final Set<String> alertedLateAdds = new HashSet<>();

    /** A subject created within this many days counts as a "late add". */
    private static final int LATE_ADD_WINDOW_DAYS = 5;

    public IntelligentCheckScheduler(ReleaseService releaseService,
                                     CheckpointService checkpointService,
                                     MailService mailService) {
        this.releaseService = releaseService;
        this.checkpointService = checkpointService;
        this.mailService = mailService;
    }

    /**
     * Runs hourly. Scans active (unreleased) releases for late-added subjects
     * whose end-UAT deadline is close, and alerts their developers once.
     */
    @Scheduled(cron = "${cockpit.scheduler.late-add-cron:0 0 * * * *}")
    public void detectLateAddsAndAlert() {
        LocalDate today = LocalDate.now();
        List<Release> releases = releaseService.getReleases();

        for (Release release : releases) {
            if (release.released()) continue;
            boolean approaching = checkpointService
                    .isEndUatApproachingOrPassed(release.releaseDate(), today);
            if (!approaching) continue;

            for (Subject s : releaseService.getAllSubjects(release.name())) {
                boolean recentlyAdded = s.createdDate() != null
                        && !s.createdDate().isBefore(today.minusDays(LATE_ADD_WINDOW_DAYS));
                if (!recentlyAdded) continue;

                String dedupeKey = release.name() + "|" + s.key();
                if (alertedLateAdds.contains(dedupeKey)) continue;

                log.info("Late-add detected: {} in {} — end-UAT approaching. Alerting {}",
                        s.key(), release.name(), s.developerEmail());
                mailService.sendSubjectAlert(release.name(), s,
                        checkpointService.compute(release.releaseDate()));
                alertedLateAdds.add(dedupeKey);
            }
        }
    }
}
