package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import com.bnpparibas.releasecockpit.model.Domain.Subject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * BNP Paribas corporate HTML email templates (Release Guardian).
 * Primary green #009464 · Dark green #007348. Outlook-safe (inline styles +
 * tables), dependency-free. A per-gap link resolver is passed in so each
 * missing artifact carries its SharePoint folder link (or Octane link).
 */
public final class EmailTemplate {

    private EmailTemplate() {}

    private static final DateTimeFormatter DMY = DateTimeFormatter.ofPattern("dd MMM yyyy");

    /** Resolver returning the SharePoint folder URL for an artifact key, or null. */
    public interface LinkResolver { String spFolder(String artifactKey); }

    private static final Map<String, String> LABEL = Map.ofEntries(
            Map.entry("OCTANE_TESTS_LINKED", "Octane test cases linked & passed"),
            Map.entry("BCM_TESTING", "BCM end-to-end testing"),
            Map.entry("PR", "Peer Review (PR) document — Change Request folder"),
            Map.entry("PR_EXCEL", "Peer Review Document"),
            Map.entry("ESTIMATION_SHEET", "Estimation sheet"),
            Map.entry("OCTANE_REVIEW_DOC", "Octane Testcase Review Document"),
            Map.entry("OCTANE_EXECUTION_DOC", "Octane Testcase Execution Document"),
            Map.entry("UNIT_TEST", "Unit test evidence")
    );
    private static final Map<String, String> ACTION = Map.ofEntries(
            Map.entry("OCTANE_TESTS_LINKED", "Link the test cases to this Jira id in Octane and ensure all runs pass."),
            Map.entry("BCM_TESTING", "Execute the BCM end-to-end test in Octane and mark it passed."),
            Map.entry("PR", "Upload the Peer Review (PR Code) document to the epic's Change Request folder."),
            Map.entry("PR_EXCEL", "Place the Peer Review Excel (.xlsx) in 03 - Quality / 06 - Peer Reviews / DEV - Code."),
            Map.entry("ESTIMATION_SHEET", "Add the estimation sheet for this epic to the Change Request folder."),
            Map.entry("OCTANE_REVIEW_DOC", "Upload the UAT test-case review evidence to Test Case (UAT)."),
            Map.entry("OCTANE_EXECUTION_DOC", "Upload the UAT test-case execution evidence to Test Exec (UAT)."),
            Map.entry("UNIT_TEST", "Attach the unit-test report/coverage for this epic.")
    );
    private static String label(String k) { return LABEL.getOrDefault(k, k); }
    private static String action(String k) { return ACTION.getOrDefault(k, "Provide the missing artifact for this item."); }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static final String GREEN = "#009464", GREEN_D = "#007348", GREEN_L = "#E8F5F0";
    private static final String RED = "#c0392b", RED_L = "#fde8e8", AMBER = "#D98E04";

    private static final String CSS = ""
        + "body{margin:0;padding:0;background:#f4f4f4;font-family:Arial,sans-serif;font-size:14px;color:#333}"
        + ".wrap{max-width:660px;margin:20px auto;background:#fff;border-radius:4px;box-shadow:0 1px 4px rgba(0,0,0,.12);overflow:hidden}"
        + ".hdr{background:#009464;padding:18px 28px}.hdr-title{color:#fff;font-size:20px;font-weight:bold}"
        + ".hdr-sub{color:#cceedf;font-size:12px;margin-top:3px}.body{padding:24px 28px}"
        + ".sec{font-size:11px;font-weight:bold;color:#009464;text-transform:uppercase;letter-spacing:1px;border-bottom:1px solid #e0e0e0;padding-bottom:4px;margin:20px 0 10px}"
        + ".epic-box{background:#E8F5F0;border-left:4px solid #009464;padding:12px 16px;border-radius:0 4px 4px 0;margin-bottom:16px}"
        + ".epic-key{font-weight:bold;font-size:16px;color:#007348}.epic-title{font-size:14px;color:#333;margin-top:3px}"
        + ".meta{font-size:12px;color:#666;margin-top:8px;line-height:1.9}.meta span{display:inline-block;margin-right:22px;margin-bottom:2px}"
        + ".badge{background:#fde8e8;color:#c0392b;font-size:11px;font-weight:bold;padding:2px 7px;border-radius:3px;border:1px solid #f5c6c6;white-space:nowrap}"
        + ".detail{font-size:12px;color:#999;margin-top:3px}"
        + ".action{background:#fffbe6;border:1px solid #ffe082;border-radius:4px;padding:14px 16px;margin-top:20px}"
        + ".step{font-size:13px;color:#444;margin:5px 0}"
        + ".naming{background:#f8f8f8;border:1px solid #e0e0e0;border-radius:4px;padding:10px 14px;margin-top:14px;font-size:12px;color:#555}"
        + "code{background:#E8F5F0;color:#007348;padding:1px 4px;border-radius:2px;font-family:Consolas,monospace}"
        + ".ftr{background:#f0f0f0;padding:12px 28px;font-size:11px;color:#888;border-top:1px solid #e0e0e0}";

    public static String gapEmail(String company, String releaseName, String docCutoff,
                                  String releaseDate, long daysToRelease,
                                  Subject s, String jiraUrl, LinkResolver links,
                                  List<com.bnpparibas.releasecockpit.model.ArtifactSpec> artifacts) {
        String today = LocalDate.now().format(DMY);
        List<String> missing = s.readiness().missing();
        String octaneUrl = s.readiness().octaneUrl();
        List<String> missingEnvs = s.readiness().octaneMissingEnvs();

        String assignee = firstNonBlank(s.developerName(), s.developerEmail(), "Developer");
        String reporter = firstNonBlank(s.reporterName(), s.reporterEmail(), "");
        String greeting = (!reporter.isBlank() && !reporter.equals(assignee))
                ? "Hello <strong>" + esc(assignee) + "</strong> &amp; <strong>" + esc(reporter) + "</strong>,"
                : "Hello <strong>" + esc(assignee) + "</strong>,";

        StringBuilder rows = new StringBuilder();
        for (String key : missing) {
            boolean isOctane = key.equals("OCTANE_TESTS_LINKED") || key.equals("BCM_TESTING");
            String spUrl = isOctane ? null : (links != null ? links.spFolder(key) : null);
            String detail = action(key);
            if (isOctane && missingEnvs != null && !missingEnvs.isEmpty())
                detail += " Missing environment(s): " + String.join(", ", missingEnvs) + ".";
            String linkRow = "";
            if (spUrl != null && !spUrl.isBlank())
                linkRow = "<div style=\"margin-top:6px\"><a href=\"" + esc(spUrl) + "\" target=\"_blank\" style=\"color:#0067b8;font-weight:bold;text-decoration:underline\">&#128193; Open SharePoint Folder</a></div>";
            else if (isOctane && octaneUrl != null && !octaneUrl.isBlank())
                linkRow = "<div style=\"margin-top:6px\"><a href=\"" + esc(octaneUrl) + "\" target=\"_blank\" style=\"color:#0067b8;font-weight:bold;text-decoration:underline\">&#128279; Open Octane Feature</a></div>";
            rows.append("<tr><td style=\"padding:9px 12px;border-bottom:1px solid #f0f0f0;vertical-align:top\">")
                .append("<span class=\"badge\">MISSING</span><strong style=\"margin-left:8px\">").append(esc(label(key))).append("</strong>")
                .append("<div class=\"detail\">").append(esc(detail)).append("</div>").append(linkRow).append("</td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>Release Guardian</title><style>" + CSS + "</style></head><body><div class=\"wrap\">"
                + "<div class=\"hdr\"><div class=\"hdr-title\">&#128737;&nbsp; Release Guardian</div>"
                + "<div class=\"hdr-sub\">" + esc(company) + " &middot; IT TA ADM &middot; Automated Release Check</div></div>"
                + "<div class=\"body\"><p style=\"margin-top:0\">" + greeting + "</p>"
                + "<p>The automated release readiness check found <strong>" + missing.size() + " missing artifact(s)</strong> "
                + "for your epic in release <strong>" + esc(releaseName) + "</strong>. Please provide the required items before the release cutoff.</p>"
                + "<div class=\"sec\">Epic Details</div><div class=\"epic-box\"><div class=\"epic-key\">"
                + (jiraUrl != null ? "<a href=\"" + esc(jiraUrl) + "\" style=\"color:#007348;text-decoration:underline\">" + esc(s.key()) + "</a>" : esc(s.key()))
                + "</div><div class=\"epic-title\">" + esc(s.summary()) + "</div>"
                + "<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:10px;font-size:12px;color:#555\"><tr>"
                + "<td style=\"padding:2px 28px 2px 0;white-space:nowrap\"><strong>Release:</strong> " + esc(releaseName) + "</td>"
                + "<td style=\"padding:2px 28px 2px 0;white-space:nowrap\"><strong>Assignee:</strong> " + esc(firstNonBlank(s.developerName(), s.developerEmail(), "-")) + "</td>"
                + "<td style=\"padding:2px 28px 2px 0;white-space:nowrap\"><strong>Reporter:</strong> " + esc(firstNonBlank(s.reporterName(), s.reporterEmail(), "-")) + "</td>"
                + "<td style=\"padding:2px 0;white-space:nowrap\"><strong>Checked:</strong> " + today + "</td>"
                + "</tr></table>"
                + "<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin-top:6px;font-size:12px;color:#555\"><tr>"
                + (docCutoff != null && !docCutoff.isBlank()
                    ? "<td style=\"padding-right:40px;white-space:nowrap\"><strong>Document cutoff:</strong> <span style=\"color:#B8860B;font-weight:bold\">" + esc(docCutoff) + "</span></td>" : "")
                + (releaseDate != null && !releaseDate.isBlank()
                    ? "<td style=\"white-space:nowrap\"><strong>Release date:</strong> " + esc(releaseDate) + "</td>" : "")
                + "</tr></table>"
                + "</div>"
                + octaneRunSummary(s)
                + "<div class=\"sec\">Missing Artifacts (" + missing.size() + ")</div>"
                + "<table style=\"width:100%;border-collapse:collapse;font-size:13px\"><thead><tr>"
                + "<th style=\"background:#f5f5f5;padding:8px 12px;text-align:left;font-size:11px;font-weight:bold;color:#555;border-bottom:2px solid #009464\">Artifact &amp; Details</th>"
                + "</tr></thead><tbody>" + rows + "</tbody></table>"
                + "<div class=\"action\"><strong>&#9889; Action Required</strong>"
                + "<div class=\"step\">1. Upload the missing files to the SharePoint folders (links above)</div>"
                + "<div class=\"step\">2. For Octane gaps, add/link the missing test cases (link above)</div>"
                + "<div class=\"step\">3. Make sure filenames contain the required keyword (see guide below)</div>"
                + "<div class=\"step\">4. The next automated check will verify and clear this alert</div></div>"
                + namingGuide(artifacts) + "</div></div></body></html>";
    }

    /** Renders the Octane status: an overall banner + per-env coloured cells. */
    private static String octaneRunSummary(Subject s) {
        var r = s.readiness();
        var env = r.octaneEnvSummary();
        // Determine the overall Octane state from the env marks (worst wins).
        String overall = octaneOverall(s);
        String[] band = switch (overall) {
            case "FAILED" -> new String[]{"#c0392b", "#fdecea", "Failed"};
            case "NEEDS_ATTENTION" -> new String[]{"#B8860B", "#fff8e1", "Needs Attention"};
            case "PASSED" -> new String[]{"#009464", "#e9f7f1", "Passed"};
            default -> new String[]{"#888", "#f4f4f4", "No Run"};
        };
        StringBuilder cells = new StringBuilder();
        if (env != null) for (var e : env.entrySet()) {
            String v = e.getValue() == null ? "" : e.getValue();
            String color = envColor(v);
            cells.append("<td style=\"padding:6px 12px;text-align:center;border:1px solid #eee\">")
                 .append("<div style=\"font-size:11px;color:#888\">").append(esc(e.getKey())).append("</div>")
                 .append("<div style=\"font-size:13px;font-weight:bold;color:").append(color).append("\">")
                 .append(esc(envWord(v))).append("</div></td>");
        }
        String banner = "<div style=\"display:inline-block;padding:5px 12px;border-radius:6px;"
                + "background:" + band[1] + ";color:" + band[0] + ";font-weight:bold;font-size:12px;margin-bottom:8px\">"
                + "Octane: " + band[2] + "</div>";
        String octaneUrl = r.octaneUrl();
        String featureLink = (octaneUrl != null && !octaneUrl.isBlank())
                ? "<div style=\"margin:4px 0 8px\"><a href=\"" + esc(octaneUrl) + "\" target=\"_blank\" "
                    + "style=\"color:#0067b8;font-weight:bold;font-size:12px;text-decoration:underline\">&#128279; Open Octane feature &amp; runs</a></div>"
                : "";
        String runs = "";
        if (r.totalRuns() > 0) {
            runs = "<div style=\"font-size:12px;color:#555;margin-bottom:6px\">Total: <strong>"
                    + r.passedRuns() + "/" + r.totalRuns() + " passed</strong>"
                    + (r.failedRuns() > 0 ? ", <strong style=\"color:#c0392b\">" + r.failedRuns() + " failed</strong>" : "")
                    + "</div>";
        }
        // Per-test detail lines (with per-line Octane links) mirroring the UI.
        StringBuilder detailRows = new StringBuilder();
        if (r.octaneDetail() != null) for (String d : r.octaneDetail()) {
            if (d == null || d.isBlank()) continue;
            String[] parts = d.split(" \\|\\|", 2);
            String text = parts[0];
            String link = parts.length > 1 ? parts[1] : null;
            String col = detailColor(text);
            detailRows.append("<div style=\"font-size:11.5px;color:").append(col).append(";margin:1px 0\">")
                      .append(esc(text));
            if (link != null) detailRows.append(" <a href=\"").append(esc(link))
                    .append("\" target=\"_blank\" style=\"color:#0067b8;font-weight:bold;text-decoration:underline\">Open &#128279;</a>");
            detailRows.append("</div>");
        }
        String detailBlock = detailRows.length() > 0
                ? "<div style=\"margin-top:4px;padding:8px 10px;background:#fafafa;border:1px solid #eee;border-radius:6px\">"
                    + detailRows + "</div>"
                : "";
        return "<div class=\"sec\">Octane Status</div>" + banner + featureLink + runs
                + (cells.length() > 0
                    ? "<table style=\"border-collapse:collapse;margin-bottom:6px\"><tr>" + cells + "</tr></table>"
                    : "")
                + detailBlock;
    }

    /** Colour for a detail line by its status keyword. */
    private static String detailColor(String text) {
        String t = text == null ? "" : text.toLowerCase();
        if (t.contains("failed") || t.contains("no test") || t.contains("never run") || t.contains("no run")) return "#c0392b";
        if (t.contains("needs attention")) return "#B8860B";
        if (t.contains("passed")) return "#009464";
        return "#555";
    }

    /** Overall Octane state for a subject: FAILED > NEEDS_ATTENTION > PASSED > NO_RUN. */
    private static String octaneOverall(Subject s) {
        var envs = s.readiness().octaneMissingEnvs();
        if (envs != null) {
            boolean fail = envs.stream().anyMatch(m -> {
                String t = m.toLowerCase();
                // Note: release-tag issues contain "needs attention" and are handled
                // as warnings below, not hard failures.
                return t.contains("failed") || t.contains("no test") || t.contains("never run")
                        || (t.contains("not run") && !t.contains("needs attention"))
                        || t.contains("cannot verify");
            });
            if (fail) return "FAILED";
            if (envs.stream().anyMatch(m -> m.toLowerCase().contains("needs attention"))) return "NEEDS_ATTENTION";
        }
        var env = s.readiness().octaneEnvSummary();
        if (env == null || env.isEmpty()) return s.readiness().octaneTestsLinked() ? "PASSED" : "NO_RUN";
        boolean anyFail = env.values().stream().anyMatch(v -> v != null && v.contains("\u2717"));
        boolean anyAtt  = env.values().stream().anyMatch(v -> v != null && v.contains("\u26A0"));
        if (anyFail) return "FAILED";
        if (anyAtt) return "NEEDS_ATTENTION";
        return "PASSED";
    }

    private static String envColor(String v) {
        if (v == null) return "#888";
        if (v.contains("\u2717")) return "#c0392b";        // ✗ red
        if (v.contains("\u26A0")) return "#B8860B";        // ⚠ amber
        if (v.contains("\u2713")) return "#009464";        // ✓ green
        return "#888";
    }

    private static String envWord(String v) {
        if (v == null) return "";
        if (v.contains("\u2717")) return "Failed";
        if (v.contains("\u26A0")) return "Needs Attn";
        if (v.contains("\u2713")) return "Passed";
        return v;
    }

    /** Compact inline env run summary for the summary table (DEV Passed · IST Needs Attn). */
    private static String envSummaryInline(Subject s) {
        var env = s.readiness().octaneEnvSummary();
        if (env == null || env.isEmpty()) return "<span style=\"color:#bbb\">—</span>";
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (var e : env.entrySet()) {
            String v = e.getValue() == null ? "" : e.getValue();
            if (!first) sb.append(" &middot; ");
            sb.append("<span style=\"color:").append(envColor(v)).append("\">")
              .append(esc(e.getKey())).append(" ").append(esc(envWord(v))).append("</span>");
            first = false;
        }
        return sb.toString();
    }

    /** File naming rules built from the live artifacts.json config. */
    private static String namingGuide(List<com.bnpparibas.releasecockpit.model.ArtifactSpec> artifacts) {
        StringBuilder r = new StringBuilder();
        if (artifacts != null) for (var a : artifacts) {
            if (a == null || !a.enabled) continue;
            if (a.source != null && a.source.equalsIgnoreCase("octane")) continue; // SharePoint files only
            var m = a.match;
            String all = (m != null && m.all != null && !m.all.isEmpty()) ? String.join(" + ", m.all) : "";
            String any = (m != null && m.any != null && !m.any.isEmpty()) ? String.join(" / ", m.any) : "";
            String keyword = all;
            if (!any.isBlank()) keyword = keyword.isBlank() ? "one of: " + any : all + " AND one of: " + any;
            if (keyword.isBlank()) keyword = "(any file)";
            String fmt = (m != null && m.extensions != null && !m.extensions.isEmpty())
                    ? String.join(", ", m.extensions) + " only" : "Any";
            String min = a.minFiles > 1 ? " (min " + a.minFiles + " files)" : "";
            r.append("<tr><td style=\"padding:3px 8px 3px 0;color:#444\">").append(esc(a.label))
             .append("</td><td style=\"padding:3px 8px 3px 0\"><code>").append(esc(keyword)).append("</code></td>")
             .append("<td style=\"color:#666\">").append(esc(fmt)).append(esc(min)).append("</td></tr>");
        }
        if (r.length() == 0) return "";
        return "<div class=\"naming\"><strong>&#128203; File naming rules</strong> — filename must contain the listed keyword(s), case-insensitive (<code>{EPIC}</code> = the epic key):"
                + "<table style=\"width:100%;margin-top:6px;border-collapse:collapse;font-size:12px\">"
                + "<tr style=\"color:#009464;font-weight:bold\"><td style=\"padding:2px 8px 2px 0\">Artifact</td>"
                + "<td style=\"padding:2px 8px 2px 0\">Filename must contain</td><td>Format</td></tr>" + r + "</table></div>";
    }

    public static String summaryEmail(String company, String releaseName, String docCutoff,
                                      String releaseDate, long daysToRelease, ReleaseSummary sum,
                                      ReleaseHealth health, List<Subject> subjects, LinkResolver links,
                                      String jiraBaseUrl) {
        String today = LocalDate.now().format(DMY);
        int total = subjects.size();
        int withGaps = (int) subjects.stream().filter(s -> s.readiness().missingCount() > 0).count();
        int ok = total - withGaps;
        int pct = total == 0 ? 0 : (int) Math.round(ok * 100.0 / total);
        String healthColor = health.score() >= 80 ? GREEN : health.score() >= 50 ? AMBER : RED;

        StringBuilder rows = new StringBuilder();
        for (Subject s : subjects) {
            boolean compliant = s.readiness().missingCount() == 0;
            String mark = compliant ? "&#10003;" : "&#10007;";
            String markColor = compliant ? GREEN : RED;
            StringBuilder gapLinks = new StringBuilder();
            if (!compliant) {
                for (String key : s.readiness().missing()) {
                    boolean isOctane = key.equals("OCTANE_TESTS_LINKED") || key.equals("BCM_TESTING");
                    String url = isOctane ? s.readiness().octaneUrl() : (links != null ? links.spFolder(key) : null);
                    String linkTag = (url != null && !url.isBlank())
                            ? " <a href=\"" + esc(url) + "\" target=\"_blank\" style=\"color:#0067b8;font-weight:bold;text-decoration:underline\">" + (isOctane ? "Open in Octane" : "Open SharePoint folder") + " &#128279;</a>" : "";
                    String envs = "";
                    if (isOctane && s.readiness().octaneMissingEnvs() != null && !s.readiness().octaneMissingEnvs().isEmpty())
                        envs = " [" + String.join(", ", s.readiness().octaneMissingEnvs()) + "]";
                    gapLinks.append("<div style=\"margin-top:2px;color:#c0392b;font-size:11px\">&#10007; ")
                            .append(esc(label(key))).append(esc(envs)).append(linkTag).append("</div>");
                }
            }
            String keyUrl = (jiraBaseUrl != null && !jiraBaseUrl.isBlank())
                    ? jiraBaseUrl + "/browse/" + s.key() : null;
            String keyCell = (keyUrl != null)
                    ? "<a href=\"" + esc(keyUrl) + "\" target=\"_blank\" style=\"color:" + (compliant ? GREEN_D : RED) + ";text-decoration:underline;margin-left:6px\">" + esc(s.key()) + "</a>"
                    : "<span style=\"color:" + (compliant ? GREEN_D : RED) + ";margin-left:6px\">" + esc(s.key()) + "</span>";
            rows.append("<tr><td style=\"padding:7px 10px;font-weight:bold;white-space:nowrap\">")
                .append("<span style=\"color:").append(markColor).append("\">").append(mark).append("</span>")
                .append(keyCell).append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:12px;color:#444\">").append(esc(trim(s.summary(), 55))).append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:12px;color:#444\"><div>").append(esc(firstNonBlank(s.developerName(), s.developerEmail(), "-"))).append("</div>")
                .append(s.reporterName() != null && !s.reporterName().isBlank() ? "<div style=\"color:#888;font-size:11px\">Reporter: " + esc(s.reporterName()) + "</div>" : "").append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:12px\">")
                .append(compliant ? "<span style=\"color:#009464;font-size:11px\">Good for Release</span>" : gapLinks.toString()).append("</td>")
                .append("<td style=\"padding:7px 10px;font-size:11px\">").append(envSummaryInline(s)).append("</td></tr>");
        }

        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Release Guardian — Summary</title><style>" + CSS + "</style></head><body><div class=\"wrap\">"
                + "<div class=\"hdr\"><div class=\"hdr-title\">&#128737;&nbsp; Release Guardian — Summary</div>"
                + "<div class=\"hdr-sub\">" + esc(company) + " &middot; IT TA ADM &middot; " + esc(releaseName) + " &middot; " + today + "</div></div>"
                + "<div class=\"body\"><p>Release readiness for <strong>" + esc(releaseName) + "</strong>. "
                + "<strong style=\"color:#009464\">" + ok + " good</strong> and <strong style=\"color:#c0392b\">" + withGaps + " with gaps</strong> out of <strong>" + total + "</strong>.</p>"
                + "<p style=\"margin:-6px 0 12px;font-size:13px\">"
                + (docCutoff != null && !docCutoff.isBlank()
                    ? "<strong>Document cutoff:</strong> <span style=\"color:#B8860B;font-weight:bold\">" + esc(docCutoff) + "</span>" : "")
                + (releaseDate != null && !releaseDate.isBlank()
                    ? "<span style=\"margin-left:24px\">&nbsp;&nbsp;&middot;&nbsp;&nbsp;<strong>Release date:</strong> " + esc(releaseDate) + "</span>" : "")
                + "</p>"
                + "<table style=\"width:100%;border-collapse:collapse;margin-bottom:14px\"><tr>"
                + statBox(ok, "COMPLIANT", GREEN_L, GREEN, GREEN_D) + "<td style=\"width:3%\"></td>"
                + statBox(withGaps, "WITH GAPS", RED_L, RED, RED) + "<td style=\"width:3%\"></td>"
                + statBox(total, "TOTAL", "#f0f0f0", "#555", "#666") + "</tr></table>"
                + "<div style=\"margin:6px 0 16px\"><div style=\"font-size:11px;color:#555;margin-bottom:5px\">Release readiness "
                + "<strong style=\"color:" + healthColor + "\">" + pct + "% ready</strong> &middot; health "
                + "<strong style=\"color:" + healthColor + "\">" + health.score() + "% (" + gradeText(health.grade()) + ")</strong> "
                + "&middot; Octane " + health.octaneScore() + "% &middot; SharePoint " + health.sharepointScore() + "%</div>"
                + "<table style=\"width:100%;border-collapse:collapse;border-radius:6px;overflow:hidden\"><tr>"
                + (ok > 0 ? "<td style=\"height:18px;background:#009464;width:" + pct + "%\"></td>" : "")
                + (withGaps > 0 ? "<td style=\"height:18px;background:#c0392b;width:" + (100 - pct) + "%\"></td>" : "")
                + "</tr></table>"
                + "<div style=\"font-size:11px;color:#666;margin-top:5px\">"
                + "<span style=\"display:inline-block;width:9px;height:9px;background:#009464;border-radius:2px;margin-right:4px\"></span>"
                + ok + " Good for Release &nbsp;&nbsp;"
                + "<span style=\"display:inline-block;width:9px;height:9px;background:#c0392b;border-radius:2px;margin:0 4px\"></span>"
                + withGaps + " With gaps &nbsp;&nbsp; Total " + total + "</div></div>"
                + "<table style=\"width:100%;border-collapse:collapse;font-size:13px\"><thead><tr style=\"background:#f0f0f0\">"
                + th("Epic") + th("Title") + th("Developer / Reporter") + th("Status") + th("Octane Runs") + "</tr></thead><tbody>" + rows + "</tbody></table>"
                + "</div><div class=\"ftr\">Automated summary from <strong>Release Guardian</strong> &middot; IT TA ADM &middot; " + today + "</div></div></body></html>";
    }

    private static String statBox(int n, String lbl, String bg, String numC, String lblC) {
        return "<td style=\"padding:10px 14px;border-radius:4px;text-align:center;width:30%;background:" + bg + "\">"
                + "<div style=\"font-size:24px;font-weight:bold;color:" + numC + "\">" + n + "</div>"
                + "<div style=\"font-size:11px;margin-top:2px;color:" + lblC + "\">" + lbl + "</div></td>";
    }
    private static String th(String t) { return "<th style=\"padding:8px 10px;font-size:11px;color:#555;text-align:left;border-bottom:2px solid #009464\">" + t + "</th>"; }
    private static String gradeText(String g) {
        return switch (g == null ? "" : g) {
            case "GOOD", "EXCELLENT" -> "Good"; case "AT_RISK" -> "At Risk"; case "CRITICAL" -> "Critical"; default -> g;
        };
    }
    private static String trim(String s, int n) { if (s == null) return ""; return s.length() > n ? s.substring(0, n) + "…" : s; }
    private static String firstNonBlank(String... xs) { for (String x : xs) if (x != null && !x.isBlank()) return x; return ""; }
}
