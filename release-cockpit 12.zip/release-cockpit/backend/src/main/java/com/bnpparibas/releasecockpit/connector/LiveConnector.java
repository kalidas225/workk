package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.ArtifactSpec;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane bearer token (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    public LiveConnector(CockpitProperties props, HttpClientFactory clients,
                         com.bnpparibas.releasecockpit.service.ArtifactConfigService artifacts) {
        this.props = props;
        this.clients = clients;
        this.artifacts = artifacts;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira base-url not configured; returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();

        // 1) Explicit release names take priority (no project lookup needed).
        if (!isBlank(j.getReleaseNames())) {
            for (String name : j.getReleaseNames().split(",")) {
                name = name.trim();
                if (!name.isEmpty()) out.add(new Release(name, name, null, false, ""));
            }
            log.info("Using {} explicit release name(s) from config.", out.size());
            return out;
        }

        // 2) Otherwise scan project fixVersions.
        if (isBlank(j.getProjectKeys())) {
            log.warn("Neither release-names nor project-keys set; no releases. "
                    + "Set cockpit.jira.release-names (e.g. 25.07,25.08) or project-keys.");
            return List.of();
        }
        for (String project : j.getProjectKeys().split(",")) {
            project = project.trim();
            if (project.isEmpty()) continue;
            // Jira DC: project key is case-sensitive; numeric ids also work.
            String body = getJira("/rest/api/2/project/" + enc(project) + "/versions");
            if (body == null) {
                log.warn("Jira versions for project '{}' returned no body (check the key — "
                        + "it must be the PROJECT KEY, e.g. TCAAS1484, not the name).", project);
                continue;
            }
            try {
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        if (name.isEmpty()) continue;
                        LocalDate date = safeDate(v.path("releaseDate").asText(null));
                        boolean released = v.path("released").asBoolean(false);
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                } else {
                    // Jira returned an error object (e.g. 400) rather than an array.
                    log.warn("Jira versions for '{}' not an array — response: {}", project,
                            body.length() > 300 ? body.substring(0, 300) : body);
                }
            } catch (Exception e) {
                log.warn("Parsing Jira versions for '{}' failed: {}", project, e.getMessage());
            }
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String fields = "summary,status,assignee,reporter,created";
            if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank())
                fields += "," + j.getOctaneLinkField();
            if (j.getOctaneFeatureField() != null && !j.getOctaneFeatureField().isBlank())
                fields += "," + j.getOctaneFeatureField();
            String url = "/rest/api/2/search?jql=" + enc(jql) + "&maxResults=200&fields=" + fields;
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");

            // Parse all issues first (cheap, no network).
            record Raw(String key, String summary, String status, String dev, String devEmail,
                       String rep, String repEmail, LocalDate created, List<String> octaneIds,
                       String featureId) {}
            List<Raw> raws = new ArrayList<>();
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null && !j.getOctaneLinkField().isBlank()) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                // Feature id (Octane backlog item the tests cover).
                String featureId = "";
                if (j.getOctaneFeatureField() != null && !j.getOctaneFeatureField().isBlank()) {
                    JsonNode fv = f.path(j.getOctaneFeatureField());
                    featureId = fv.isTextual() ? fv.asText("") : fv.path("value").asText(fv.asText(""));
                    featureId = featureId == null ? "" : featureId.replaceAll("[^0-9]", "");
                }
                raws.add(new Raw(key, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        f.path("assignee").path("displayName").asText(""),
                        f.path("assignee").path("emailAddress").asText(""),
                        f.path("reporter").path("displayName").asText(""),
                        f.path("reporter").path("emailAddress").asText(""),
                        safeDate(f.path("created").asText("").replaceAll("T.*", "")),
                        octaneIds, featureId));
            }

            ExecutorService pool = Executors.newFixedThreadPool(
                    Math.min(12, Math.max(2, raws.size())));
            try {
                final int relYear = releaseYearFor(releaseName);
                List<Future<Subject>> futures = new ArrayList<>();
                for (Raw rw : raws) {
                    futures.add(pool.submit(() -> {
                        boolean octaneOk = checkOctane(rw.octaneIds(), rw.featureId());
                        Readiness r = buildReadiness(rw.key(), octaneOk, relYear);
                        return new Subject(rw.key(), rw.summary(), rw.status(),
                                rw.dev(), rw.devEmail(), rw.rep(), rw.repEmail(),
                                rw.created(), rw.octaneIds(), r);
                    }));
                }
                for (Future<Subject> fut : futures) {
                    try { out.add(fut.get()); }
                    catch (Exception e) { log.warn("Subject check failed: {}", e.getMessage()); }
                }
            } finally {
                pool.shutdown();
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject from artifacts.json. For each enabled
     * SharePoint artifact, resolves its folder, finds files (per goInside rules)
     * and requires minFiles. Per-subject skips are handled in subject-checks.json,
     * not here. The numeric subject id is the trailing number of the epic key.
     */
    private Readiness buildReadiness(String epicKey, boolean octaneOk, int year) {
        java.util.Map<String, Boolean> results = new java.util.HashMap<>();
        for (ArtifactSpec spec : artifacts.sharePointArtifacts()) {
            results.put(spec.key, checkSharePointArtifact(epicKey, spec, year));
        }
        // Artifacts not enabled are absent from the map and default to satisfied
        // (so a disabled artifact never shows as a gap).
        boolean pr = results.getOrDefault("PR", true);
        boolean prExcel = results.getOrDefault("PR_EXCEL", true);
        boolean est = results.getOrDefault("ESTIMATION_SHEET", true);
        boolean rev = results.getOrDefault("OCTANE_REVIEW_DOC", true);
        boolean exec = results.getOrDefault("OCTANE_EXECUTION_DOC", true);
        boolean unit = results.getOrDefault("UNIT_TEST", true); // disabled by default

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");
        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing);
    }

    /** Numeric subject id = trailing digits of the epic key (TCAAS1484-4971 -> 4971). */
    private String subjectIdOf(String epicKey) {
        var m = java.util.regex.Pattern.compile("(\\d+)$").matcher(epicKey);
        return m.find() ? m.group(1) : epicKey;
    }

    /** Year used for {YEAR} substitution — from the release's date, else current year. */
    private int releaseYearFor(String releaseName) {
        try {
            for (Release r : listReleases()) {
                if (r.name().equals(releaseName) && r.releaseDate() != null) {
                    return r.releaseDate().getYear();
                }
            }
        } catch (Exception ignore) { }
        return java.time.Year.now().getValue();
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    private boolean checkOctane(List<String> octaneIds, String featureId) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl())) return false;
        boolean haveFeature = featureId != null && !featureId.isBlank();
        boolean haveIds = octaneIds != null && !octaneIds.isEmpty();
        if (!haveFeature && !haveIds) {
            log.info("Octane: no feature id (field '{}') or test ids (field '{}') on subject — skipping",
                    props.getJira().getOctaneFeatureField(), props.getJira().getOctaneLinkField());
            return false;
        }
        try {
            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return false;

            // Prefer the FEATURE link: query tests whose covered backlog item (the
            // feature from Jira) = featureId. Octane test entity links tests to a
            // backlog item via 'covered_content' / 'test_of_last_run' depending on
            // setup; we filter by the feature id.
            String query;
            if (haveFeature) {
                query = "\"covered_content={id=" + featureId + "}\"";
            } else {
                String ids = String.join(" || ", octaneIds.stream().map(i -> "id=" + i).toList());
                query = "\"(" + ids + ")\"";
            }
            String base = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId();
            String url = base + "/tests?fields=id,name,last_runs&query=" + enc(query);
            HttpResponse<String> r = octaneGet(url);
            if (r != null && r.statusCode() == 401) { octaneSignIn(); r = octaneGet(url); }
            if (r == null || r.statusCode() >= 400) {
                log.info("Octane query HTTP {} (feature={}, ids={})",
                        r == null ? "null" : r.statusCode(), featureId, octaneIds);
                return false;
            }
            JsonNode root = mapper.readTree(r.body());
            int total = root.path("total_count").asInt(0);
            // Optionally require that all linked tests have a passing last run.
            boolean allPassed = true;
            JsonNode data = root.has("data") ? root.path("data") : root.path("d").path("results");
            if (data.isArray() && data.size() > 0) {
                for (JsonNode t : data) {
                    String status = t.path("last_runs").path("data").path(0)
                            .path("native_status").path("name").asText(
                                t.path("last_runs").path("status").asText(""));
                    if (status != null && !status.isBlank()
                            && !status.equalsIgnoreCase("Passed")) { allPassed = false; break; }
                }
            }
            boolean ok = total > 0 && allPassed;
            log.info("Octane feature={} ids={} -> {} test(s), allPassed={} -> {}",
                    featureId, octaneIds, total, allPassed, ok ? "PASS" : "MISSING");
            return ok;
        } catch (Exception e) {
            log.warn("Octane check failed gracefully: {}", e.getMessage());
            return false;
        }
    }

    private void octaneSignIn() {
        var o = props.getOctane();
        try {
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() < 400) {
                // capture the LWSSO_COOKIE_KEY from Set-Cookie
                String cookie = r.headers().allValues("set-cookie").stream()
                        .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                        .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                octaneCookie = cookie;
                log.info("Octane sign-in {}", cookie != null ? "OK" : "returned no cookie");
            } else {
                log.warn("Octane sign-in HTTP {}", r.statusCode());
            }
        } catch (Exception e) {
            log.warn("Octane sign-in failed gracefully: {}", e.getMessage());
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", octaneCookie)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    // ---- SharePoint ----
    // Per-epic cache of the subfolders that contain at least one file, so the
    // listing happens once per epic (not once per artifact). Cleared each scan
    // via the cache TTL on the service layer; here it lives for the connector.

    /**
     * Checks one SharePoint artifact for an epic using its artifacts.json spec.
     *
     * Folder resolution: spec.folder with {YEAR} -> current year and {EPIC} ->
     * epic key, prefixed by the configured root path, under the library. If
     * spec.folder is empty, the epic's own folder under the root is used.
     *
     * Files are listed (recursing into subfolders when goInside=true) and a file
     * matches when its name contains ALL of match.all (after {EPIC} substitution)
     * AND at least one of match.any AND, if extensions is non-empty, ends with one
     * of them. The check passes when at least minFiles files match.
     */
    private boolean checkSharePointArtifact(String epicKey, ArtifactSpec spec, int year) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return false;
        boolean mandatory = spec.mandatory == null || spec.mandatory; // default mandatory
        try {
            String y = String.valueOf(year);
            String root = (sp.getRootPath() == null ? "" : sp.getRootPath()).replace("{YEAR}", y);
            String sub = (spec.folder == null ? "" : spec.folder).replace("{YEAR}", y).replace("{EPIC}", epicKey);

            String subjectId = subjectIdOf(epicKey);
            List<String> anyTokens = (spec.match != null && spec.match.any != null) ? spec.match.any : List.of();
            List<String> exts = (spec.match != null && spec.match.extensions != null) ? spec.match.extensions : List.of();

            List<String> matchingFiles = new ArrayList<>();
            String checkedFolder;

            boolean folderConfigured = sub != null && !sub.isBlank();

            if (!folderConfigured) {
                // CASE A — empty folder (PR, ESTIMATION, UNIT_TEST):
                // The root "...02 - {YEAR} Change request" contains change-request
                // folders whose NAME contains the subject id. Find that folder, go
                // INSIDE it (recursively), and match files by the keywords.
                String baseRel = (siteAndLibrary(sp) + "/" + root).replaceAll("/{2,}", "/");
                List<FolderRef> subjectFolders = findSubjectFolders(baseRel, subjectId, epicKey);
                checkedFolder = subjectFolders.isEmpty() ? baseRel + "/<no folder matching " + subjectId + ">"
                        : subjectFolders.get(0).serverRel;
                for (FolderRef fr : subjectFolders) {
                    for (String name : listFiles(fr.serverRel, true, 0)) {
                        if (keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                    }
                }
            } else {
                // CASE B — configured shared folder (PR_EXCEL, TEST CASE, TEST EXEC):
                // Files live directly in this (year-specific) folder; the FILE NAME
                // must contain the subject id AND one of the keywords (+ extension).
                String baseRel = (siteAndLibrary(sp) + "/" + root + sub).replaceAll("/{2,}", "/");
                checkedFolder = baseRel;
                for (String name : listFiles(baseRel, spec.goInside, 0)) {
                    boolean hasId = name.toLowerCase().contains(subjectId.toLowerCase())
                            || name.toLowerCase().contains(epicKey.toLowerCase());
                    if (hasId && keywordMatches(name, anyTokens, exts)) matchingFiles.add(name);
                }
            }

            boolean ok = matchingFiles.size() >= Math.max(1, spec.minFiles);
            log.info("SharePoint {} [{}] mandatory={} folder='{}' matched={} {} -> {}",
                    epicKey, spec.key, mandatory, checkedFolder, matchingFiles.size(),
                    matchingFiles.isEmpty() ? "" : matchingFiles,
                    ok ? "PASS" : (mandatory ? "MISSING" : "MISSING(optional)"));
            return ok || !mandatory; // non-mandatory never produces a gap
        } catch (Exception e) {
            log.warn("SharePoint check failed ({} {}): {}", epicKey, spec.key, e.getMessage());
            return !mandatory;
        }
    }

    private record FolderRef(String name, String serverRel) {}

    /**
     * Lists subfolders under baseRel and returns those whose name contains the
     * subject id (or the full epic key). These are the per-subject folders.
     */
    private List<FolderRef> findSubjectFolders(String baseRel, String subjectId, String epicKey) {
        List<FolderRef> out = new ArrayList<>();
        var sp = props.getSharepoint();
        try {
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + encodePath(baseRel) + "')/Folders?$select=Name,ServerRelativeUrl";
            HttpResponse<String> r = spGet(url);
            if (r == null || r.statusCode() >= 400) {
                if (r != null) log.info("SharePoint Folders HTTP {} for '{}'", r.statusCode(), baseRel);
                return out;
            }
            JsonNode root = mapper.readTree(r.body());
            JsonNode folders = root.has("value") ? root.path("value") : root.path("d").path("results");
            String keyl = epicKey.toLowerCase();
            // Match the subject id as a whole token (not a substring of a bigger
            // number), e.g. "2328" matches "TCAAS1484-2328 - desc" but not "12328".
            java.util.regex.Pattern idPat = java.util.regex.Pattern.compile(
                    "(?<![0-9])" + java.util.regex.Pattern.quote(subjectId) + "(?![0-9])");
            if (folders.isArray()) for (JsonNode f : folders) {
                String name = f.path("Name").asText("");
                if ("Forms".equalsIgnoreCase(name)) continue;
                String nl = name.toLowerCase();
                boolean hit = nl.contains(keyl) || idPat.matcher(name).find();
                if (hit) {
                    String srv = f.path("ServerRelativeUrl").asText("");
                    if (srv.isBlank()) srv = baseRel + "/" + name;
                    out.add(new FolderRef(name, srv));
                }
            }
        } catch (Exception e) {
            log.info("findSubjectFolders failed ({}): {}", baseRel, e.getMessage());
        }
        return out;
    }

    /** Keyword match: contains one of `any` (if given) and ends with one of `exts` (if given). */
    private boolean keywordMatches(String name, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        if (any != null && !any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** site path + library, e.g. /sites/ITTAADM/Project Documents */
    private String siteAndLibrary(CockpitProperties.SharePoint sp) {
        String sitePath = sp.getBaseUrl().replaceFirst("^https?://[^/]+", "");
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        return (sitePath + "/" + lib).replaceAll("/{2,}", "/");
    }

    /** Lists file names directly in a folder, optionally recursing into subfolders. */
    private List<String> listFiles(String serverRel, boolean recurse, int depth) {
        List<String> names = new ArrayList<>();
        if (depth > 5) return names; // safety bound
        var sp = props.getSharepoint();
        try {
            String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                    + encodePath(serverRel) + "')/Files?$select=Name";
            HttpResponse<String> r = spGet(url);
            if (r != null && r.statusCode() < 400) {
                JsonNode root = mapper.readTree(r.body());
                JsonNode files = root.has("value") ? root.path("value")
                        : root.path("d").path("results");
                if (files.isArray()) for (JsonNode f : files) names.add(f.path("Name").asText(""));
            } else if (r != null) {
                // Log at INFO so auth/path problems are visible (not hidden at debug).
                log.info("SharePoint Files HTTP {} for folder '{}'{}", r.statusCode(), serverRel,
                        (r.statusCode() == 401 || r.statusCode() == 403) ? " — cookies likely expired" : "");
            }
            if (recurse) {
                String furl = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                        + encodePath(serverRel) + "')/Folders?$select=Name,ServerRelativeUrl";
                HttpResponse<String> fr = spGet(furl);
                if (fr != null && fr.statusCode() < 400) {
                    JsonNode froot = mapper.readTree(fr.body());
                    JsonNode folders = froot.has("value") ? froot.path("value")
                            : froot.path("d").path("results");
                    if (folders.isArray()) for (JsonNode sf : folders) {
                        String name = sf.path("Name").asText("");
                        if ("Forms".equalsIgnoreCase(name)) continue; // skip system folder
                        String srv = sf.path("ServerRelativeUrl").asText("");
                        if (srv.isBlank()) srv = serverRel + "/" + name;
                        names.addAll(listFiles(srv, true, depth + 1));
                    }
                } else if (fr != null) {
                    log.info("SharePoint Folders HTTP {} for folder '{}'", fr.statusCode(), serverRel);
                }
            }
        } catch (Exception e) {
            log.info("listFiles error ({}): {}", serverRel, e.getMessage());
        }
        return names;
    }

    private HttpResponse<String> spGet(String url) {
        try {
            var sp = props.getSharepoint();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                    .header("Accept", "application/json;odata=nometadata")
                    .timeout(Duration.ofSeconds(20)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.debug("SharePoint GET failed: {}", e.getMessage());
            return null;
        }
    }

    /** A file matches when its name contains the Jira id (full key or its number) and (if given) an extension. */
    private boolean fileMatchesId(String name, String epicKey, String idNum, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        boolean hasId = lower.contains(epicKey.toLowerCase()) || lower.contains(idNum.toLowerCase());
        if (!hasId) return false;
        if (exts != null && !exts.isEmpty()) {
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) return true;
            return false;
        }
        return true;
    }

    /** A file matches if it contains all `all` tokens, one `any` token, and (if given) an extension. */
    private boolean fileMatches(String name, List<String> all, List<String> any, List<String> exts) {
        if (name == null || name.isBlank()) return false;
        String lower = name.toLowerCase();
        for (String a : all) if (!lower.contains(a.toLowerCase())) return false;
        if (!any.isEmpty()) {
            boolean hit = false;
            for (String a : any) if (lower.contains(a.toLowerCase())) { hit = true; break; }
            if (!hit) return false;
        }
        if (!exts.isEmpty()) {
            boolean ext = false;
            for (String e : exts) if (lower.endsWith(e.toLowerCase())) { ext = true; break; }
            if (!ext) return false;
        }
        return true;
    }

    /** Encode a server-relative path for GetFolderByServerRelativeUrl('...'). */
    private String encodePath(String path) {
        return path.replace("'", "''").replace(" ", "%20");
    }
    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(30)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
