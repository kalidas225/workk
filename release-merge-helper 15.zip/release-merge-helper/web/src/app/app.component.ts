import { Component, computed, inject, signal } from '@angular/core';
import { Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { GitApi } from './core/git-api.service';
import {
  Branch, CherryPickState, ConflictFile, DryItem, MrResponse, ProjectGroup, PushResponse,
  RepoRef, SqlWarning, SubjectGroup,
} from './core/models';
import { ThemeToggleComponent } from './shared/theme-toggle.component';
import { ConflictEditorComponent } from './shared/conflict-editor.component';
import { SettingsPanelComponent } from './shared/settings-panel.component';
import { SettingsService } from './core/settings.service';
import { ToastBus } from './core/http-error.interceptor';
import { SearchableSelectComponent, SelectOption } from './shared/searchable-select.component';

type Step = 'repos' | 'pick';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, ThemeToggleComponent, ConflictEditorComponent, SettingsPanelComponent, SearchableSelectComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  private api = inject(GitApi);
  settings = inject(SettingsService);
  showSettings = signal(false);
  gitlabError = signal<string | null>(null);

  step = signal<Step>('repos');
  // Reference-counted busy state. A single boolean broke when two requests overlapped: the
  // faster one's completion cleared the loader while the slower was still pending. We count
  // in-flight requests instead, so the loader stays on until the LAST one finishes.
  private busyCount = signal(0);
  busy = computed(() => this.busyCount() > 0);
  private busyMsgStack: { id: number; msg: string }[] = [];
  private busySeq = 0;
  busyMsg = signal<string | null>(null);

  private startBusy(msg = ''): number {
    const id = ++this.busySeq;
    this.busyCount.update((n) => n + 1);
    if (msg) { this.busyMsgStack.push({ id, msg }); this.busyMsg.set(msg); }
    return id;
  }
  private endBusy(id?: number) {
    this.busyCount.update((n) => Math.max(0, n - 1));
    if (id != null) {
      this.busyMsgStack = this.busyMsgStack.filter((x) => x.id !== id);
      // show the most recent remaining message, or clear if none
      this.busyMsg.set(this.busyMsgStack.length ? this.busyMsgStack[this.busyMsgStack.length - 1].msg : null);
    } else if (this.busyCount() === 0) {
      this.busyMsgStack = []; this.busyMsg.set(null);
    }
  }
  error = signal<string | null>(null);
  toast = signal<string | null>(null);
  bus = inject(ToastBus);
  toasts = this.bus.items;
  dismissToast(id: number) { this.bus.dismiss(id); }
  toastError(msg: string) { this.bus.push('error', msg); }
  private pushToast(kind: 'error' | 'success' | 'info', msg: string) { this.bus.push(kind, msg); }

  projectGroups = signal<ProjectGroup[]>([]);
  gitlabOn = signal(false);
  repoFilter = signal('');
  activeRepo = signal<RepoRef | null>(null);
  repoRoot = signal('');
  get repoKey() { return this.repoRoot() || ''; }

  branches = signal<Branch[]>([]);
  source = signal('develop');
  target = signal('');

  groups = signal<SubjectGroup[]>([]);
  total = signal(0);
  selected = signal<Set<string>>(new Set());
  filter = signal('');
  collapsed = signal<Set<string>>(new Set());

  targetProtected = signal(false);
  forceNewBranch = signal(false);
  newBranch = signal('');

  dryResults = signal<DryItem[] | null>(null);
  state = signal<CherryPickState | null>(null); // active cherry-pick (conflict or done)
  pushed = signal<PushResponse | null>(null);
  sqlFixed = signal<Set<string>>(new Set());

  // merge request
  showMr = signal(false);
  mrTitle = signal('');
  mrDesc = signal('');
  mrTarget = signal('');
  mrLabels = signal('');
  mrRemoveSource = signal(false);
  mrSquash = signal(false);
  mrResult = signal<MrResponse | null>(null);

  // commit diff viewer
  diffSha = signal<string | null>(null);
  diffFiles = signal<{ file: string; patch: string; additions: number; deletions: number; rows: { type: string; left: string | null; right: string | null; leftNo: number | null; rightNo: number | null }[] }[] | null>(null);
  diffTitle = signal('');
  diffCollapsed = signal<Set<string>>(new Set());
  toggleDiffFile(name: string) { const s = new Set(this.diffCollapsed()); s.has(name) ? s.delete(name) : s.add(name); this.diffCollapsed.set(s); }
  isDiffCollapsed(name: string) { return this.diffCollapsed().has(name); }
  collapseAllDiffs() { this.diffCollapsed.set(new Set((this.diffFiles() || []).map(f => f.file))); }
  expandAllDiffs() { this.diffCollapsed.set(new Set()); }

  conflictFiles = computed<ConflictFile[]>(() => this.state()?.files ?? []);
  inConflict = computed(() => this.state()?.status === 'conflict');
  done = computed(() => this.state()?.status === 'done');

  filteredRepoGroups = computed(() => {
    const q = this.repoFilter().trim().toLowerCase();
    if (!q) return this.projectGroups();
    return this.projectGroups()
      .map((g) => ({ ...g, repos: g.repos.filter((r) => r.name.toLowerCase().includes(q) || r.path.toLowerCase().includes(q)) }))
      .filter((g) => g.repos.length > 0 || g.group.toLowerCase().includes(q));
  });

  // Only local branches; never show remotes (origin/...). Dedupe by name.
  branchOptions = computed<SelectOption[]>(() => {
    const seen = new Set<string>();
    const opts: SelectOption[] = [];
    for (const b of this.branches()) {
      if (b.remote) continue;
      const name = b.name.replace(/^origin\//, '');
      if (seen.has(name)) continue;
      seen.add(name);
      opts.push({ value: name, label: name, hint: b.date, protected: b.protectedBranch });
    }
    return opts;
  });

  filteredGroups = computed(() => {
    const q = this.filter().trim().toLowerCase();
    if (!q) return this.groups();
    return this.groups()
      .map((g) => ({ ...g, commits: g.commits.filter((c) =>
        c.subject.toLowerCase().includes(q) || c.subjectKey.toLowerCase().includes(q) ||
        c.author.toLowerCase().includes(q) || c.shortHash.includes(q)) }))
      .filter((g) => g.commits.length > 0 || g.key.toLowerCase().includes(q));
  });

  selectedCount = computed(() => this.selected().size);
  selectedCommitsOrdered = computed(() => {
    const out: string[] = [];
    for (const g of this.groups()) for (const c of g.commits) if (this.selected().has(c.hash)) out.push(c.hash);
    return out;
  });
  mustBranch = computed(() => this.targetProtected() || this.forceNewBranch());
  canRun = computed(() => {
    if (this.selectedCount() === 0 || !this.target()) return false;
    if (this.mustBranch() && !this.newBranch().trim()) return false;
    return true;
  });

  ngOnInit() { this.loadRepos(); }
  loadRepos() {
    const _b = this.startBusy();
    this.api.repos().subscribe({
      next: (r) => { this.endBusy(_b); this.projectGroups.set(r.groups); this.gitlabOn.set(r.gitlab); this.gitlabError.set(r.gitlabError ?? null); },
      error: () => { this.endBusy(_b); },
    });
  }
  openSettings() { this.showSettings.set(true); }
  onSettingsSaved() { this.loadRepos(); }

  loadingMsg = signal<string | null>(null);
  cloneProgress = signal<{ pct: number; phase: string; detail: string } | null>(null);
  private es: EventSource | null = null;

  chooseRepo(r: RepoRef) {
    if (!r.operable) { this.toastError(`"${r.name}" can't be operated on.`); return; }
    this.activeRepo.set(r);
    this.branches.set([]);
    this.groups.set([]); this.total.set(0);
    this.source.set(''); this.target.set('');
    this.selected.set(new Set());
    this.resetBranchState();
    const key = r.localPath ?? (r.gitlabId != null ? String(r.gitlabId) : r.path);
    this.repoRoot.set(key);
    this.cloneBusyId = this.startBusy();
    this.cloneProgress.set(null);
    this.loadingMsg.set(r.cached ? 'Opening repository…' : 'Preparing repository…');

    // Stream clone progress via SSE so the developer sees live percentage + phase.
    // Robust against: SSE not supported, mid-clone disconnect, false 'error' on normal close,
    // and a hung clone (timeout falls back to the plain connect endpoint).
    const s = this.settings.settings();
    const params = new URLSearchParams({
      repoKey: key,
      gitlabUrl: s.baseUrl || '', gitlabGroup: s.group || '', gitlabToken: s.token || '',
    });
    this.closeStream();

    let settled = false;
    const finishOk = (res: any) => {
      if (settled) return; settled = true;
      this.closeStream();
      this.endBusy(this.cloneBusyId); this.loadingMsg.set(null); this.cloneProgress.set(null);
      this.repoRoot.set(res.repoKey || res.root);
      this.source.set(res.currentBranch || 'develop');
      this.loadBranches(() => { if (!this.branches().some((b) => b.name === this.source())) this.source.set(res.currentBranch || 'develop'); });
      this.step.set('pick');
    };
    const finishErr = (msg: string) => {
      if (settled) return; settled = true;
      this.closeStream();
      this.endBusy(this.cloneBusyId); this.loadingMsg.set(null); this.cloneProgress.set(null);
      this.toastError(msg);
    };
    // Hard timeout: if no done/error in 6 minutes, fall back to a direct connect call.
    this.streamTimer = setTimeout(() => {
      if (settled) return;
      this.closeStream();
      this.api.connect(key).subscribe({ next: (res) => finishOk(res), error: (e) => finishErr(e?.error?.error || 'Connect timed out.') });
    }, 6 * 60 * 1000);

    try {
      this.es = new EventSource(`/api/connect-stream?${params.toString()}`);
    } catch {
      // SSE unavailable — go straight to the plain connect endpoint.
      this.api.connect(key).subscribe({ next: (res) => finishOk(res), error: (e) => finishErr(e?.error?.error || 'Connect failed.') });
      return;
    }

    this.es.addEventListener('progress', (ev: MessageEvent) => {
      try {
        const p = JSON.parse(ev.data);
        this.cloneProgress.set({ pct: p.overallPct, phase: p.phase, detail: p.detail });
        this.loadingMsg.set(p.phase === 'Ready' || p.detail === 'cached' ? 'Opening repository…' : 'Cloning repository…');
      } catch { /* ignore malformed frame */ }
    });
    this.es.addEventListener('done', (ev: MessageEvent) => {
      try { finishOk(JSON.parse(ev.data)); } catch { finishErr('Connect failed.'); }
    });
    this.es.addEventListener('error', (ev: MessageEvent) => {
      // EventSource fires 'error' on BOTH real errors and normal stream close.
      // If we already settled (done arrived), ignore. If the server sent an error payload,
      // use it. Otherwise it's a transport drop — fall back to the plain connect endpoint.
      if (settled) return;
      let msg: string | null = null;
      try { msg = JSON.parse((ev as any).data)?.error || null; } catch { /* no payload = transport drop */ }
      if (msg) { finishErr(msg); return; }
      // transport-level close without a payload: retry once via XHR before giving up.
      this.closeStream();
      this.api.connect(key).subscribe({ next: (res) => finishOk(res), error: (e) => finishErr(e?.error?.error || 'Connect failed.') });
    });
  }
  private streamTimer: any = null;
  private cloneBusyId = 0;
  private closeStream() {
    try { this.es?.close(); } catch { /* */ }
    this.es = null;
    if (this.streamTimer) { clearTimeout(this.streamTimer); this.streamTimer = null; }
  }
  resetBranchState() {
    this.forceNewBranch.set(false);
    this.newBranchEdited.set(false);
    this.newBranch.set('');
    this.targetProtected.set(false);
    this.dryResults.set(null);
    this.state.set(null);
    this.pushed.set(null);
    this.mrResult.set(null);
    this.showMr.set(false);
  }
  changeRepo() {
    // go back to repo list and clear everything from the current repo
    this.step.set('repos');
    this.activeRepo.set(null);
    this.repoRoot.set('');
    this.branches.set([]);
    this.groups.set([]); this.total.set(0);
    this.source.set(''); this.target.set('');
    this.selected.set(new Set());
    this.resetBranchState();
  }

  loadBranches(then?: () => void) { this.run(this.api.branches(this.repoKey), (r) => { this.branches.set(r.branches); then?.(); }); }
  fetchAll() {
    this.run(this.api.fetchAll(this.repoKey), (r) => {
      this.flash(r.output || 'Fetched.');
      // reload branches AND subjects so the view reflects the freshly-fetched state
      this.loadBranches(() => this.loadCommits());
    }, 'Fetching latest from origin…');
  }
  onSourceChange(v: string) { this.source.set(v); this.resetBranchState(); this.loadCommits(); }
  onTargetChange(v: string) { this.target.set(v); this.resetBranchState(); this.loadCommits(); }
  pageSize = 500;
  loadedOffset = signal(0);
  loadCommits() {
    if (!this.source()) { this.groups.set([]); this.total.set(0); this.selected.set(new Set()); this.loadedOffset.set(0); return; }
    const reqRepo = this.repoKey, reqSrc = this.source(), reqTgt = this.target();
    this.loadedOffset.set(0);
    this.run(this.api.commits(reqRepo, reqSrc, reqTgt, this.pageSize, 0), (r) => {
      // Ignore a late response if the user switched repo/branch in the meantime.
      if (this.repoKey !== reqRepo || this.source() !== reqSrc || this.target() !== reqTgt) return;
      this.groups.set(r.groups); this.total.set(r.total);
      this.loadedOffset.set(r.returned ?? r.groups.reduce((a, g) => a + g.count, 0));
      this.selected.set(new Set()); this.dryResults.set(null); this.state.set(null); this.pushed.set(null);
    }, 'Loading subjects…');
    if (this.target()) this.checkProtection();
  }

  loadedCount = computed(() => this.groups().reduce((a, g) => a + g.count, 0));
  hasMore = computed(() => this.loadedCount() < this.total());

  loadMore() {
    const reqRepo = this.repoKey, reqSrc = this.source(), reqTgt = this.target();
    const offset = this.loadedCount();
    this.run(this.api.commits(reqRepo, reqSrc, reqTgt, this.pageSize, offset), (r) => {
      if (this.repoKey !== reqRepo || this.source() !== reqSrc || this.target() !== reqTgt) return;
      // Merge new groups into existing, combining commits for subjects that span pages.
      const byKey = new Map(this.groups().map((g) => [g.key, { ...g, commits: [...g.commits] }]));
      for (const g of r.groups) {
        const ex = byKey.get(g.key);
        if (ex) { ex.commits.push(...g.commits); ex.count = ex.commits.length; }
        else byKey.set(g.key, { ...g, commits: [...g.commits] });
      }
      this.groups.set([...byKey.values()]);
    }, 'Loading more subjects…');
  }
  checkProtection() {
    if (!this.target()) { this.targetProtected.set(false); return; }
    this.api.protectedCheck(this.repoKey, this.target()).subscribe({
      next: (r) => {
        this.targetProtected.set(r.isProtected);
        // always refresh the suggested branch name for the CURRENT target (fixes stale name)
        if (r.isProtected || this.forceNewBranch()) this.newBranch.set(this.suggestBranchName());
        else this.newBranch.set('');
      },
      error: () => {},
    });
  }
  // Selected subject keys (e.g. TCAAS1484-3055), in order.
  selectedSubjects = computed(() => {
    const keys: string[] = [];
    for (const g of this.groups()) {
      if (g.commits.some((c) => this.selected().has(c.hash)) && !keys.includes(g.key)) keys.push(g.key);
    }
    return keys;
  });
  private lastSubjects: string[] = [];
  private lastCommitSubject = '';
  // Subject line of the most recent selected commit (top of the list = newest).
  private latestSelectedCommitSubject(): string {
    for (const g of this.groups()) {
      for (const c of g.commits) {
        if (this.selected().has(c.hash)) return c.subject || '';
      }
    }
    return '';
  }
  suggestBranchName() {
    const subs = this.selectedSubjects();
    if (subs.length === 1) return `cherry-pick/${subs[0]}`;
    if (subs.length > 1) return `cherry-pick/${subs[0]}-and-${subs.length - 1}-more`;
    const t = this.target().replace(/^remotes\/[^/]+\//, '').replace(/[^\w./-]/g, '-');
    return `cherry-pick/${t}-${new Date().toISOString().slice(0, 10)}`;
  }

  newBranchEdited = signal(false);
  private refreshBranchName() {
    if (this.mustBranch() && !this.newBranchEdited()) this.newBranch.set(this.suggestBranchName());
  }
  onNewBranchInput(v: string) { this.newBranch.set(v); this.newBranchEdited.set(true); }
  toggleCommit(h: string) { const s = new Set(this.selected()); s.has(h) ? s.delete(h) : s.add(h); this.selected.set(s); this.refreshBranchName(); }
  isSelected(h: string) { return this.selected().has(h); }
  toggleGroup(g: SubjectGroup) {
    const s = new Set(this.selected());
    const allOn = g.commits.every((c) => s.has(c.hash));
    for (const c of g.commits) allOn ? s.delete(c.hash) : s.add(c.hash);
    this.selected.set(s); this.refreshBranchName();
  }
  groupState(g: SubjectGroup): 'all' | 'some' | 'none' {
    const on = g.commits.filter((c) => this.selected().has(c.hash)).length;
    if (on === 0) return 'none'; return on === g.commits.length ? 'all' : 'some';
  }
  toggleCollapse(k: string) { const s = new Set(this.collapsed()); s.has(k) ? s.delete(k) : s.add(k); this.collapsed.set(s); }
  selectAll() { const s = new Set<string>(); for (const g of this.filteredGroups()) for (const c of g.commits) s.add(c.hash); this.selected.set(s); this.refreshBranchName(); }
  clearAll() { this.selected.set(new Set()); this.refreshBranchName(); }

  dryRun() {
    if (!this.canRun()) return;
    this.run(this.api.dryRun({ repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(), newBranch: this.newBranch() }),
      (r) => this.dryResults.set(r.results), 'Dry run — checking for conflicts…');
  }

  apply() {
    if (!this.canRun()) return;
    const n = this.selectedCommitsOrdered().length;
    this.lastSubjects = this.selectedSubjects();          // capture for the MR title
    this.lastCommitSubject = this.latestSelectedCommitSubject();
    const _b = this.startBusy(`Cherry-picking ${n} commit(s)…`); this.dryResults.set(null);
    this.api.start({
      repoKey: this.repoKey, target: this.target(), commits: this.selectedCommitsOrdered(),
      forceNewBranch: this.forceNewBranch(), newBranch: this.mustBranch() ? this.newBranch().trim() : undefined,
    }).subscribe({
      next: (s) => { this.endBusy(_b); this.state.set(s); if (s.status === 'done') { this.onCherryDone(s); } },
      error: () => { this.endBusy(_b); },
    });
  }

  onResolved(resolutions: { file: string; content?: string; side?: "ours" | "theirs" | "delete" }[]) {
    const wb = this.state()?.workBranch; if (!wb) return;
    const _b = this.startBusy('Applying resolution & continuing…');
    this.api.resolve({ repoKey: this.repoKey, workBranch: wb, resolutions }).subscribe({
      next: (s) => { this.endBusy(_b); this.state.set(s);
        if (s.status === 'done') { this.onCherryDone(s); }
        else this.flash('Resolved — next conflict.'); },
      error: () => { this.endBusy(_b); },
    });
  }
  onAbort() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.api.abort({ repoKey: this.repoKey, workBranch: wb }).subscribe({
      next: () => { this.state.set(null); this.flash('Cherry-pick aborted. Nothing applied.'); },
      error: () => {},
    });
  }

  onCherryDone(s: CherryPickState) {
    this.prefillMr(s);
    const parts = [`Applied ${s.applied} commit(s)`];
    if (s.skipped) parts.push(`${s.skipped} skipped (already on target)`);
    if (s.autoResolved?.length) parts.push(`${s.autoResolved.length} order file(s) auto-merged`);
    this.pushToast('success', parts.join(' · ') + ` → ${s.workBranch}`);
    // bring the result into view so the developer doesn't have to hunt for it
    setTimeout(() => {
      const el = document.querySelector('.ok-drawer');
      el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  }
  prefillMr(s: CherryPickState) {
    this.mrTarget.set(this.target());
    // Title = the subject ID(s) added to the target branch, e.g.
    //   "STS-220, STS-231 added to release/STS-R6.2026.0"
    // Falls back to the latest commit's subject line if no subject IDs were detected.
    const subs = (this.lastSubjects || []).filter((k) => k && k.toLowerCase() !== 'other');
    const tgt = this.target();
    let title: string;
    if (subs.length) {
      const ids = subs.length > 4 ? `${subs.slice(0, 4).join(', ')} +${subs.length - 4} more` : subs.join(', ');
      title = `${ids} added to ${tgt}`;
    } else if (this.lastCommitSubject) {
      title = this.lastCommitSubject;
    } else {
      title = `${s.applied} commit(s) added to ${tgt}`;
    }
    this.mrTitle.set(title);
    this.mrDesc.set(
`## :white_check_mark: Merge Request Acceptance Checklist
- [ ] User Story Related Subtasks and Octane Test cases were present with proper comments.
- [ ] The changes made to the code are compatible with frontend changes.
- [ ] The SonarQube quality scan has been executed and verified. :100: 
- [ ] Security & Core features have been thoroughly checked.
    - * [ ] Ensure that the code securely stores sensitive data.
    - * [ ] Any identified vulnerabilities must be explained by the Developer.
    - * [ ] Verify for any missing or poorly implemented functions.
- [ ] Performance and maintainability have been assessed.
    - * [ ] Avoid inefficient string concatenations, logging, or object allocations in the code.
    - * [ ] The code should not have a negative impact on system performance.
    - * [ ] Confirm that the code is easy to test and debug.
- [ ] Readability and documentation have been reviewed.
    - * [ ] The relevant User Story, Octane, or documentation should clarify the code's purpose.
    - * [ ] Emphasize clarity and conciseness in the code.
- [ ] Naming conventions and automatable tasks have been validated.
    - * [ ] Adherence to naming standards in variables, methods, classes, etc.
    - * [ ] Ensure that names are clear and straightforward.
    - * [ ] Check if any part of the code can be automated.
- [ ] The commit message aligns our [guidelines](
https://confluence.group.echonet/display/TCAAS2745/Source+Control+-+Commit+Message+Format) :green_heart:.

### :point_right: Purpose of this Merge Request
- [ ] Features Development :shamrock:
- [ ] Bug / Defect Fixations :spider:
- [ ] Hotfix Development :fire:
- [ ] Depreciation or Obsolescence Management :dizzy:
- [ ] Code Tests, Execution Tests, Unit Testing and Test case modification :repeat:
- [ ] Pipeline Build Related Changes, Confirm the MR labeled with ~"The TCM" :v:
- [ ] Code Library or Dependency Modifications :globe_with_meridians:
- [ ] Environment level Configuration :earth_asia: 
- [ ] Documentation :books:
- [ ] Code Style Changes (Code formatting, Local variables, Naming standards) :sunglasses:
- [ ] Code Refactoring (No functional changes, No API Changes) :recycle: 
- [ ] Others, Please describe in comment section:

##### For more information, :speech_balloon: The Team TCM :v:`
    );
    this.mrResult.set(null); this.showMr.set(false);
  }
  openMr() { this.showMr.set(true); }
  raiseMr() {
    const wb = this.state()?.workBranch; if (!wb || !this.mrTitle().trim() || !this.mrTarget().trim()) return;
    const labels = this.mrLabels().split(',').map((x) => x.trim()).filter(Boolean);
    const _b = this.startBusy('Creating merge request…');
    this.api.mergeRequest({ repoKey: this.repoKey, sourceBranch: wb, targetBranch: this.mrTarget().trim(),
      title: this.mrTitle().trim(), description: this.mrDesc(), removeSourceBranch: this.mrRemoveSource(),
      squash: this.mrSquash(), labels }).subscribe({
      next: (r) => { this.endBusy(_b); this.mrResult.set(r); if (r.ok) this.flash(`MR !${r.iid} created.`); },
      error: () => { this.endBusy(_b); },
    });
  }
  viewCommitDiff(sha: string, label: string) {
    this.diffSha.set(sha); this.diffTitle.set(label); this.diffFiles.set(null);
    const _b = this.startBusy('Loading diff…');
    this.api.commitDiff(this.repoKey, sha).subscribe({
      next: (r) => { this.endBusy(_b); this.diffFiles.set(r.files); this.diffCollapsed.set(new Set(r.files.slice(1).map(f => f.file))); },
      error: () => { this.endBusy(_b); this.diffSha.set(null); },
    });
  }
  viewMergedDiff() {
    const wb = this.state()?.workBranch; if (!wb) return;
    this.diffSha.set('__merged__'); this.diffTitle.set(`What changed on ${wb}`); this.diffFiles.set(null);
    const _b = this.startBusy('Loading diff…');
    this.api.branchDiff(this.repoKey, this.target(), wb).subscribe({
      next: (r) => { this.endBusy(_b); this.diffFiles.set(r.files); this.diffCollapsed.set(new Set(r.files.slice(1).map(f => f.file))); },
      error: () => { this.endBusy(_b); this.diffSha.set(null); },
    });
  }
  closeDiff() { this.diffSha.set(null); this.diffFiles.set(null); }
  push() {
    const wb = this.state()?.workBranch; if (!wb) return;
    const _b = this.startBusy('Pushing branch to origin…');
    this.api.push({ repoKey: this.repoKey, branch: wb, setUpstream: true }).subscribe({
      next: (r) => { this.endBusy(_b); this.pushed.set(r); this.flash(`Pushed ${wb}.`); },
      error: () => { this.endBusy(_b); },
    });
  }
  fixSql(w: SqlWarning) {
    this.api.fixSql(this.repoKey, w.file).subscribe({
      next: () => { const s = new Set(this.sqlFixed()); s.add(w.file); this.sqlFixed.set(s); this.flash(`Added trailing / to ${w.file}`); },
      error: () => {},
    });
  }
  isFixed(f: string) { return this.sqlFixed().has(f); }
  copy(t: string) { navigator.clipboard?.writeText(t); this.flash('Copied.'); }

  private run<T>(obs: Observable<T>, ok: (r: T) => void, msg?: string) {
    const _b = this.startBusy(msg);
    obs.subscribe({ next: (r: T) => { this.endBusy(_b); ok(r); },
      error: () => { this.endBusy(_b); } });
  }
  private flash(m: string) { this.pushToast('success', m); }
}
