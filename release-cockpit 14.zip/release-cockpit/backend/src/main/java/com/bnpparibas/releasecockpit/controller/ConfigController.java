package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Lightweight UI config — lets the frontend self-configure (default release to
 * auto-select, Jira base URL for subject links) from the backend properties so
 * nothing is hardcoded in the client.
 *
 *   GET /api/config -> { defaultRelease, jiraBaseUrl }
 */
@RestController
@RequestMapping("/api/config")
public class ConfigController {

    private final CockpitProperties props;

    public ConfigController(CockpitProperties props) {
        this.props = props;
    }

    @GetMapping
    public Map<String, Object> config() {
        Map<String, Object> m = new HashMap<>();
        m.put("defaultRelease", props.getJira().getDefaultRelease());
        m.put("jiraBaseUrl", props.getJira().getBaseUrl());
        return m;
    }
}
