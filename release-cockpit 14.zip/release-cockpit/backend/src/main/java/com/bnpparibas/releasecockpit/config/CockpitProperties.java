package com.bnpparibas.releasecockpit.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Strongly-typed configuration bound from application.yml (cockpit.*).
 * Mirrors the placeholders documented there.
 */
@Data
@Component
@ConfigurationProperties(prefix = "cockpit")
public class CockpitProperties {

    /** When true, use in-memory mock connectors instead of live systems. */
    private boolean mockMode = true;

    private Jira jira = new Jira();
    private Octane octane = new Octane();
    private SharePoint sharepoint = new SharePoint();
    private Proxy proxy = new Proxy();
    private ServiceNow servicenow = new ServiceNow();
    private Ai ai = new Ai();
    private Cors cors = new Cors();
    private Mail mail = new Mail();
    private Scheduler scheduler = new Scheduler();

    @Data
    public static class Scheduler {
        /** Auto-check cron (default every 3 hours). */
        private String autoCheckCron = "0 0 */3 * * *";
        /** Hourly late-add detection cron. */
        private String lateAddCron = "0 0 * * * *";
        /** When true, the auto-check emails gaps + manager summary. */
        private boolean autoMail = false;
    }

    @Data
    public static class Jira {
        private String baseUrl;
        private String authMode = "basic"; // basic | bearer
        private String username;            // network id, e.g. c59849
        private String password;            // network password (basic auth)
        private String email;
        private String apiToken;
        private String pat;
        /** Custom field id holding Octane IDs, e.g. customfield_10075. */
        private String octaneLinkField;
        /** Custom field id holding the Octane FEATURE id at subject level
         *  (tests are linked to this feature). Octane is queried for tests whose
         *  covered feature = this id. */
        private String octaneFeatureField;
        /** Project key(s) to scan for releases (fixVersions), comma separated. */
        private String projectKeys;
        /** Optional explicit release names (comma separated) if not using project versions. */
        private String releaseNames;
        /** Release auto-selected in the UI on load (e.g. STS-2026-X5). */
        private String defaultRelease;
        /** JQL template to find subjects of a release. {RELEASE} is substituted. */
        private String subjectJql = "issuetype = Epic AND fixVersion = \"{RELEASE}\" ORDER BY key ASC";
    }

    @Data
    public static class Octane {
        private String baseUrl;
        private String sharedSpaceId;
        private String workspaceId;
        private String clientId;
        private String clientSecret;
    }

    @Data
    public static class SharePoint {
        private String baseUrl;
        private String authMode = "cookie"; // cookie | ntlm | basic
        private String username;
        private String password;
        private String domain;
        /** Cookie auth (SharePoint Online) — these expire ~weekly. */
        private String fedAuth;
        private String rtFa;
        private String libraryName = "Documents";
        private String rootPath = "/Releases/{RELEASE}/{EPIC}";
    }

    @Data
    public static class Proxy {
        /** When true, Octane + SharePoint calls route through this proxy. */
        private boolean enabled = false;
        private String host;
        private int port = 8080;
        private String user;
        private String pass;
        /** When true, trust all TLS certs (mirrors NODE_TLS_REJECT_UNAUTHORIZED=0). */
        private boolean trustAllSsl = false;
    }

    @Data
    public static class Mail {
        private String fromName = "Release Cockpit";
        private String fromAddress;
        private String replyTo;             // shown when a developer clicks Reply
        private String fallbackTo;
        private String[] summaryTo = new String[0];
        /** Managers CC'd on every developer gap email (comma-separated env). */
        private String[] managersCc = new String[0];
    }

    @Data
    public static class Ai {
        /** When true, the company LLM rewrites email text before sending. */
        private boolean enabled = false;
        private String baseUrl;
        private String apiKey;
        private String apiKeyHeader;        // blank = use Bearer Authorization
        private String model = "gpt-oss-120b-ITG";
        private int timeoutMs = 15000;
    }

    @Data
    public static class Cors {
        /** Allowed origins for the API. Empty = allow all (dev). */
        private String[] allowedOrigins = new String[0];
    }

    @Data
    public static class ServiceNow {
        /** Off until you connect it. When false, the panel shows "Not configured". */
        private boolean enabled = false;
        private String baseUrl;       // https://yourinstance.service-now.com
        private String username;
        private String password;       // or an OAuth token if you prefer
        /** Table to query, e.g. "change_request" or "rm_release". */
        private String table = "change_request";
        /** Field on the ServiceNow record that carries the Jira/release key. */
        private String releaseField = "u_release";
    }
}
