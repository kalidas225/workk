// Runtime config — edit AFTER build without recompiling. Loaded before the app.
//   useMock : true  = in-browser demo data (no backend)
//             false = call the real API at apiBase
//   apiBase : the API root. '/api' = same origin as this app (recommended in
//             production where the frontend is served by/behind the backend).
//             Use a full URL only if the API is on a different host.
window.__cockpit = {
  useMock: false,
  apiBase: '/api'
};
