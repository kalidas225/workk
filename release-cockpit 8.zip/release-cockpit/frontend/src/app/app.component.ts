import { Component, OnInit, ElementRef, ViewChild, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, registerables } from 'chart.js';
import { ApiService } from './api.service';
import { DropdownComponent, DropdownOption } from './dropdown.component';
import {
  Release, Checkpoints, Subject, ReleaseSummary, Page, ARTIFACT_LABELS,
  ReleaseHealth, ConnectionStatus, ServiceNowTicket, CTask, ReleaseChanges, SubjectCheckConfig, ChecksConfig, Milestone,
} from './models';

Chart.register(...registerables);

type Tab = 'dashboard' | 'servicenow' | 'config';
const ENVS = ['DEV', 'IST', 'UAT'];
const SP_ITEMS = ['PR_EXCEL', 'OCTANE_REVIEW_DOC', 'OCTANE_EXECUTION_DOC'];

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, DropdownComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent implements OnInit, AfterViewChecked {
  releases: Release[] = [];
  selected = '';
  checkpoints?: Checkpoints;
  summary?: ReleaseSummary;
  health?: ReleaseHealth;
  systems: ConnectionStatus[] = [];
  subjectsPage?: Page<Subject>;
  tickets: ServiceNowTicket[] = [];
  checks?: ChecksConfig;

  page = 0; size = 20;
  loading = false; toast = ''; sendingKey = ''; mailingAll = false; mailingSummary = false;
  // per-section loading flags so each panel can show its own spinner
  loadingTimeline = false; loadingHealth = false; loadingCharts = false; loadingSubjects = false;
  tab: Tab = 'dashboard';
  theme: 'light' | 'dark' = 'light';
  artifactLabels = ARTIFACT_LABELS;
  envs = ENVS; spItems = SP_ITEMS;

  // per-system refresh state
  sysLoading: Record<string, boolean> = {};
  // dropdown open state

  // filters
  filterText = '';
  filterStatus = '';
  filterReadiness = ''; // '', 'ready', 'gaps'
  filterDev = '';

  @ViewChild('devChart') devChartRef?: ElementRef<HTMLCanvasElement>;
  @ViewChild('readyChart') readyChartRef?: ElementRef<HTMLCanvasElement>;
  private devChart?: Chart; private readyChart?: Chart;
  private chartsDirty = false;
  devLegend: { name: string; count: number; color: string }[] = [];

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    const saved = (typeof localStorage !== 'undefined' && localStorage.getItem('rc-theme')) as any;
    this.setTheme(saved === 'dark' ? 'dark' : 'light');
    this.api.getStatus().subscribe(s => this.systems = s);
    this.api.getConfig().subscribe(cfg => {
      if (cfg.jiraBaseUrl) this.jiraBase = cfg.jiraBaseUrl;
      this.spConfig = cfg;
      this.api.getReleases().subscribe(r => {
        this.releases = r;
        this.buildReleaseOptions();
        const def = cfg.defaultRelease && r.find(x => x.name === cfg.defaultRelease);
        if (def) { this.selected = def.name; this.load(); this.pollScanStatus(); }
        this.booting = false;
      }, () => this.booting = false);
    }, () => this.booting = false);
  }

  ngAfterViewChecked(): void {
    if (this.chartsDirty && this.summary && this.tab === 'dashboard'
        && this.readyChartRef) {
      this.renderCharts();
      this.chartsDirty = false;
    }
  }

  setTheme(t: 'light' | 'dark'): void {
    this.theme = t;
    if (typeof document !== 'undefined') document.documentElement.setAttribute('data-theme', t);
    if (typeof localStorage !== 'undefined') localStorage.setItem('rc-theme', t);
    this.chartsDirty = true;
  }

  setTab(t: Tab): void {
    this.tab = t;
    if (t === 'servicenow') this.api.getServiceNow(this.selected).subscribe({ next: x => this.tickets = x, error: () => this.tickets = [] });
    if (t === 'dashboard') this.chartsDirty = true;
    if (t === 'config' && !this.cfgLoaded && !this.cfgLoading) {
      this.loadConfigTab();
    }
    if (t === 'config') this.loadEnvLinks();
  }

  cfgLoaded = false;
  private loadConfigTab(): void {
    this.cfgLoading = true;
    // Load this release's check overrides (release-scoped). Never let a failure
    // hang the tab — always clear the spinner.
    this.api.getChecks(this.selected).subscribe({
      next: c => { this.checks = c; this.recomputeCfgKeys(); },
      error: () => { this.checks = this.checks ?? { default: { octaneEnvironments: ['DEV','IST','UAT'], bcmEndToEnd: false, skipSharePoint: [], note: '' }, overrides: {} } as any; this.recomputeCfgKeys(); },
    });
    // Reuse already-loaded subjects if present; else fetch once.
    if (this.allSubjects && this.allSubjects.length) {
      this.cfgLoading = false; this.cfgLoaded = true; this.recomputeCfgKeys();
      return;
    }
    this.api.getSubjects(this.selected, 0, 500).subscribe({
      next: p => { this.allSubjects = p.content; this.cfgLoading = false; this.cfgLoaded = true; this.recomputeCfgKeys(); },
      error: () => { this.allSubjects = []; this.cfgLoading = false; this.cfgLoaded = true; this.flash('Could not load subjects — try Refresh'); },
    });
  }

  onRelease(): void {
    this.page = 0;
    this.tab = 'dashboard';   // always land on dashboard when the release changes
    // Reset per-release state so tab counts/data don't leak across releases.
    this.tickets = [];
    this.allSubjects = [];
    this.envLinks = {};
    this.statusOverrides = {};
    this.releaseChanges = undefined;
    this.changeGroups = [];
    this.cfgKeys = [];        // reset the Check config count immediately
    this.checks = undefined as any;
    this.cfgLoaded = false;
    this.subjectsPage = undefined;
    this.summary = undefined;
    this.health = undefined;
    this.checkpoints = undefined;
    this.devLegend = [];
    // Force a fresh LIVE scan for the newly selected release (evict cache), so
    // switching releases never shows stale cached data.
    this.loading = true;
    this.api.refreshRelease(this.selected).subscribe({
      next: () => { this.load(); this.pollScanStatus(); },
      error: () => { this.load(); this.pollScanStatus(); },
    });
  }

  load(): void {
    if (!this.selected) return;
    this.loading = true;
    this.loadingTimeline = this.loadingHealth = this.loadingCharts = this.loadingSubjects = true;
    this.api.getCheckpoints(this.selected).subscribe(c => { this.checkpoints = c; this.loadingTimeline = false; this.recomputeMilestones(); });
    this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; this.loadingCharts = false; });
    this.api.getHealth(this.selected).subscribe(h => { this.health = h; this.loadingHealth = false; });
    // Populate the Check config count up-front (independent of opening the tab),
    // so the badge is correct on first load and every release change.
    this.api.getChecks(this.selected).subscribe({
      next: c => { this.checks = c; this.recomputeCfgKeys(); },
      error: () => {},
    });
    this.loadEnvLinks();
    this.loadSubjects();
  }
  loadSubjects(): void {
    this.loadingSubjects = true;
    // Load ALL subjects for the release once, then filter + paginate on the client
    // so the filters (status / readiness / developer) persist across page changes.
    this.api.getSubjects(this.selected, 0, 500).subscribe(p => {
      this.allSubjects = p.content;
      this.loading = false;
      this.loadingSubjects = false;
      this.applyFilters();          // recompute the filtered view
      this.rebuildSubjectDerived();
      this.recomputeCfgKeys();
    });
  }
  refresh(): void {
    if (!this.selected) { this.flash('Pick a release first'); return; }
    this.flash('Refreshing from source…');
    this.tab = 'dashboard';            // always return to dashboard on refresh
    this.loading = true;
    // Evict the backend cache and force a fresh live scan, THEN reload + poll.
    this.api.refreshRelease(this.selected).subscribe({
      next: () => { this.load(); this.pollScanStatus(); },
      error: () => { this.load(); this.pollScanStatus(); },
    });
  }

  // Per-system refresh: re-probe one system + (for data systems) reload data.
  refreshSystem(sys: string): void {
    this.sysLoading[sys] = true;
    this.api.getStatus().subscribe(all => {
      const one = all.find(s => s.system === sys);
      if (one) { const idx = this.systems.findIndex(x => x.system === sys); if (idx >= 0) this.systems[idx] = one; }
      if (sys === 'JIRA') { this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; }); this.loadSubjects(); }
      if (sys === 'SERVICENOW') this.api.getServiceNow(this.selected).subscribe(t => this.tickets = t);
      setTimeout(() => { this.sysLoading[sys] = false; this.flash(sys + ' refreshed'); }, 350);
    });
  }

  // ---- dropdown ----
  pick(name: string): void { if (name !== this.selected) { this.selected = name; this.onRelease(); } }

  // ---- filtering (precomputed fields — NOT getters — to avoid CD loops) ----
  filtered: Subject[] = [];
  statusFilterOptions: DropdownOption[] = [{ value: '', label: 'All status' }];
  devFilterOptions: DropdownOption[] = [{ value: '', label: 'All developers' }];
  readinessFilterOptions: DropdownOption[] = [
    { value: '', label: 'All readiness' },
    { value: 'ready', label: 'Ready' },
    { value: 'gaps', label: 'Has gaps' },
  ];
  releaseOptions: DropdownOption[] = [];

  private rebuildSubjectDerived(): void {
    const all = this.allSubjects ?? [];
    const statuses = Array.from(new Set(all.map(s => s.status))).sort();
    const devs = Array.from(new Set(all.map(s => s.developerName))).sort();
    this.statusFilterOptions = [{ value: '', label: 'All status' }, ...statuses.map(s => ({ value: s, label: s }))];
    this.devFilterOptions = [{ value: '', label: 'All developers' }, ...devs.map(d => ({ value: d, label: d }))];
    this.applyFilters();
  }

  applyFilters(): void {
    let list = this.allSubjects ?? [];
    const q = this.filterText.trim().toLowerCase();
    if (q) list = list.filter(s =>
      s.key.toLowerCase().includes(q) || s.summary.toLowerCase().includes(q) ||
      s.developerName.toLowerCase().includes(q) || s.reporterName.toLowerCase().includes(q) ||
      s.developerEmail.toLowerCase().includes(q));
    if (this.filterStatus) list = list.filter(s => s.status === this.filterStatus);
    if (this.filterDev) list = list.filter(s => s.developerName === this.filterDev);
    if (this.filterReadiness === 'ready') list = list.filter(s => s.readiness.missingCount === 0);
    if (this.filterReadiness === 'gaps') list = list.filter(s => s.readiness.missingCount > 0);
    this.filtered = list;
    // Keep the current page in range after filtering.
    if (this.page >= this.totalPages) this.page = Math.max(0, this.totalPages - 1);
  }
  // The subjects visible on the current page (client-side pagination of the
  // filtered list, so filters persist across page changes).
  get pagedSubjects(): Subject[] {
    const start = this.page * this.size;
    return this.filtered.slice(start, start + this.size);
  }
  setStatusFilter(v: string): void { this.filterStatus = v; this.page = 0; this.applyFilters(); }
  setReadinessFilter(v: string): void { this.filterReadiness = v; this.page = 0; this.applyFilters(); }
  setDevFilter(v: string): void { this.filterDev = v; this.page = 0; this.applyFilters(); }
  clearFilters(): void { this.filterText = ''; this.filterStatus = ''; this.filterReadiness = ''; this.filterDev = ''; this.page = 0; this.applyFilters(); }
  get hasFilters(): boolean { return !!(this.filterText || this.filterStatus || this.filterReadiness || this.filterDev); }

  private buildReleaseOptions(): void {
    const currentYear = new Date().getFullYear();
    const yearOf = (r: Release): number => {
      if (r.releaseDate) { const y = new Date(r.releaseDate).getFullYear(); if (!isNaN(y)) return y; }
      const m = r.name.match(/(20\d{2})/); // e.g. STS-2026-R6
      return m ? parseInt(m[1], 10) : 0;
    };
    // Hide archived: only show current year and future (drop older years).
    const visible = this.releases.filter(r => {
      const y = yearOf(r);
      return y === 0 || y >= currentYear;
    });
    // Sort: active (unreleased) first, then by year (current year first), then name.
    visible.sort((a, b) => {
      if (a.released !== b.released) return a.released ? 1 : -1;     // active first
      const ya = yearOf(a), yb = yearOf(b);
      if (ya !== yb) return yb - ya;                                  // newer year first
      return b.name.localeCompare(a.name);
    });
    this.releaseOptions = visible.map(r => ({
      value: r.name, label: r.name,
      tag: r.released ? 'Released' : 'Active', tagLive: !r.released,
    }));
  }

  private buildDevLegend(): void {
    const pal = ['#00A36F', '#3E63DD', '#D98E04', '#6E56CF', '#E5484D', '#12A594', '#E93D82', '#5B6472'];
    const d = this.summary?.developerDistribution ?? [];
    this.devLegend = d.map((x, i) => ({ name: x.developer, count: x.subjectCount, color: pal[i % pal.length] }));
  }

  nextPage(): void { if (this.page + 1 < this.totalPages) { this.page++; } }
  prevPage(): void { if (this.page > 0) { this.page--; } }
  goPage(p: number): void { this.page = p; }
  get totalPages(): number { return Math.max(1, Math.ceil(this.filtered.length / this.size)); }
  get pageNumbers(): number[] { return Array.from({ length: this.totalPages }, (_, i) => i); }
  get selRelease(): Release | undefined { return this.releases.find(r => r.name === this.selected); }

  sendMail(s: Subject): void {
    this.sendingKey = s.key;
    this.api.sendMail(this.selected, s.key).subscribe(r => { this.sendingKey = ''; this.flash('Email queued for ' + s.developerName + ' + reporter'); });
  }
  mailAll(): void { this.mailingAll = true; this.api.mailAll(this.selected).subscribe({ next: r => { this.mailingAll = false; this.flash('Queued ' + r.sent + ' email(s) to developers with gaps'); }, error: () => { this.mailingAll = false; this.flash('Failed to send — check backend logs'); } }); }
  mailSummary(): void { this.mailingSummary = true; this.api.mailSummary(this.selected).subscribe({ next: r => { this.mailingSummary = false; this.flash(r.status || 'Summary email sent'); }, error: () => { this.mailingSummary = false; this.flash('Failed to send summary — check backend logs'); } }); }

  missingLabels(s: Subject): string[] { return s.readiness.missing.map(m => this.artifactLabels[m] ?? m); }
  gapLabel(key: string): string { return this.artifactLabels[key] ?? key; }
  statusClass(st: string): string {
    return st === 'ACTIVE' ? 's-active' : st === 'DUE_SOON' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : 's-active';
  }
  gradeClass(g?: string): string { return g === 'EXCELLENT' ? 'g-ex' : g === 'GOOD' ? 'g-gd' : g === 'AT_RISK' ? 'g-rk' : g === 'CRITICAL' ? 'g-cr' : 'g-gd'; }
  objectKeys(o: Record<string, string> | undefined | null): string[] { return o ? Object.keys(o) : []; }
  isMissing(s: Subject, key: string): boolean { return !!s.readiness?.missing?.includes(key); }
  whyOpen: Record<string, boolean> = {};
  toggleWhy(key: string): void { this.whyOpen[key] = !this.whyOpen[key]; }
  spOpen: Record<string, boolean> = {};
  toggleSp(key: string): void { this.spOpen[key] = !this.spOpen[key]; }
  // True if the subject has a yellow Octane needs-attention flag.
  hasNeedsAttention(s: Subject): boolean {
    return (s.readiness?.octaneMissingEnvs || []).some(e => (e || '').toLowerCase().includes('needs attention'));
  }
  // Per-subject refresh: re-check just one subject and update its row.
  refreshingKey = '';
  refreshSubject(s: Subject): void {
    this.refreshingKey = s.key;
    // Collapse any expanded evidence panels for this subject while it refreshes.
    this.whyOpen[s.key] = false;
    this.spOpen[s.key] = false;
    this.api.refreshSubject(this.selected, s.key).subscribe({
      next: fresh => {
        if (fresh) {
          const upd = (list: Subject[]) => { const i = list.findIndex(x => x.key === fresh.key); if (i >= 0) list[i] = fresh; };
          upd(this.allSubjects);
          this.applyFilters();
        }
        this.refreshingKey = '';
        this.flash('Refreshed ' + s.key);
      },
      error: () => { this.refreshingKey = ''; this.flash('Refresh failed for ' + s.key); },
    });
  }
  detailClass(d: string): string {
    const t = (d || '').toLowerCase();
    // The explanation line mentions multiple states — keep it neutral.
    if (t.startsWith('latest run per test overrides')) return 'd-note';
    // Overall + per-test lines: colour by the status word at the end.
    if (t.includes('— failed') || t.endsWith('failed') || t.includes(': failed') || t.includes('result: failed')) return 'd-fail';
    if (t.includes('needs attention') || t.includes('release not tagged')) return 'd-warn';
    if (t.includes('— passed') || t.includes('result: passed') || t.includes(': passed')) return 'd-ok';
    if (t.includes('no test') || t.includes('never run') || (t.includes('no run') && !t.includes('needs attention'))) return 'd-fail';
    return '';
  }
  detailText(d: string): string { return (d || '').split(' ||')[0]; }
  detailLink(d: string): string | null { const p = (d || '').split(' ||'); return p.length > 1 ? p[1] : null; }
  // Octane status dot: red if any failure/missing test, yellow if needs-attention
  // (and nothing worse), green if all clear.
  octaneDot(s: Subject): string {
    const envs = (s.readiness.octaneMissingEnvs || []).map(e => e.toLowerCase());
    // Release-tag issues carry "needs attention" and are yellow, not red.
    const hasFail = envs.some(e => (e.includes('failed') || e.includes('no test')
      || e.includes('never run') || e.includes('cannot verify')
      || (e.includes('not run') && !e.includes('needs attention')))
      && !e.includes('release not tagged') && !e.includes('needs attention'));
    if (hasFail || !s.readiness.octaneTestsLinked) return 'n';   // red
    const hasAttention = envs.some(e => e.includes('needs attention'));
    if (hasAttention) return 'w';                                // yellow
    return 'y';                                                   // green
  }

  savingCp = false;
  // Milestones editable in Config, including the Release cutoff date.
  milestones: { key: string; label: string; date: string; overridden: boolean; status: string }[] = [];
  private recomputeMilestones(): void {
    const tl = this.checkpoints?.timeline ?? [];
    // RELEASE is read-only (from Jira); DOC_CUTOFF is the editable document deadline.
    this.milestones = tl.filter(m => m.key !== 'RELEASE').map(m => ({
      key: m.key,
      label: m.key === 'DOC_CUTOFF' ? 'Document cutoff' : m.label,
      date: (m.date ?? '').substring(0, 10),
      overridden: !!m.overridden,
      status: m.status ?? '',
    }));
    this.rebuildEnvLinkDefs();
  }
  // Extra PPD stages currently on the timeline (PPD3, PPD4, …).
  get extraPpdKeys(): string[] {
    return this.milestones.filter(m => /^PPD[3-9]$/.test(m.key)).map(m => m.key);
  }
  // Add the next PPD stage (PPD-3, then PPD-4, …). Defaults its date to the day
  // after PPD-2 (or the last extra PPD), then the user can adjust it.
  addPpdStage(): void {
    const existing = new Set(this.extraPpdKeys);
    let n = 3;
    while (existing.has('PPD' + n) && n < 9) n++;
    if (n > 8) { this.flash('Maximum PPD stages reached'); return; }
    // Seed a date: day after the latest PPD currently on the timeline.
    const ppdDates = this.milestones
      .filter(m => /^PPD\d$/.test(m.key) && m.date)
      .map(m => new Date(m.date));
    let seed = ppdDates.length ? new Date(Math.max(...ppdDates.map(d => d.getTime()))) : new Date();
    seed.setDate(seed.getDate() + 1);
    const iso = seed.toISOString().substring(0, 10);
    this.onCheckpointDate('PPD' + n, iso);
  }
  removePpdStage(key: string): void {
    // Clearing the date removes the override, which removes the stage.
    this.onCheckpointDate(key, '');
  }
  isExtraPpd(key: string): boolean { return /^PPD[3-9]$/.test(key); }
  // Timeline nodes to render. When extra PPD stages are present, the PPD-1 rollback
  // node is dropped to save horizontal space (it's still editable in Config).
  get displayTimeline(): Milestone[] {
    const tl = this.checkpoints?.timeline ?? [];
    const hasExtraPpd = tl.some(m => this.isExtraPpd(m.key));
    return hasExtraPpd ? tl.filter(m => m.key !== 'PPD1_ROLLBACK') : tl;
  }
  // Manual environment links (PPD-1, PPD-2, Prod ServiceNow). Each has an optional
  // label (e.g. a ServiceNow change number) and a URL.
  envLinks: Record<string, {label: string; url: string}> = {};
  // Which timeline stage each env link maps to (for inline display).
  // The Prod ServiceNow change belongs to the production release, so it shows
  // under the RELEASE node — not PPD-1.
  envLinkStage: Record<string, string> = { PPD1: 'PPD1', PPD2: 'PPD2', PROD_SERVICENOW: 'RELEASE' };
  envLinkDefs: { key: string; label: string }[] = [
    { key: 'PPD1', label: 'PPD-1 environment' },
    { key: 'PPD2', label: 'PPD-2 environment' },
    { key: 'PROD_SERVICENOW', label: 'Prod ServiceNow change' },
  ];
  // Rebuild env-link inputs so each extra PPD stage gets its own link slot, mapped
  // to its own timeline node.
  private rebuildEnvLinkDefs(): void {
    const defs: { key: string; label: string }[] = [
      { key: 'PPD1', label: 'PPD-1 environment' },
      { key: 'PPD2', label: 'PPD-2 environment' },
    ];
    for (const k of this.extraPpdKeys) {
      const n = k.replace('PPD', '');
      defs.push({ key: k, label: 'PPD-' + n + ' environment' });
      this.envLinkStage[k] = k;   // maps to its own node
    }
    defs.push({ key: 'PROD_SERVICENOW', label: 'Prod ServiceNow change' });
    this.envLinkDefs = defs;
    this.recomputeStageLinks();
  }
  savingLink = '';
  loadEnvLinks(): void {
    if (!this.selected) return;
    this.api.getEnvLinks(this.selected).subscribe({ next: m => { this.envLinks = m || {}; this.recomputeStageLinks(); }, error: () => {} });
    this.api.getStatusOverrides(this.selected).subscribe({ next: m => this.statusOverrides = m || {}, error: () => {} });
    // Auto-fetch ServiceNow changes (grouped by env) + linked incidents/problems.
    this.api.getReleaseChanges(this.selected).subscribe({
      next: c => {
        this.releaseChanges = c;
        this.rebuildChangeGroups();
        this.recomputeStageLinks();
        this.applyServiceNowDates();
      },
      error: () => { this.releaseChanges = undefined; this.changeGroups = []; },
    });
  }
  releaseChanges?: ReleaseChanges;

  // ---- ServiceNow change groups (PPD-1 / PPD-2 / PROD) with min/max ----
  changeGroups: { key: string; label: string; changes: ServiceNowTicket[] }[] = [];
  changeGroupOpen: Record<string, boolean> = { PPD1: true, PPD2: true, PROD: true };
  private rebuildChangeGroups(): void {
    const rc = this.releaseChanges;
    if (!rc) { this.changeGroups = []; return; }
    this.changeGroups = [
      { key: 'PPD1', label: 'PPD-1', changes: rc.ppd1 || [] },
      { key: 'PPD2', label: 'PPD-2', changes: rc.ppd2 || [] },
      { key: 'PROD', label: 'PROD', changes: rc.prod || [] },
    ];
  }
  toggleChangeGroup(key: string): void { this.changeGroupOpen[key] = !this.changeGroupOpen[key]; }
  snowStateClass(state: string): string {
    const s = (state || '').toLowerCase();
    if (s.includes('clos') || s.includes('complete') || s.includes('review')) return 'st-done';
    if (s.includes('implement') || s.includes('progress')) return 'st-active';
    if (s.includes('cancel') || s.includes('fail')) return 'st-bad';
    return 'st-new';
  }

  /**
   * Apply real ServiceNow change dates to the timeline. A ServiceNow date always
   * overrides the calculated one. PPD-1 change -> PPD1 node, PPD-2 -> PPD2 node,
   * PROD -> RELEASE node. The PPD-1 rollback CTASK date -> PPD1_ROLLBACK node.
   */
  private applyServiceNowDates(): void {
    const rc = this.releaseChanges;
    if (!rc || !this.checkpoints?.timeline) return;
    const ymd = (s?: string) => (s || '').substring(0, 10) || null;
    const firstDate = (arr?: ServiceNowTicket[]) => arr && arr.length ? ymd(arr[0].startDate) : null;
    const overrides: Record<string, string | null> = {
      PPD1: firstDate(rc.ppd1),
      PPD2: firstDate(rc.ppd2),
      RELEASE: firstDate(rc.prod),
    };
    // PPD-1 rollback: use the rollback CTASK's planned start on the PPD-1 change.
    const ppd1 = rc.ppd1 && rc.ppd1[0];
    const rb = ppd1?.ctasks?.find(t => t.rollback);
    if (rb) overrides['PPD1_ROLLBACK'] = ymd(rb.plannedStart);

    let changed = false;
    const tl = this.checkpoints.timeline.map(m => {
      const ov = overrides[m.key];
      if (ov && ov !== (m.date || '').substring(0, 10)) {
        changed = true;
        return { ...m, date: ov, overridden: true };
      }
      return m;
    });
    if (changed) {
      this.checkpoints = { ...this.checkpoints, timeline: tl };
      this.recomputeMilestones();
    }
  }
  // Incidents/problems are shown once the release has gone to Prod.
  get showPostRelease(): boolean {
    return !!this.releaseChanges && (this.checkpoints?.daysToRelease ?? 1) < 0
      && ((this.releaseChanges.incidents?.length || 0) + (this.releaseChanges.problems?.length || 0) > 0);
  }
  hasEnvLinks(): boolean { return Object.keys(this.envLinks || {}).length > 0; }
  onEnvLink(key: string, label: string, url: string): void {
    this.savingLink = key;
    this.api.setEnvLink(this.selected, key, label, url).subscribe({
      next: m => { this.envLinks = m || {}; this.recomputeStageLinks(); this.savingLink = ''; this.flash('Link saved'); },
      error: () => { this.savingLink = ''; this.flash('Failed to save link'); },
    });
  }
  // Env links attached to a given timeline stage (for inline rendering).
  // Precomputed into stageLinks whenever envLinks changes, so the template does
  // not call a method returning a new array on every change-detection cycle
  // (which caused the dashboard to freeze).
  stageLinks: Record<string, { key: string; label: string; url: string }[]> = {};
  private recomputeStageLinks(): void {
    const out: Record<string, { key: string; label: string; url: string }[]> = {};
    // 1) Auto changes from ServiceNow, grouped by env, under their stage node.
    const rc = this.releaseChanges;
    if (rc) {
      const add = (stage: string, tickets: ServiceNowTicket[] | undefined) => {
        for (const t of tickets || []) {
          (out[stage] = out[stage] || []).push({ key: t.number, label: t.number, url: t.url });
        }
      };
      add('PPD1', rc.ppd1);
      add('PPD2', rc.ppd2);
      add('RELEASE', rc.prod);   // Prod changes under the Release node
    }
    // 2) Manual env-links (both — manual entries are additive to the auto ones).
    for (const d of this.envLinkDefs) {
      const stage = this.envLinkStage[d.key];
      const link = this.envLinks[d.key];
      if (stage && link && link.url) {
        (out[stage] = out[stage] || []).push({ key: d.key, label: link.label || d.label, url: link.url });
      }
    }
    this.stageLinks = out;
  }
  linksForStage(stageKey: string): { key: string; label: string; url: string }[] {
    return this.stageLinks[stageKey] || [];
  }

  // Manual timeline status override (Done / In Progress / Overdue / Scheduled).
  statusOptions: DropdownOption[] = [
    { value: '', label: 'Auto (from dates)' },
    { value: 'DONE', label: 'Done' },
    { value: 'ACTIVE', label: 'In Progress' },
    { value: 'OVERDUE', label: 'Overdue' },
    { value: 'UPCOMING', label: 'Scheduled' },
  ];
  statusOverrides: Record<string, string> = {};
  onStatusOverride(stageKey: string, status: string): void {
    this.api.setStatusOverride(this.selected, stageKey, status).subscribe({
      next: r => {
        this.statusOverrides = r.overrides || {};
        if (r.checkpoints && (r.checkpoints as any).timeline) { this.checkpoints = r.checkpoints; this.recomputeMilestones(); }
        this.flash('Status updated');
      },
      error: () => this.flash('Failed to update status'),
    });
  }

  onCheckpointDate(stage: string, date: string): void {
    this.savingCp = true;
    this.api.setCheckpoint(this.selected, stage, date || null).subscribe({
      next: cp => { this.checkpoints = cp; this.savingCp = false; this.recomputeMilestones(); this.flash("Milestone date updated"); },
      error: () => { this.savingCp = false; this.flash('Failed to update date'); },
    });
  }
  resetCheckpoints(): void {
    this.savingCp = true;
    this.api.resetCheckpoints(this.selected).subscribe({
      next: cp => { this.checkpoints = cp; this.savingCp = false; this.recomputeMilestones(); this.flash("Milestone dates reset to Jira"); },
      error: () => { this.savingCp = false; this.flash('Failed to reset dates'); },
    });
  }
  barClass(score?: number): string { const s = score ?? 0; return s >= 80 ? 'bar-ok' : s >= 50 ? 'bar-warn' : 'bar-bad'; }
  // Classifies an Octane missing-env label for coloring: failed/never-run are the
  // strongest (fail), wrong-release amber, no-test default red.
  envSeverity(env: string): string {
    const e = (env || '').toLowerCase();
    if (e.includes('failed') || e.includes('never run')) return 'gap-fail';
    if (e.includes('needs attention') || e.includes('wrong release')) return 'gap-warn';
    return '';
  }
  msClass(st: string): string { return st === 'ACTIVE' ? 's-active' : st === 'DUE_SOON' ? 's-warn' : st === 'OVERDUE' ? 's-bad' : st === 'DONE' ? 's-done' : 's-up'; }
  msTag(st: string): string { return st === 'ACTIVE' ? 'today' : st === 'DUE_SOON' ? 'soon' : st === 'OVERDUE' ? 'overdue' : st === 'DONE' ? 'done' : 'upcoming'; }
  gradeLabel(g?: string): string { return g === 'EXCELLENT' ? 'Excellent' : g === 'GOOD' ? 'Good' : g === 'AT_RISK' ? 'At risk' : g === 'CRITICAL' ? 'Critical' : '—'; }

  sysDot(st: string): string { return st === 'UP' ? 'dot-ok' : st === 'DOWN' ? 'dot-bad' : st === 'DEGRADED' ? 'dot-warn' : st === 'NOT_CONFIGURED' ? 'dot-mock' : 'dot-info'; }
  sysLabel(st: string): string { return st === 'UP' ? 'Live' : st === 'DOWN' ? 'Down' : st === 'DEGRADED' ? 'Degraded' : st === 'NOT_CONFIGURED' ? 'Off' : 'Mock'; }
  sysBadgeStyle(st: string): any {
    const map: any = { UP: ['var(--ok-dim)', 'var(--ok)'], DOWN: ['var(--bad-dim)', 'var(--bad)'], DEGRADED: ['var(--warn-dim)', 'var(--warn)'], MOCK: ['var(--info-dim)', 'var(--info)'], NOT_CONFIGURED: ['var(--chip)', 'var(--muted)'] };
    const c = map[st] || map['MOCK']; return { background: c[0], color: c[1] };
  }

  readyPct(): number { return this.summary && this.summary.totalSubjects ? Math.round(this.summary.ready / this.summary.totalSubjects * 100) : 0; }

  // ---- config editing ----
  cfgFor(key: string): SubjectCheckConfig {
    return this.checks?.overrides[key] ?? this.checks?.default ?? { octaneEnvironments: ENVS, bcmEndToEnd: false, skipSharePoint: [], note: '' };  }
  // Check config lists ALL subjects of the selected release (from Jira). The
  // JSON (checks.overrides) only customises specific subjects; subjects without
  // an override use the default config.
  booting = true;
  spConfig: any = null;
  allSubjects: Subject[] = [];
  cfgLoading = false;
  // background scan status
  scanState: { scanning: boolean; lastChecked: string | null; nextCheck: string | null; subjectCount: number } | null = null;
  private scanTimer: any = null;

  jiraBase = (typeof window !== 'undefined' && (window as any).__cockpit?.jiraBaseUrl) || 'https://jira.group.echonet';
  jiraUrl(key: string): string { return `${this.jiraBase}/browse/${key}`; }

  // Builds the absolute SharePoint folder URL where a given artifact's document
  // should be created, with {YEAR} filled from the selected release.
  sharePointUrl(artifactKey: string): string | null {
    const cfg = this.spConfig;
    if (!cfg || !cfg.sharePointBaseUrl) return null;
    const art = cfg.sharePointArtifacts?.[artifactKey];
    if (!art || !art.folder) return null;
    const year = this.yearOfSelected();
    const folder = String(art.folder).replace(/\{YEAR\}/g, String(year));
    // base-url already includes /sites/<site>; the library is a doc-lib path segment.
    const lib = cfg.sharePointLibrary ? '/' + encodeURI(cfg.sharePointLibrary) : '';
    return `${cfg.sharePointBaseUrl}${lib}${encodeURI(folder)}`;
  }
  private yearOfSelected(): number {
    const r = this.releases.find(x => x.name === this.selected);
    if (r?.releaseDate) { const y = new Date(r.releaseDate).getFullYear(); if (!isNaN(y)) return y; }
    const m = (this.selected || '').match(/(20\d{2})/);
    return m ? parseInt(m[1], 10) : new Date().getFullYear();
  }
  // Map a gap key to the artifact key used in config for the SharePoint link.
  gapArtifactKey(gap: string): string { return gap; }

  pollScanStatus(): void {
    if (this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; }
    let firstPoll = true;
    const refreshAll = () => {
      this.loadSubjects();
      this.loadingCharts = true; this.loadingHealth = true;
      this.api.getSummary(this.selected).subscribe(s => { this.summary = s; this.buildDevLegend(); this.chartsDirty = true; this.loadingCharts = false; });
      this.api.getHealth(this.selected).subscribe(h => { this.health = h; this.loadingHealth = false; });
    };
    const tick = () => {
      if (!this.selected) return;
      this.api.getScanStatus(this.selected).subscribe(st => {
        const wasScanning = this.scanState?.scanning;
        this.scanState = st;
        // Refresh when a scan finishes, OR when the very first poll already shows
        // a completed scan with data (scan finished before we started polling).
        if ((wasScanning && !st.scanning) ||
            (firstPoll && !st.scanning && (st.subjectCount ?? 0) > 0 && !this.summary)) {
          refreshAll();
        }
        firstPoll = false;
        if (!st.scanning && this.scanTimer) { clearInterval(this.scanTimer); this.scanTimer = null; }
      });
    };
    tick();
    this.scanTimer = setInterval(tick, 4000);
  }
  cfgKeys: string[] = [];
  // Accurate count for the Check config badge: full list once loaded, else the
  // release's total subject count from the summary (so it's right on first load).
  get cfgCount(): number {
    if (this.cfgKeys.length) return this.cfgKeys.length;
    if (this.summary?.totalSubjects) return this.summary.totalSubjects;
    return 0;
  }
  private recomputeCfgKeys(): void {
    // Prefer the full subject list (loaded when the config tab opens). Before that
    // is available, fall back to the current subjects page so the count is still
    // populated on first load / release change.
    let subjectKeys = this.allSubjects.map(s => s.key);
    if (subjectKeys.length) {
      const extra = this.checks ? Object.keys(this.checks.overrides).filter(k => !subjectKeys.includes(k)) : [];
      this.cfgKeys = [...subjectKeys, ...extra];
    } else {
      this.cfgKeys = this.checks ? Object.keys(this.checks.overrides) : [];
    }
  }

  toggleEnv(key: string, env: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.octaneEnvironments = cfg.octaneEnvironments.includes(env) ? cfg.octaneEnvironments.filter(e => e !== env) : [...cfg.octaneEnvironments, env];
    this.saveCfg(key, cfg);
  }
  toggleBcm(key: string): void { const cfg = { ...this.cfgFor(key) }; cfg.bcmEndToEnd = !cfg.bcmEndToEnd; this.saveCfg(key, cfg); }
  toggleSkip(key: string, item: string): void {
    const cfg = { ...this.cfgFor(key) };
    cfg.skipSharePoint = cfg.skipSharePoint.includes(item) ? cfg.skipSharePoint.filter(s => s !== item) : [...cfg.skipSharePoint, item];
    this.saveCfg(key, cfg);
  }
  private saveCfg(key: string, cfg: SubjectCheckConfig): void {
    if (this.checks) this.checks.overrides[key] = cfg;
    this.api.putCheck(key, cfg, this.selected).subscribe(() => this.flash('Saved check config for ' + key));
  }

  private flash(m: string): void { this.toast = m; setTimeout(() => { if (this.toast === m) this.toast = ''; }, 3000); }

  private renderCharts(): void {
    if (!this.summary) return;
    const text = this.theme === 'dark' ? '#8A93A4' : '#6A7488';
    const grid = this.theme === 'dark' ? 'rgba(255,255,255,.06)' : 'rgba(17,24,39,.06)';
    const pal = ['#00A36F', '#3E63DD', '#D98E04', '#6E56CF', '#E5484D', '#12A594', '#E93D82', '#5B6472'];
    if (this.devChartRef) {
      this.devChart?.destroy();
      const d = this.summary.developerDistribution;
      const colors = d.map((_, i) => pal[i % pal.length]);
      this.devChart = new Chart(this.devChartRef.nativeElement, {
        type: 'doughnut',
        data: { labels: d.map(x => x.developer), datasets: [{ data: d.map(x => x.subjectCount), backgroundColor: colors, borderWidth: 0, hoverOffset: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '66%',
          plugins: {
            legend: { display: false },
            tooltip: { callbacks: { label: (ctx: any) => ` ${ctx.label}: ${ctx.parsed}` } }
          } },
      });
    }
    if (this.readyChartRef) {
      this.readyChart?.destroy();
      const b = this.summary.readinessBreakdown;
      this.readyChart = new Chart(this.readyChartRef.nativeElement, {
        type: 'bar',
        data: { labels: ['Octane', 'SharePoint'], datasets: [
          { label: 'Ready', data: [b.octaneOk, b.sharepointOk], backgroundColor: '#00A36F', borderRadius: 5, barPercentage: 0.55 },
          { label: 'Missing', data: [b.octaneMissing, b.sharepointMissing], backgroundColor: '#E5484D', borderRadius: 5, barPercentage: 0.55 } ] },
        options: { responsive: true, maintainAspectRatio: false,
          scales: { x: { stacked: true, grid: { display: false }, ticks: { color: text, font: { size: 11 } } },
                    y: { stacked: true, beginAtZero: true, grid: { color: grid }, ticks: { color: text, font: { size: 10 } } } },
          plugins: { legend: { position: 'bottom', labels: { boxWidth: 9, boxHeight: 9, font: { size: 11 }, color: text, usePointStyle: true, pointStyle: 'circle' } } } },
      });
    }
  }
}
