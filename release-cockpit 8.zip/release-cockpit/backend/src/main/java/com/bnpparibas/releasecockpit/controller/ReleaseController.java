package com.bnpparibas.releasecockpit.controller;

import com.bnpparibas.releasecockpit.model.Domain.*;
import com.bnpparibas.releasecockpit.service.HealthService;
import com.bnpparibas.releasecockpit.service.MailService;
import com.bnpparibas.releasecockpit.service.ReleaseService;
import com.bnpparibas.releasecockpit.service.ReleaseService.Page;
import com.bnpparibas.releasecockpit.service.StatusService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * The dashboard API.
 *
 *   GET  /api/releases                          -> dropdown options
 *   GET  /api/releases/{name}/checkpoints       -> PPD / end-UAT dates + status
 *   GET  /api/releases/{name}/summary           -> pie-chart aggregates
 *   GET  /api/releases/{name}/subjects?page&size-> paginated subjects
 *   POST /api/releases/{name}/refresh           -> clear cache (manual refresh)
 *   POST /api/releases/{name}/subjects/{key}/mail -> email one developer
 *   POST /api/releases/{name}/mail-all          -> email all not-ready devs
 */
@RestController
@RequestMapping("/api/releases")
public class ReleaseController {

    private final ReleaseService releaseService;
    private final MailService mailService;
    private final HealthService healthService;
    private final StatusService statusService;
    private final com.bnpparibas.releasecockpit.service.ServiceNowService serviceNowService;
    private final com.bnpparibas.releasecockpit.service.EnvLinkService envLinkService;
    private final com.bnpparibas.releasecockpit.service.StatusOverrideService statusOverrideService;

    public ReleaseController(ReleaseService releaseService, MailService mailService,
                             HealthService healthService, StatusService statusService,
                             com.bnpparibas.releasecockpit.service.ServiceNowService serviceNowService,
                             com.bnpparibas.releasecockpit.service.EnvLinkService envLinkService,
                             com.bnpparibas.releasecockpit.service.StatusOverrideService statusOverrideService) {
        this.releaseService = releaseService;
        this.mailService = mailService;
        this.healthService = healthService;
        this.statusService = statusService;
        this.serviceNowService = serviceNowService;
        this.envLinkService = envLinkService;
        this.statusOverrideService = statusOverrideService;
    }

    @GetMapping("/{name}/env-links")
    public Map<String, Map<String, String>> envLinks(@PathVariable String name) {
        return envLinkService.forRelease(name);
    }

    @PutMapping("/{name}/env-links/{envKey}")
    public Map<String, Map<String, String>> setEnvLink(@PathVariable String name, @PathVariable String envKey,
                                          @RequestBody Map<String, String> body) {
        return envLinkService.set(name, envKey, body.get("label"), body.get("url"));
    }

    @GetMapping("/{name}/status-overrides")
    public Map<String, String> statusOverrides(@PathVariable String name) {
        return statusOverrideService.forRelease(name);
    }

    @PutMapping("/{name}/status-overrides/{stageKey}")
    public java.util.Map<String, Object> setStatusOverride(@PathVariable String name, @PathVariable String stageKey,
                                                           @RequestBody Map<String, String> body) {
        statusOverrideService.set(name, stageKey, body.get("status"));
        // Return the recomputed checkpoints so the UI updates the timeline at once.
        return java.util.Map.of("overrides", statusOverrideService.forRelease(name),
                "checkpoints", releaseService.getCheckpoints(name));
    }

    @GetMapping
    public List<Release> releases() {
        return releaseService.getReleases();
    }

    @GetMapping("/{name}/checkpoints")
    public Checkpoints checkpoints(@PathVariable String name) {
        return releaseService.getCheckpoints(name);
    }

    /** Override a single milestone date (stage: END_UAT|PPD1|PPD1_ROLLBACK|PPD2|LCAB). */
    @org.springframework.web.bind.annotation.PutMapping("/{name}/checkpoints/{stage}")
    public Checkpoints setCheckpoint(@PathVariable String name, @PathVariable String stage,
                                     @org.springframework.web.bind.annotation.RequestBody java.util.Map<String, String> body) {
        String dateStr = body == null ? null : body.get("date");
        java.time.LocalDate date = (dateStr == null || dateStr.isBlank()) ? null : java.time.LocalDate.parse(dateStr);
        return releaseService.setCheckpointOverride(name, stage.toUpperCase(), date);
    }

    /** Reset all milestone overrides for a release back to Jira-derived dates. */
    @org.springframework.web.bind.annotation.DeleteMapping("/{name}/checkpoints")
    public Checkpoints resetCheckpoints(@PathVariable String name) {
        return releaseService.resetCheckpointOverrides(name);
    }

    @GetMapping("/{name}/summary")
    public ReleaseSummary summary(@PathVariable String name) {
        return releaseService.getSummary(name);
    }

    @GetMapping("/{name}/health")
    public ReleaseHealth health(@PathVariable String name) {
        return healthService.compute(releaseService.getSummary(name),
                releaseService.getCheckpoints(name));
    }

    @GetMapping("/{name}/subjects")
    public Page<Subject> subjects(@PathVariable String name,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "20") int size) {
        return releaseService.getSubjectsPage(name, page, size);
    }

    @GetMapping("/{name}/scan-status")
    public Map<String, Object> scanStatus(@PathVariable String name) {
        var st = releaseService.getScanState(name);
        Map<String, Object> m = new java.util.HashMap<>();
        m.put("scanning", st.scanning());
        m.put("lastChecked", st.lastChecked() == null ? null : st.lastChecked().toString());
        m.put("nextCheck", st.nextCheck() == null ? null : st.nextCheck().toString());
        m.put("subjectCount", st.subjects().size());
        return m;
    }

    @PostMapping("/{name}/refresh")
    public ResponseEntity<Map<String, Object>> refresh(@PathVariable String name) {
        releaseService.refreshAll();
        releaseService.refreshRelease(name);
        return ResponseEntity.ok(Map.of("refreshed", true, "release", name));
    }

    /**
     * Re-check a single subject. The connector scans per release, so this triggers
     * a background re-scan of the release and returns the subject's freshest data
     * from the cache. The UI updates just that one row.
     */
    @PostMapping("/{name}/subjects/{key:.+}/refresh")
    public ResponseEntity<Subject> refreshSubject(@PathVariable String name, @PathVariable String key) {
        Subject s = releaseService.refreshOneSubject(name, key);
        return s == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(s);
    }

    @PostMapping("/{name}/subjects/{key:.+}/mail")
    public ResponseEntity<Map<String, Object>> mailOne(@PathVariable String name,
                                                       @PathVariable String key) {
        Subject subject = releaseService.getSubject(name, key);
        if (subject == null) {
            // Cache may be cold (no scan yet) — do a synchronous single-subject fetch.
            subject = releaseService.refreshOneSubject(name, key);
        }
        if (subject == null) {
            return ResponseEntity.notFound().build();
        }
        String status = mailService.sendSubjectAlert(name, subject, releaseService.getCheckpoints(name));
        return ResponseEntity.ok(Map.of("status", status, "key", key));
    }

    @PostMapping("/{name}/mail-all")
    public ResponseEntity<Map<String, Object>> mailAll(@PathVariable String name) {
        int sent = mailService.sendAllAlerts(name, releaseService.getAllSubjects(name),
                releaseService.getCheckpoints(name));
        return ResponseEntity.ok(Map.of("sent", sent, "release", name));
    }

    @PostMapping("/{name}/mail-summary")
    public ResponseEntity<Map<String, Object>> mailSummary(@PathVariable String name) {
        ReleaseSummary sum = releaseService.getSummary(name);
        ReleaseHealth h = healthService.compute(sum, releaseService.getCheckpoints(name));
        String status = mailService.sendReleaseSummary(name, sum, h,
                releaseService.getCheckpoints(name), releaseService.getAllSubjects(name));
        return ResponseEntity.ok(Map.of("status", status, "release", name));
    }

    @GetMapping("/{name}/servicenow")
    public List<ServiceNowTicket> servicenowTickets(@PathVariable String name) {
        // Flatten the grouped release-changes (the correct gateway data) into a
        // single list. The old ticketsForRelease() used the legacy Table API and
        // returned wrong/empty results, so we no longer use it here.
        var rc = serviceNowService.changesForRelease(name);
        List<ServiceNowTicket> all = new java.util.ArrayList<>();
        all.addAll(rc.ppd1());
        all.addAll(rc.ppd2());
        all.addAll(rc.prod());
        return all;
    }

    /** Changes grouped by env (PPD-1/PPD-2/Prod) + linked incidents/problems. */
    @GetMapping("/{name}/servicenow/changes")
    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges servicenowChanges(@PathVariable String name) {
        return serviceNowService.changesForRelease(name);
    }

    /** Fetch a single ServiceNow change by number (e.g. CHG0045821). */
    @GetMapping("/servicenow/changes/{changeNumber}")
    public ResponseEntity<String> serviceNowChange(@PathVariable String changeNumber) {
        return ResponseEntity.ok(serviceNowService.getChangeDetails(changeNumber));
    }
}
