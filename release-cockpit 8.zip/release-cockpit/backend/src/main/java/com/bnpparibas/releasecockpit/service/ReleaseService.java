package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.connector.ReleaseDataConnector;
import com.bnpparibas.releasecockpit.model.Domain.*;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Central service. Aggregates connector data into the shapes the dashboard
 * needs: paginated subjects, pie-chart summaries, and per-release checkpoints.
 *
 * Hybrid caching: results are cached (see CacheConfig) and served instantly;
 * the UI's "Refresh" button calls evict* to force a re-fetch.
 */
@Service
public class ReleaseService {

    private final ReleaseDataConnector connector;
    private final CheckpointService checkpointService;
    private final CheckpointOverrideService overrideService;

    public ReleaseService(ReleaseDataConnector connector, CheckpointService checkpointService,
                          CheckpointOverrideService overrideService) {
        this.connector = connector;
        this.checkpointService = checkpointService;
        this.overrideService = overrideService;
    }

    @Cacheable("releases")
    public List<Release> getReleases() {
        // Null-safe: some Jira versions have no release date — sort those last.
        return connector.listReleases().stream()
                .sorted(Comparator.comparing(Release::releaseDate,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());
    }

    public Release getRelease(String releaseName) {
        return getReleases().stream()
                .filter(r -> r.name().equals(releaseName))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Release not found: " + releaseName));
    }

    public Checkpoints getCheckpoints(String releaseName) {
        return checkpointService.compute(getRelease(releaseName).releaseDate(),
                overrideService.forRelease(releaseName));
    }

    @Cacheable("subjects")
    public List<Subject> getAllSubjects(String releaseName) {
        return connector.listSubjects(releaseName);
    }

    /** Paginated slice of subjects (page is 0-based). */
    public Page<Subject> getSubjectsPage(String releaseName, int page, int size) {
        List<Subject> all = getAllSubjects(releaseName);
        int from = Math.max(0, page * size);
        int to = Math.min(all.size(), from + size);
        List<Subject> slice = from >= all.size() ? List.of() : all.subList(from, to);
        return new Page<>(slice, page, size, all.size());
    }

    /** Aggregates the data the pie charts need. */
    public ReleaseSummary getSummary(String releaseName) {
        List<Subject> all = getAllSubjects(releaseName);
        int ready = (int) all.stream().filter(s -> s.readiness().missingCount() == 0).count();
        int notReady = all.size() - ready;

        Map<String, Long> byDev = all.stream()
                .collect(Collectors.groupingBy(Subject::developerName, Collectors.counting()));
        List<DeveloperLoad> dist = byDev.entrySet().stream()
                .map(e -> new DeveloperLoad(e.getKey(), e.getValue().intValue()))
                .sorted(Comparator.comparingInt(DeveloperLoad::subjectCount).reversed())
                .collect(Collectors.toList());

        int octaneOk = (int) all.stream().filter(s -> s.readiness().octaneTestsLinked()).count();
        int spOk = (int) all.stream().filter(this::sharepointComplete).count();

        ReadinessBreakdown breakdown = new ReadinessBreakdown(
                octaneOk, all.size() - octaneOk,
                spOk, all.size() - spOk
        );

        return new ReleaseSummary(releaseName, all.size(), ready, notReady, dist, breakdown);
    }

    private boolean sharepointComplete(Subject s) {
        Readiness r = s.readiness();
        return r.prDoc() && r.unitTest() && r.estimationSheet()
                && r.prExcel() && r.octaneReviewDoc() && r.octaneExecutionDoc();
    }

    /** Force a refresh: clear caches so next read re-fetches from the source. */
    @CacheEvict(cacheNames = {"releases", "subjects"}, allEntries = true)
    public void refreshAll() {
        // Eviction handled by annotation; nothing else needed.
    }

    /** A minimal page wrapper (avoids dragging in Spring Data). */
    public record Page<T>(List<T> content, int page, int size, int totalElements) {
        public int totalPages() {
            return size == 0 ? 0 : (int) Math.ceil((double) totalElements / size);
        }
    }
}
