package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.Readiness;
import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Live connector — active when cockpit.mock-mode=false.
 *
 * IMPORTANT — graceful degradation:
 * This connector is intentionally fault-tolerant so the application ALWAYS
 * starts and serves the dashboard, even if Jira / Octane / SharePoint are not
 * yet configured or are unreachable. Any failure (missing base URL, auth error,
 * timeout, non-2xx) is logged and yields an EMPTY result rather than throwing.
 * As each system is connected it begins returning real data; until then the
 * dashboard simply shows nothing for that system.
 *
 * The Octane/SharePoint readiness rules from Release Guardian
 * (artifacts.json, folder maps, environment filtering, BCM end-to-end) are the
 * remaining port — see CONNECTORS.md. This class wires the Jira fetch and the
 * structure; the per-artifact checks return "not yet verified" (false) until
 * those are ported, but never crash the app.
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "cockpit.mock-mode", havingValue = "false")
public class LiveConnector implements ReleaseDataConnector {

    private final CockpitProperties props;
    private final HttpClientFactory clients;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;        // direct (Jira — internal network)
    private final HttpClient saas;        // proxied (Octane + SharePoint — SaaS)

    // cached Octane bearer token (re-fetched on demand / on 401)
    private volatile String octaneCookie;

    public LiveConnector(CockpitProperties props, HttpClientFactory clients) {
        this.props = props;
        this.clients = clients;
        this.http = clients.direct();
        this.saas = clients.proxied();
        log.info("LiveConnector active (mock-mode=false). Unconfigured/unreachable "
                + "systems will return empty results so the app still runs.");
    }

    @Override
    public List<Release> listReleases() {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira base-url not configured; returning no releases.");
            return List.of();
        }
        List<Release> out = new ArrayList<>();

        // 1) Explicit release names take priority (no project lookup needed).
        if (!isBlank(j.getReleaseNames())) {
            for (String name : j.getReleaseNames().split(",")) {
                name = name.trim();
                if (!name.isEmpty()) out.add(new Release(name, name, null, false, ""));
            }
            log.info("Using {} explicit release name(s) from config.", out.size());
            return out;
        }

        // 2) Otherwise scan project fixVersions.
        if (isBlank(j.getProjectKeys())) {
            log.warn("Neither release-names nor project-keys set; no releases. "
                    + "Set cockpit.jira.release-names (e.g. 25.07,25.08) or project-keys.");
            return List.of();
        }
        for (String project : j.getProjectKeys().split(",")) {
            project = project.trim();
            if (project.isEmpty()) continue;
            // Jira DC: project key is case-sensitive; numeric ids also work.
            String body = getJira("/rest/api/2/project/" + enc(project) + "/versions");
            if (body == null) {
                log.warn("Jira versions for project '{}' returned no body (check the key — "
                        + "it must be the PROJECT KEY, e.g. TCAAS1484, not the name).", project);
                continue;
            }
            try {
                JsonNode arr = mapper.readTree(body);
                if (arr.isArray()) {
                    for (JsonNode v : arr) {
                        String name = v.path("name").asText("");
                        if (name.isEmpty()) continue;
                        LocalDate date = safeDate(v.path("releaseDate").asText(null));
                        boolean released = v.path("released").asBoolean(false);
                        out.add(new Release(v.path("id").asText(name), name, date, released,
                                v.path("description").asText("")));
                    }
                } else {
                    // Jira returned an error object (e.g. 400) rather than an array.
                    log.warn("Jira versions for '{}' not an array — response: {}", project,
                            body.length() > 300 ? body.substring(0, 300) : body);
                }
            } catch (Exception e) {
                log.warn("Parsing Jira versions for '{}' failed: {}", project, e.getMessage());
            }
        }
        return out;
    }

    @Override
    public List<Subject> listSubjects(String releaseName) {
        var j = props.getJira();
        if (isBlank(j.getBaseUrl())) {
            log.warn("Jira not configured; returning no subjects for {}", releaseName);
            return List.of();
        }
        List<Subject> out = new ArrayList<>();
        try {
            String jql = j.getSubjectJql().replace("{RELEASE}", releaseName);
            String url = "/rest/api/2/search?jql=" + enc(jql)
                    + "&maxResults=200&fields=summary,status,assignee,reporter,created,"
                    + (j.getOctaneLinkField() == null ? "" : j.getOctaneLinkField());
            String body = getJira(url);
            if (body == null) return out;
            JsonNode issues = mapper.readTree(body).path("issues");

            // Parse all issues first (cheap, no network).
            record Raw(String key, String summary, String status, String dev, String devEmail,
                       String rep, String repEmail, LocalDate created, List<String> octaneIds) {}
            List<Raw> raws = new ArrayList<>();
            for (JsonNode it : issues) {
                JsonNode f = it.path("fields");
                String key = it.path("key").asText("");
                List<String> octaneIds = new ArrayList<>();
                if (j.getOctaneLinkField() != null) {
                    String raw = f.path(j.getOctaneLinkField()).asText("");
                    for (String t : raw.split("[ ,;]+")) if (!t.isBlank()) octaneIds.add(t.trim());
                }
                raws.add(new Raw(key, f.path("summary").asText(""),
                        f.path("status").path("name").asText(""),
                        f.path("assignee").path("displayName").asText(""),
                        f.path("assignee").path("emailAddress").asText(""),
                        f.path("reporter").path("displayName").asText(""),
                        f.path("reporter").path("emailAddress").asText(""),
                        safeDate(f.path("created").asText("").replaceAll("T.*", "")),
                        octaneIds));
            }

            // Run the readiness checks for all subjects in PARALLEL — each
            // subject does 1 Octane query + 1 SharePoint folder listing (not 6),
            // so a 36-subject release goes from hundreds of sequential calls to
            // a few dozen concurrent ones. Bounded pool keeps the proxy happy.
            ExecutorService pool = Executors.newFixedThreadPool(
                    Math.min(12, Math.max(2, raws.size())));
            try {
                List<Future<Subject>> futures = new ArrayList<>();
                for (Raw rw : raws) {
                    futures.add(pool.submit(() -> {
                        boolean octaneOk = checkOctane(rw.octaneIds());
                        Readiness r = buildReadiness(rw.key(), octaneOk);
                        return new Subject(rw.key(), rw.summary(), rw.status(),
                                rw.dev(), rw.devEmail(), rw.rep(), rw.repEmail(),
                                rw.created(), rw.octaneIds(), r);
                    }));
                }
                for (Future<Subject> fut : futures) {
                    try { out.add(fut.get()); }
                    catch (Exception e) { log.warn("Subject check failed: {}", e.getMessage()); }
                }
            } finally {
                pool.shutdown();
            }
        } catch (Exception e) {
            log.warn("listSubjects failed gracefully for {}: {}", releaseName, e.getMessage());
        }
        return out;
    }

    // ---- readiness assembly ----
    /**
     * Builds the Readiness for a subject. Octane result is passed in. SharePoint
     * artifacts are resolved from a SINGLE listing of the epic's folder tree
     * (cached per epic) instead of one HTTP call per artifact.
     */
    private Readiness buildReadiness(String epicKey, boolean octaneOk) {
        Set<String> presentFolders = sharePointFoldersWithFiles(epicKey);
        boolean pr = hasFolder(presentFolders, "PR");
        boolean prExcel = hasFolder(presentFolders, "PR_EXCEL");
        boolean est = hasFolder(presentFolders, "ESTIMATION_SHEET");
        boolean rev = hasFolder(presentFolders, "OCTANE_REVIEW_DOC");
        boolean exec = hasFolder(presentFolders, "OCTANE_EXECUTION_DOC");
        boolean unit = hasFolder(presentFolders, "UNIT_TEST");

        List<String> missing = new ArrayList<>();
        if (!octaneOk) missing.add("OCTANE_TESTS_LINKED");
        if (!pr) missing.add("PR");
        if (!unit) missing.add("UNIT_TEST");
        if (!est) missing.add("ESTIMATION_SHEET");
        if (!prExcel) missing.add("PR_EXCEL");
        if (!rev) missing.add("OCTANE_REVIEW_DOC");
        if (!exec) missing.add("OCTANE_EXECUTION_DOC");
        return new Readiness(octaneOk, pr, unit, est, prExcel, rev, exec, missing.size(), missing);
    }

    private boolean hasFolder(Set<String> present, String artifactKey) {
        return present.contains(artifactFolder(artifactKey));
    }

    // ---- Octane ----
    /**
     * Checks the subject's linked Octane test cases exist (and ideally have
     * passing runs). Returns true only if there is at least one linked id and
     * Octane confirms it. Signs in lazily; re-signs once on 401.
     */
    private boolean checkOctane(List<String> octaneIds) {
        var o = props.getOctane();
        if (isBlank(o.getBaseUrl()) || octaneIds == null || octaneIds.isEmpty()) return false;
        try {
            if (octaneCookie == null) octaneSignIn();
            if (octaneCookie == null) return false;
            // Query test cases by id list: /api/shared_spaces/{ss}/workspaces/{ws}/tests?query="..."
            String ids = String.join(" || ", octaneIds.stream().map(i -> "id=" + i).toList());
            String url = o.getBaseUrl() + "/api/shared_spaces/" + o.getSharedSpaceId()
                    + "/workspaces/" + o.getWorkspaceId()
                    + "/tests?fields=id,name,last_runs&query=\"" + enc("(" + ids + ")") + "\"";
            HttpResponse<String> r = octaneGet(url);
            if (r != null && r.statusCode() == 401) { octaneSignIn(); r = octaneGet(url); }
            if (r == null || r.statusCode() >= 400) return false;
            int total = mapper.readTree(r.body()).path("total_count").asInt(0);
            return total > 0;
        } catch (Exception e) {
            log.warn("Octane check failed gracefully: {}", e.getMessage());
            return false;
        }
    }

    private void octaneSignIn() {
        var o = props.getOctane();
        try {
            String payload = "{\"client_id\":\"" + o.getClientId()
                    + "\",\"client_secret\":\"" + o.getClientSecret() + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(o.getBaseUrl() + "/authentication/sign_in"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(payload)).build();
            HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() < 400) {
                // capture the LWSSO_COOKIE_KEY from Set-Cookie
                String cookie = r.headers().allValues("set-cookie").stream()
                        .filter(c -> c.startsWith("LWSSO_COOKIE_KEY"))
                        .findFirst().map(c -> c.split(";", 2)[0]).orElse(null);
                octaneCookie = cookie;
                log.info("Octane sign-in {}", cookie != null ? "OK" : "returned no cookie");
            } else {
                log.warn("Octane sign-in HTTP {}", r.statusCode());
            }
        } catch (Exception e) {
            log.warn("Octane sign-in failed gracefully: {}", e.getMessage());
        }
    }

    private HttpResponse<String> octaneGet(String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Cookie", octaneCookie)
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15)).GET().build();
            return saas.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (Exception e) {
            log.warn("Octane GET failed: {}", e.getMessage());
            return null;
        }
    }

    // ---- SharePoint ----
    // Per-epic cache of the subfolders that contain at least one file, so the
    // listing happens once per epic (not once per artifact). Cleared each scan
    // via the cache TTL on the service layer; here it lives for the connector.
    private final java.util.concurrent.ConcurrentHashMap<String, Set<String>> spFolderCache
            = new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * Lists the epic's artifact subfolders ONCE and returns the set of subfolder
     * names that contain at least one file. Uses cookie auth (FedAuth + rtFa).
     *
     * The library + root path + epic form the server-relative folder:
     *   /sites/<site>/<library>/<root-path>/<EPIC>
     * We list its Folders (and each folder's file count) in a single call using
     * $expand=Folders/Files. Returns an empty set on any error.
     */
    private Set<String> sharePointFoldersWithFiles(String epicKey) {
        var sp = props.getSharepoint();
        if (isBlank(sp.getBaseUrl()) || isBlank(sp.getFedAuth())) return Set.of();
        return spFolderCache.computeIfAbsent(epicKey, k -> {
            try {
                String serverRel = epicServerRelative(sp, k);
                // One call: list subfolders, expanding each folder's Files so we
                // can tell which subfolders actually contain documents.
                String url = sp.getBaseUrl() + "/_api/web/GetFolderByServerRelativeUrl('"
                        + encodePath(serverRel) + "')/Folders?$expand=Files&$select=Name,Files/Name";
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Cookie", "FedAuth=" + sp.getFedAuth() + "; rtFa=" + nz(sp.getRtFa()))
                        .header("Accept", "application/json;odata=nometadata")
                        .timeout(Duration.ofSeconds(20)).GET().build();
                HttpResponse<String> r = saas.send(req, HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() >= 400) {
                    log.warn("SharePoint {} -> HTTP {} (folder: {})", k, r.statusCode(), serverRel);
                    return Set.of();
                }
                Set<String> present = new HashSet<>();
                JsonNode folders = mapper.readTree(r.body()).path("value");
                for (JsonNode folder : folders) {
                    String name = folder.path("Name").asText("");
                    JsonNode files = folder.path("Files");
                    int count = files.isArray() ? files.size() : 0;
                    // also count nested files reachable via the expand
                    if (count > 0) present.add(name);
                }
                log.info("SharePoint {} subfolders-with-files: {}", k, present);
                return present;
            } catch (Exception e) {
                log.warn("SharePoint listing failed gracefully ({}): {}", k, e.getMessage());
                return Set.of();
            }
        });
    }

    /** Builds the server-relative path of an epic's folder, slash-normalised. */
    private String epicServerRelative(CockpitProperties.SharePoint sp, String epicKey) {
        // site path comes from the base URL, e.g. https://host/sites/ITTAADM -> /sites/ITTAADM
        String sitePath = sp.getBaseUrl().replaceFirst("^https?://[^/]+", "");
        String lib = sp.getLibraryName() == null ? "" : sp.getLibraryName();
        String root = sp.getRootPath() == null ? "" : sp.getRootPath();
        String raw = sitePath + "/" + lib + "/" + root + "/" + epicKey;
        return raw.replaceAll("/{2,}", "/"); // collapse double slashes
    }

    /** Encode a server-relative path for use inside GetFolderByServerRelativeUrl('...'). */
    private String encodePath(String path) {
        // SharePoint wants spaces as %20 and a single-quote doubled; keep slashes.
        return path.replace("'", "''").replace(" ", "%20");
    }

    /** Maps an artifact key to its SharePoint subfolder (adjust to artifacts.json). */
    private String artifactFolder(String key) {
        return switch (key) {
            case "PR" -> "01 - PR";
            case "PR_EXCEL" -> "01 - PR";
            case "ESTIMATION_SHEET" -> "02 - Estimation";
            case "OCTANE_REVIEW_DOC" -> "03 - Quality/Review";
            case "OCTANE_EXECUTION_DOC" -> "03 - Quality/Execution";
            case "UNIT_TEST" -> "04 - Unit Test";
            default -> key;
        };
    }
    private String getJira(String path) {
        try {
            var j = props.getJira();
            HttpRequest.Builder b = HttpRequest.newBuilder()
                    .uri(URI.create(j.getBaseUrl() + path))
                    .timeout(Duration.ofSeconds(12)).GET()
                    .header("Accept", "application/json");
            if ("bearer".equalsIgnoreCase(j.getAuthMode())) {
                b.header("Authorization", "Bearer " + nz(j.getPat()));
            } else {
                String basic = Base64.getEncoder()
                        .encodeToString((nz(j.getEmail()) + ":" + nz(j.getApiToken())).getBytes());
                b.header("Authorization", "Basic " + basic);
            }
            HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() >= 400) {
                log.warn("Jira {} -> HTTP {}", path, r.statusCode());
                return null;
            }
            return r.body();
        } catch (Exception e) {
            log.warn("Jira call failed ({}): {}", path, e.getMessage());
            return null;
        }
    }

    private LocalDate safeDate(String s) {
        try { return (s == null || s.isBlank()) ? null : LocalDate.parse(s); }
        catch (Exception e) { return null; }
    }
    private String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private boolean isBlank(String s) { return s == null || s.isBlank(); }
    private String nz(String s) { return s == null ? "" : s; }
}
