package com.bnpparibas.releasecockpit.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Per-release checkpoint date overrides. Dates are auto-computed from the Jira
 * release date; these overrides let each stage (End-UAT, PPD-1, PPD-1 rollback,
 * PPD-2, LCAB) be corrected from the Config tab when they shift, without code or
 * config-file edits. Overrides persist to config/checkpoint-overrides.json.
 */
@Slf4j
@Service
public class CheckpointOverrideService {

    private static final String RESOURCE = "checkpoint-overrides.json";
    private static final File EXTERNAL = new File("config/" + RESOURCE);
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, Map<String, LocalDate>> byRelease = new HashMap<>();

    public CheckpointOverrideService() { load(); }

    private void load() {
        try {
            JsonNode root;
            if (EXTERNAL.exists()) {
                root = mapper.readTree(EXTERNAL);
            } else {
                try (InputStream is = new ClassPathResource(RESOURCE).getInputStream()) {
                    root = mapper.readTree(is);
                }
            }
            JsonNode releases = root.path("releases");
            releases.fieldNames().forEachRemaining(rel -> {
                Map<String, LocalDate> dates = new HashMap<>();
                JsonNode node = releases.path(rel);
                node.fieldNames().forEachRemaining(k -> {
                    try { dates.put(k, LocalDate.parse(node.path(k).asText())); }
                    catch (Exception ignore) {}
                });
                byRelease.put(rel, dates);
            });
            log.info("Loaded checkpoint overrides for {} release(s)", byRelease.size());
        } catch (Exception e) {
            log.warn("No checkpoint overrides loaded: {}", e.getMessage());
        }
    }

    public Map<String, LocalDate> forRelease(String releaseName) {
        return byRelease.getOrDefault(releaseName, Map.of());
    }

    /** Valid override stage keys (release date always comes from Jira). */
    public static final java.util.List<String> STAGES =
            java.util.List.of("END_UAT", "PPD1", "PPD1_ROLLBACK", "PPD2", "LCAB");

    /**
     * Sets (or clears) a single stage override for a release. A null/blank date
     * clears the override so it reverts to the auto-computed value.
     */
    public synchronized Map<String, LocalDate> setOverride(String releaseName, String stage, LocalDate date) {
        if (!STAGES.contains(stage)) throw new IllegalArgumentException("Unknown stage: " + stage);
        Map<String, LocalDate> dates = byRelease.computeIfAbsent(releaseName, k -> new HashMap<>());
        if (date == null) dates.remove(stage); else dates.put(stage, date);
        if (dates.isEmpty()) byRelease.remove(releaseName);
        persist();
        return forRelease(releaseName);
    }

    /** Clears ALL overrides for a release (reset to Jira-derived dates). */
    public synchronized void clearRelease(String releaseName) {
        byRelease.remove(releaseName);
        persist();
    }

    private void persist() {
        try {
            EXTERNAL.getParentFile().mkdirs();
            ObjectNode root = mapper.createObjectNode();
            ObjectNode releases = root.putObject("releases");
            for (var relEntry : byRelease.entrySet()) {
                ObjectNode rel = releases.putObject(relEntry.getKey());
                for (var d : relEntry.getValue().entrySet()) {
                    rel.put(d.getKey(), d.getValue().toString());
                }
            }
            mapper.writerWithDefaultPrettyPrinter().writeValue(EXTERNAL, root);
            log.info("Persisted checkpoint overrides to {}", EXTERNAL.getPath());
        } catch (Exception e) {
            log.warn("Failed to persist checkpoint overrides: {}", e.getMessage());
        }
    }
}
