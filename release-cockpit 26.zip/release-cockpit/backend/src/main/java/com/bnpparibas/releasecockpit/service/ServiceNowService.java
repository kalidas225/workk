package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.config.CockpitProperties;
import com.bnpparibas.releasecockpit.model.Domain.ServiceNowTicket;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ServiceNow integration for BNP's API gateway.
 *
 * Ported from the working standalone service: OAuth2 client-credentials
 * (consumer key/secret -> bearer token) against a token endpoint, then calls
 * the gateway's /changes and /changes/{number} endpoints. Separate credentials
 * for the changes and attachments APIs, each token cached until expiry.
 *
 *   - Mock mode (or not enabled): returns deterministic demo tickets.
 *   - Live: OAuth2 token -> GET {baseUrl}/changes?sysparm_query=...
 *
 * Uses the JDK HttpClient via HttpClientFactory.proxied() so the corporate
 * proxy (with Basic proxy auth) is applied automatically.
 */
@Slf4j
@Service
public class ServiceNowService {

    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final CockpitProperties props;
    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient http;
    private final String proxyAuthHeader;

    /** Cached OAuth2 tokens keyed by "changes" / "attachments". */
    private final ConcurrentHashMap<String, TokenWithExpiry> tokenCache = new ConcurrentHashMap<>();

    public ServiceNowService(CockpitProperties props,
                             com.bnpparibas.releasecockpit.connector.HttpClientFactory clients) {
        this.props = props;
        // Use the NO-Authenticator proxied client: the JDK's Authenticator-equipped
        // client can silently drop our per-request Authorization header (that's the
        // "Authorization header not valid or not found" error). We add the proxy's
        // own Proxy-Authorization header manually instead.
        this.http = clients.proxiedNoAuth();
        this.proxyAuthHeader = clients.proxyAuthHeader();
    }

    public boolean isEnabled() {
        return props.getServicenow().isEnabled();
    }

    /** Lightweight connectivity check: obtain a token + hit /changes with limit 1. */
    public boolean ping() {
        var sn = props.getServicenow();
        if (!sn.isEnabled()) return false;
        try {
            String url = sn.getBaseUrl() + "/changes?sysparm_limit=1";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.warn("ServiceNow ping HTTP {} — body: {}", resp.statusCode(),
                        resp.body() != null && resp.body().length() > 300
                                ? resp.body().substring(0, 300) : resp.body());
                return false;
            }
            return true;
        } catch (Exception e) {
            log.warn("ServiceNow ping failed: {}", e.getMessage());
            return false;
        }
    }

    // ---- token handling -----------------------------------------------------

    private record TokenWithExpiry(String token, long expiresAt) {
        boolean isExpired() { return System.currentTimeMillis() >= expiresAt; }
    }

    /** OAuth2 client-credentials token for the given API ("changes" or "attachments"). */
    private synchronized String getAccessToken(String api) {
        var sn = props.getServicenow();
        var oauth = "attachments".equals(api) ? sn.getAttachments() : sn.getChanges();
        String cacheKey = api;

        TokenWithExpiry cached = tokenCache.get(cacheKey);
        if (cached != null && !cached.isExpired()) return cached.token();

        try {
            String creds = oauth.getConsumerKey() + ":" + oauth.getConsumerSecret();
            String encoded = Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8));
            String bodyStr = "grant_type=client_credentials";
            HttpRequest.Builder rb = HttpRequest.newBuilder()
                    .uri(URI.create(sn.getTokenUrl()))
                    .header("Authorization", "Basic " + encoded)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Accept", "application/json")
                    .timeout(Duration.ofSeconds(15))
                    .POST(HttpRequest.BodyPublishers.ofString(bodyStr));
            // Proxy auth added manually (no Authenticator on this client).
            if (proxyAuthHeader != null) rb.header("Proxy-Authorization", proxyAuthHeader);
            HttpRequest req = rb.build();
            // DIAGNOSTIC: confirm what we're about to send. The Authorization value
            // is masked. allowRestrictedHeaders MUST include "authorization" or the
            // JDK will silently drop the header when the proxy Authenticator is set.
            log.info("ServiceNow token request -> {}", sn.getTokenUrl());
            log.info("  allowRestrictedHeaders='{}'", System.getProperty("jdk.httpclient.allowRestrictedHeaders", "<unset>"));
            log.info("  request headers (as built): {}", maskAuth(req.headers().map()));
            log.info("  consumerKey present={}, secret present={}, basic-len={}",
                    oauth.getConsumerKey() != null && !oauth.getConsumerKey().isBlank(),
                    oauth.getConsumerSecret() != null && !oauth.getConsumerSecret().isBlank(),
                    encoded.length());
            log.info("  body='{}'", bodyStr);
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow token endpoint HTTP {} for {} — body: {}",
                        resp.statusCode(), api, resp.body());
                throw new RuntimeException("Token request failed: HTTP " + resp.statusCode());
            }
            JsonNode body = mapper.readTree(resp.body());
            String token = body.path("access_token").asText("");
            if (token.isBlank()) throw new RuntimeException("No access_token in token response");
            long expiresIn = body.path("expires_in").asLong(300);
            long expiresAt = System.currentTimeMillis() + (expiresIn - 60) * 1000; // 60s buffer
            tokenCache.put(cacheKey, new TokenWithExpiry(token, expiresAt));
            log.info("ServiceNow {} token obtained (expires in {}s)", api, expiresIn);
            return token;
        } catch (Exception e) {
            log.error("ServiceNow {} token error: {}", api, e.getMessage());
            throw new RuntimeException("ServiceNow token error: " + e.getMessage(), e);
        }
    }

    public void clearTokenCache() { tokenCache.clear(); }

    /** Masks Authorization/Proxy-Authorization values in a header map for logging. */
    private java.util.Map<String, java.util.List<String>> maskAuth(java.util.Map<String, java.util.List<String>> headers) {
        java.util.Map<String, java.util.List<String>> out = new java.util.LinkedHashMap<>();
        headers.forEach((k, v) -> {
            if (k.equalsIgnoreCase("authorization") || k.equalsIgnoreCase("proxy-authorization")) {
                String first = v.isEmpty() ? "" : v.get(0);
                String scheme = first.contains(" ") ? first.substring(0, first.indexOf(' ')) : first;
                out.put(k, java.util.List.of(scheme + " ***(" + (first.length()) + " chars)"));
            } else {
                out.put(k, v);
            }
        });
        return out;
    }

    // ---- HTTP with 401 self-heal -------------------------------------------

    private HttpResponse<String> getWithAuth(String api, String url) throws Exception {
        String token = getAccessToken(api);
        HttpResponse<String> resp = doGet(url, token);
        if (resp.statusCode() == 401) {
            log.info("ServiceNow 401 on {} — refreshing token and retrying", api);
            tokenCache.remove(api);
            token = getAccessToken(api);
            resp = doGet(url, token);
        }
        return resp;
    }

    private HttpResponse<String> doGet(String url, String token) throws Exception {
        return doGet(url, token, 20);
    }

    private HttpResponse<String> doGet(String url, String token, int timeoutSec) throws Exception {
        HttpRequest.Builder rb = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Bearer " + token)
                .header("Accept", "application/json")
                .timeout(Duration.ofSeconds(timeoutSec)).GET();
        if (proxyAuthHeader != null) rb.header("Proxy-Authorization", proxyAuthHeader);
        return http.send(rb.build(), HttpResponse.BodyHandlers.ofString());
    }

    private HttpResponse<String> getWithAuth(String api, String url, int timeoutSec) throws Exception {
        String token = getAccessToken(api);
        HttpResponse<String> resp = doGet(url, token, timeoutSec);
        if (resp.statusCode() == 401) {
            tokenCache.remove(api);
            resp = doGet(url, getAccessToken(api), timeoutSec);
        }
        return resp;
    }

    // ---- release ticket listing (used by the dashboard) --------------------

    public List<ServiceNowTicket> ticketsForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockTickets(releaseName);
        }
        try {
            // Filter changes by the release field when configured; otherwise return
            // recent changes for the environment. The gateway expects an UNencoded
            // encoded-query in sysparm_query (URL-encoded once).
            String query = (sn.getReleaseField() != null && !sn.getReleaseField().isBlank())
                    ? sn.getReleaseField() + "=" + releaseName
                    : "u_environment=" + sn.getEnvironment();
            String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                    + "start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=50";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow /changes HTTP {}", resp.statusCode());
                return List.of();
            }
            return parse(resp.body(), sn.getBaseUrl());
        } catch (Exception e) {
            log.error("ServiceNow fetch failed: {}", e.getMessage());
            return List.of();
        }
    }

    /** Fetch a single change by its number (e.g. CHG0045821). */
    public String getChangeDetails(String changeNumber) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) return "{}";
        try {
            String query = "number=" + changeNumber;
            String fields = "sys_id,number,short_description,description,state,priority,risk,impact,"
                    + "assignment_group,assigned_to,start_date,end_date,type,u_environment";
            String url = sn.getBaseUrl() + "/changes"
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=1";
            HttpResponse<String> resp = getWithAuth("changes", url);
            if (resp.statusCode() >= 400) {
                log.error("ServiceNow change-details HTTP {}", resp.statusCode());
                return "{}";
            }
            JsonNode root = mapper.readTree(resp.body()).path("result");
            if (root.isArray() && root.size() > 0) return mapper.writeValueAsString(root.get(0));
            return "{}";
        } catch (Exception e) {
            log.error("ServiceNow change-details failed: {}", e.getMessage());
            return "{}";
        }
    }

    // ---- release changes grouped by env + linked incidents/problems ---------

    /**
     * All ServiceNow records for a release. Changes are matched by the release key
     * appearing in short_description (this instance's naming convention), then
     * bucketed into PPD-1 / PPD-2 / Prod. Incidents and problems linked to those
     * changes (caused-by) are also returned, for display after the Prod release.
     */
    /** Short-lived cache of release changes so repeated calls / release switches are fast. */
    private final java.util.concurrent.ConcurrentHashMap<String, CachedChanges> changesCache
            = new java.util.concurrent.ConcurrentHashMap<>();
    private record CachedChanges(com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges data, long at) {
        boolean fresh() { return System.currentTimeMillis() - at < 120_000; } // 2 min
    }

    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges changesForRelease(String releaseName) {
        return changesForRelease(releaseName, false);
    }

    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges changesForRelease(
            String releaseName, boolean forceRefresh) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            return mockReleaseChanges(releaseName);
        }
        if (!forceRefresh) {
            CachedChanges cached = changesCache.get(releaseName);
            if (cached != null && cached.fresh()) return cached.data();
        } else {
            changesCache.remove(releaseName);
        }
        // Retry the query a couple of times on transient timeouts, with backoff.
        Exception last = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            try {
                var data = doChangesQuery(releaseName, sn);
                // Only cache a SUCCESSFUL, non-empty (or clearly-empty) result. A
                // failed/timed-out attempt returns null so we retry instead of
                // caching an empty response (that was the "other releases show
                // nothing" bug — a timeout poisoned the cache).
                if (data != null) {
                    changesCache.put(releaseName, new CachedChanges(data, System.currentTimeMillis()));
                    return data;
                }
            } catch (Exception e) {
                last = e;
                log.warn("ServiceNow changes attempt {}/3 for {} failed: {}", attempt, releaseName, e.getMessage());
            }
            try { Thread.sleep(400L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
        }
        log.error("ServiceNow changesForRelease gave up for {} after retries: {}",
                releaseName, last == null ? "empty/timeout" : last.getMessage());
        // Return stale cache if we have any, else empty — but DON'T overwrite cache.
        CachedChanges stale = changesCache.get(releaseName);
        return stale != null ? stale.data() : empty(true);
    }

    /** One attempt of the changes query. Returns null on timeout so caller retries. */
    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges doChangesQuery(
            String releaseName, CockpitProperties.ServiceNow sn) throws Exception {
        String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                + "start_date,end_date,type,u_environment";
        String query = buildReleaseQuery(releaseName);
        String url = sn.getBaseUrl() + "/changes"
                + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                + "&sysparm_display_value=all&sysparm_limit=200";
        log.info("ServiceNow changes query for {}: {}", releaseName, query);
        HttpResponse<String> resp;
        try {
            resp = getWithAuth("changes", url, 20);   // 3 lean LIKE clauses; allow 20s
        } catch (java.net.http.HttpTimeoutException te) {
            log.warn("ServiceNow /changes timed out for {} (will retry)", releaseName);
            return null;   // signal retry
        }
        if (resp.statusCode() >= 400) {
            log.error("ServiceNow /changes HTTP {} for release {} — body: {}",
                    resp.statusCode(), releaseName, resp.body());
            return null;   // retry (could be transient 5xx)
        }
        log.info("ServiceNow /changes RAW response for {}:\n{}", releaseName, resp.body());
        List<ServiceNowTicket> all = parse(resp.body(), sn.getBaseUrl());
        List<ServiceNowTicket> ppd1 = new ArrayList<>();
        List<ServiceNowTicket> ppd2 = new ArrayList<>();
        List<ServiceNowTicket> extraPpd = new ArrayList<>();
        List<ServiceNowTicket> prod = new ArrayList<>();
        for (ServiceNowTicket t : all) {
            String env = t.env() == null ? "" : t.env();
            if ("PPD1".equals(env)) ppd1.add(t);
            else if ("PPD2".equals(env)) ppd2.add(t);
            else if (env.matches("PPD\\d+")) extraPpd.add(t);   // PPD3, PPD4, …
            else prod.add(t);
        }
        log.info("ServiceNow release {} -> {} changes (PPD1={} PPD2={} PPD3+={} PROD={})",
                releaseName, all.size(), ppd1.size(), ppd2.size(), extraPpd.size(), prod.size());
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                ppd1, ppd2, prod, List.of(), List.of(), true, extraPpd);
    }

    /**
     * Incidents/problems related to the release's changes. `queryField` is the
     * field on the incident/problem table that references a change — this is a
     * sys_id reference, so we pass change SYS_IDs (not CHG numbers). Logs the exact
     * query + full response so we can confirm what's actually related.
     */
    private List<ServiceNowTicket> linkedRecords(String api, String queryField,
                                                 List<String> changeSysIds,
                                                 CockpitProperties.ServiceNow sn) {
        if (changeSysIds.isEmpty()) return List.of();
        try {
            String type = "incidents".equals(api) ? "incident" : "problem";
            // Reference fields match on sys_id. IN takes a comma-separated list.
            String query = queryField + "IN" + String.join(",", changeSysIds);
            String fields = "sys_id,number,short_description,state,priority,assigned_to,"
                    + queryField;
            String url = sn.getBaseUrl() + "/" + api
                    + "?sysparm_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&sysparm_fields=" + URLEncoder.encode(fields, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=100";
            log.info("ServiceNow /{} query (field={}): {}", api, queryField, query);
            HttpResponse<String> resp = getWithAuth("changes", url, 10);
            if (resp.statusCode() >= 400) {
                log.warn("ServiceNow /{} HTTP {} — body: {}", api, resp.statusCode(), resp.body());
                return List.of();
            }
            log.info("ServiceNow /{} RAW ({}): {}", api, queryField,
                    resp.body().length() > 2000 ? resp.body().substring(0, 2000) + "…" : resp.body());
            List<ServiceNowTicket> out = new ArrayList<>();
            JsonNode result = mapper.readTree(resp.body()).path("result");
            for (JsonNode r : result) {
                out.add(new ServiceNowTicket(
                        dv(r, "number"), dv(r, "short_description"), dv(r, "state"),
                        dv(r, "priority"), dv(r, "assigned_to"), type,
                        deepLink(type, dv(r, "sys_id"), dv(r, "number")), ""));
            }
            return out;
        } catch (Exception e) {
            log.warn("ServiceNow linked {} fetch failed: {}", api, e.getMessage());
            return List.of();
        }
    }

    /**
     * Incidents & problems related to this release's changes. Returns three groups:
     *   incidents  — incidents CAUSED BY the changes (post-deployment), field caused_by
     *   problems   — problems DELIVERED/FIXED BY the changes (rfc)
     * Uses change SYS_IDs (reference fields match on sys_id, not CHG number), which
     * is why the earlier number-based query returned unrelated records.
     */
    public com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges issuesForRelease(String releaseName) {
        var sn = props.getServicenow();
        if (!sn.isEnabled() || props.isMockMode()) {
            var m = mockReleaseChanges(releaseName);
            return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                    List.of(), List.of(), List.of(), m.incidents(), m.problems(), true, List.of());
        }
        try {
            var changes = changesForRelease(releaseName);
            // Collect change sys_ids (extracted from each change's deep-link URL).
            List<String> sysIds = new ArrayList<>();
            java.util.function.Consumer<List<ServiceNowTicket>> collect = list -> {
                for (var t : list) {
                    String sid = sysIdFromUrl(t.url());
                    if (!sid.isBlank()) sysIds.add(sid);
                }
            };
            collect.accept(changes.ppd1());
            collect.accept(changes.ppd2());
            collect.accept(changes.prod());
            log.info("ServiceNow issues for {} — change sys_ids: {}", releaseName, sysIds);
            if (sysIds.isEmpty()) return empty(true);

            // Incidents caused by the change (post-deployment) + problems fixed/delivered.
            List<ServiceNowTicket> incidents = linkedRecords("incidents", "caused_by", sysIds, sn);
            List<ServiceNowTicket> problems = linkedRecords("problems", "rfc", sysIds, sn);
            return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                    List.of(), List.of(), List.of(), incidents, problems, true, List.of());
        } catch (Exception e) {
            log.warn("ServiceNow issuesForRelease failed: {}", e.getMessage());
            return empty(true);
        }
    }

    /** Extracts sys_id from a deep-link URL like ...sys_id=XXXX. */
    private String sysIdFromUrl(String url) {
        if (url == null) return "";
        int i = url.indexOf("sys_id=");
        if (i < 0) return "";
        String rest = url.substring(i + 7);
        int amp = rest.indexOf('&');
        return amp >= 0 ? rest.substring(0, amp) : rest;
    }

    /**
     * Derives the environment bucket from a change's env field + text.
     * Handles bracket tags used in change titles: [PPD-1]/[PPD1], [PPD-2]/[PPD2],
     * [PROD]/[PRODUCTION], and a bare [PPD] (pre-prod). Prod keywords win over PPD
     * so a "production" change isn't mis-bucketed. A bare [PPD] with no number maps
     * to PPD1 by default (adjust once PPD-1 vs PPD-2 examples are confirmed).
     */
    /**
     * Derives the environment bucket from a change's short description (the tag).
     *
     * The BRACKET TAG in the title is authoritative and is checked FIRST, because
     * the u_environment field / description body often say "Production" even for a
     * pre-prod (PPD) rehearsal, which would otherwise mis-bucket everything as Prod.
     *
     * Rules (from the real data):
     *   [PROD] ...                      -> PROD
     *   [PPD] ... Rehearsal 1           -> PPD1
     *   [PPD] ... Rehearsal 2           -> PPD2
     *   [PPD] ... Rehearsal 1 rollback  -> PPD1 (rollback still belongs to PPD-1)
     *   [PPD-1]/[PPD-2] explicit        -> PPD1/PPD2
     *   [PPD] (no number)               -> PPD1
     */
    private String deriveEnv(String shortDesc, String extraText) {
        String title = (shortDesc == null ? "" : shortDesc).toLowerCase();

        // 1) Authoritative bracket tag in the title.
        //    [prod] wins; [ppd] is pre-prod and needs a rehearsal number to split.
        boolean prodTag = title.matches(".*\\[\\s*prod[a-z]*\\s*\\].*");
        boolean ppdTag  = title.matches(".*\\[\\s*ppd\\s*\\].*");

        if (prodTag) return "PROD";

        // Explicit [PPD-N] / [PPDN] tag with a number.
        java.util.regex.Matcher tagNum = java.util.regex.Pattern
                .compile("\\[\\s*ppd[-_ ]?(\\d+)\\s*\\]").matcher(title);
        if (tagNum.find()) return "PPD" + tagNum.group(1);

        if (ppdTag) {
            // Bare [PPD] tag: split by the Rehearsal number in the title.
            // "Rehearsal 3" -> PPD3, "Rehearsal 2" -> PPD2, etc. (any N).
            java.util.regex.Matcher reh = java.util.regex.Pattern
                    .compile("rehearsal\\s*(\\d+)").matcher(title);
            if (reh.find()) return "PPD" + reh.group(1);
            return "PPD1"; // bare [PPD] with no rehearsal number -> PPD-1
        }

        // 2) No bracket tag — fall back to a Rehearsal / PPD-N number in the title.
        java.util.regex.Matcher reh = java.util.regex.Pattern
                .compile("rehearsal\\s*(\\d+)").matcher(title);
        if (reh.find()) return "PPD" + reh.group(1);
        java.util.regex.Matcher ppdNum = java.util.regex.Pattern
                .compile("ppd[-_ ]?(\\d+)").matcher(title);
        if (ppdNum.find()) return "PPD" + ppdNum.group(1);
        if (title.contains("prod")) return "PROD";
        if (title.contains("ppd") || title.contains("pre-prod")) return "PPD1";
        return "";
    }

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges empty(boolean enabled) {
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                List.of(), List.of(), List.of(), List.of(), List.of(), enabled, List.of());
    }

    /**
     * Builds a ServiceNow encoded-query matching the release key. By default this
     * searches short_description ONLY, with a small set of format variants — this
     * is fast. Searching the large `description` free-text body with LIKE across
     * many OR clauses is extremely slow and caused request timeouts, so it's opt-in
     * (cockpit.servicenow.search-description=true) and only added as a fallback.
     */
    private String buildReleaseQuery(String releaseName) {
        List<String> variants = releaseKeyVariants(releaseName);
        List<String> conds = new ArrayList<>();
        for (String v : variants) conds.add("short_descriptionLIKE" + v);
        if (props.getServicenow().isSearchDescription()) {
            for (String v : variants) conds.add("descriptionLIKE" + v);
        }
        return String.join("^OR", conds);
    }

    /**
     * Known textual formats a release key can take in ServiceNow free-text fields.
     * "STS-2026-X5" -> ["STS-2026-X5", "STS X5.2026.0", "STS-X5-2026", "STS X5 2026"].
     * The parts (STS, 2026, X5) are recombined defensively so we catch the common
     * rearrangements teams use in change titles.
     */
    private List<String> releaseKeyVariants(String releaseName) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<>();
        out.add(releaseName);                       // raw, e.g. STS-2026-R6
        // Parse tokens: PREFIX, 4-digit YEAR, and a CODE like X5 / R6 (letter+digits).
        String[] p = releaseName.split("[-_ .]+");
        String prefix = null, year = null, code = null;
        for (String t : p) {
            if (t.matches("\\d{4}")) year = t;                     // 2026
            else if (t.matches("(?i)[A-Z]+\\d+")) code = t.toUpperCase(); // X5, R6
            else if (prefix == null) prefix = t;                   // STS
        }
        if (prefix != null && year != null && code != null) {
            // Only the formats actually seen in real change titles, to keep the
            // ServiceNow LIKE query fast (each clause is a text scan):
            //   "STS X5.2026.0"  (with trailing .0)
            //   "STS X5.2026"    (without .0)
            // The raw "STS-2026-X5" form is already added above. Extra rearrangements
            // were dropped — they rarely matched and made the query time out.
            out.add(prefix + " " + code + "." + year + ".0");  // STS X5.2026.0
            out.add(prefix + " " + code + "." + year);          // STS R6.2026
        }
        return new ArrayList<>(out);
    }

    private List<ServiceNowTicket> parse(String json, String baseUrl) {
        List<ServiceNowTicket> out = new ArrayList<>();
        try {
            JsonNode result = mapper.readTree(json).path("result");
            // Build the change list ONLY — no per-change CTASK calls here. CTASKs are
            // loaded lazily (on expand) via /servicenow/changes/{number}/ctasks, so
            // the main list returns fast and never times out on releases with many
            // changes.
            for (JsonNode r : result) {
                String shortDesc = dv(r, "short_description");
                String desc = dv(r, "description");
                String number = dv(r, "number");
                String sysId = dv(r, "sys_id");
                String env = deriveEnv(shortDesc, desc);
                String start = dv(r, "start_date");
                String end = dv(r, "end_date");
                out.add(new ServiceNowTicket(
                        number, shortDesc, dv(r, "state"), dv(r, "priority"),
                        dv(r, "assigned_to"), "change_request",
                        deepLink("change_request", sysId, number), env, start, end, List.of()));
            }
        } catch (Exception e) {
            log.error("ServiceNow parse failed: {}", e.getMessage());
        }
        return out;
    }

    /** Public CTASK fetch for the lazy on-expand endpoint. */
    public List<com.bnpparibas.releasecockpit.model.Domain.CTask> ctasksForChange(String changeNumber) {
        if (!props.getServicenow().isEnabled() || props.isMockMode()) return List.of();
        return fetchCtasks(changeNumber);
    }

    /**
     * Builds a clickable ServiceNow UI deep link:
     *   {uiBaseUrl}/nav_to.do?uri=change_request.do?sys_id={sysId}
     * Falls back to a number-based link if sys_id is missing.
     */
    private String deepLink(String table, String sysId, String number) {
        String ui = props.getServicenow().getUiBaseUrl();
        if (ui == null || ui.isBlank()) ui = "https://bnpp.service-now.com";
        if (sysId != null && !sysId.isBlank()) {
            return ui + "/nav_to.do?uri=" + table + ".do?sys_id=" + sysId;
        }
        return ui + "/nav_to.do?uri=" + table + "_list.do?sysparm_query=number=" + number;
    }

    /**
     * Fetch the change tasks (CTASKs) for a change via the gateway's dedicated
     * /changes/tasks endpoint, filtered by the parent change number. The response
     * is logged once so the exact shape can be confirmed. A task is flagged as a
     * rollback if its description/type says so.
     */
    private List<com.bnpparibas.releasecockpit.model.Domain.CTask> fetchCtasks(String changeNumber) {
        var sn = props.getServicenow();
        List<com.bnpparibas.releasecockpit.model.Domain.CTask> out = new ArrayList<>();
        try {
            // /changes/tasks?sysparm_query=change_request.number=CHGxxxx
            String q = "change_request.number=" + changeNumber;
            String url = sn.getBaseUrl() + "/changes/tasks"
                    + "?sysparm_query=" + URLEncoder.encode(q, StandardCharsets.UTF_8)
                    + "&sysparm_display_value=all&sysparm_limit=100";
            HttpResponse<String> resp = getWithAuth("changes", url, 10);
            if (resp.statusCode() >= 400) {
                log.warn("ServiceNow CTASK fetch HTTP {} for {} (url={})", resp.statusCode(), changeNumber, url);
                return out;
            }
            log.info("ServiceNow CTASKs for {}: {}", changeNumber,
                    resp.body().length() > 1200 ? resp.body().substring(0, 1200) + "…" : resp.body());
            JsonNode root = mapper.readTree(resp.body());
            JsonNode tasks = root.has("result") ? root.path("result")
                    : firstNonMissing(root, "change_task", "change_tasks", "tasks", "ctasks");
            if (tasks.isArray()) for (JsonNode t : tasks) out.add(toCtask(t));
        } catch (Exception e) {
            log.warn("ServiceNow CTASK fetch failed for {}: {}", changeNumber, e.getMessage());
        }
        return out;
    }

    /** Fetches CTASKs for a small set of changes (sequential — used for PPD-1 only). */
    private List<ServiceNowTicket> withCtasks(List<ServiceNowTicket> changes) {
        if (changes == null || changes.isEmpty()) return changes;
        List<ServiceNowTicket> out = new ArrayList<>();
        for (ServiceNowTicket c : changes) {
            var ctasks = fetchCtasks(c.number());
            out.add(new ServiceNowTicket(c.number(), c.shortDescription(), c.state(),
                    c.priority(), c.assignedTo(), c.type(), c.url(), c.env(),
                    c.startDate(), c.endDate(), ctasks));
        }
        return out;
    }

    private JsonNode firstNonMissing(JsonNode node, String... fields) {
        for (String f : fields) {
            JsonNode n = node.path(f);
            if (!n.isMissingNode() && !n.isNull()) return n;
        }
        return mapper.createArrayNode();
    }

    private com.bnpparibas.releasecockpit.model.Domain.CTask toCtask(JsonNode t) {
        String desc = dv(t, "short_description");
        boolean rollback = desc.toLowerCase().contains("rollback")
                || dv(t, "u_task_type").toLowerCase().contains("rollback");
        return new com.bnpparibas.releasecockpit.model.Domain.CTask(
                dv(t, "number"), desc, dv(t, "state"), dv(t, "assigned_to"),
                dv(t, "planned_start_date"), dv(t, "planned_end_date"), rollback);
    }

    /**
     * Reads a field that may be a plain string OR a display-value object
     * {"display_value": "...", "value": "..."} (sysparm_display_value=all).
     */
    private String dv(JsonNode node, String field) {
        JsonNode f = node.path(field);
        if (f.isObject()) return f.path("display_value").asText(f.path("value").asText(""));
        return f.asText("");
    }

    // ---- demo data ----------------------------------------------------------

    private com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges mockReleaseChanges(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x33CE);
        String[] states = {"Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Carlos Luis PALMA", "Emmanuel CHEVRIER", "Carlos Manuel FILIPE"};
        java.time.LocalDate base = java.time.LocalDate.now().minusDays(20);
        java.util.function.BiFunction<String, Integer, java.util.List<com.bnpparibas.releasecockpit.model.Domain.CTask>> mkTasks =
                (env, dayOffset) -> {
            String d = base.plusDays(dayOffset).toString();
            var tasks = new java.util.ArrayList<com.bnpparibas.releasecockpit.model.Domain.CTask>();
            tasks.add(new com.bnpparibas.releasecockpit.model.Domain.CTask(
                    String.format("CTASK%07d", 100000 + rng.nextInt(99999)),
                    "Deploy " + env, states[rng.nextInt(states.length)],
                    devs[rng.nextInt(devs.length)], d + " 18:00:00", d + " 20:00:00", false));
            if ("PPD1".equals(env)) {
                tasks.add(new com.bnpparibas.releasecockpit.model.Domain.CTask(
                        String.format("CTASK%07d", 100000 + rng.nextInt(99999)),
                        "Rollback plan for PPD-1", "Scheduled",
                        devs[rng.nextInt(devs.length)], d + " 21:00:00", d + " 22:00:00", true));
            }
            return tasks;
        };
        java.util.function.BiFunction<String, Integer, ServiceNowTicket> mk = (env, dayOffset) -> {
            String d = base.plusDays(dayOffset).toString();
            String label = env.equals("PROD") ? "[ANSIBLE][PROD] STS X5.2026.0 Release"
                    : env.equals("PPD1") ? "[ANSIBLE][PPD] STS X5.2026.0 Rehearsal 1"
                    : "[ANSIBLE][PPD] STS X5.2026.0 Rehearsal 2";
            return new ServiceNowTicket(
                    String.format("CHG%07d", 1360000 + rng.nextInt(99999)),
                    label, states[rng.nextInt(states.length)], prios[rng.nextInt(prios.length)],
                    devs[rng.nextInt(devs.length)], "change_request", "#", env,
                    d + " 18:00:00", d + " 22:00:00", mkTasks.apply(env, dayOffset));
        };
        List<ServiceNowTicket> ppd1 = List.of(mk.apply("PPD1", 0));
        List<ServiceNowTicket> ppd2 = List.of(mk.apply("PPD2", 7));
        List<ServiceNowTicket> prod = List.of(mk.apply("PROD", 14));
        List<ServiceNowTicket> incidents = List.of(new ServiceNowTicket(
                String.format("INC%07d", 20000 + rng.nextInt(9999)),
                "Post-release latency spike after " + releaseName,
                "In Progress", "2 - High", devs[0], "incident", "#", ""));
        List<ServiceNowTicket> problems = List.of(new ServiceNowTicket(
                String.format("PRB%07d", 10000 + rng.nextInt(9999)),
                "Root cause analysis for " + releaseName + " regression",
                "Assess", "3 - Moderate", devs[1], "problem", "#", ""));
        return new com.bnpparibas.releasecockpit.model.Domain.ReleaseChanges(
                ppd1, ppd2, prod, incidents, problems, true, List.of());
    }

    private List<ServiceNowTicket> mockTickets(String releaseName) {
        Random rng = new Random(releaseName.hashCode() ^ 0x5A17);
        String[] states = {"New", "Assess", "Authorize", "Scheduled", "Implement", "Review", "Closed"};
        String[] prios = {"1 - Critical", "2 - High", "3 - Moderate", "4 - Low"};
        String[] devs = {"Sreenath Babu Vairavasingh", "Srinivasan Nagarajan", "Selvakumar C",
                "Kameshwaran Pandi", "Akhila Gowrishankar"};
        String[] descs = {
                "Production deployment for release " + releaseName,
                "Database schema migration", "Firewall rule change for new endpoints",
                "Config rollout to UAT", "Certificate renewal", "Load balancer update",
                "Batch job schedule change", "Rollback plan validation"
        };
        int n = 3 + rng.nextInt(5);
        List<ServiceNowTicket> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            out.add(new ServiceNowTicket(
                    String.format("CHG%07d", 30000 + rng.nextInt(9999)),
                    descs[rng.nextInt(descs.length)],
                    states[rng.nextInt(states.length)],
                    prios[rng.nextInt(prios.length)],
                    devs[rng.nextInt(devs.length)],
                    "change_request",
                    "#"));
        }
        return out;
    }
}
