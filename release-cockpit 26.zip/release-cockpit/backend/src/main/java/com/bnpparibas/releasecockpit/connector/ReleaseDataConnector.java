package com.bnpparibas.releasecockpit.connector;

import com.bnpparibas.releasecockpit.model.Domain.Release;
import com.bnpparibas.releasecockpit.model.Domain.Subject;

import java.util.List;

/**
 * The data-source contract. Two implementations:
 *   - MockConnector (default; in-memory demo data so the app runs with no creds)
 *   - LiveConnector (calls Jira/Octane/SharePoint; ported from Release Guardian)
 *
 * Selected by the cockpit.mock-mode flag.
 */
public interface ReleaseDataConnector {

    /** All releases (Jira fixVersions) configured for the year. */
    List<Release> listReleases();

    /** Subjects (epics) tagged for a given release, with readiness resolved. */
    List<Subject> listSubjects(String releaseName);

    /** Live scan progress for a release (e.g. "7/11"), or null if not scanning. */
    default String scanProgress(String releaseName) { return null; }

    /**
     * Re-check a single subject and return its fresh data (or null if not found).
     * Default: re-scan the release and pick the one subject. Connectors may
     * override with a cheaper single-subject path.
     */
    default Subject refreshSubject(String releaseName, String subjectKey) {
        return listSubjects(releaseName).stream()
                .filter(s -> s.key().equalsIgnoreCase(subjectKey))
                .findFirst().orElse(null);
    }
}
