package com.bnpparibas.releasecockpit.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Strongly-typed configuration bound from application.yml (cockpit.*).
 * Mirrors the placeholders documented there.
 */
@Data
@Component
@ConfigurationProperties(prefix = "cockpit")
public class CockpitProperties {

    /** When true, use in-memory mock connectors instead of live systems. */
    private boolean mockMode = true;

    private Jira jira = new Jira();
    private Octane octane = new Octane();
    private SharePoint sharepoint = new SharePoint();
    private Proxy proxy = new Proxy();
    private ServiceNow servicenow = new ServiceNow();
    private Ai ai = new Ai();
    private Cors cors = new Cors();
    private Mail mail = new Mail();
    private Scheduler scheduler = new Scheduler();

    @Data
    public static class Scheduler {
        /**
         * Master switch for ALL background auto-checks (scheduled cron rescans and
         * late-add detection). Default FALSE — data refreshes only on user action
         * (Refresh button / release switch). Set true to enable periodic rescans.
         */
        private boolean autoCheckEnabled = false;
        /** Auto-check cron (default every 3 hours). Only runs if autoCheckEnabled. */
        private String autoCheckCron = "0 0 */3 * * *";
        /** Hourly late-add detection cron. Only runs if autoCheckEnabled. */
        private String lateAddCron = "0 0 * * * *";
        /** When true, the auto-check emails gaps + manager summary. */
        private boolean autoMail = false;
        /** How long a cached scan stays fresh (ms). */
        private long cacheTtlMs = 600000L;
        /** When true, a stale cache auto-refreshes in the background on read. */
        private boolean autoRescanEnabled = false;
    }

    @Data
    public static class Jira {
        private String baseUrl;
        private String authMode = "basic"; // basic | bearer
        private String username;            // network id, e.g. c59849
        private String password;            // network password (basic auth)
        private String email;
        private String apiToken;
        private String pat;
        /** Custom field id holding Octane IDs, e.g. customfield_10075. */
        private String octaneLinkField;
        /** Custom field id holding the Octane FEATURE id at subject level
         *  (tests are linked to this feature). Octane is queried for tests whose
         *  covered feature = this id. */
        private String octaneFeatureField;
        /** Project key(s) to scan for releases (fixVersions), comma separated. */
        private String projectKeys;
        /** Optional explicit release names (comma separated) if not using project versions. */
        private String releaseNames;
        /** Release auto-selected in the UI on load (e.g. STS-2026-X5). */
        private String defaultRelease;
        /** JQL template to find subjects of a release. {RELEASE} is substituted. */
        private String subjectJql = "issuetype = Epic AND fixVersion = \"{RELEASE}\" ORDER BY key ASC";
    }

    @Data
    public static class Octane {
        private String baseUrl;
        private String sharedSpaceId;
        private String workspaceId;
        private String clientId;
        private String clientSecret;
        /**
         * Client-type header sent with every Octane REST call. Without it (or with
         * the wrong value), Octane omits aggregate/reference fields such as
         * run_in_releases even when requested. HPE_MQM_UI mirrors what the Octane
         * browser UI sends (which is where the field IS visible); some integrations
         * use HPE_REST_API_TECH_PREVIEW instead.
         */
        private String clientType = "HPE_MQM_UI";
        /** Workspace config id used by the Jira octane-coverage REST API. */
        private String workspaceConfigId;
        /** Require all linked tests to have passed (not just exist). */
        private boolean requireRunsPassed = true;
        /**
         * Octane release name (as it appears in test run_in_releases). If set,
         * this is matched instead of the Jira release name — they often differ
         * (Jira "STS-2026-X5" vs Octane "STS-2026-R6").
         */
        private String releaseName;
        /**
         * When false, tests are NOT filtered by release (release assignment is
         * ignored; only presence + run status are checked). Default true.
         */
        private boolean checkReleaseAssignment = true;
        /**
         * When true, a test that is present but NOT attached to ANY release
         * (run_in_releases empty) is flagged as a hard problem ("no release tagged").
         * Default FALSE, because run_in_releases is not always returned reliably by
         * the /tests list API — enabling this without confirming the field populates
         * can produce false negatives on passing tests. Only turn on once the logs
         * confirm run_in_releases is present. A wrong-release tag is always flagged
         * regardless of this setting.
         */
        private boolean flagUntaggedTests = true;
        /**
         * Maps an Octane test_type name to an environment bucket, e.g.
         * "Unit Test": "DEV", "Acceptance": "UAT", "End to End": "BCM", "IST": "IST".
         */
        private java.util.Map<String, String> testTypeEnvMap = new java.util.LinkedHashMap<>();
    }

    @Data
    public static class SharePoint {
        private String baseUrl;
        private String authMode = "cookie"; // cookie | ntlm | basic
        private String username;
        private String password;
        private String domain;
        /** Cookie auth (SharePoint Online) — these expire ~weekly. */
        private String fedAuth;
        private String rtFa;
        private String libraryName = "Documents";
        private String rootPath = "/Releases/{RELEASE}/{EPIC}";
    }

    @Data
    public static class Proxy {
        /** When true, Octane + SharePoint calls route through this proxy. */
        private boolean enabled = false;
        private String host;
        private int port = 8080;
        private String user;
        private String pass;
        /** When true, trust all TLS certs (mirrors NODE_TLS_REJECT_UNAUTHORIZED=0). */
        private boolean trustAllSsl = false;
    }

    @Data
    public static class Mail {
        private String fromName = "Release Guardian";
        private String fromAddress;
        private String replyTo;
        private String fallbackTo;
        private String[] summaryTo = new String[0];
        private String[] managersCc = new String[0];
        /** BNP SecuredMail REST endpoint. Blank = emails are logged, not sent. */
        private String securedMailUrl;
    }

    @Data
    public static class Ai {
        /** When true, the company LLM rewrites email text before sending. */
        private boolean enabled = false;
        private String baseUrl;
        private String apiKey;
        private String apiKeyHeader;        // blank = use Bearer Authorization
        private String model = "gpt-oss-120b-ITG";
        private int timeoutMs = 15000;
    }

    @Data
    public static class Cors {
        /** Allowed origins for the API. Empty = allow all (dev). */
        private String[] allowedOrigins = new String[0];
    }

    @Data
    public static class ServiceNow {
        /** Off until you connect it. When false, the panel shows "Not configured". */
        private boolean enabled = false;
        /** BNP ServiceNow gateway base, e.g. https://data.itgp.api.group.echonet/servicenow/v2 */
        private String baseUrl;
        /** OAuth2 token endpoint, e.g. https://itgp.api.group.echonet/auth/oauth2/v2/token */
        private String tokenUrl;
        /** OAuth2 client-credentials for the /changes API. */
        private Oauth changes = new Oauth();
        /** OAuth2 client-credentials for the /attachments API. */
        private Oauth attachments = new Oauth();
        /** Environment to filter changes by (u_environment), e.g. "Production". */
        private String environment = "Production";
        /** Field on the change record carrying the release key (optional filter). */
        private String releaseField = "u_release";
        /**
         * ServiceNow UI base for building clickable deep links (NOT the API gateway).
         * Links are built as {uiBaseUrl}/nav_to.do?uri=change_request.do?sys_id=...
         * e.g. https://bnpp.service-now.com
         */
        private String uiBaseUrl = "https://bnpp.service-now.com";
        /**
         * Whether to also search the large `description` body (slow). Off by default
         * — short_description matching is fast and sufficient for these releases.
         */
        private boolean searchDescription = false;

        // --- legacy basic-auth fields (kept for backwards-compat / other flows) ---
        private String username;
        private String password;
        private String table = "change_request";

        public static class Oauth {
            private String consumerKey;
            private String consumerSecret;
            public String getConsumerKey() { return consumerKey; }
            public void setConsumerKey(String v) { this.consumerKey = v; }
            public String getConsumerSecret() { return consumerSecret; }
            public void setConsumerSecret(String v) { this.consumerSecret = v; }
        }
    }
}
