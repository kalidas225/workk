package com.bnpparibas.releasecockpit.service;

import com.bnpparibas.releasecockpit.model.Domain.Checkpoints;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseHealth;
import com.bnpparibas.releasecockpit.model.Domain.ReleaseSummary;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Computes a composite "release health" meter (0-100) from readiness.
 *
 * Health is driven ONLY by Octane and SharePoint readiness (the two gating
 * checks); the release timeline is deliberately excluded so health reflects
 * artifact/test completeness, not schedule.
 *
 * Weighting:
 *   - 50%  octane      (share of subjects with Octane fully covered)
 *   - 50%  sharepoint  (share of subjects SharePoint-complete)
 *
 * Grade / color bands:
 *   - >= 80  GOOD      (green)
 *   - >= 50  AT_RISK   (yellow)
 *   - <  50  CRITICAL  (red)
 */
@Service
public class HealthService {

    public ReleaseHealth compute(ReleaseSummary summary, Checkpoints checkpoints) {
        int total = Math.max(1, summary.totalSubjects());

        int readiness = pct(summary.ready(), total);
        int octane = pct(summary.readinessBreakdown().octaneOk(), total);
        int sharepoint = pct(summary.readinessBreakdown().sharepointOk(), total);

        // Octane + SharePoint only (50/50). Timeline intentionally excluded.
        int score = (int) Math.round(octane * 0.50 + sharepoint * 0.50);

        // Needs-attention subjects shave points: a release with any needs-attention
        // never reads a clean 100% — 2 points per subject (capped), min 98% impact.
        int needsAtt = summary.readinessBreakdown().needsAttention();
        if (needsAtt > 0) {
            score = Math.max(0, score - Math.min(20, needsAtt * 2));
            score = Math.min(score, 98);
        }

        List<String> risks = new ArrayList<>();
        if (octane < 80) risks.add("Octane coverage is " + octane + "% (" + summary.readinessBreakdown().octaneOk() + "/" + total + ")");
        if (sharepoint < 80) risks.add("SharePoint artifacts " + sharepoint + "% complete (" + summary.readinessBreakdown().sharepointOk() + "/" + total + ")");
        if (needsAtt > 0) risks.add(needsAtt + " subject(s) need attention (Octane runs)");
        if (summary.notReady() > 0) risks.add(summary.notReady() + " of " + total + " subjects still have gaps");
        if (risks.isEmpty()) risks.add("On track — Octane and SharePoint are complete");

        // timeline kept in the record for compatibility but always 100 (unused).
        return new ReleaseHealth(score, grade(score), readiness, octane, sharepoint, 100, risks);
    }

    private int pct(int part, int total) {
        return (int) Math.round((part * 100.0) / total);
    }

    private String grade(int score) {
        if (score >= 80) return "GOOD";       // green
        if (score >= 50) return "AT_RISK";    // yellow
        return "CRITICAL";                    // red
    }
}
