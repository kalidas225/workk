'use strict';

/**
 * Core readiness orchestrator.
 *
 * For each ACTIVE release:
 *   1. Pull its epics from Jira.
 *   2. For each epic, run every enabled artifact check:
 *        - sharepoint artifacts -> folder/file existence
 *        - octane artifact       -> linked test cases exist
 *   3. If anything is missing, email the responsible developer (once/day),
 *      then record it in Oracle.
 *
 * Parallel releases are handled by the DB layer: only releases whose
 * END_DATE has not passed are returned by getActiveReleases(), so a finished
 * release is silently dropped on the next run.
 */

const { config, loadArtifacts } = require('../config');
const logger = require('../logger');
const jira = require('../connectors/jira');
const octane = require('../connectors/octane');
const sharepoint = require('../connectors/sharepoint');
const oracle = require('../db/oracle');
const { sendMissingArtifactsEmail } = require('../email/mailer');

function expandPath(template, releaseName, epicKey) {
  return template.replace(/\{RELEASE\}/g, releaseName).replace(/\{EPIC\}/g, epicKey);
}

function jiraEpicUrl(epicKey) {
  return `${config.jira.baseUrl}/browse/${epicKey}`;
}

/**
 * Run all artifact checks for a single epic.
 * Returns an array of { key, label, present, detail }.
 */
async function checkEpic(release, epic) {
  const artifacts = loadArtifacts();
  const checks = [];

  for (const art of artifacts) {
    try {
      if (art.source === 'octane') {
        const res = await octane.countLinkedTestCases(epic.key);
        const present = res.count >= (art.minTestCases || 1);
        checks.push({
          key: art.key,
          label: art.label,
          present,
          detail: present
            ? `${res.count} linked test case(s)`
            : 'No Octane test cases linked to this Jira key',
        });
      } else if (art.source === 'sharepoint') {
        const root = expandPath(config.sharepoint.rootPath, release.name, epic.key);
        const folderPath = `${root}${art.folder}`;
        const res = await sharepoint.checkArtifactFolder(folderPath, art.match, art.minFiles);
        checks.push({
          key: art.key,
          label: art.label,
          present: res.present,
          detail: res.present
            ? `Found: ${res.matchedFiles.slice(0, 3).join(', ')}${res.matchedFiles.length > 3 ? '…' : ''}`
            : `No matching file in ${folderPath}`,
        });
      } else {
        logger.warn({ art }, 'Unknown artifact source, skipping');
      }
    } catch (err) {
      // A connector failure should not silently pass the check — mark missing.
      logger.error({ err: err.message, epic: epic.key, artifact: art.key }, 'Artifact check error');
      checks.push({
        key: art.key,
        label: art.label,
        present: false,
        detail: `Check failed: ${err.message}`,
      });
    }
  }
  return checks;
}

/**
 * Process one release end-to-end.
 * @returns summary object for reporting.
 */
async function processRelease(release, { dryRun }) {
  logger.info({ release: release.name, endDate: release.endDate }, 'Processing release');
  const epics = await jira.getReleaseEpics(release.name);

  const summary = { release: release.name, epics: [], emailsSent: 0, epicsWithGaps: 0 };

  for (const epic of epics) {
    const checks = await checkEpic(release, epic);
    const missing = checks.filter((c) => !c.present);
    const epicResult = {
      key: epic.key,
      developerEmail: epic.developerEmail,
      missing: missing.map((m) => m.key),
      total: checks.length,
    };

    if (missing.length === 0) {
      logger.info({ epic: epic.key }, 'All artifacts present');
      summary.epics.push(epicResult);
      continue;
    }

    summary.epicsWithGaps += 1;
    const to = epic.developerEmail || config.mail.fallbackTo;

    // Dedupe: don't re-email the same dev about the same epic the same day.
    const dup = await oracle.alreadyNotifiedToday(release.name, epic.key, to);
    if (dup) {
      logger.info({ epic: epic.key, to }, 'Already notified today, skipping email');
      epicResult.skippedDuplicate = true;
      summary.epics.push(epicResult);
      continue;
    }

    const sendRes = await sendMissingArtifactsEmail(
      {
        developerName: epic.developerName,
        developerEmail: epic.developerEmail,
        releaseName: release.name,
        epicKey: epic.key,
        epicSummary: epic.summary,
        epicUrl: jiraEpicUrl(epic.key),
        checks,
      },
      { dryRun }
    );

    if (sendRes.sent) {
      summary.emailsSent += 1;
      await oracle.recordNotification(release.name, epic.key, to, epicResult.missing);
    }
    epicResult.emailedTo = sendRes.to;
    summary.epics.push(epicResult);
  }

  logger.info(
    { release: release.name, epics: epics.length, gaps: summary.epicsWithGaps, emails: summary.emailsSent },
    'Release processed'
  );
  return summary;
}

/**
 * Main entry: check all active releases (or a single named release).
 * @param {object} opts
 * @param {boolean} opts.dryRun
 * @param {string}  [opts.releaseName] — if set, check only this release.
 */
async function runCheck(opts = {}) {
  const dryRun = opts.dryRun != null ? opts.dryRun : config.dryRun;

  let releases;
  if (opts.releaseName) {
    const r = await oracle.getReleaseByName(opts.releaseName);
    if (!r) throw new Error(`Release "${opts.releaseName}" not found in RG_RELEASES`);
    releases = [r];
  } else {
    releases = await oracle.getActiveReleases();
  }

  if (releases.length === 0) {
    logger.info('No active releases to process');
    return { releases: [], dryRun };
  }

  logger.info({ count: releases.length, dryRun }, 'Starting readiness check');
  const results = [];
  for (const release of releases) {
    // Process releases sequentially to keep API rate limits sane.
    // eslint-disable-next-line no-await-in-loop
    const s = await processRelease(release, { dryRun });
    results.push(s);
  }
  return { releases: results, dryRun };
}

module.exports = { runCheck, processRelease, checkEpic };
