'use strict';

/**
 * Oracle database layer.
 *
 * Responsibilities:
 *   - Read release definitions (name, start/end dates).
 *   - Provide the set of ACTIVE releases (parallel-safe via end dates).
 *   - Persist a notification log so we don't email the same person about the
 *     same missing artifact twice in the same day.
 *
 * Uses node-oracledb. Thin mode by default (no Oracle client needed) unless
 * ORACLE_CLIENT_LIB_DIR is set, in which case Thick mode is initialised.
 */

const oracledb = require('oracledb');
const { config } = require('../config');
const logger = require('../logger');

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = true;

if (config.oracle.clientLibDir) {
  try {
    oracledb.initOracleClient({ libDir: config.oracle.clientLibDir });
    logger.info('Initialised Oracle Thick client');
  } catch (e) {
    logger.warn({ err: e.message }, 'Could not init Thick client; continuing in Thin mode');
  }
}

let pool = null;

async function getPool() {
  if (pool) return pool;
  pool = await oracledb.createPool({
    user: config.oracle.user,
    password: config.oracle.password,
    connectString: config.oracle.connectString,
    poolMin: config.oracle.poolMin,
    poolMax: config.oracle.poolMax,
    poolIncrement: 1,
  });
  logger.info('Oracle connection pool created');
  return pool;
}

async function withConn(fn) {
  const p = await getPool();
  const conn = await p.getConnection();
  try {
    return await fn(conn);
  } finally {
    try {
      await conn.close();
    } catch (e) {
      logger.warn({ err: e.message }, 'Error closing Oracle connection');
    }
  }
}

/**
 * Return releases that are currently ACTIVE.
 *
 * A release is active when:
 *   START_DATE <= now  AND  (END_DATE IS NULL OR END_DATE >= now)
 *
 * This is what makes parallel releases safe: once a release's END_DATE has
 * passed, it is excluded automatically and we stop checking/emailing for it.
 */
async function getActiveReleases() {
  return withConn(async (conn) => {
    const sql = `
      SELECT RELEASE_ID, RELEASE_NAME, START_DATE, END_DATE
      FROM   RG_RELEASES
      WHERE  START_DATE <= SYSTIMESTAMP
        AND  (END_DATE IS NULL OR END_DATE >= SYSTIMESTAMP)
      ORDER BY END_DATE NULLS LAST, RELEASE_NAME`;
    const result = await conn.execute(sql);
    return (result.rows || []).map((r) => ({
      id: r.RELEASE_ID,
      name: r.RELEASE_NAME,
      startDate: r.START_DATE,
      endDate: r.END_DATE,
    }));
  });
}

/**
 * Fetch a single release by name (active or not) — used by --release CLI flag.
 */
async function getReleaseByName(name) {
  return withConn(async (conn) => {
    const sql = `
      SELECT RELEASE_ID, RELEASE_NAME, START_DATE, END_DATE
      FROM   RG_RELEASES
      WHERE  RELEASE_NAME = :name`;
    const result = await conn.execute(sql, { name });
    const r = (result.rows || [])[0];
    if (!r) return null;
    return { id: r.RELEASE_ID, name: r.RELEASE_NAME, startDate: r.START_DATE, endDate: r.END_DATE };
  });
}

/**
 * Has this exact (release, epic, developer) already been notified today?
 * Prevents duplicate spam if the job runs more than once a day.
 */
async function alreadyNotifiedToday(releaseName, epicKey, developerEmail) {
  return withConn(async (conn) => {
    const sql = `
      SELECT COUNT(*) AS CNT
      FROM   RG_NOTIFICATION_LOG
      WHERE  RELEASE_NAME = :releaseName
        AND  EPIC_KEY     = :epicKey
        AND  DEVELOPER_EMAIL = :developerEmail
        AND  TRUNC(SENT_AT) = TRUNC(SYSTIMESTAMP)`;
    const result = await conn.execute(sql, { releaseName, epicKey, developerEmail });
    return (result.rows[0].CNT || 0) > 0;
  });
}

/**
 * Record that a notification was sent.
 */
async function recordNotification(releaseName, epicKey, developerEmail, missingKeys) {
  return withConn(async (conn) => {
    const sql = `
      INSERT INTO RG_NOTIFICATION_LOG
        (RELEASE_NAME, EPIC_KEY, DEVELOPER_EMAIL, MISSING_ARTIFACTS, SENT_AT)
      VALUES
        (:releaseName, :epicKey, :developerEmail, :missingArtifacts, SYSTIMESTAMP)`;
    await conn.execute(sql, {
      releaseName,
      epicKey,
      developerEmail,
      missingArtifacts: (missingKeys || []).join(','),
    });
  });
}

async function close() {
  if (pool) {
    await pool.close(5);
    pool = null;
    logger.info('Oracle pool closed');
  }
}

module.exports = {
  getActiveReleases,
  getReleaseByName,
  alreadyNotifiedToday,
  recordNotification,
  withConn,
  close,
};
