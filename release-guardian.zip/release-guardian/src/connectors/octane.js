'use strict';

/**
 * OpenText / Micro Focus ALM Octane connector.
 *
 * Authenticates with API client credentials (cookie-based session), then
 * checks whether any test cases are linked to a given Jira key.
 *
 * Two linking strategies (set OCTANE_LINK_STRATEGY):
 *   "field" -> a string field/UDF on the test case equals/contains the Jira key.
 *   "tag"   -> the test case carries a tag whose name equals the Jira key.
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../logger');

let cookieJar = null; // Octane uses a LWSSO_COOKIE_KEY session cookie.

function api() {
  const instance = axios.create({
    baseURL: config.octane.baseUrl,
    timeout: 30000,
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
  });
  instance.interceptors.request.use((cfg) => {
    if (cookieJar) cfg.headers.Cookie = cookieJar;
    return cfg;
  });
  return instance;
}

/**
 * Sign in. Octane returns a session cookie we reuse for subsequent calls.
 */
async function authenticate() {
  if (cookieJar) return;
  const resp = await axios.post(
    `${config.octane.baseUrl}/authentication/sign_in`,
    { client_id: config.octane.clientId, client_secret: config.octane.clientSecret },
    { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
  );
  const setCookie = resp.headers['set-cookie'] || [];
  cookieJar = setCookie.map((c) => c.split(';')[0]).join('; ');
  if (!cookieJar) throw new Error('Octane authentication did not return a session cookie');
  logger.info('Authenticated with Octane');
}

function wsBase() {
  return `/api/shared_spaces/${config.octane.sharedSpaceId}/workspaces/${config.octane.workspaceId}`;
}

/**
 * Octane query language uses a specific quoting format. We escape quotes.
 */
function q(value) {
  return String(value).replace(/"/g, '\\"');
}

/**
 * Count test cases linked to a Jira key. Returns { count, sample: [...] }.
 */
async function countLinkedTestCases(jiraKey) {
  await authenticate();
  const instance = api();

  let query;
  if (config.octane.linkStrategy === 'tag') {
    // Test cases that have a user_tag with the given name.
    query = `"user_tags={name='${q(jiraKey)}'}"`;
  } else {
    // Field strategy: a UDF/string field equals the Jira key.
    const field = config.octane.jiraKeyField;
    query = `"${field}='${q(jiraKey)}'"`;
  }

  const url = `${wsBase()}/test_cases`;
  try {
    const resp = await instance.get(url, {
      params: { query, fields: 'id,name', limit: 50 },
    });
    const data = resp.data || {};
    const items = data.data || [];
    return {
      count: typeof data.total_count === 'number' ? data.total_count : items.length,
      sample: items.slice(0, 5).map((t) => ({ id: t.id, name: t.name })),
    };
  } catch (err) {
    const status = err.response && err.response.status;
    // A 401 likely means the session expired — retry once.
    if (status === 401) {
      cookieJar = null;
      await authenticate();
      const resp = await api().get(url, { params: { query, fields: 'id,name', limit: 50 } });
      const data = resp.data || {};
      const items = data.data || [];
      return {
        count: typeof data.total_count === 'number' ? data.total_count : items.length,
        sample: items.slice(0, 5).map((t) => ({ id: t.id, name: t.name })),
      };
    }
    logger.error({ err: err.message, status, jiraKey }, 'Octane test-case lookup failed');
    throw err;
  }
}

module.exports = { authenticate, countLinkedTestCases };
