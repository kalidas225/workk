'use strict';

/**
 * SharePoint connector via Microsoft Graph API.
 *
 * Uses the OAuth2 client-credentials flow (app registration) to get a token,
 * resolves the site + drive once, then lists files in a given folder path and
 * tells you whether files matching a rule exist.
 */

const axios = require('axios');
const { config } = require('../config');
const logger = require('../logger');

const GRAPH = 'https://graph.microsoft.com/v1.0';
const LOGIN = 'https://login.microsoftonline.com';

let token = null;
let tokenExpiresAt = 0;
let cachedSiteId = null;
let cachedDriveId = null;

/**
 * Acquire (and cache) an app-only Graph token.
 */
async function getToken() {
  const now = Date.now();
  if (token && now < tokenExpiresAt - 60000) return token;

  const url = `${LOGIN}/${config.graph.tenantId}/oauth2/v2.0/token`;
  const params = new URLSearchParams();
  params.append('client_id', config.graph.clientId);
  params.append('client_secret', config.graph.clientSecret);
  params.append('scope', 'https://graph.microsoft.com/.default');
  params.append('grant_type', 'client_credentials');

  const resp = await axios.post(url, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    timeout: 30000,
  });
  token = resp.data.access_token;
  tokenExpiresAt = now + (resp.data.expires_in || 3600) * 1000;
  logger.info('Acquired Microsoft Graph token');
  return token;
}

function graph() {
  const instance = axios.create({ baseURL: GRAPH, timeout: 30000 });
  instance.interceptors.request.use(async (cfg) => {
    const t = await getToken();
    cfg.headers.Authorization = `Bearer ${t}`;
    return cfg;
  });
  return instance;
}

/**
 * Resolve the site id from hostname + server-relative path. Cached.
 */
async function getSiteId() {
  if (cachedSiteId) return cachedSiteId;
  const g = graph();
  const path = config.sharepoint.sitePath.replace(/^\//, '');
  const resp = await g.get(`/sites/${config.sharepoint.hostname}:/${path}`);
  cachedSiteId = resp.data.id;
  logger.info({ siteId: cachedSiteId }, 'Resolved SharePoint site');
  return cachedSiteId;
}

/**
 * Resolve the drive (document library) id by display name. Cached.
 */
async function getDriveId() {
  if (cachedDriveId) return cachedDriveId;
  const g = graph();
  const siteId = await getSiteId();
  const resp = await g.get(`/sites/${siteId}/drives`);
  const drives = resp.data.value || [];
  const wanted = config.sharepoint.libraryName.toLowerCase();
  const drive = drives.find((d) => (d.name || '').toLowerCase() === wanted) || drives[0];
  if (!drive) throw new Error('No document library (drive) found on the site');
  cachedDriveId = drive.id;
  logger.info({ driveId: cachedDriveId, library: drive.name }, 'Resolved SharePoint library');
  return cachedDriveId;
}

/**
 * List the immediate children (files + folders) of a folder path.
 * Returns [] if the folder does not exist (so a missing folder = missing artifact).
 */
async function listFolder(folderPath) {
  const g = graph();
  const driveId = await getDriveId();
  // Encode each path segment but keep slashes.
  const clean = folderPath.replace(/^\/+|\/+$/g, '');
  const encoded = clean
    .split('/')
    .map((s) => encodeURIComponent(s))
    .join('/');
  const url = clean
    ? `/drives/${driveId}/root:/${encoded}:/children`
    : `/drives/${driveId}/root/children`;

  try {
    const items = [];
    let next = `${url}?$top=200`;
    while (next) {
      // eslint-disable-next-line no-await-in-loop
      const resp = await g.get(next.startsWith('http') ? next.replace(GRAPH, '') : next);
      for (const it of resp.data.value || []) items.push(it);
      next = resp.data['@odata.nextLink'] || null;
    }
    return items;
  } catch (err) {
    const status = err.response && err.response.status;
    if (status === 404) {
      logger.warn({ folderPath }, 'SharePoint folder not found (treated as empty)');
      return [];
    }
    logger.error({ err: err.message, status, folderPath }, 'SharePoint listing failed');
    throw err;
  }
}

/**
 * Decide whether a file item satisfies a match rule.
 */
function fileMatches(item, match) {
  if (item.folder) return false; // It's a folder, not a file.
  const name = (item.name || '').toLowerCase();

  const extOk = (exts) => {
    if (!exts || exts.length === 0) return true;
    return exts.some((e) => name.endsWith(e.toLowerCase()));
  };

  if (!match || match.type === 'extension') {
    return extOk(match && match.extensions);
  }
  if (match.type === 'nameContains') {
    const all = (match.all || []).every((sub) => name.includes(String(sub).toLowerCase()));
    return all && extOk(match.extensions);
  }
  if (match.type === 'regex') {
    try {
      const re = new RegExp(match.pattern, match.flags || 'i');
      return re.test(item.name || '');
    } catch (e) {
      logger.error({ pattern: match.pattern }, 'Invalid regex in artifacts.json');
      return false;
    }
  }
  return false;
}

/**
 * Check one artifact folder. Returns { present, matchedFiles, total, folderPath }.
 */
async function checkArtifactFolder(folderPath, match, minFiles = 1) {
  const items = await listFolder(folderPath);
  const matched = items.filter((it) => fileMatches(it, match));
  return {
    present: matched.length >= (minFiles || 1),
    matchedFiles: matched.map((m) => m.name),
    total: items.length,
    folderPath,
  };
}

module.exports = { checkArtifactFolder, listFolder, getSiteId, getDriveId };
