'use strict';

/**
 * Central configuration. Reads .env once, exposes a typed config object,
 * and can validate that required values are present.
 *
 * Nothing else in the codebase should read process.env directly.
 */

const path = require('path');
const fs = require('fs');
require('dotenv').config();

function bool(v, def = false) {
  if (v === undefined || v === null || v === '') return def;
  return String(v).toLowerCase() === 'true';
}

function int(v, def) {
  const n = parseInt(v, 10);
  return Number.isNaN(n) ? def : n;
}

function list(v) {
  if (!v) return [];
  return String(v)
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

const config = {
  env: process.env.NODE_ENV || 'development',
  port: int(process.env.PORT, 8080),
  log: {
    level: process.env.LOG_LEVEL || 'info',
    pretty: bool(process.env.LOG_PRETTY, false),
  },
  cron: {
    schedule: process.env.CRON_SCHEDULE || '0 7 * * 1-5',
    tz: process.env.CRON_TZ || 'UTC',
    enabled: bool(process.env.CRON_ENABLED, true),
  },
  dryRun: bool(process.env.DRY_RUN, false),

  jira: {
    baseUrl: (process.env.JIRA_BASE_URL || '').replace(/\/+$/, ''),
    authMode: (process.env.JIRA_AUTH_MODE || 'basic').toLowerCase(),
    email: process.env.JIRA_EMAIL || '',
    apiToken: process.env.JIRA_API_TOKEN || '',
    pat: process.env.JIRA_PAT || '',
    epicJql: process.env.JIRA_EPIC_JQL || 'issuetype = Epic AND fixVersion = "{RELEASE}"',
    developerField: process.env.JIRA_DEVELOPER_FIELD || 'assignee',
    octaneLinkField: process.env.JIRA_OCTANE_LINK_FIELD || '',
  },

  octane: {
    baseUrl: (process.env.OCTANE_BASE_URL || '').replace(/\/+$/, ''),
    sharedSpaceId: process.env.OCTANE_SHARED_SPACE_ID || '',
    workspaceId: process.env.OCTANE_WORKSPACE_ID || '',
    clientId: process.env.OCTANE_CLIENT_ID || '',
    clientSecret: process.env.OCTANE_CLIENT_SECRET || '',
    linkStrategy: (process.env.OCTANE_LINK_STRATEGY || 'field').toLowerCase(),
    jiraKeyField: process.env.OCTANE_JIRA_KEY_FIELD || 'jira_key_udf',
  },

  graph: {
    tenantId: process.env.GRAPH_TENANT_ID || '',
    clientId: process.env.GRAPH_CLIENT_ID || '',
    clientSecret: process.env.GRAPH_CLIENT_SECRET || '',
  },

  sharepoint: {
    hostname: process.env.SHAREPOINT_HOSTNAME || '',
    sitePath: process.env.SHAREPOINT_SITE_PATH || '',
    libraryName: process.env.SHAREPOINT_LIBRARY_NAME || 'Documents',
    rootPath: process.env.SHAREPOINT_ROOT_PATH || '/Releases/{RELEASE}/{EPIC}',
  },

  oracle: {
    user: process.env.ORACLE_USER || '',
    password: process.env.ORACLE_PASSWORD || '',
    connectString: process.env.ORACLE_CONNECT_STRING || '',
    poolMin: int(process.env.ORACLE_POOL_MIN, 1),
    poolMax: int(process.env.ORACLE_POOL_MAX, 4),
    clientLibDir: process.env.ORACLE_CLIENT_LIB_DIR || '',
  },

  mail: {
    host: process.env.SMTP_HOST || '',
    port: int(process.env.SMTP_PORT, 587),
    secure: bool(process.env.SMTP_SECURE, false),
    user: process.env.SMTP_USER || '',
    password: process.env.SMTP_PASSWORD || '',
    rejectUnauthorized: bool(process.env.SMTP_TLS_REJECT_UNAUTHORIZED, true),
    fromName: process.env.MAIL_FROM_NAME || 'Release Guardian',
    fromAddress: process.env.MAIL_FROM_ADDRESS || '',
    replyTo: process.env.MAIL_REPLY_TO || '',
    cc: list(process.env.MAIL_CC),
    bcc: list(process.env.MAIL_BCC),
    fallbackTo: process.env.MAIL_FALLBACK_TO || '',
    subjectTemplate:
      process.env.MAIL_SUBJECT_TEMPLATE ||
      '[Release {RELEASE}] Action needed on {EPIC} — {MISSING_COUNT} item(s) missing',
    companyName: process.env.COMPANY_NAME || 'Your Company',
    companyLogoUrl: process.env.COMPANY_LOGO_URL || '',
    portalUrl: process.env.RELEASE_PORTAL_URL || '',
  },
};

/**
 * Load the artifact definitions (config/artifacts.json).
 * Cached after first read.
 */
let _artifacts = null;
function loadArtifacts() {
  if (_artifacts) return _artifacts;
  const p = path.join(__dirname, '..', 'config', 'artifacts.json');
  const raw = fs.readFileSync(p, 'utf8');
  const parsed = JSON.parse(raw);
  _artifacts = (parsed.artifacts || []).filter((a) => a.enabled !== false);
  return _artifacts;
}

/**
 * Validate that the values needed for a real run are present.
 * Returns { ok: boolean, problems: string[] }.
 */
function validate() {
  const problems = [];
  const need = (cond, msg) => {
    if (!cond) problems.push(msg);
  };

  need(config.jira.baseUrl, 'JIRA_BASE_URL is empty');
  if (config.jira.authMode === 'basic') {
    need(config.jira.email, 'JIRA_EMAIL is empty (basic auth)');
    need(config.jira.apiToken, 'JIRA_API_TOKEN is empty (basic auth)');
  } else {
    need(config.jira.pat, 'JIRA_PAT is empty (bearer auth)');
  }

  need(config.octane.baseUrl, 'OCTANE_BASE_URL is empty');
  need(config.octane.sharedSpaceId, 'OCTANE_SHARED_SPACE_ID is empty');
  need(config.octane.workspaceId, 'OCTANE_WORKSPACE_ID is empty');
  need(config.octane.clientId, 'OCTANE_CLIENT_ID is empty');
  need(config.octane.clientSecret, 'OCTANE_CLIENT_SECRET is empty');

  need(config.graph.tenantId, 'GRAPH_TENANT_ID is empty');
  need(config.graph.clientId, 'GRAPH_CLIENT_ID is empty');
  need(config.graph.clientSecret, 'GRAPH_CLIENT_SECRET is empty');
  need(config.sharepoint.hostname, 'SHAREPOINT_HOSTNAME is empty');
  need(config.sharepoint.sitePath, 'SHAREPOINT_SITE_PATH is empty');

  need(config.oracle.user, 'ORACLE_USER is empty');
  need(config.oracle.password, 'ORACLE_PASSWORD is empty');
  need(config.oracle.connectString, 'ORACLE_CONNECT_STRING is empty');

  need(config.mail.host, 'SMTP_HOST is empty');
  need(config.mail.fromAddress, 'MAIL_FROM_ADDRESS is empty');

  return { ok: problems.length === 0, problems };
}

module.exports = { config, loadArtifacts, validate };
