'use strict';

/**
 * HTTP server + cron scheduler. This is the process that runs on the
 * IBM Cloud pod.
 *
 * Endpoints:
 *   GET  /healthz                 -> liveness/readiness probe
 *   POST /run                     -> trigger a check now (body: {dryRun, release})
 *   GET  /run                     -> same as POST for convenience (query params)
 *
 * Cron:
 *   Runs runCheck() on the configured schedule when CRON_ENABLED=true.
 */

const express = require('express');
const cron = require('node-cron');
const { config } = require('./config');
const logger = require('./logger');
const { runCheck } = require('./core/checker');
const oracle = require('./db/oracle');

const app = express();
app.use(express.json());

// Prevent overlapping runs (cron + manual).
let running = false;

async function guardedRun(opts) {
  if (running) {
    logger.warn('A check is already running; ignoring this trigger');
    return { skipped: true, reason: 'already-running' };
  }
  running = true;
  try {
    return await runCheck(opts);
  } finally {
    running = false;
  }
}

app.get('/healthz', (req, res) => {
  res.json({ status: 'ok', running, time: new Date().toISOString() });
});

app.post('/run', async (req, res) => {
  const dryRun = req.body && req.body.dryRun === true;
  const releaseName = req.body && req.body.release;
  try {
    const result = await guardedRun({ dryRun, releaseName });
    res.json({ ok: true, result });
  } catch (e) {
    logger.error({ err: e.message }, 'Manual run failed');
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.get('/run', async (req, res) => {
  const dryRun = req.query.dryRun === 'true';
  const releaseName = req.query.release;
  try {
    const result = await guardedRun({ dryRun, releaseName });
    res.json({ ok: true, result });
  } catch (e) {
    logger.error({ err: e.message }, 'Manual run failed');
    res.status(500).json({ ok: false, error: e.message });
  }
});

const server = app.listen(config.port, () => {
  logger.info({ port: config.port, env: config.env }, 'Release Guardian server listening');

  if (config.cron.enabled) {
    if (!cron.validate(config.cron.schedule)) {
      logger.error({ schedule: config.cron.schedule }, 'Invalid CRON_SCHEDULE; scheduler not started');
      return;
    }
    cron.schedule(
      config.cron.schedule,
      async () => {
        logger.info('Cron trigger fired');
        try {
          await guardedRun({ dryRun: config.dryRun });
        } catch (e) {
          logger.error({ err: e.message }, 'Scheduled run failed');
        }
      },
      { timezone: config.cron.tz }
    );
    logger.info({ schedule: config.cron.schedule, tz: config.cron.tz }, 'Cron scheduler started');
  } else {
    logger.info('Cron disabled (CRON_ENABLED=false); use POST /run to trigger');
  }
});

// Graceful shutdown for Kubernetes/IBM Cloud.
async function shutdown(sig) {
  logger.info({ sig }, 'Shutting down');
  server.close(async () => {
    await oracle.close().catch(() => {});
    process.exit(0);
  });
  // Hard exit after 10s if something hangs.
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = app;
