'use strict';

/**
 * Builds the HTML + plain-text bodies for the "missing artifacts" alert.
 *
 * The template is intentionally inline-styled and table-based so it renders
 * consistently across Outlook / EMA clients (which strip <style> and flexbox).
 */

const { config } = require('../config');

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/**
 * @param {object} p
 * @param {string} p.developerName
 * @param {string} p.releaseName
 * @param {string} p.epicKey
 * @param {string} p.epicSummary
 * @param {string} p.epicUrl
 * @param {Array}  p.checks  full list of { key, label, present, detail }
 */
function buildEmail(p) {
  const missing = p.checks.filter((c) => !c.present);
  const present = p.checks.filter((c) => c.present);
  const brand = '#0b5fff';
  const danger = '#d92d20';
  const ok = '#067647';
  const ink = '#1f2937';
  const muted = '#6b7280';
  const line = '#e5e7eb';
  const bg = '#f3f4f6';

  const logo = config.mail.companyLogoUrl
    ? `<img src="${esc(config.mail.companyLogoUrl)}" alt="${esc(config.mail.companyName)}" height="28" style="display:block;border:0;outline:none;">`
    : `<span style="font-size:18px;font-weight:700;color:#ffffff;">${esc(config.mail.companyName)}</span>`;

  const rowsMissing = missing
    .map(
      (c) => `
      <tr>
        <td style="padding:10px 14px;border-bottom:1px solid ${line};vertical-align:top;width:26px;">
          <span style="display:inline-block;width:18px;height:18px;border-radius:50%;background:${danger};color:#fff;text-align:center;font-size:12px;line-height:18px;">&#10005;</span>
        </td>
        <td style="padding:10px 14px;border-bottom:1px solid ${line};">
          <div style="font-size:14px;font-weight:600;color:${ink};">${esc(c.label)}</div>
          <div style="font-size:12px;color:${muted};margin-top:2px;">${esc(c.detail || 'Not found')}</div>
        </td>
      </tr>`
    )
    .join('');

  const rowsPresent = present
    .map(
      (c) => `
      <tr>
        <td style="padding:8px 14px;border-bottom:1px solid ${line};vertical-align:top;width:26px;">
          <span style="display:inline-block;width:18px;height:18px;border-radius:50%;background:${ok};color:#fff;text-align:center;font-size:12px;line-height:18px;">&#10003;</span>
        </td>
        <td style="padding:8px 14px;border-bottom:1px solid ${line};">
          <div style="font-size:13px;color:${ink};">${esc(c.label)}</div>
        </td>
      </tr>`
    )
    .join('');

  const portalBtn = config.mail.portalUrl
    ? `<a href="${esc(config.mail.portalUrl)}" style="display:inline-block;background:${brand};color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;padding:11px 22px;border-radius:8px;">Open Release Portal</a>`
    : '';

  const epicLink = p.epicUrl
    ? `<a href="${esc(p.epicUrl)}" style="color:${brand};text-decoration:none;font-weight:600;">${esc(p.epicKey)}</a>`
    : `<span style="font-weight:600;">${esc(p.epicKey)}</span>`;

  const html = `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Release readiness</title></head>
<body style="margin:0;padding:0;background:${bg};">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${bg};padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="width:600px;max-width:92%;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid ${line};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">

        <tr><td style="background:${brand};padding:18px 24px;">${logo}</td></tr>

        <tr><td style="padding:24px 24px 8px 24px;">
          <div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:${muted};font-weight:700;">Release readiness check</div>
          <div style="font-size:22px;font-weight:700;color:${ink};margin-top:6px;">Action needed on ${esc(p.epicKey)}</div>
          <p style="font-size:14px;color:${ink};line-height:1.55;margin:14px 0 0 0;">
            Hi ${esc(p.developerName || 'there')}, the readiness check for release
            <strong>${esc(p.releaseName)}</strong> found <strong style="color:${danger};">${missing.length}</strong>
            required item(s) missing on epic ${epicLink}${p.epicSummary ? ` — <em style="color:${muted};">${esc(p.epicSummary)}</em>` : ''}.
            Please address the items below.
          </p>
        </td></tr>

        <tr><td style="padding:16px 24px 0 24px;">
          <div style="font-size:13px;font-weight:700;color:${danger};margin-bottom:6px;">Missing (${missing.length})</div>
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid ${line};border-radius:10px;overflow:hidden;">
            ${rowsMissing || `<tr><td style="padding:12px 14px;color:${muted};font-size:13px;">Nothing missing.</td></tr>`}
          </table>
        </td></tr>

        ${
          present.length
            ? `<tr><td style="padding:18px 24px 0 24px;">
                 <div style="font-size:13px;font-weight:700;color:${ok};margin-bottom:6px;">Already in place (${present.length})</div>
                 <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid ${line};border-radius:10px;overflow:hidden;">
                   ${rowsPresent}
                 </table>
               </td></tr>`
            : ''
        }

        ${
          portalBtn
            ? `<tr><td align="center" style="padding:24px;">${portalBtn}</td></tr>`
            : `<tr><td style="height:24px;"></td></tr>`
        }

        <tr><td style="padding:16px 24px;background:#fafafa;border-top:1px solid ${line};">
          <p style="margin:0;font-size:11px;color:${muted};line-height:1.5;">
            This is an automated message from ${esc(config.mail.companyName)} Release Guardian.
            You received it because you are the responsible developer for ${esc(p.epicKey)} in release ${esc(p.releaseName)}.
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;

  const textLines = [];
  textLines.push(`Release readiness check — ${p.releaseName}`);
  textLines.push('');
  textLines.push(`Hi ${p.developerName || 'there'},`);
  textLines.push('');
  textLines.push(
    `Epic ${p.epicKey}${p.epicSummary ? ` (${p.epicSummary})` : ''} is missing ${missing.length} required item(s):`
  );
  for (const c of missing) textLines.push(`  [X] ${c.label} — ${c.detail || 'Not found'}`);
  if (present.length) {
    textLines.push('');
    textLines.push('Already in place:');
    for (const c of present) textLines.push(`  [OK] ${c.label}`);
  }
  if (config.mail.portalUrl) {
    textLines.push('');
    textLines.push(`Release portal: ${config.mail.portalUrl}`);
  }
  textLines.push('');
  textLines.push(`— ${config.mail.companyName} Release Guardian (automated)`);

  return { html, text: textLines.join('\n') };
}

module.exports = { buildEmail };
