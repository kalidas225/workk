'use strict';

const pino = require('pino');
const { config } = require('./config');

const options = { level: config.log.level };

if (config.log.pretty) {
  options.transport = {
    target: 'pino-pretty',
    options: { colorize: true, translateTime: 'SYS:standard', ignore: 'pid,hostname' },
  };
}

const logger = pino(options);

module.exports = logger;
