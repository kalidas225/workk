# Release Guardian

A release-readiness checker for teams that ship via **Jira release epics**.

For every epic in an active release, Release Guardian verifies that:

1. **Octane test cases** exist and are linked to the Jira key.
2. The required **SharePoint artifacts** are present, across six folders:
   - `PR` – the Pull Request document
   - `UnitTest` – unit test evidence
   - `Estimation` – the estimation sheet
   - `PRExcel` – the PR tracking Excel sheet (separate from the PR doc)
   - `OctaneReview` – the Octane test-case **review** document
   - `OctaneExecution` – the Octane test-case **execution** document

If **even one** item is missing, it emails the responsible developer an
attractive, branded summary of exactly what's missing — and what's already done.

It is **parallel-release safe**: it only looks at releases whose **end date has
not passed**, so finished releases are dropped automatically.

---

## Table of contents

- [How it works](#how-it-works)
- [Prerequisites](#prerequisites)
- [Quick start](#quick-start)
- [Configuration — every placeholder explained](#configuration--every-placeholder-explained)
  - [The `.env` file](#the-env-file)
  - [The `config/artifacts.json` file](#the-configartifactsjson-file)
- [Setting up the From / To emails and the template](#setting-up-the-from--to-emails-and-the-template)
- [The Oracle database](#the-oracle-database)
- [Running it](#running-it)
- [Deploying to IBM Cloud](#deploying-to-ibm-cloud)
- [How parallel releases are handled](#how-parallel-releases-are-handled)
- [Linking Octane test cases to Jira](#linking-octane-test-cases-to-jira)
- [Troubleshooting](#troubleshooting)
- [Project layout](#project-layout)

---

## How it works

```
                ┌──────────────┐
   cron / REST  │  checker.js  │
   ───────────▶ │ (orchestrator)│
                └──────┬───────┘
                       │ 1. active releases (END_DATE not passed)
              ┌────────▼─────────┐
              │   Oracle (DB)    │  RG_RELEASES, RG_NOTIFICATION_LOG
              └────────┬─────────┘
                       │ 2. epics for each release
              ┌────────▼─────────┐
              │      Jira        │  JQL → epics + developer email
              └────────┬─────────┘
        3. per epic, check each artifact
        ┌──────────────┼───────────────┐
   ┌────▼────┐    ┌─────▼──────┐   ┌────▼─────┐
   │ Octane  │    │ SharePoint │   │  (more)  │
   │ tests   │    │ via Graph  │   │          │
   └────┬────┘    └─────┬──────┘   └──────────┘
        └──────────────┬┘
              4. if anything missing
              ┌────────▼─────────┐
              │  SMTP (EMA relay)│  → email developer, log in Oracle
              └──────────────────┘
```

---

## Prerequisites

- **Node.js 18+** (Node 20 recommended; the Docker image uses Node 20).
- A **Jira** account/token that can run JQL and read epics.
- An **Octane** API client id/secret with read access to the workspace.
- An **Azure AD app registration** with Microsoft Graph **application**
  permission `Sites.Read.All` (admin-consented) for SharePoint access.
- An **Oracle** schema you can create two tables in.
- Access to your **EMA SMTP relay** for sending mail.

> `node-oracledb` runs in **Thin mode** by default — you do **not** need to
> install the Oracle Instant Client. Only set `ORACLE_CLIENT_LIB_DIR` if you
> specifically need Thick mode.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Create your config from the template
cp .env.example .env
#    …then edit .env (see the next section for every field).

# 3. Create the database tables
npm run init:db

# 4. Add at least one release row (see "The Oracle database" below)

# 5. Check connectivity to every system
npm run test:config        # = node src/cli.js validate-config

# 6. Do a DRY RUN first — computes everything, sends NO email
npm run check:dry          # = node src/cli.js run --dry-run

# 7. When happy, run for real
npm run check              # = node src/cli.js run
```

---

## Configuration — every placeholder explained

There are **two** files you edit. Nothing else needs touching for normal use.

### The `.env` file

Copy `.env.example` to `.env` and replace every value to the right of `=`.
Below is what each one means. (The `.env.example` file itself also has inline
comments.)

#### General / runtime

| Variable | What to put | Example |
|---|---|---|
| `PORT` | Port the REST API listens on | `8080` |
| `LOG_LEVEL` | `trace`/`debug`/`info`/`warn`/`error` | `info` |
| `LOG_PRETTY` | `true` for readable local logs, `false` in prod | `false` |
| `CRON_SCHEDULE` | 5-field cron for the daily check | `0 7 * * 1-5` |
| `CRON_TZ` | Timezone for the cron | `Asia/Kolkata` |
| `CRON_ENABLED` | `true` to auto-run on schedule | `true` |
| `DRY_RUN` | `true` = never send mail (safe default for first runs) | `false` |

#### Jira

| Variable | What to put |
|---|---|
| `JIRA_BASE_URL` | Base URL, **no trailing slash**. Cloud: `https://you.atlassian.net` |
| `JIRA_AUTH_MODE` | `basic` (Cloud: email + token) or `bearer` (Data Center PAT) |
| `JIRA_EMAIL` | Service-account email (basic auth only) |
| `JIRA_API_TOKEN` | API token from id.atlassian.com (basic auth only) |
| `JIRA_PAT` | Personal Access Token (bearer auth only) |
| `JIRA_EPIC_JQL` | JQL that finds the release epics. `{RELEASE}` is replaced at runtime |
| `JIRA_DEVELOPER_FIELD` | Where the responsible dev is. `assignee`, or a `customfield_XXXXX` |
| `JIRA_OCTANE_LINK_FIELD` | *(optional)* epic field holding Octane IDs |

> **Tip on `JIRA_EPIC_JQL`:** the default is
> `issuetype = Epic AND fixVersion = "{RELEASE}" ORDER BY key ASC`.
> If your releases aren't tracked by `fixVersion`, change this to match — e.g.
> a custom field: `issuetype = Epic AND "Target Release" = "{RELEASE}"`.
> The release name comes from the `RELEASE_NAME` column in Oracle, so the two
> must agree.

#### Octane

| Variable | What to put |
|---|---|
| `OCTANE_BASE_URL` | e.g. `https://octane.yourco.com` |
| `OCTANE_SHARED_SPACE_ID` | Number from the Octane URL `p=<shared>/<workspace>` |
| `OCTANE_WORKSPACE_ID` | The workspace number |
| `OCTANE_CLIENT_ID` / `OCTANE_CLIENT_SECRET` | API Access keys (Octane → Settings → API Access) |
| `OCTANE_LINK_STRATEGY` | `field` (a UDF holds the Jira key) or `tag` (a tag = the Jira key) |
| `OCTANE_JIRA_KEY_FIELD` | If strategy=`field`, the UDF name, e.g. `jira_key_udf` |

#### SharePoint (Microsoft Graph)

| Variable | What to put |
|---|---|
| `GRAPH_TENANT_ID` | Azure AD tenant id |
| `GRAPH_CLIENT_ID` | App registration (client) id |
| `GRAPH_CLIENT_SECRET` | App registration client secret |
| `SHAREPOINT_HOSTNAME` | e.g. `yourco.sharepoint.com` |
| `SHAREPOINT_SITE_PATH` | e.g. `/sites/Releases` |
| `SHAREPOINT_LIBRARY_NAME` | The document library display name, usually `Documents` |
| `SHAREPOINT_ROOT_PATH` | Folder root per epic. `{RELEASE}` and `{EPIC}` are replaced at runtime |

> The full path checked for, say, the PR folder is
> `SHAREPOINT_ROOT_PATH` + the artifact's `folder` from `artifacts.json`.
> With the defaults that's `/Releases/25.07/REL-1042/PR`.

#### Oracle

| Variable | What to put |
|---|---|
| `ORACLE_USER` / `ORACLE_PASSWORD` | DB credentials |
| `ORACLE_CONNECT_STRING` | Easy Connect: `host:port/service`, e.g. `db:1521/ORCLPDB1` |
| `ORACLE_POOL_MIN` / `ORACLE_POOL_MAX` | Pool sizing; defaults fine |
| `ORACLE_CLIENT_LIB_DIR` | Leave blank (Thin mode). Set only for Thick mode |

#### Email (covered in detail in the next section)

`SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD`,
`SMTP_TLS_REJECT_UNAUTHORIZED`, `MAIL_FROM_NAME`, `MAIL_FROM_ADDRESS`,
`MAIL_REPLY_TO`, `MAIL_CC`, `MAIL_BCC`, `MAIL_FALLBACK_TO`,
`MAIL_SUBJECT_TEMPLATE`, `COMPANY_NAME`, `COMPANY_LOGO_URL`, `RELEASE_PORTAL_URL`.

### The `config/artifacts.json` file

This defines **what to check**. Each entry is one required artifact. Edit folder
names and file-matching rules to fit your SharePoint exactly.

```json
{
  "key": "ESTIMATION_SHEET",        // internal id, keep unique
  "label": "Estimation sheet",      // shown in the email
  "enabled": true,                  // set false to skip without deleting
  "source": "sharepoint",           // "sharepoint" or "octane"
  "folder": "/Estimation",          // appended to SHAREPOINT_ROOT_PATH
  "match": {                        // when does a file "count"?
    "type": "nameContains",
    "all": ["estimat"],             // filename must contain ALL of these
    "extensions": [".xlsx", ".xls", ".csv"]
  },
  "minFiles": 1                     // how many matches needed to pass
}
```

**Match rule types:**

- `extension` – passes if any file has one of `extensions`.
- `nameContains` – filename must contain **all** strings in `all`
  (case-insensitive) **and** match `extensions` (if given).
- `regex` – filename matches `pattern` (with optional `flags`, default `i`).

The Octane check is special:

```json
{ "key": "OCTANE_TESTS_LINKED", "source": "octane", "minTestCases": 1 }
```

To **add a new folder to check**, copy any `sharepoint` block, give it a unique
`key`, set its `folder` and `match`, and you're done — no code change needed.
To **stop checking** something, set its `enabled` to `false`.

---

## Setting up the From / To emails and the template

**From address** (who the mail appears to come from):

```bash
MAIL_FROM_NAME=Release Guardian
MAIL_FROM_ADDRESS=release-guardian@yourcompany.com
```

**To address** is resolved automatically per epic, in this order:

1. The Jira field named by `JIRA_DEVELOPER_FIELD` (if it holds an email).
2. The epic **assignee**'s email.
3. The epic **reporter**'s email.
4. If none resolve → **`MAIL_FALLBACK_TO`** (set this to a team DL so alerts are
   never lost).

**CC / BCC / Reply-To** (all optional, comma-separated for multiple):

```bash
MAIL_REPLY_TO=release-team@yourcompany.com
MAIL_CC=release-managers@yourcompany.com
MAIL_BCC=
```

**Subject line** — edit the template, these tokens are substituted:

```bash
MAIL_SUBJECT_TEMPLATE=[Release {RELEASE}] Action needed on {EPIC} — {MISSING_COUNT} item(s) missing
```

| Token | Becomes |
|---|---|
| `{RELEASE}` | the release name |
| `{EPIC}` | the Jira epic key |
| `{MISSING_COUNT}` | number of missing items |

**Branding the template:**

```bash
COMPANY_NAME=Acme Corp                              # shown in header + footer
COMPANY_LOGO_URL=https://acme.com/logo.png          # optional; replaces the name text
RELEASE_PORTAL_URL=https://wiki.acme.com/releases   # optional; adds a button
```

The HTML body lives in `src/email/template.js`. It's deliberately built with
inline styles + tables so it renders correctly in Outlook / EMA clients. You can
restyle colors there (look for the `brand`, `danger`, `ok` variables at the top
of `buildEmail`). A rendered preview is shipped as `sample-email.png`.

**SMTP / EMA relay settings:**

```bash
SMTP_HOST=ema-relay.yourcompany.com
SMTP_PORT=587            # 587 = STARTTLS, 465 = implicit TLS
SMTP_SECURE=false        # true only for port 465
SMTP_USER=               # blank if the relay allows anonymous internal relay
SMTP_PASSWORD=
SMTP_TLS_REJECT_UNAUTHORIZED=true   # false only for self-signed certs (risky)
```

Verify it works without sending real mail to developers:

```bash
npm run test:config      # checks the SMTP connection (and every other system)
npm run check:dry        # logs who WOULD be emailed, sends nothing
```

---

## The Oracle database

Two tables are created by `npm run init:db`:

**`RG_RELEASES`** — your release definitions. The `END_DATE` is what makes
parallel releases safe.

| Column | Meaning |
|---|---|
| `RELEASE_NAME` | Must match what your Jira JQL expects (e.g. the fixVersion) |
| `START_DATE` | When the release becomes active |
| `END_DATE` | When it stops being checked. `NULL` = no end yet |

Add a release:

```sql
INSERT INTO RG_RELEASES (RELEASE_NAME, START_DATE, END_DATE)
VALUES ('25.07', TIMESTAMP '2026-05-01 00:00:00', TIMESTAMP '2026-06-15 23:59:59');

-- A second, parallel release running at the same time:
INSERT INTO RG_RELEASES (RELEASE_NAME, START_DATE, END_DATE)
VALUES ('25.08', TIMESTAMP '2026-05-10 00:00:00', TIMESTAMP '2026-07-01 23:59:59');
COMMIT;
```

**`RG_NOTIFICATION_LOG`** — an audit trail of every email sent. It also powers
**deduplication**: a given (release, epic, developer) is emailed at most **once
per calendar day**, even if the job runs multiple times.

---

## Running it

| Command | What it does |
|---|---|
| `npm run check` | Check all **active** releases and email gaps |
| `npm run check:dry` | Same, but **send no email** (logs intentions) |
| `npm run check:release -- "25.07"` | Check **one** named release (active or not) |
| `npm start` | Start the **server**: REST API + in-app cron |
| `npm run init:db` | Create the Oracle tables |
| `npm run test:config` | Validate config + connectivity to every system |

**REST API** (when running `npm start`):

```bash
# Health probe
curl http://localhost:8080/healthz

# Trigger a run now (dry run)
curl -X POST http://localhost:8080/run -H 'Content-Type: application/json' \
     -d '{"dryRun": true}'

# Trigger a run for one release
curl -X POST http://localhost:8080/run -H 'Content-Type: application/json' \
     -d '{"release": "25.07"}'
```

Overlapping runs are prevented automatically (cron won't stack on a manual run).

---

## Deploying to IBM Cloud

1. **Build & push** the image to IBM Cloud Container Registry:

   ```bash
   ibmcloud cr namespace-add myns        # once
   ibmcloud cr build -t us.icr.io/myns/release-guardian:1.0 .
   ```

2. **Create the secret** from your `.env` (keeps secrets out of the manifest):

   ```bash
   kubectl create secret generic release-guardian-env --from-env-file=.env
   ```

3. **Edit `k8s-deployment.yaml`** — replace `IMAGE_PLACEHOLDER` with your image
   reference, then apply:

   ```bash
   kubectl apply -f k8s-deployment.yaml
   ```

The default manifest runs a single long-lived pod that hosts the REST API **and**
the internal scheduler. If you prefer Kubernetes to own the schedule, uncomment
the `CronJob` block in the manifest and set `CRON_ENABLED=false` in the secret so
the app doesn't double-schedule.

> Keep `replicas: 1`. Two replicas would each run the scheduler and could send
> duplicate emails (the daily dedupe limits the blast radius, but one replica is
> cleaner).

---

## How parallel releases are handled

The query that selects what to work on is, in plain terms:

> a release is **active** when `START_DATE <= now` **and**
> (`END_DATE` is null **or** `END_DATE >= now`).

So you can have any number of releases in flight simultaneously — each is
checked independently, its epics pulled with its own `RELEASE_NAME`. The moment a
release's `END_DATE` passes, the **next run simply stops including it** — no
config change, no code change, no more emails for that release. To extend a
release, push its `END_DATE` out; to retire one early, set `END_DATE` to now.

---

## Linking Octane test cases to Jira

Two strategies, set by `OCTANE_LINK_STRATEGY`:

- **`field`** (default): a string field/UDF on the Octane test case holds the
  Jira key. Put that field's name in `OCTANE_JIRA_KEY_FIELD` (e.g.
  `jira_key_udf`). The check counts test cases where that field equals the epic
  key.
- **`tag`**: the test case carries a **tag** whose name is the Jira key. No field
  needed.

Pick whichever matches how your team already links them. If you're not linking
yet, the `field` approach (add a UDF on test cases and paste the Jira key) is the
simplest to adopt.

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `validate-config` says **SMTP: FAILED** | Wrong `SMTP_HOST`/`PORT`/`SECURE`; relay needs auth; firewall |
| `validate-config` says **Oracle: FAILED** | Wrong `ORACLE_CONNECT_STRING`; DB user lacks rights; network |
| `validate-config` says **Octane: FAILED** | Wrong client id/secret or shared-space/workspace ids |
| `validate-config` says **SharePoint/Graph: FAILED** | App lacks `Sites.Read.All` admin consent; wrong site path |
| No epics found | `JIRA_EPIC_JQL` doesn't match your workflow, or `RELEASE_NAME` ≠ fixVersion |
| Folder always "missing" | The `folder` in `artifacts.json` doesn't match SharePoint exactly (it's case/space sensitive) |
| File present but not detected | Tighten/loosen the `match` rule (extensions / `nameContains`) |
| Developer not emailed | Couldn't resolve their email → check it lands in `MAIL_FALLBACK_TO` |
| Same person emailed twice | Shouldn't happen within a day; check `RG_NOTIFICATION_LOG` |
| Oracle Thick-mode needed | Set `ORACLE_CLIENT_LIB_DIR` to your Instant Client path |

Set `LOG_LEVEL=debug` and `LOG_PRETTY=true` while diagnosing.

---

## Project layout

```
release-guardian/
├── .env.example              # copy to .env; every placeholder, documented
├── config/
│   └── artifacts.json        # WHAT to check (folders + match rules)
├── src/
│   ├── config.js             # loads & validates config (the only env reader)
│   ├── logger.js
│   ├── cli.js                # run / validate-config commands
│   ├── server.js             # REST API + cron (the pod's main process)
│   ├── connectors/
│   │   ├── jira.js           # find epics + resolve developer email
│   │   ├── octane.js         # count linked test cases
│   │   └── sharepoint.js     # Graph: list folders, match files
│   ├── core/
│   │   └── checker.js        # the orchestrator
│   ├── db/
│   │   ├── oracle.js         # pool + queries (active releases, dedupe log)
│   │   └── initSchema.js     # creates the two tables
│   └── email/
│       ├── template.js       # the HTML/text email builder
│       └── mailer.js         # nodemailer SMTP sender
├── Dockerfile
├── k8s-deployment.yaml       # IBM Cloud manifests (Deployment or CronJob)
├── sample-email.png          # preview of the alert email
└── README.md
```

---

## Security notes

- `.env` is gitignored. On IBM Cloud, inject it as a **Kubernetes Secret**, never
  bake it into the image.
- The app runs as a **non-root** user in the container.
- Use a **dedicated service account** for Jira/Octane/Graph with least-privilege
  (read-only is enough).
