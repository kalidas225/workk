package com.sorcefodge.starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SorcefodgeApplicationTests {

    @Test
    void contextLoads() {
    }
}
