package com.sorcefodge.starter;

import com.sorcefodge.starter.model.DatabaseConfig;
import com.sorcefodge.starter.model.ProjectRequest;
import com.sorcefodge.starter.service.ProjectGeneratorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayInputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ProjectGeneratorServiceTests {

    @Autowired
    ProjectGeneratorService generator;

    @Test
    void generatesValidZipForMavenJava() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "maven", "java", "3.3.5",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21",
                List.of("web", "data-jpa", "lombok"),
                new DatabaseConfig("h2", "", "sa", "", "update")
        );
        byte[] zip = generator.generate(req);
        assertNotNull(zip);
        assertTrue(zip.length > 0);

        Set<String> entries = new HashSet<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zip))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                entries.add(e.getName());
            }
        }
        assertTrue(entries.contains("demo/pom.xml"));
        assertTrue(entries.contains("demo/src/main/java/com/example/demo/DemoApplication.java"));
        assertTrue(entries.contains("demo/src/test/java/com/example/demo/DemoApplicationTests.java"));
        assertTrue(entries.contains("demo/src/main/resources/application.properties"));
        assertTrue(entries.contains("demo/.gitignore"));
        assertTrue(entries.contains("demo/README.md"));
    }

    @Test
    void generatesValidZipForGradleKotlin() throws Exception {
        ProjectRequest req = new ProjectRequest(
                "gradle-kotlin", "kotlin", "3.3.5",
                "com.example", "demo", "demo", "Demo",
                "com.example.demo", "jar", "21",
                List.of("web"),
                DatabaseConfig.none()
        );
        byte[] zip = generator.generate(req);
        Set<String> entries = new HashSet<>();
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(zip))) {
            ZipEntry e;
            while ((e = zis.getNextEntry()) != null) {
                entries.add(e.getName());
            }
        }
        assertTrue(entries.contains("demo/build.gradle.kts"));
        assertTrue(entries.contains("demo/settings.gradle.kts"));
        assertTrue(entries.contains("demo/src/main/kotlin/com/example/demo/DemoApplication.kt"));
    }
}
