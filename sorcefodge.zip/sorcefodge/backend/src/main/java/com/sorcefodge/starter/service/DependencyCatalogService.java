package com.sorcefodge.starter.service;

import com.sorcefodge.starter.model.Dependency;
import com.sorcefodge.starter.model.DependencyCategory;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * In-memory catalog of Spring Boot starter dependencies, mirroring the
 * grouping used by start.spring.io. Kept in code (no external metadata
 * file) so the service is self-contained and works offline.
 */
@Service
public class DependencyCatalogService {

    private final List<DependencyCategory> categories;
    private final Map<String, Dependency> byId;

    public DependencyCatalogService() {
        this.categories = buildCatalog();
        this.byId = new LinkedHashMap<>();
        for (DependencyCategory cat : categories) {
            for (Dependency dep : cat.dependencies()) {
                byId.put(dep.id(), dep);
            }
        }
    }

    public List<DependencyCategory> getCategories() {
        return categories;
    }

    public Optional<Dependency> findById(String id) {
        return Optional.ofNullable(byId.get(id));
    }

    public List<Dependency> resolve(List<String> ids) {
        return ids.stream()
                .map(byId::get)
                .filter(java.util.Objects::nonNull)
                .toList();
    }

    private List<DependencyCategory> buildCatalog() {
        List<DependencyCategory> list = new java.util.ArrayList<>();

        list.add(new DependencyCategory("Developer Tools", List.of(
                dep("devtools", "Spring Boot DevTools",
                        "Provides fast application restarts, LiveReload, and configurations for enhanced development experience.",
                        "org.springframework.boot", "spring-boot-devtools", null, "runtime", "Developer Tools"),
                dep("lombok", "Lombok",
                        "Java annotation library which helps to reduce boilerplate code.",
                        "org.projectlombok", "lombok", null, "provided", "Developer Tools"),
                dep("configuration-processor", "Spring Configuration Processor",
                        "Generate metadata for developers to offer contextual help and code completion for @ConfigurationProperties classes.",
                        "org.springframework.boot", "spring-boot-configuration-processor", null, "provided", "Developer Tools"),
                dep("docker-compose", "Docker Compose Support",
                        "Provides Docker Compose support for enhanced development experience.",
                        "org.springframework.boot", "spring-boot-docker-compose", null, "runtime", "Developer Tools")
        )));

        list.add(new DependencyCategory("Web", List.of(
                dep("web", "Spring Web",
                        "Build web, including RESTful, applications using Spring MVC. Uses Apache Tomcat as the default embedded container.",
                        "org.springframework.boot", "spring-boot-starter-web", null, "compile", "Web"),
                dep("webflux", "Spring Reactive Web",
                        "Build reactive web applications with Spring WebFlux and Netty.",
                        "org.springframework.boot", "spring-boot-starter-webflux", null, "compile", "Web"),
                dep("graphql", "Spring for GraphQL",
                        "Build GraphQL applications with Spring for GraphQL and GraphQL Java.",
                        "org.springframework.boot", "spring-boot-starter-graphql", null, "compile", "Web"),
                dep("websocket", "WebSocket",
                        "Build WebSocket and STOMP messaging applications.",
                        "org.springframework.boot", "spring-boot-starter-websocket", null, "compile", "Web"),
                dep("data-rest", "Spring Data REST",
                        "Expose Spring Data repositories over REST via Spring Data REST.",
                        "org.springframework.boot", "spring-boot-starter-data-rest", null, "compile", "Web"),
                dep("session", "Spring Session",
                        "Provides an API and implementations for managing user session information.",
                        "org.springframework.session", "spring-session-core", null, "compile", "Web")
        )));

        list.add(new DependencyCategory("Template Engines", List.of(
                dep("thymeleaf", "Thymeleaf",
                        "A modern server-side Java template engine for both web and standalone environments.",
                        "org.springframework.boot", "spring-boot-starter-thymeleaf", null, "compile", "Template Engines"),
                dep("freemarker", "Apache Freemarker",
                        "Java library to generate text output (HTML web pages, e-mails, configuration files, source code, etc.) based on templates and changing data.",
                        "org.springframework.boot", "spring-boot-starter-freemarker", null, "compile", "Template Engines"),
                dep("mustache", "Mustache",
                        "Logic-less templates with separation of view from logic.",
                        "org.springframework.boot", "spring-boot-starter-mustache", null, "compile", "Template Engines"),
                dep("groovy-templates", "Groovy Templates",
                        "Groovy templating engine.",
                        "org.springframework.boot", "spring-boot-starter-groovy-templates", null, "compile", "Template Engines")
        )));

        list.add(new DependencyCategory("Security", List.of(
                dep("security", "Spring Security",
                        "Highly customizable authentication and access-control framework for Spring applications.",
                        "org.springframework.boot", "spring-boot-starter-security", null, "compile", "Security"),
                dep("oauth2-client", "OAuth2 Client",
                        "Spring Boot integration for Spring Security's OAuth2/OpenID Connect client features.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-client", null, "compile", "Security"),
                dep("oauth2-resource-server", "OAuth2 Resource Server",
                        "Spring Boot integration for Spring Security's OAuth2 resource server features.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-resource-server", null, "compile", "Security"),
                dep("oauth2-authorization-server", "OAuth2 Authorization Server",
                        "Spring Boot integration for Spring Authorization Server.",
                        "org.springframework.boot", "spring-boot-starter-oauth2-authorization-server", null, "compile", "Security")
        )));

        list.add(new DependencyCategory("SQL", List.of(
                dep("data-jpa", "Spring Data JPA",
                        "Persist data in SQL stores with Java Persistence API using Spring Data and Hibernate.",
                        "org.springframework.boot", "spring-boot-starter-data-jpa", null, "compile", "SQL"),
                dep("data-jdbc", "Spring Data JDBC",
                        "Persist data in SQL stores with plain JDBC using Spring Data.",
                        "org.springframework.boot", "spring-boot-starter-data-jdbc", null, "compile", "SQL"),
                dep("jdbc", "JDBC API",
                        "Database Connectivity API that defines how a client may connect and query a database.",
                        "org.springframework.boot", "spring-boot-starter-jdbc", null, "compile", "SQL"),
                dep("mysql", "MySQL Driver",
                        "MySQL JDBC driver.",
                        "com.mysql", "mysql-connector-j", null, "runtime", "SQL"),
                dep("postgresql", "PostgreSQL Driver",
                        "A JDBC and R2DBC driver that allows Java programs to connect to a PostgreSQL database using standard, database independent Java code.",
                        "org.postgresql", "postgresql", null, "runtime", "SQL"),
                dep("h2", "H2 Database",
                        "Provides a fast in-memory database that supports JDBC API and R2DBC access, with a small (2mb) footprint.",
                        "com.h2database", "h2", null, "runtime", "SQL"),
                dep("hsql", "HyperSQL Database",
                        "Lightweight 100% Java SQL Database Engine.",
                        "org.hsqldb", "hsqldb", null, "runtime", "SQL"),
                dep("derby", "Apache Derby Database",
                        "An open source relational database implemented entirely in Java.",
                        "org.apache.derby", "derby", null, "runtime", "SQL"),
                dep("mssql", "MS SQL Server Driver",
                        "JDBC driver for Microsoft SQL Server.",
                        "com.microsoft.sqlserver", "mssql-jdbc", null, "runtime", "SQL"),
                dep("oracle", "Oracle Driver",
                        "JDBC driver for Oracle Database.",
                        "com.oracle.database.jdbc", "ojdbc11", null, "runtime", "SQL"),
                dep("flyway", "Flyway Migration",
                        "Version control for your database so you can migrate from any version (incl. an empty database) to the latest version of the schema.",
                        "org.flywaydb", "flyway-core", null, "compile", "SQL"),
                dep("liquibase", "Liquibase Migration",
                        "Liquibase database migration and source control library.",
                        "org.liquibase", "liquibase-core", null, "compile", "SQL")
        )));

        list.add(new DependencyCategory("NoSQL", List.of(
                dep("data-redis", "Spring Data Redis (Access+Driver)",
                        "Advanced and thread-safe Java Redis client for synchronous, asynchronous, and reactive usage.",
                        "org.springframework.boot", "spring-boot-starter-data-redis", null, "compile", "NoSQL"),
                dep("data-mongodb", "Spring Data MongoDB",
                        "Store data in flexible, JSON-like documents, meaning fields can vary from document to document.",
                        "org.springframework.boot", "spring-boot-starter-data-mongodb", null, "compile", "NoSQL"),
                dep("data-elasticsearch", "Spring Data Elasticsearch (Access+Driver)",
                        "A distributed, RESTful search and analytics engine with support for Spring Data.",
                        "org.springframework.boot", "spring-boot-starter-data-elasticsearch", null, "compile", "NoSQL"),
                dep("data-cassandra", "Spring Data for Apache Cassandra",
                        "A free and open-source, distributed, NoSQL database management system that offers high scalability and high availability without compromising performance.",
                        "org.springframework.boot", "spring-boot-starter-data-cassandra", null, "compile", "NoSQL"),
                dep("data-neo4j", "Spring Data Neo4j",
                        "Provides graph data persistence with Neo4j, the most popular graph database.",
                        "org.springframework.boot", "spring-boot-starter-data-neo4j", null, "compile", "NoSQL")
        )));

        list.add(new DependencyCategory("Messaging", List.of(
                dep("amqp", "Spring for RabbitMQ",
                        "Gives your applications a common platform to send and receive messages, and your messages a safe place to live until received.",
                        "org.springframework.boot", "spring-boot-starter-amqp", null, "compile", "Messaging"),
                dep("kafka", "Spring for Apache Kafka",
                        "Publish, subscribe, store, and process streams of records.",
                        "org.springframework.kafka", "spring-kafka", null, "compile", "Messaging"),
                dep("kafka-streams", "Spring for Apache Kafka Streams",
                        "Building stream processing applications with Apache Kafka Streams.",
                        "org.apache.kafka", "kafka-streams", null, "compile", "Messaging"),
                dep("activemq", "Spring for Apache ActiveMQ 5",
                        "Spring JMS support with Apache ActiveMQ 'Classic'.",
                        "org.springframework.boot", "spring-boot-starter-activemq", null, "compile", "Messaging"),
                dep("artemis", "Spring for Apache ActiveMQ Artemis",
                        "Spring JMS support with Apache ActiveMQ Artemis.",
                        "org.springframework.boot", "spring-boot-starter-artemis", null, "compile", "Messaging")
        )));

        list.add(new DependencyCategory("I/O", List.of(
                dep("batch", "Spring Batch",
                        "Batch applications with transactions, retry/skip and chunk based processing.",
                        "org.springframework.boot", "spring-boot-starter-batch", null, "compile", "I/O"),
                dep("integration", "Spring Integration",
                        "Adds support for Enterprise Integration Patterns. Enables lightweight messaging and supports integration with external systems via declarative adapters.",
                        "org.springframework.boot", "spring-boot-starter-integration", null, "compile", "I/O"),
                dep("validation", "Validation",
                        "Bean Validation with Hibernate validator.",
                        "org.springframework.boot", "spring-boot-starter-validation", null, "compile", "I/O"),
                dep("mail", "Java Mail Sender",
                        "Send email using Java Mail and Spring Framework's JavaMailSender.",
                        "org.springframework.boot", "spring-boot-starter-mail", null, "compile", "I/O"),
                dep("quartz", "Quartz Scheduler",
                        "Schedule jobs using Quartz.",
                        "org.springframework.boot", "spring-boot-starter-quartz", null, "compile", "I/O")
        )));

        list.add(new DependencyCategory("Ops", List.of(
                dep("actuator", "Spring Boot Actuator",
                        "Supports built in (or custom) endpoints that let you monitor and manage your application - such as application health, metrics, sessions, etc.",
                        "org.springframework.boot", "spring-boot-starter-actuator", null, "compile", "Ops"),
                dep("prometheus", "Prometheus",
                        "Expose Actuator metrics in the Prometheus format via Micrometer.",
                        "io.micrometer", "micrometer-registry-prometheus", null, "runtime", "Ops"),
                dep("cloud-config-client", "Config Client",
                        "Client that connects to a Spring Cloud Config Server to fetch the application's configuration.",
                        "org.springframework.cloud", "spring-cloud-starter-config", null, "compile", "Ops"),
                dep("cloud-eureka", "Eureka Discovery Client",
                        "A REST based service for locating services for the purpose of load balancing and failover of middle-tier servers.",
                        "org.springframework.cloud", "spring-cloud-starter-netflix-eureka-client", null, "compile", "Ops")
        )));

        list.add(new DependencyCategory("Testing", List.of(
                dep("testcontainers", "Testcontainers",
                        "Provides lightweight, throwaway instances of common databases, Selenium web browsers, or anything else that can run in a Docker container.",
                        "org.testcontainers", "junit-jupiter", null, "test", "Testing"),
                dep("restdocs", "Spring REST Docs",
                        "Document RESTful services by combining hand-written and auto-generated documentation.",
                        "org.springframework.restdocs", "spring-restdocs-mockmvc", null, "test", "Testing")
        )));

        return list;
    }

    private static Dependency dep(String id, String name, String description,
                                  String groupId, String artifactId, String version,
                                  String scope, String category) {
        return new Dependency(id, name, description, groupId, artifactId, version, scope, category,
                List.of(), null, null);
    }
}
