package com.sorcefodge.starter.controller;

import com.sorcefodge.starter.model.MetadataResponse;
import com.sorcefodge.starter.service.MetadataService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MetadataController {

    private final MetadataService metadataService;

    public MetadataController(MetadataService metadataService) {
        this.metadataService = metadataService;
    }

    @GetMapping("/metadata")
    public ResponseEntity<MetadataResponse> metadata() {
        return ResponseEntity.ok(metadataService.getMetadata());
    }
}
