package com.sorcefodge.starter.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.util.List;

/**
 * Incoming request from frontend describing the project to generate.
 */
public record ProjectRequest(
        @NotBlank @Pattern(regexp = "maven|gradle-groovy|gradle-kotlin", message = "type must be maven, gradle-groovy or gradle-kotlin")
        String type,

        @NotBlank @Pattern(regexp = "java|kotlin|groovy", message = "language must be java, kotlin or groovy")
        String language,

        @NotBlank
        String bootVersion,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.\\-]*$", message = "groupId is invalid")
        String groupId,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_\\-]*$", message = "artifactId is invalid")
        String artifactId,

        @NotBlank
        String name,

        String description,

        @NotBlank @Pattern(regexp = "^[a-zA-Z][a-zA-Z0-9_.]*$", message = "packageName is invalid")
        String packageName,

        @NotBlank @Pattern(regexp = "jar|war", message = "packaging must be jar or war")
        String packaging,

        @NotBlank @Pattern(regexp = "8|11|17|21|22|23", message = "Unsupported java version")
        String javaVersion,

        @NotNull
        List<String> dependencies,

        DatabaseConfig database
) {
    public ProjectRequest {
        if (dependencies == null) dependencies = List.of();
        if (description == null) description = "";
        if (database == null) database = DatabaseConfig.none();
    }
}
