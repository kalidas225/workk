package com.sorcefodge.starter.service;

import com.sorcefodge.starter.model.Dependency;
import com.sorcefodge.starter.model.ProjectRequest;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PomBuilder {

    public String build(ProjectRequest request, List<Dependency> dependencies) {
        StringBuilder pom = new StringBuilder();
        pom.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        pom.append("<project xmlns=\"http://maven.apache.org/POM/4.0.0\"\n");
        pom.append("         xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n");
        pom.append("         xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd\">\n");
        pom.append("    <modelVersion>4.0.0</modelVersion>\n\n");

        pom.append("    <parent>\n");
        pom.append("        <groupId>org.springframework.boot</groupId>\n");
        pom.append("        <artifactId>spring-boot-starter-parent</artifactId>\n");
        pom.append("        <version>").append(escape(request.bootVersion())).append("</version>\n");
        pom.append("        <relativePath/>\n");
        pom.append("    </parent>\n\n");

        pom.append("    <groupId>").append(escape(request.groupId())).append("</groupId>\n");
        pom.append("    <artifactId>").append(escape(request.artifactId())).append("</artifactId>\n");
        pom.append("    <version>0.0.1-SNAPSHOT</version>\n");
        pom.append("    <packaging>").append(escape(request.packaging())).append("</packaging>\n");
        pom.append("    <name>").append(escape(request.name())).append("</name>\n");
        pom.append("    <description>").append(escape(safe(request.description()))).append("</description>\n\n");

        pom.append("    <properties>\n");
        pom.append("        <java.version>").append(escape(request.javaVersion())).append("</java.version>\n");
        pom.append("        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>\n");
        if ("kotlin".equals(request.language())) {
            pom.append("        <kotlin.version>1.9.25</kotlin.version>\n");
        }
        pom.append("    </properties>\n\n");

        pom.append("    <dependencies>\n");
        // Always include the language base
        for (Dependency d : dependencies) {
            appendDependency(pom, d);
        }

        // Spring Boot test starter (always present)
        pom.append("        <dependency>\n");
        pom.append("            <groupId>org.springframework.boot</groupId>\n");
        pom.append("            <artifactId>spring-boot-starter-test</artifactId>\n");
        pom.append("            <scope>test</scope>\n");
        pom.append("        </dependency>\n");

        if ("kotlin".equals(request.language())) {
            appendSimple(pom, "org.jetbrains.kotlin", "kotlin-reflect", null, null);
            appendSimple(pom, "org.jetbrains.kotlin", "kotlin-stdlib", null, null);
            appendSimple(pom, "com.fasterxml.jackson.module", "jackson-module-kotlin", null, null);
        } else if ("groovy".equals(request.language())) {
            appendSimple(pom, "org.codehaus.groovy", "groovy", null, null);
        }

        if ("war".equals(request.packaging())) {
            appendSimple(pom, "org.springframework.boot", "spring-boot-starter-tomcat", null, "provided");
        }

        pom.append("    </dependencies>\n\n");

        pom.append("    <build>\n");
        if ("kotlin".equals(request.language())) {
            pom.append("        <sourceDirectory>${project.basedir}/src/main/kotlin</sourceDirectory>\n");
            pom.append("        <testSourceDirectory>${project.basedir}/src/test/kotlin</testSourceDirectory>\n");
        }
        pom.append("        <plugins>\n");
        pom.append("            <plugin>\n");
        pom.append("                <groupId>org.springframework.boot</groupId>\n");
        pom.append("                <artifactId>spring-boot-maven-plugin</artifactId>\n");
        // Lombok exclusion in repackage
        if (dependencies.stream().anyMatch(d -> "lombok".equals(d.id()))) {
            pom.append("                <configuration>\n");
            pom.append("                    <excludes>\n");
            pom.append("                        <exclude>\n");
            pom.append("                            <groupId>org.projectlombok</groupId>\n");
            pom.append("                            <artifactId>lombok</artifactId>\n");
            pom.append("                        </exclude>\n");
            pom.append("                    </excludes>\n");
            pom.append("                </configuration>\n");
        }
        pom.append("            </plugin>\n");
        if ("kotlin".equals(request.language())) {
            pom.append("            <plugin>\n");
            pom.append("                <groupId>org.jetbrains.kotlin</groupId>\n");
            pom.append("                <artifactId>kotlin-maven-plugin</artifactId>\n");
            pom.append("                <configuration>\n");
            pom.append("                    <args>\n");
            pom.append("                        <arg>-Xjsr305=strict</arg>\n");
            pom.append("                    </args>\n");
            pom.append("                    <compilerPlugins>\n");
            pom.append("                        <plugin>spring</plugin>\n");
            pom.append("                    </compilerPlugins>\n");
            pom.append("                </configuration>\n");
            pom.append("                <dependencies>\n");
            pom.append("                    <dependency>\n");
            pom.append("                        <groupId>org.jetbrains.kotlin</groupId>\n");
            pom.append("                        <artifactId>kotlin-maven-allopen</artifactId>\n");
            pom.append("                        <version>${kotlin.version}</version>\n");
            pom.append("                    </dependency>\n");
            pom.append("                </dependencies>\n");
            pom.append("            </plugin>\n");
        }
        pom.append("        </plugins>\n");
        pom.append("    </build>\n\n");

        pom.append("</project>\n");
        return pom.toString();
    }

    private void appendDependency(StringBuilder pom, Dependency d) {
        pom.append("        <dependency>\n");
        pom.append("            <groupId>").append(escape(d.groupId())).append("</groupId>\n");
        pom.append("            <artifactId>").append(escape(d.artifactId())).append("</artifactId>\n");
        if (d.version() != null && !d.version().isBlank()) {
            pom.append("            <version>").append(escape(d.version())).append("</version>\n");
        }
        if (!"compile".equals(d.scope())) {
            // Maven scope mapping: provided -> provided, runtime -> runtime, test -> test
            String scope = "provided".equals(d.scope()) ? "provided" : d.scope();
            if (!"compile".equals(scope)) {
                pom.append("            <scope>").append(escape(scope)).append("</scope>\n");
            }
        }
        if ("lombok".equals(d.id())) {
            pom.append("            <optional>true</optional>\n");
        }
        pom.append("        </dependency>\n");
    }

    private void appendSimple(StringBuilder pom, String g, String a, String v, String scope) {
        pom.append("        <dependency>\n");
        pom.append("            <groupId>").append(escape(g)).append("</groupId>\n");
        pom.append("            <artifactId>").append(escape(a)).append("</artifactId>\n");
        if (v != null) pom.append("            <version>").append(escape(v)).append("</version>\n");
        if (scope != null) pom.append("            <scope>").append(escape(scope)).append("</scope>\n");
        pom.append("        </dependency>\n");
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String safe(String s) {
        return s == null ? "" : s;
    }
}
