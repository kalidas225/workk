package com.sorcefodge.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SorcefodgeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SorcefodgeApplication.class, args);
    }
}
