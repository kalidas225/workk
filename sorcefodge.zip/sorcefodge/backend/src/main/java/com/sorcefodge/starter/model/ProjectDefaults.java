package com.sorcefodge.starter.model;

public record ProjectDefaults(
        String type,
        String language,
        String bootVersion,
        String groupId,
        String artifactId,
        String name,
        String description,
        String packageName,
        String packaging,
        String javaVersion
) {
}
