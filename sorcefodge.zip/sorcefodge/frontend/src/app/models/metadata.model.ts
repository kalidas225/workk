export interface Dependency {
  id: string;
  name: string;
  description: string;
  groupId: string;
  artifactId: string;
  version: string | null;
  scope: string;
  category: string;
  incompatibleWith: string[];
  minBootVersion: string | null;
  maxBootVersion: string | null;
}

export interface DependencyCategory {
  name: string;
  dependencies: Dependency[];
}

export interface ProjectDefaults {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
}

export interface MetadataResponse {
  types: string[];
  languages: string[];
  bootVersions: string[];
  packagings: string[];
  javaVersions: string[];
  defaults: ProjectDefaults;
  dependencies: DependencyCategory[];
}

export interface DatabaseConfig {
  type: string;       // none | h2 | postgresql | mysql | oracle | mssql
  url: string;
  username: string;
  password: string;
  ddlAuto: string;    // none | validate | update | create | create-drop
}

export interface ProjectRequest {
  type: string;
  language: string;
  bootVersion: string;
  groupId: string;
  artifactId: string;
  name: string;
  description: string;
  packageName: string;
  packaging: string;
  javaVersion: string;
  dependencies: string[];
  database: DatabaseConfig;
}

export interface DatabaseOption {
  id: string;
  label: string;
  defaultUrl: string;
  defaultUsername: string;
}

export const DATABASE_OPTIONS: DatabaseOption[] = [
  { id: 'none',       label: 'None',         defaultUrl: '',                                                       defaultUsername: '' },
  { id: 'h2',         label: 'H2 (in-mem)',  defaultUrl: 'jdbc:h2:mem:demo;DB_CLOSE_DELAY=-1;MODE=PostgreSQL',     defaultUsername: 'sa' },
  { id: 'postgresql', label: 'PostgreSQL',   defaultUrl: 'jdbc:postgresql://localhost:5432/demo',                  defaultUsername: 'postgres' },
  { id: 'mysql',      label: 'MySQL',        defaultUrl: 'jdbc:mysql://localhost:3306/demo?useSSL=false&serverTimezone=UTC', defaultUsername: 'root' },
  { id: 'oracle',     label: 'Oracle',       defaultUrl: 'jdbc:oracle:thin:@localhost:1521:XE',                    defaultUsername: 'system' },
  { id: 'mssql',      label: 'SQL Server',   defaultUrl: 'jdbc:sqlserver://localhost:1433;databaseName=demo;encrypt=false', defaultUsername: 'sa' }
];

export const DDL_AUTO_OPTIONS: { id: string; label: string }[] = [
  { id: 'none',        label: 'none' },
  { id: 'validate',    label: 'validate' },
  { id: 'update',      label: 'update' },
  { id: 'create',      label: 'create' },
  { id: 'create-drop', label: 'create-drop' }
];
