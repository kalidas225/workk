# sorcefodge

A self-hosted clone of [start.spring.io](https://start.spring.io) — generates ready-to-run Spring Boot project zips. Frontend in **Angular 18**, backend in **Java 21 + Spring Boot 3.3.5**.

The generator service itself runs on Java 21, but the *generated* projects can target Java 8, 11, 17, 21, 22, or 23 — the selected version is injected into the produced POM / Gradle build.

---

## Features

- **Build tool**: Maven, Gradle (Groovy DSL), Gradle (Kotlin DSL)
- **Language**: Java, Kotlin, Groovy
- **Spring Boot versions**: 3.3.5, 3.3.4, 3.2.11, 3.1.12
- **Java versions**: 8, 11, 17, 21, 22, 23
- **Packaging**: JAR or WAR
- **40+ starter dependencies** grouped by category (Web, SQL, NoSQL, Security, Messaging, Ops, Testing, …)
- **Database configuration** — choose H2, PostgreSQL, MySQL, Oracle, or SQL Server. Driver is auto-added, JDBC URL / username / password / `ddl-auto` are written into the generated `application.properties`. Hibernate dialect set automatically when Spring Data JPA is selected.
- **Smart Lombok handling**: emitted as `provided` + `optional` and excluded from the Spring Boot Maven plugin repackage step
- **Live form** — package name auto-derives from group + artifact (until you edit it)
- **Searchable dependency picker** with keyboard navigation (↑/↓/Enter/Esc)
- **Keyboard shortcuts** — `⌘B` opens dependency picker, `⌘Enter` generates

---

## Project structure

```
sorcefodge/
├── backend/                          # Spring Boot 3.3.5 on Java 21
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/sorcefodge/starter/
│       │   ├── SorcefodgeApplication.java       (entry point)
│       │   ├── config/CorsConfig.java           (CORS for /api/**)
│       │   ├── controller/
│       │   │   ├── MetadataController.java      (GET /api/metadata)
│       │   │   └── GeneratorController.java     (POST /api/generate)
│       │   ├── exception/
│       │   ├── model/                           (DTOs incl. DatabaseConfig, ProjectRequest)
│       │   └── service/
│       │       ├── DependencyCatalogService.java  (in-memory starter catalog)
│       │       ├── MetadataService.java
│       │       ├── ProjectGeneratorService.java   (orchestrates zip assembly)
│       │       ├── PomBuilder.java                (writes pom.xml)
│       │       ├── GradleBuilder.java             (writes build.gradle[.kts])
│       │       └── SourceTemplateService.java    (main class, tests, application.properties)
│       ├── main/resources/application.properties
│       └── test/java/com/sorcefodge/starter/...
│
└── frontend/                         # Angular 18 (standalone components, signals)
    ├── package.json
    ├── angular.json
    ├── proxy.conf.json               (dev proxy /api -> http://localhost:8080)
    └── src/
        ├── index.html
        ├── styles.scss
        ├── main.ts
        └── app/
            ├── app.config.ts
            ├── app.component.{ts,html,scss}
            ├── models/metadata.model.ts
            └── services/starter-api.service.ts
```

---

## Running it

### Prerequisites

- **Java 21+** (any distribution — Temurin, Oracle, Corretto, Liberica)
- **Maven 3.6+** (or use IntelliJ's bundled Maven)
- **Node 18+** and **npm**
- Internet access on first run so Maven and npm can pull dependencies

### Backend — IntelliJ IDEA

1. **Open** the `backend` folder in IntelliJ as a Maven project.
2. **Set the project SDK to JDK 21** — `File → Project Structure → Project SDK`. IntelliJ usually auto-detects this from the POM but verify if you see compile errors.
3. **Reimport / refresh Maven** — IntelliJ's Maven sidebar → click the refresh button.
4. **Right-click** `SorcefodgeApplication.java` → `Run 'SorcefodgeApplication'`.

The app listens on **http://localhost:8080**.

Alternatively from the command line:

```bash
cd backend
mvn clean install
mvn spring-boot:run
```

### Backend endpoints

| Method | Path | Description |
| ------ | ---- | ----------- |
| `GET`  | `/api/metadata` | Returns options + dependency catalog as JSON |
| `POST` | `/api/generate` | Body: `ProjectRequest` JSON. Returns the project as `application/zip`. |

Sanity-check curl:

```bash
curl http://localhost:8080/api/metadata | head -c 400

curl -X POST http://localhost:8080/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "type":"maven","language":"java","bootVersion":"3.3.5",
    "groupId":"com.example","artifactId":"shop","name":"shop",
    "description":"Shop API","packageName":"com.example.shop",
    "packaging":"jar","javaVersion":"21",
    "dependencies":["web","data-jpa"],
    "database":{"type":"postgresql","url":"","username":"postgres","password":"secret","ddlAuto":"update"}
  }' \
  -o shop.zip
unzip -l shop.zip
unzip -p shop.zip shop/src/main/resources/application.properties
```

You should see a populated `application.properties` with the datasource block.

### Frontend

```bash
cd frontend
npm install      # first time only
npm start        # ng serve on :4200 with proxy to backend
```

Open **http://localhost:4200**. The dev server proxies `/api/**` to the backend on port 8080.

### Frontend production build

```bash
cd frontend
npm run build
# output in dist/sorcefodge-frontend — static files for any host
```

---

## Database configuration in generated projects

Picking a database in the UI (or sending `database.type` in the JSON request) produces this in the generated `application.properties`:

```properties
spring.application.name=shop
server.port=8080

# ===== Datasource =====
spring.datasource.url=jdbc:postgresql://localhost:5432/shop
spring.datasource.username=postgres
spring.datasource.password=secret
spring.datasource.driver-class-name=org.postgresql.Driver

# ===== JPA / Hibernate =====   (only if Spring Data JPA is selected)
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQLDialect
```

For H2, the H2 console is also enabled at `/h2-console`.

The driver dependency (`postgresql`, `mysql-connector-j`, `h2`, `ojdbc11`, or `mssql-jdbc`) is auto-added to the generated `pom.xml` / `build.gradle`.

---

## Troubleshooting

**"CorsConfig.java does not compile" / similar in IntelliJ:**
This usually means IntelliJ's project SDK is set to a JDK below 21. Fix:
1. `File → Project Structure → Project → SDK` — choose JDK 21
2. `File → Project Structure → Modules → sorcefodge-backend → Language level` — set to 21
3. `Build → Rebuild Project`

**`mvn` fails with "release version 21 not supported":**
Your `JAVA_HOME` is pointing to JDK < 21. Either install JDK 21 and update `JAVA_HOME`, or in IntelliJ go to `Settings → Build, Execution, Deployment → Build Tools → Maven → Runner` and set `JRE` to a JDK 21.

**Frontend can't reach backend:**
The proxy in `frontend/proxy.conf.json` expects backend on `localhost:8080`. If you changed that, edit `proxy.conf.json` accordingly.

---

## License

MIT — do whatever you like with this.
