# Cherry Deck

A modern, developer-friendly console for **subject-wise git cherry-picking** onto protected
release branches — with an **interactive side-by-side conflict editor**, centralised **repo
discovery** (GitLab group + local clones), and a **SQL trailing-slash linter** for Ansible.

- **Backend:** plain Node.js — **zero dependencies** (built-in `http`; no Express, no framework)
- **Frontend:** Angular 20 (standalone components, signals), dark + light mode
- **Push** to origin from the UI; raise the MR in GitLab from the pushed branch

---

## Answers to common questions

**"Express vs Node?"** Express *was* just a library running on Node — there was never a second
runtime. This version drops Express entirely and uses Node's built-in `http` module, so the
backend has **no npm dependencies at all**. It's as plain-Node as it gets.

**"Why is the order-resolver / conflict-parser a separate file?"** Only for testability — each is
one focused, unit-tested function. They run *inside* `gitService.js`; separating the file changes
nothing at runtime.

**"Do you open an editor to resolve conflicts?"** Yes — now there's a real **in-browser
side-by-side conflict editor**. When a cherry-pick conflicts, the pick **pauses**, the conflicted
files are parsed into hunks, and each hunk is shown as **ours (release)** vs **theirs (incoming)**.
The developer picks a side per hunk (or "both"), then continues. Fully manual — no auto-suggestion.

**"Can it show all repos?"** Yes — the landing page lists every repo discovered from your **GitLab
group** (REST API) and your **local clones** (folder scan), merged and grouped.

---

## How conflict resolution works

Developers work entirely from the UI. The server keeps a **clone cache** (clones each GitLab
repo once into `CACHE_DIR`, fetches to update) and runs git there — nobody checks out locally.

1. Select subjects, hit **Cherry-pick**. Commits apply oldest→newest onto a safe branch.
2. **Simple `order_of_execution` conflicts merge automatically.** These files use the block format:

   ```
   #PAY-220
   schema/add_iban.sql
   schema/grant_iban.sql
   ```

   When a pick conflicts *only* in `order_of_execution_{release,develop}.info`, Cherry Deck
   block-merges them: the release file's blocks are kept in place, each subject's new file paths
   are appended to its existing block (de-duped), and subjects present only on the incoming side
   are appended as new blocks. The pick continues with no developer interaction — shown as
   "auto-merged" in the result.
3. **Real code conflicts open the side-by-side editor.** The pick pauses; each conflicted file is
   shown hunk-by-hunk as ours (release) vs theirs (incoming). The developer picks a side per hunk
   (or both), then continues. Fully manual, no auto-suggestion.
4. **Push** the branch, then **Raise a merge request** — fills title/target/description/labels and
   creates the MR in GitLab, linking straight to it.


---

## Screenshots

| | Dark | Light |
|---|---|---|
| Repositories | `screenshots/repos-dark.png` | `screenshots/repos-light.png` |
| Subject ledger | `screenshots/ledger-dark.png` | `screenshots/ledger-light.png` |
| **Conflict editor** | `screenshots/conflict-dark.png` | `screenshots/conflict-light.png` |
| Done (SQL lint + push) | `screenshots/done-dark.png` | `screenshots/done-light.png` |

---

## Run it

### Backend (no install needed — zero deps)
```bash
cd server
node server.js              # http://localhost:5173 (serves API + bundled UI)
```

### Configuration — per-developer token (in the UI)

There is **no shared server token**. Each developer enters their own GitLab connection in the app:

1. Click the **gear icon** (top right) → the GitLab connection panel opens.
2. Enter:
   - **GitLab URL** — e.g. `https://gitlab-dogen.group.echonet`
   - **Group path** — e.g. `Wholesale/cib/bp2s/sts` (your projects like `sts-frontend`, `sts-backend` live inside it)
   - **Personal access token** — created in GitLab → Preferences → Access Tokens, scope `api`
3. **Test connection** confirms the token (shows your GitLab username), then **Save**.

The token is stored in that developer's browser (localStorage) and sent with each request as the
`X-GitLab-Token` header — never persisted server-side, never shared. Pushes and merge requests are
attributed to whoever's token is used. Optional server env fallbacks (`GITLAB_BASE_URL`,
`GITLAB_GROUP`, `GITLAB_TOKEN`, `LOCAL_SCAN_ROOTS`, `CACHE_DIR`, `PORT`) still work for local dev.


### Frontend dev (optional)
```bash
cd web && npm install && npm start           # ng serve :4200, proxies /api -> :5173
# rebuild bundled UI:
cd web && npm run build && cp -r dist/cherry-deck/browser/* ../server/public/
```

---

## Architecture

```
cherry-deck/
├── server/                       plain Node, zero deps
│   ├── server.js                 built-in http; routes only
│   └── lib/
│       ├── gitService.js         interactive cherry-pick state machine, push, SQL lint
│       ├── conflictParser.js     parse conflicted files into ours/theirs hunks (tested)
│       ├── repoDiscovery.js      GitLab group API + local scan, merged (tested)
│       ├── sqlLint.js            SQL trailing-slash linter (tested)
│       └── orderResolver.js      optional order-file auto-merge (tested, off by default)
│   └── test/                     node test/<file>.js
│   └── public/                   bundled Angular UI
├── web/                          Angular 20 source (incl. conflict-editor component)
└── screenshots/
```

### API
| Method | Route | Purpose |
|---|---|---|
| GET  | `/api/repos` | all repos (GitLab group ∪ local clones), grouped |
| POST | `/api/connect` | select a repo |
| GET  | `/api/branches?repoKey=` | branches (with protected flag) |
| POST | `/api/fetch` | `git fetch --all --prune` |
| GET  | `/api/commits?repoKey=&source=&target=` | subject-grouped commits |
| POST | `/api/dry-run` | classify each commit clean / conflict (+ files) |
| POST | `/api/cherry-pick/start` | begin; returns `done` or `conflict` + parsed hunks |
| POST | `/api/cherry-pick/resolve` | apply chosen resolutions, continue |
| POST | `/api/cherry-pick/abort` | abort, restore original state |
| POST | `/api/push` | `git push -u origin <branch>` |
| POST | `/api/fix-sql` | append a trailing `/` to a flagged SQL file |

### Safety guarantees
- Source branch is read-only; commits can't be lost.
- Protected targets are never written to; picks go to a new branch created from them.
- New branches use `checkout -b` (fails if name exists) — no force-updates.
- Refuses to run on a dirty tree; clears any stale in-progress cherry-pick before starting.
- Abort restores the original branch, removes the throwaway branch, leaves the tree clean.
- git runs with prompts/editor/pager disabled so it never blocks.

---

## Tested (run `node test/<name>.js`)
- `conflictParser` — splits 2-way and diff3 conflicts into correct ours/theirs hunks; serializes back with no markers.
- `gitService` interactive flow — real conflict pauses, resolves via a chosen side, continues to done; develop + release untouched; abort leaves a clean tree.
- `repoDiscovery` — local clones discovered and resolvable by key.
- `sqlLint`, `orderResolver` — as before.

---

## BNP / locked-down notes
- Fonts load from Google Fonts in `web/src/index.html`; self-host from Artifactory for air-gapped.
- `Fetch`/`Push` run git non-interactively — configure a credential helper or SSH agent.
- GitLab token: prefer a group access token with `api` scope via Vault.
